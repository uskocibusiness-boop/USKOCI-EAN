# USKOČI UX MASTER REV14

Ovaj paket je derivat kompletne REV13 predaje. Ne menja runtime aplikacije.

- `USKOCI_UX_PRODUCT_MASTER_REV14.html` — glavni pregled, pretraga, tokovi i svih 77 ugovora.
- `USKOCI_UX_PRODUCT_MASTER_REV14.md` — isti master za Codex/diff.
- `USKOCI_SURFACE_MAP_REV14.json` — machine-readable konsolidacija screen → surface/merge/role/media/icon.
- `requester_flow.svg`, `worker_flow.svg`, `agreement_state.svg` — dijagrami.

Najvažnija odluka: funkcije se čuvaju, ali 77 tehničkih ugovora se ne prikazuju kao 77 ravnopravnih stranica.
