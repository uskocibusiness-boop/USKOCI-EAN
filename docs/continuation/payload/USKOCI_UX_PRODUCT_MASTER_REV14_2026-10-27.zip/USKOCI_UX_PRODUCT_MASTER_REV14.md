# USKOČI — UX / Product Master REV14
**Status:** konačna projektna osnova za sledeći povezani HTML i implementaciju; nije dokaz da je runtime izmenjen.  
**Izvor:** kompletan `USKOCI_KOMPLETAN_PLAN_I_DIZAJN_REV13_2026-10-27.zip`, uključujući `CODEX_PLAN_RADA.md`, 77 screen contract-a, market/AI/account flow ugovore, ikonice, screenshot audit i source-read dokaze.  
**Referentni source presek:** `a9692e11942609bab9406215c3e407d79589dafa`. REV12 dokaz beleži FULL semantičko čitanje svih 711 mobilnih source fajlova i svih 42 Edge source fajla; SQL/test istorija nije cela ponovo čitana niti je runtime pokrenut.
## 0. Odluka koja vodi ceo proizvod
USKOČI se projektuje od **životnog posla korisnika**, ne od postojećih ruta. Jedan nalog podržava dve operativne namere — **Treba mi neko** i **Želim da uskočim** — ali Dogovor, Poruke, nalog i reputacija ostaju zajednički. Workspace kontekst nije doživotna uloga i ne menja autoritet konkretnih podataka.

Svaki ekran mora odmah da odgovori na pet pitanja: **gde sam, šta sada važi, šta se očekuje od mene, šta mogu da uradim i šta će se dogoditi posle toga.** Ako ekran ne može da odgovori, nije spreman za finalni dizajn.
## 1. Kanonski objekti proizvoda
- **Potreba / zadatak** — ono što naručilac želi da se uradi. Može imati prijave, pitanja, fotografije i više potrebnih ljudi.
- **Prijava / ponuda** — konkretna ponuda izvršioca za jednu potrebu; sadrži cenu/osnovu, broj ljudi, termin i poruku kada su relevantni.
- **Dogovor** — prihvaćena saradnja. Ima svoje važeće uslove; kasnija izmena oglasa ih ne menja.
- **Predlog izmene** — predlog, ne važeći uslov. Postaje važeći tek potvrđenim odgovorom druge strane.
- **Razgovor** — AI razgovor pripada intake/profile poslu; privatna ljudska poruka pripada Dogovoru; javni Q&A pripada zadatku. To su tri različita kanala.
- **Raspored / dostupnost** — potvrđeni termini Dogovora i lična dostupnost izvršioca su različiti slojevi.
- **Profil** — identitet + javna reputacija + radni profil po usluzi; ne koristiti globalni način rada kao zamenu za per-service podatke.
## 2. Informaciona arhitektura i dva workspace-a
### 2.1. Workspace „Treba mi neko“
Donja navigacija: **Početna · Moje potrebe · Dogovori · Poruke**. Naručilac nema obavezan puni kalendar; termin prati kroz Početnu i Dogovor.

### 2.2. Workspace „Želim da uskočim“
Donja navigacija: **Početna · Prilike · Dogovori · Poruke**. Raspored i dostupnost su worker alati dostupni sa Početne/profila i Dogovora.

### 2.3. Promena workspace-a
U headeru Početne prikazati trenutnu nameru kao mali selector: **Treba mi neko ▾** ili **Želim da uskočim ▾**. Bottom sheet nudi samo te dve opcije i kratko objašnjenje. Promena workspace-a ne menja nalog niti dozvole nad već postojećim Dogovorima.
## 3. Dva golden path toka
### 3.1. Naručilac
**Početna → AI opis potrebe → završni pregled → objava → prijave/ponude → ponuda osobe → potvrda izbora → Dogovor → Poruke/Tok/Dokazi → završetak → ocena.**

![Requester flow](requester_flow.svg)

### 3.2. Izvršilac
**Početna → Prilike lista/mapa → detalj zadatka → prijava → pregled prijave → čeka odgovor → Dogovor → Poruke/Raspored → završetak → ocena.**

![Worker flow](worker_flow.svg)
## 4. Dogovor — centralni workspace
Dogovor ne sme biti obična kartica sa cenom. To je zajednički workspace jedne prihvaćene saradnje. Ciljni header: naziv posla, druga osoba/osobe, status i diskretna uloga korisnika u tom Dogovoru. Ispod su četiri sekcije: **Pregled · Poruke · Tok · Dokazi**. „Dokazi“ se prikazuje samo ako tok ili sadržaj imaju smislen dokaz/prilog; prazan tab se ne prikazuje.

### 4.1. Pregled
- „Važi sada“: cena + osnova, broj ljudi/obim, termin ili **Bez termina**, približno/tačno mesto prema dozvoli.
- Pending izmena je zasebna kartica; nikad ne menja prikaz važećih uslova pre prihvatanja.
- Jedna dominantna sledeća radnja izvedena iz backend actionstate-a, ne iz lokalne pretpostavke.
- `…` sadrži Predloži izmenu, Otkaži Dogovor, Prijavi problem, Podrška — samo ono što je dozvoljeno u tom stanju.

### 4.2. Role/action matrica
| Stanje | Naručilac | Izvršilac |
|---|---|---|
| Potvrđen | Vidi važeće uslove; može predložiti dozvoljenu izmenu/problem/otkazivanje. | Vidi iste važeće uslove; može predložiti dozvoljenu izmenu/problem/otkazivanje. |
| Tuđi predlog izmene čeka | **Prihvatite / Odbijte** ako je predlog izvršioca. | **Prihvatite / Odbijte** ako je predlog naručioca. |
| Moj predlog izmene čeka | Čeka odgovor; Povucite samo ako owner dozvoljava. | Čeka odgovor; Povucite samo ako owner dozvoljava. |
| Izvršilac završio | **Potvrdite završetak** ili **Prijavite problem**. | Vidi da se čeka potvrda naručioca; ne može ponovo završavati. |
| Rad u toku / završetak dozvoljen | Ne dobija worker CTA. | **Označite posao završenim** kada actionstate dozvoli. |
| Problem | Vidi shared problem i dozvoljen support/safety nastavak. | Isto, prema svojim dozvolama. |
| Završen | Oceni kada je eligible. | Oceni kada je eligible. |
| Otkazan | Read-only istorija i razlog koji je dozvoljeno prikazati. | Isto. |

![Agreement state](agreement_state.svg)

### 4.3. Šta Dogovor nikada ne radi
- Ne prikazuje telefon kao podrazumevani kanal.
- Ne prepisuje važeće uslove iz kasnije izmene javnog zadatka.
- Ne završava saradnju dok nerešena izmena blokira završetak prema owneru.
- Ne pretvara „primljen problem“ u presudu ili naplatu.
- Ne prikazuje „Predloženo“ kao potvrđeno.
## 5. Cena i broj ljudi — jedna semantika kroz ceo proizvod
Svaki iznos nosi osnovu: **ukupno / po osobi / po satu / privatna ponuda**. `HOURLY` se prikazuje kao npr. **1.200 RSD/sat**, a broj ljudi odvojeno. Dok je poslovna odluka D06 otvorena, UI ne računa izmišljeni ukupan iznos. Poređenje kandidata uvek pokazuje i broj ljudi obuhvaćen ponudom.
## 6. Fotografije i mediji
- **Zadatak:** 1–3 fotografije u intake-u; ako ih nema, ne prikazivati praznu galeriju. Na detalju: horizontalni carousel ili 2+1 grid; tap otvara fullscreen viewer.
- **AI:** plus otvara „Dodajte fotografiju / Fotografишите“; fotografija pripada tom conversation/task kontekstu. Glas je transkript, ne voice message.
- **Privatne poruke:** fotografija i voice message samo kada capability postoji. Upload potvrda nije isto što i slanje poruke.
- **Dokazi Dogovora:** samo ako stvarni flow zahteva/ima priloge; ne izmišljati obaveznu fotografiju za svaki posao.
- **Profil:** avatar sa inicijalima kao fallback; nikada ne koristiti dekorativni bedž kao lažnu verifikaciju.
## 7. Mapa i lokacija
- Prilike imaju **jedan** ekran sa List/Mapa pogledom i zajedničkim query/filter stanjem.
- Pin standard: brand green; hitan: warm orange; izabran: veći pin + halo. Tap pina otvara task preview karticu.
- Nakon pomeranja mape ponuditi **Pretražite ovo područje**; ne osvežavati agresivno dok korisnik pomera mapu.
- Javni detalj koristi približno mesto. Tačna lokacija pripada permissioned Dogovor toku.
- „Mesto Dogovora“ je sheet sa statusom dozvole; fullscreen mapa samo kada korisnik treba da pregleda/potvrdi tačku.
## 8. Raspored
- Pun kalendar je worker-centric: **Mesec · Nedelja · Dan**.
- Potvrđeni Dogovori sa terminom su događaji; tap otvara baš taj Dogovor.
- Dogovori bez termina su u zasebnom bloku **Bez termina** i nikada ne dobijaju izmišljeni datum.
- Dostupnost je drugi sloj; ne sme prepisati prihvaćeni termin Dogovora.
- Requester nema potrebu da održava ličnu dostupnost; njegove obaveze su na Home/Dogovor kontekstu.
## 9. Vizuelni sistem — premium, miran, živ
### 9.1. Površine
- Canvas `#F7F8F5`, surface `#FFFFFF`, ink `#152720`, brand action `#08664F`, accent orange `#EF9237`.
- Kartice: 20–24 px radius, veoma blag border, široka meka senka; ne stavljati senku na svaki red.
- Jedan primarni CTA po trenutku. Sticky CTA samo kada korisnik donosi odluku/šalje komandu.

### 9.2. Tri klase ikona
1. **Hero 2.5D** — samo velike namere i selected empty/success states: Objavite potrebu, Uskočite i zaradite, Dogovor, Poruke, Raspored. Svaki predmet ima svoju karakterističnu boju, ali isti ugao, svetlo i materijal.
2. **Semantičke 2D ikonice** — male činjenice u karticama: lokacija koral, vreme plavo, novac zlatno/oker, ljudi ljubičasto, alat/posao tirkiz, remote indigo, privacy violet/green.
3. **Sistemske utility ikonice** — Nazad, X, `…`, search, filter, send; neutralne, bez 2.5D.

### 9.3. Tipografija i motion
- Naslov ekrana 26–28, section 20–22, body 16, meta 14; veliki naslovi ne smeju pojesti prvi viewport.
- Press ~110 ms; tab ~160 ms; sheet ~280 ms; reduced motion → instant/blagi opacity.
- AI otkriva samo već prihvaćen tekst; istorija se ne animira ponovo; screen reader dobija ceo odgovor jednom.
## 10. Modal / sheet pravila
| Tip | Koristi za | Ne koristi za |
|---|---|---|
| Bottom sheet | workspace switch, filtere, photo source, kratki picker, Q&A composer, participants | dugačak unos ili složenu reviziju |
| Full-height sheet | mapu, candidate preview, completion review, veći contextual flow | običnu informaciju od dve rečenice |
| Full screen | AI intake, task/application/amendment forms, legal document, account closure | kratku potvrdu |
| Alert/dialog | destruktivnu završnu potvrdu kada su posledice već objašnjene | čitav formular |
| Inline banner/card | partial error, unknown outcome, pending amendment, local refresh | globalni modal koji blokira bez potrebe |

## 11. Konsolidacija 77 postojećih ugovora
Ova tabela je ključna odluka: **čuvamo funkciju i owner, ali ne čuvamo svaki route kao ravnopravnu mentalnu destinaciju.**

| ID | Naziv | Ciljna površina | Pripada / spaja se u |
|---|---|---|---|
| `launch` | Pokretanje i obnova | System/infrastructure state | Sistem i pristup |
| `welcome` | Dobro došli | Full screen | Sistem i pristup |
| `login` | Prijavi se | Full screen | Sistem i pristup |
| `signup` | Napravi nalog | Full screen | Sistem i pristup |
| `authConfirm` | Potvrdi kontakt | Full screen | Sistem i pristup |
| `forgot` | Obnova pristupa | Full screen | Sistem i pristup |
| `recovery` | Nova lozinka | Full screen | Sistem i pristup |
| `restricted` | Nalog trenutno nije dostupan | Full screen | Sistem i pristup |
| `deepLink` | Otvaranje dozvoljenog odredišta | System/infrastructure state | Sistem i pristup |
| `home` | Početna | Full screen | Početna i shell |
| `newTaskAI` | Opiši zadatak | Full screen | Treba mi neko — AI objava |
| `aiMedia` | Fotografija ili glas u razgovoru | Composer capability + bottom sheet | newTaskAI / workerAI |
| `conversationPoint` | Potvrdi mesto u razgovoru | Inline prompt + full-screen map sheet | newTaskAI |
| `taskReview` | Pregledaj zadatak | Full screen | Treba mi neko — AI objava |
| `reviewLocation` | Izmeni mesto u pregledu | Full-screen map sheet | taskReview |
| `publicationState` | Zadatak je objavljen | Success state / receipt | taskReview → ownTask |
| `taskPhotos` | Fotografije zadatka | Full-screen gallery/editor | newTaskAI / ownTask |
| `workerAI` | Opiši šta radite | Full screen | Želim da uskočim — radni profil |
| `workerReview` | Pregledaj ponudu | Full screen | Želim da uskočim — radni profil |
| `workerProfile` | Radni profil | Full screen | Želim da uskočim — radni profil |
| `workerLocation` | Područje rada | Full screen | Želim da uskočim — radni profil |
| `workerAvailability` | Dostupnost | Full screen | Želim da uskočim — radni profil |
| `discovery` | Zadaci | Full screen | Prilike i javni zadatak |
| `discoveryFilters` | Pretraga i filteri | Bottom sheet / full-height sheet | discovery |
| `taskDetail` | Detalji zadatka | Full screen | Prilike i javni zadatak |
| `qa` | Pitanja o zadatku | Embedded section + See all screen | taskDetail / ownTask |
| `qaComposer` | Pitanje ili odgovor | Bottom sheet composer | qa |
| `publicProfile` | Profil saradnika | Full screen | Prilike i javni zadatak |
| `apply` | Nova prijava | Full screen | Prijave izvršioca |
| `applyReceipt` | Prijava je poslata | Success state / receipt | apply → applicationDetail |
| `applications` | Moje prijave | Full screen | Prijave izvršioca |
| `applicationDetail` | Tvoja prijava | Full screen | Prijave izvršioca |
| `myNeeds` | Moji zadaci | Full screen | Moje potrebe i izbor ljudi |
| `ownTask` | Moj zadatak | Full screen | Moje potrebe i izbor ljudi |
| `taskLifecycle` | Status zadatka | Action sheet + destructive dialog | ownTask |
| `candidates` | Prijave na zadatak | Full screen | Moje potrebe i izbor ljudi |
| `candidateDetail` | Ponuda osobe | Full-height bottom sheet or screen | candidates |
| `selectReview` | Potvrdi izbor | Full-screen confirmation sheet | candidateDetail |
| `agreements` | Dogovori | Full screen | Dogovor i izvršenje |
| `agreementDetail` | Dogovor | Full screen | Dogovor i izvršenje |
| `completionReview` | Završetak posla | Full-height confirmation sheet | agreementDetail |
| `amendment` | Predloži izmenu | Full-screen subflow | agreementDetail |
| `amendmentReview` | Pregled izmene | Review screen / full-height sheet | amendment |
| `agreementCancel` | Otkaži Dogovor | Destructive full-height sheet + final dialog | agreementDetail |
| `exactLocation` | Mesto Dogovora | Bottom sheet + full-screen map when needed | agreementDetail |
| `rating` | Oceni saradnju | Full screen | Dogovor i izvršenje |
| `messagesInbox` | Poruke | Full screen | Poruke i grupa |
| `chat` | Privatne poruke | Full screen | Poruke i grupa |
| `groupChat` | Grupni razgovor | Full screen | Poruke i grupa |
| `groupParticipants` | Učesnici grupe | Bottom sheet | groupChat |
| `calendar` | Raspored | Full screen | Raspored i istorija |
| `archive` | Arhiva | Full screen | Raspored i istorija |
| `profile` | Profil | Full screen | Profil, nalog i bezbednost |
| `personal` | Lični podaci | Full screen | Profil, nalog i bezbednost |
| `avatar` | Fotografija profila | Photo picker/editor sheet | personal / profile |
| `ratings` | Ocene | Full screen | Profil, nalog i bezbednost |
| `settings` | Podešavanja | Full screen | Profil, nalog i bezbednost |
| `password` | Promeni lozinku | Full screen | Profil, nalog i bezbednost |
| `permissions` | Dozvole uređaja | Contextual education + OS settings | settings |
| `notifications` | Obaveštenja | Full screen | Profil, nalog i bezbednost |
| `notificationPreferences` | Obaveštenja — podešavanja | Full screen | Profil, nalog i bezbednost |
| `privacy` | Privatnost i podaci | Full screen | Profil, nalog i bezbednost |
| `privacyWho` | Ko šta vidi | Informational bottom sheet | privacy |
| `retention` | Rokovi čuvanja | Inline expandable section / detail sheet | privacy |
| `legal` | Pravila i saglasnosti | Full screen | Profil, nalog i bezbednost |
| `legalConsent` | Pregled i prihvatanje dokumenta | Full-screen document | legal |
| `export` | Kopija Tvojih podataka | Full screen | Profil, nalog i bezbednost |
| `closure` | Zatvaranje naloga | Full-screen destructive flow | privacy |
| `blocked` | Blokirane osobe | Full screen | Profil, nalog i bezbednost |
| `safety` | Prijavi ili blokirajte | Full screen | Profil, nalog i bezbednost |
| `help` | Podrška | Full screen | Profil, nalog i bezbednost |
| `supportRequest` | Novi zahtev | Full screen | Profil, nalog i bezbednost |
| `supportDetail` | Zahtev podršci | Full screen | Profil, nalog i bezbednost |
| `supportOperator` | Rad podrške | Internal operator surface | help/supportDetail |
| `about` | O aplikaciji | Full screen | Profil, nalog i bezbednost |
| `aiHistory` | AI razgovori | Full screen | Profil, nalog i bezbednost |
| `aiTranscript` | Sačuvani razgovor | Full screen | Profil, nalog i bezbednost |

## 12. Detaljna specifikacija svakog ugovora/površine
Globalno: UI copy koristi formalno **Vi/Vam/Vas**; istorijski sadržaj korisnika ostaje doslovan. Runtime owner, revizija, account/focus guard i idempotency imaju prednost nad prototipskom demonstracijom.

### 12.1. `launch` — Pokretanje i obnova
**Domena:** Sistem i pristup  
**Postojeća ruta/ulaz:** INTERNAL_ROOT_LAYOUT, INTERNAL_APP_LAYOUT  
**Ciljna UX površina:** System/infrastructure state  
**Konsolidaciona odluka:** Ne prikazivati kao stalnu destinaciju u navigaciji.  
**Cilj korisnika:** Pouzdano obnoviti nalog i dozvoljeno odredište bez praznog ekrana.  
**Publika/kontekst:** Svi korisnici  
**Vizuelni obrazac:** Mirna auth površina; 2.5D samo na welcome hero-u. Jedna dominantna akcija, bez dekorativnih kartica oko formulara.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Cold start, povratak iz background-a, važeći deep-link.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Brend znak malog obima
- Kratka poruka samo kada čekanje traje
- Dozvoljen oporavak ako obnova ne uspe
**Radnje i odredišta:**
- **Nastavi** — uslov: Tek kada je autoritet sesije poznat.
  - Potvrđen rezultat: Automatski otvoriti dozvoljen cilj.
**Sekundarne radnje:**
- Pokušaj ponovo pri prolaznoj grešci
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nema sesije: otvoriti auth, bez lažne greške.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Obnavljamo stanje naloga. Bez prikaza privatnih kartica prethodnog naloga.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Ne resetovati legitimni aktivni tok radi splash animacije; accountId/accountRevision menjaju navigator.  
**Runtime owner porodica:** SHELL  
**Relevantni source ulazi:** `src/app/_layout.tsx`, `src/app/(app)/_layout.tsx`, `src/app/(app)/index.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Tabovi se otvaraju čim je shell spreman; opcioni home podaci ih ne blokiraju.

### 12.2. `welcome` — Dobro došli
**Domena:** Sistem i pristup  
**Postojeća ruta/ulaz:** /auth  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Objasniti dve namere na istom nalogu i započeti podržan put prijave.  
**Publika/kontekst:** Neprijavljen korisnik  
**Vizuelni obrazac:** Mirna auth površina; 2.5D samo na welcome hero-u. Jedna dominantna akcija, bez dekorativnih kartica oko formulara.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Cold start bez sesije, odjava ili zaštićen cilj sa očuvanom povratnom namerom.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Logo i kratak naslov
- Objavi zadatak i Uskoči i zaradi kao dva neposredna ulaza
- Već imaš nalog? Prijavi se
- Pravni linkovi prema stvarnoj dostupnosti
**Radnje i odredišta:**
- **Objavi zadatak / Uskoči i zaradi** — uslov: Izbor priprema REQUESTER ili WORKER entry intent; ne menja trajnu ulogu naloga.
  - Potvrđen rezultat: Odabrana namera otvara isti auth tok. Posle potvrđenog auth-a odgovarajući entry owner vodi ka /nova ili /zadaci, uz dozvoljeni povratni kontekst.
**Sekundarne radnje:**
- Već imaš nalog? Prijavi se
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Nije relevantno za javni uvod; pravni linkovi ipak poštuju svoju dostupnost.
**Povratak i očuvanje:** Namera preživljava auth; Back vraća smislen ulaz. Postojeći aktivni tok/deep link ne resetovati radi brend animacije.  
**Runtime owner porodica:** AUTH  
**Relevantni source ulazi:** `src/app/auth.tsx`, `src/app/oporavak.tsx`, `src/hooks/useAuthFormCommand.ts`, `src/data/authClientService.ts`, `src/hooks/useAuthAvailability.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Nema globalnog requester/worker switch-a ili duplih naloga.

### 12.3. `login` — Prijavi se
**Domena:** Sistem i pristup  
**Postojeća ruta/ulaz:** /auth  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Ući u pravi nalog i nastaviti prethodnu dozvoljenu nameru.  
**Publika/kontekst:** Neprijavljen korisnik  
**Vizuelni obrazac:** Mirna auth površina; 2.5D samo na welcome hero-u. Jedna dominantna akcija, bez dekorativnih kartica oko formulara.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Welcome, istekao session ili zaštićen deep-link.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov
- Izabrana namera i Promeni kada postoje
- Email i lozinka
- Inline validacija
- Prijavi se
- Zaboravljena lozinka i Napravi nalog
- Dodatne metode samo kada potvrđeno dostupne
**Radnje i odredišta:**
- **Prijavi se** — uslov: Validna polja i bez aktivne komande.
  - Potvrđen rezultat: authClientService.signInWithPassword; tek potvrđen session otvara cilj.
**Sekundarne radnje:**
- Prikaži/sakrij lozinku
- Zaboravili si lozinku?
- Napravi nalog
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Jasna inline poruka bez otkrivanja tuđih naloga; fokus prvo pogrešno polje.
- **unknown:** Jedan auth pokušaj, bez duplog slanja dok status nije razrešen.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Lozinku lokalno očistiti po owner ugovoru; povratni cilj nije proizvoljan URL.  
**Runtime owner porodica:** AUTH  
**Relevantni source ulazi:** `src/app/auth.tsx`, `src/app/oporavak.tsx`, `src/hooks/useAuthFormCommand.ts`, `src/data/authClientService.ts`, `src/hooks/useAuthAvailability.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Email forma radi nezavisno od kašnjenja opcione phone availability provere.

### 12.4. `signup` — Napravi nalog
**Domena:** Sistem i pristup  
**Postojeća ruta/ulaz:** /auth  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Kreirati jedan nalog i nastaviti izabranu nameru uz stvarno potrebnu potvrdu kontakta. Trenutni auth handler nema acceptance gate za pravni bundle.  
**Publika/kontekst:** Novi korisnik  
**Vizuelni obrazac:** Mirna auth površina; 2.5D samo na welcome hero-u. Jedna dominantna akcija, bez dekorativnih kartica oko formulara.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Welcome/login.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov i izabrana namera sa Promeni
- Ime, prezime, grad, email
- Lozinka: najmanje 6 znakova za novi nalog
- Pravni linkovi/status prema potvrđenom stanju; bez lažnog checkbox-a
- Napravi nalog
- Već imaš nalog? Prijavi se
**Radnje i odredišta:**
- **Napravi nalog** — uslov: Validna stvarna obavezna polja, dostupna signup metoda i nema komande u toku. UNPUBLISHED pravni bundle nije postojeći signup guard.
  - Potvrđen rezultat: authClientService.signUp; pokazati stvarni sledeći korak. Eventualni budući legal acceptance gate zahteva zasebno definisanu orchestration promenu i receipt, a ne dekorativno označeno polje.
**Sekundarne radnje:**
- Prijavi se
- Otvori važeće dokumente
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pored odgovarajućeg polja; uneti bezbedni podaci ostaju.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Ne prikazati završen nalog ako je potrebna email/OTP potvrda; tokeni ostaju van route-a.  
**Runtime owner porodica:** AUTH  
**Relevantni source ulazi:** `src/app/auth.tsx`, `src/app/oporavak.tsx`, `src/hooks/useAuthFormCommand.ts`, `src/data/authClientService.ts`, `src/hooks/useAuthAvailability.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Ne dodavati obavezni onboarding o veštinama/radnom modu da bi se samo napravio nalog.

### 12.5. `authConfirm` — Potvrdi kontakt
**Domena:** Sistem i pristup  
**Postojeća ruta/ulaz:** /auth  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Dovršiti stvarno zahtevanu potvrdu kontakta.  
**Publika/kontekst:** Neregistrovan ili nepotvrđen nalog  
**Vizuelni obrazac:** Mirna auth površina; 2.5D samo na welcome hero-u. Jedna dominantna akcija, bez dekorativnih kartica oko formulara.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Odgovor registracije ili serverom dostupni phoneOTP.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov sa bezbedno prikazanim ciljem
- Uputstvo prema stvarnoj metodi
- OTP polje samo za OTP granu
- Primarna potvrda
- Ponovno slanje uz stvarni cooldown
**Radnje i odredišta:**
- **Potvrdi** — uslov: Metoda dostupna, validan kod i aktivan challenge.
  - Potvrđen rezultat: verifyPhoneOtp ili potvrda linka kroz postojeći owner.
**Sekundarne radnje:**
- Pošalji ponovo
- Promeni kontakt ako owner dozvoljava
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Email grana: Proveri svoju email adresu. Nema lažnog OTP polja.
- **error:** Kod nije važeći ili je istekao, prema server odgovoru.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Phone metoda trenutno nije dostupna: ponuđena email alternativa.
**Povratak i očuvanje:** Sačuvati nameru, ne token; expired challenge traži novi dozvoljeni izazov.  
**Runtime owner porodica:** AUTH  
**Relevantni source ulazi:** `src/app/auth.tsx`, `src/app/oporavak.tsx`, `src/hooks/useAuthFormCommand.ts`, `src/data/authClientService.ts`, `src/hooks/useAuthAvailability.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.

### 12.6. `forgot` — Obnova pristupa
**Domena:** Sistem i pristup  
**Postojeća ruta/ulaz:** /auth  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Zatražiti podržan oporavak lozinke.  
**Publika/kontekst:** Korisnik bez pristupa  
**Vizuelni obrazac:** Mirna auth površina; 2.5D samo na welcome hero-u. Jedna dominantna akcija, bez dekorativnih kartica oko formulara.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Login.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov
- Email polje
- Kratko uputstvo
- Pošalji link
- Nazad na prijavu
**Radnje i odredišta:**
- **Pošalji link** — uslov: Validan unos i nema aktivnog slanja.
  - Potvrđen rezultat: requestPasswordRecovery, zatim jasan potvrđeni naredni korak.
**Sekundarne radnje:**
- Nazad na prijavu
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nije posebno prazno stanje: prazan unos je forma.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Proveriti postojeći pokušaj prema auth owneru; bez agresivnog ponavljanja.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Ne otkrivati postojanje tuđeg naloga; poštovati server odgovor i ograničenja ponavljanja.  
**Runtime owner porodica:** AUTH  
**Relevantni source ulazi:** `src/app/auth.tsx`, `src/app/oporavak.tsx`, `src/hooks/useAuthFormCommand.ts`, `src/data/authClientService.ts`, `src/hooks/useAuthAvailability.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.

### 12.7. `recovery` — Nova lozinka
**Domena:** Sistem i pristup  
**Postojeća ruta/ulaz:** /oporavak  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Postaviti novu lozinku samo uz važeći recovery kontekst.  
**Publika/kontekst:** Vlasnik naloga sa odgovarajućim linkom  
**Vizuelni obrazac:** Mirna auth površina; 2.5D samo na welcome hero-u. Jedna dominantna akcija, bez dekorativnih kartica oko formulara.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Native/URL recovery entry očišćen od tajni.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Verifikacija linka
- Nova lozinka i dozvoljena potvrda
- Sačuvaj lozinku
- Uspeh i nastavak prijave
**Radnje i odredišta:**
- **Sačuvaj lozinku** — uslov: Recovery session potvrđen; važeća pravila lozinke.
  - Potvrđen rezultat: Postojeći usePasswordRecovery owner; uspeh samo potvrđenim ishodom.
**Sekundarne radnje:**
- Zatraži novi link u expired stanju
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Link nije važeći ili je istekao. Zatraži novi link.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Bez važećeg recovery konteksta nema promene lozinke.
**Povratak i očuvanje:** Povratak ne prenosi recovery token u app navigaciju; unos lozinke se ne čuva u običan draft.  
**Runtime owner porodica:** AUTH  
**Relevantni source ulazi:** `src/app/auth.tsx`, `src/app/oporavak.tsx`, `src/hooks/useAuthFormCommand.ts`, `src/data/authClientService.ts`, `src/hooks/useAuthAvailability.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.

### 12.8. `restricted` — Nalog trenutno nije dostupan
**Domena:** Sistem i pristup  
**Postojeća ruta/ulaz:** /auth  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Objasniti konkretno ograničenje naloga i dozvoljen sledeći korak.  
**Publika/kontekst:** Ograničen/zatvarajući nalog  
**Vizuelni obrazac:** Mirna auth površina; 2.5D samo na welcome hero-u. Jedna dominantna akcija, bez dekorativnih kartica oko formulara.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Auth autoritet ili session promena.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Kratak status
- Potvrđen razlog bez tuđih detalja
- Dozvoljena pomoć/povratak
- Odjava ako dostupna
**Radnje i odredišta:**
- **Prikaži dostupne korake** — uslov: Iz serverom dozvoljenih mogućnosti.
  - Potvrđen rezultat: Podrška, closure stanje ili auth, prema stvarnom razlogu.
**Sekundarne radnje:**
- Odjavi se kada dozvoljeno
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Sam ovaj frame je dozvoljen minimalni prikaz bez privatnog sadržaja.
**Povratak i očuvanje:** Ne nastaviti stari editor pod nalogom koji je izgubio pravo.  
**Runtime owner porodica:** AUTH  
**Relevantni source ulazi:** `src/app/auth.tsx`, `src/app/oporavak.tsx`, `src/hooks/useAuthFormCommand.ts`, `src/data/authClientService.ts`, `src/hooks/useAuthAvailability.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.

### 12.9. `home` — Početna
**Domena:** Početna i shell  
**Postojeća ruta/ulaz:** /  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Prvo pokazati najbližu obavezu i radnje koje čekaju korisnika, zatim dve namere i stvarne nastavke.  
**Publika/kontekst:** Isti nalog sa različitim odnosima prema zadacima  
**Pravilo uloge:** Workspace je privremen kontekst, ne doživotna uloga. „Treba mi neko“ i „Želim da uskočim“ menjaju prioritete Početne i značenje drugog taba, dok Dogovori/Poruke ostaju zajednički.  
**Vizuelni obrazac:** Airbnb-like mirna podloga; dve hero kartice sa 2.5D objektima; ispod samo dinamično „Važno sada“ i najbliži nastavak.  
**Ikone:** home neutral line / hero publish + earn 2.5D  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Tab Početna ili uspešan auth bez posebne namere.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Kompaktan brend/header, obaveštenja i avatar
- Sledeći prihvaćeni termin kada postoji
- Čeka te: precizan predmet i sledeća radnja
- Objavi zadatak / Uskoči i zaradi
- Nastavljiv AI razgovor ili stvarno sačuvan nacrt, jasno razdvojeni
- Sažeti sopstveni zadaci i prijave sa Sve izlazima
- Relevantne prilike
- Četiri stalne destinacije: Početna / Zadaci / Dogovori / Poruke
**Radnje i odredišta:**
- **Otvori najbliži Dogovor / reši konkretnu stavku Čeka te; u praznom stanju Objavi zadatak / Uskoči i zaradi** — uslov: Samo potvrđeni predmet, account kontekst i dozvoljena radnja; opcioni reader ne blokira shell.
  - Potvrđen rezultat: Dogovor→/dogovor/[id]; prijava→njen receipt/Dogovor; zadatak iz radničke prijave→/prilike/[id]; sopstveni zadatak→/potrebe/[id]/pregled; nova namera→/nova ili /zadaci.
**Sekundarne radnje:**
- Sve prijave
- Moji zadaci
- Raspored uz sledeći Dogovor
- Nastavi razgovor samo ako sesija postoji
- Profil
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Dve ravnopravne namere na vrhu, zatim kratak ulaz u pripremu radnog profila. Nema izmišljenog Dogovora, nastavka ili draft-a.
- **error:** Pogođena kartica ima Pokušaj ponovo; shell ostaje upotrebljiv.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Raniji potvrđeni sažetak čitljiv, ali komande proveravaju važeći kontekst.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Root tabovi ne prave Back lanac. Detail povratak čuva Home scroll. Sesija AI razgovora nije persisted draft. Aktivne prijave ne izvoditi iz ALL limit:1 pre active filter-a.  
**Runtime owner porodica:** SHELL  
**Relevantni source ulazi:** `src/app/_layout.tsx`, `src/app/(app)/_layout.tsx`, `src/app/(app)/index.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Sva četiri root taba ostaju zajednička; profile avatar nije peti konkurentski tab.

### 12.10. `newTaskAI` — Opiši zadatak
**Domena:** Treba mi neko — AI objava  
**Postojeća ruta/ulaz:** /nova  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Prirodnim razgovorom prikupiti tačne činjenice za jedan potpun završni pregled.  
**Publika/kontekst:** Naručilac konkretnog zadatka  
**Vizuelni obrazac:** Chat je sadržaj, ne dekoracija. Kratak uvod, jedna sledeća AI potreba, media/location inline, završni pregled kao floating review card.  
**Ikone:** AI assistant + add/photo/mic utility  
**Mediji:** Fotografije zadatka: 1–3 u intake-u; prikazati samo ako postoje. Tap → fullscreen viewer. Upload/staging/unknown vezani za isti resurs.  
**Ulaz i guard:**
- **Dolazi iz:** Početna, Moji zadaci, AI istorija ili važeća izmena.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Kompaktan header sa povratkom i istorijom
- Čitljiva konverzacija bez parcijalnih poslovnih kartica
- Jedna stvarno potrebna naredna dopuna
- Composer: tekst, nezavisan glasovni unos i fotografije zadatka
- Tih ulaz u završni pregled prema važećem owner stanju; bez broja poruka ili procenta
**Radnje i odredišta:**
- **Pošalji**
  - Nazad: Abort prekida lokalno čekanje; journal ostaje
- **Pregledaj zadatak**
  - Nazad: Vraća istu instancu razgovora gde je moguće
- **Proveri poruku**
  - Nazad: Može napustiti ekran bez tvrdnje da je server otkazan
- **Novi razgovor**
  - Nazad: Ako OPEN/unknown ostaje stari razgovor
**Sekundarne radnje:**
- Dodaj fotografiju
- Glas kada podržan
- Otvori završni pregled kada dozvoljen
**Destruktivne radnje:**
- Odbacite neposlat unos samo uz potvrdu kad bi se izgubio rad
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Šta želiš da neko uradi za Tebe? Jedno jasno polje za odgovor.
- **error:** Sačuvati unos/medija kontekst u granicama ownera; ponuditi tačan oporavak.
- **unknown:** Proveravamo prethodnu poruku; isti turn intent, bez duplog AI poziva.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Povratak obnavlja prihvaćene poruke i autoritativni predlog iste konverzacije. Neposlati tekst ostaje samo u živom RAM stanju te instance ako nije drugačije dokazano; Back nije poslovno Sačuvaj. Abort prekida lokalno čekanje, ne dokazuje rollback server turn-a. Oporavak čita isti key; već sačuvan rezultat ne pokreće novi model.  
**Runtime owner porodica:** REQUESTER_AI  
**Relevantni source ulazi:** `src/app/(app)/nova.tsx`, `src/data/aiNeedV2Production.ts`, `src/ui/v2/IntakePresentation.tsx`, `supabase/functions/uskoci-ai-interview/index.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Najviše jedno zaista potrebno pitanje; jasno već navedene činjenice se ne pitaju ponovo.
- Classification ostaje interno; korisnik ne bira tehničku kategoriju kao oporavak.

### 12.11. `aiMedia` — Fotografija ili glas u razgovoru
**Domena:** Treba mi neko — AI objava  
**Postojeća ruta/ulaz:** /nova, /profil/razgovor  
**Ciljna UX površina:** Composer capability + bottom sheet → **newTaskAI / workerAI**  
**Konsolidaciona odluka:** Fotografija/glas pripadaju aktivnom AI razgovoru; nema zasebne mentalne destinacije.  
**Cilj korisnika:** Omogućiti glasovni unos u oba AI razgovora prema nezavisnim izborima gesta i slanja; fotografije su zaseban task-media tok samo za zadatak.  
**Publika/kontekst:** Vlasnik aktivne AI konverzacije  
**Vizuelni obrazac:** Chat je sadržaj, ne dekoracija. Kratak uvod, jedna sledeća AI potreba, media/location inline, završni pregled kao floating review card.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Composer prilog/mikrofon.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Kontekst: mikrofon u oba AI razgovora; fotografije samo u zadatku
- Gest: drži/pusti ili početak/kraj dodirom
- Slanje: automatski po završetku ili dodavanje transkripta u neposlati tekst
- Čitač ekrana nameće tap i pregled teksta
- Za fotografije: izbor, pregled, upload/obrada i isti task-media ishod
- Otkazivanje i oporavak prema konkretnom vlasniku
**Radnje i odredišta:**
- **Počni / završi govor**
  - Nazad: Blur/background cancel zadržava granicu i ne tvrdi server rollback
- **Otkaži snimanje**
  - Nazad: Drag cancel ili eksplicitno, identičan rezultat
**Sekundarne radnje:**
- Otkaži snimanje
- Nastavi pisanjem
- Izaberi drugu fotografiju samo u task-media grani
**Destruktivne radnje:**
- Otkaži staged prilog uz njegov server cancel/reconcile
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška konkretnog priloga ne briše celu konverzaciju.
- **unknown:** Proveriti staged/processing/absent po stvarnom command owneru; ABSENT posle pokušaja nije automatski čist reset.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Objasniti svrhu dozvole; dozvoljen tekstualni unos ostaje.
**Povratak i očuvanje:** Auto slanje govora čuva prethodni typed draft. Review transkript dopunjuje draft koji se ne predstavlja kao potvrđena poruka. Gubitak RAM bajtova fotografije nije potvrda čuvanja ili otkazivanja. Journal sa koordinatama zahteva ostaje odvojen; najpre čitati isti ishod.  
**Runtime owner porodica:** REQUESTER_AI + WORKER_AI + TASK_MEDIA (kontekstualno, nisu spojeni writers)  
**Relevantni source ulazi:** `src/app/(app)/nova.tsx`, `src/data/aiNeedV2Production.ts`, `src/ui/v2/IntakePresentation.tsx`, `supabase/functions/uskoci-ai-interview/index.ts`, `src/app/(app)/profil/razgovor.tsx`, `src/data/workerAiClientService.ts`, `src/ui/workerProfile/WorkerAiPresentation.tsx`, `supabase/functions/uskoci-worker-interview/index.ts` …  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Voice dostupnost je platform/build proverena; ne obećavati iOS parity iz Android mock-a.

### 12.12. `conversationPoint` — Potvrdi mesto u razgovoru
**Domena:** Treba mi neko — AI objava  
**Postojeća ruta/ulaz:** /nova  
**Ciljna UX površina:** Inline prompt + full-screen map sheet → **newTaskAI**  
**Konsolidaciona odluka:** Potvrda mesta je deo razgovora; mapa se otvara samo kada je potrebna tačka.  
**Cilj korisnika:** Precizirati lokaciju kada je stvarno potrebna u razgovoru.  
**Publika/kontekst:** Naručilac čiji mode/lokacijski ugovor zahteva point  
**Vizuelni obrazac:** Chat je sadržaj, ne dekoracija. Kratak uvod, jedna sledeća AI potreba, media/location inline, završni pregled kao floating review card.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** ConversationPointAsk.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Kratko konkretno pitanje
- Pretraga mesta
- Mapa/pin uz dostupnu tekstualnu alternativu
- Sažetak izabranog mesta
- Potvrdi mesto
**Radnje i odredišta:**
- **Potvrdi mesto**
  - Nazad: Close odbacuje samo nepotvrđen lokalni izbor
- **Kasnije**
  - Nazad: Pregled kasnije pokazuje blokadu objave
**Sekundarne radnje:**
- Promeni mesto
- Vrati se razgovoru
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Ista point komanda zahteva readback; ne dodavati drugu tačku.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** GPS nije obavezan: ručna pretraga/pin ostaju ako ugovor dopušta.
**Povratak i očuvanje:** Potvrđeno mesto jeste sačuvano; povratak to ne naziva samo lokalnim izborom. Ne mešati sa NeedLocationForm.  
**Runtime owner porodica:** REQUESTER_AI  
**Relevantni source ulazi:** `src/app/(app)/nova.tsx`, `src/data/aiNeedV2Production.ts`, `src/ui/v2/IntakePresentation.tsx`, `supabase/functions/uskoci-ai-interview/index.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- REMOTE bez potrebe za radnim pinom ne dobija ovaj obavezni korak.
- Native drag, camera/insets i reduced-motion provereni zasebno.

### 12.13. `taskReview` — Pregledaj zadatak
**Domena:** Treba mi neko — AI objava  
**Postojeća ruta/ulaz:** /pregled-zadatka  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Prikazati jednu celinu koju korisnik jasno potvrđuje, čuva ili objavljuje.  
**Publika/kontekst:** Naručilac aktivne konverzacije/revizije  
**Vizuelni obrazac:** Chat je sadržaj, ne dekoracija. Kratak uvod, jedna sledeća AI potreba, media/location inline, završni pregled kao floating review card.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Fotografije zadatka: 1–3 u intake-u; prikazati samo ako postoje. Tap → fullscreen viewer. Upload/staging/unknown vezani za isti resurs.  
**Ulaz i guard:**
- **Dolazi iz:** AI review-ready, postojeći nacrt ili serverom dozvoljena izmena.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov i status nacrta/izmene
- Opis i stvarne fotografije
- Usluga/mode i potrebni detalji
- Cena sa valutom i osnovom
- Termin i mesto/predaja kada relevantni
- Izmeni ciljanu činjenicu
- Jedna primarna objava; Sačuvaj nacrt kao zaseban nastavak
**Radnje i odredišta:**
- **Objavi zadatak**
  - Nazad: Unknown ostaje recovery iste komande; ne otvara generički publish
- **Sačuvaj nacrt**
  - Nazad: Kasnija korekcija otvara owned edit conversation
- **Izmeni kroz razgovor**
  - Nazad: Review→chat čuva RAM draft i već poznate činjenice
- **Proveri ishod**
  - Nazad: Ne šalje drugi provider turn
**Sekundarne radnje:**
- Sačuvaj nacrt
- Izmeni konkretan podatak
- Nazad na razgovor
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nema važećeg pregleda: vratiti u tačan razgovor, ne prazan generički ekran.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Proveravamo objavu/nacrt po istom command ID-ju; bez drugog Publish-a.
- **stale:** Pregled je promenjen. Ponovo pregledaj važeće podatke; stari digest ne potvrđuje novi tekst.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** SaveDraft i Publish koriste validan pregled, ali različitu nastavnu putanju; nacrt nije obavezan međukorak direktne objave.  
**Runtime owner porodica:** TASK_REVIEW  
**Relevantni source ulazi:** `src/app/(app)/pregled-zadatka.tsx`, `src/data/aiTaskReviewClientService.ts`, `src/data/locationClientService.ts`, `src/data/aiNeedV2Production.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Pending klasifikacija nije automatska univerzalna zabrana; uski stvarni gate ostaje.
- Public edit samo kroz server replacement contract: stara objava/prijave zatvaraju se tek po uspehu nove; prijave se ne prenose.

### 12.14. `reviewLocation` — Izmeni mesto u pregledu
**Domena:** Treba mi neko — AI objava  
**Postojeća ruta/ulaz:** /pregled-zadatka  
**Ciljna UX površina:** Full-screen map sheet → **taskReview**  
**Konsolidaciona odluka:** Lokalna izmena mesta u frozen pregledu; Primeni vraća u isti pregled.  
**Cilj korisnika:** Lokalno promeniti mesto i pripremiti nov validan pregled.  
**Publika/kontekst:** Naručilac u završnom pregledu  
**Vizuelni obrazac:** Chat je sadržaj, ne dekoracija. Kratak uvod, jedna sledeća AI potreba, media/location inline, završni pregled kao floating review card.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** NeedLocationForm iz konkretnog fact row-a.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov mesta
- Postojeća mesta i izbor
- Mapa/pretraga
- Jasna lokalna promena
- Primeni izmene
**Radnje i odredišta:**
- **Primeni potvrđene tačke**
  - Nazad: Back/Cancel pre Apply odbacuje lokalne izmene
- **Promeni grad/adresni opis**
  - Nazad: Vraća na novi review posle potvrđene izmene
**Sekundarne radnje:**
- Otkaži izmene
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Apply/newreview proveriti kod istog ownera; ne preuzimati immediate-save semantiku ConversationPointAsk.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Back/cancel vraća prethodni potvrđeni pregled; ne tvrditi da je lokacija sačuvana pre apply/newreview.  
**Runtime owner porodica:** TASK_REVIEW  
**Relevantni source ulazi:** `src/app/(app)/pregled-zadatka.tsx`, `src/data/aiTaskReviewClientService.ts`, `src/data/locationClientService.ts`, `src/data/aiNeedV2Production.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Vizuelna mapa može biti ista komponenta kao u razgovoru; writer, CTA i persistence značenje ostaju različiti.

### 12.15. `publicationState` — Zadatak je objavljen
**Domena:** Treba mi neko — AI objava  
**Postojeća ruta/ulaz:** /pregled-zadatka, /potrebe/[id]/pregled  
**Ciljna UX površina:** Success state / receipt → **taskReview → ownTask**  
**Konsolidaciona odluka:** Ne praviti praznu zasebnu stranicu; uspeh vodi na objavljeni zadatak. U navigaciji nema sopstvenu stavku.  
**Cilj korisnika:** Potvrditi samo stvarno uspešnu objavu i pokazati sledeći korisni korak.  
**Publika/kontekst:** Naručilac objavljenog zadatka  
**Vizuelni obrazac:** Chat je sadržaj, ne dekoracija. Kratak uvod, jedna sledeća AI potreba, media/location inline, završni pregled kao floating review card.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Publication receipt i odgovarajući javni readback.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Mirna potvrda
- Kratak stvarni sažetak
- Otvori zadatak
- Šta sledi: prijave i obaveštenja prema stvarnoj dostupnosti
**Radnje i odredišta:**
- **Otvori zadatak**
  - Nazad: Back takođe vodi tamo, ne na stari editable review
**Sekundarne radnje:**
- Moji zadaci
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Ako readback nije potvrđen, nastaviti proveru istog ishoda.
- **unknown:** Još proveravamo objavu; nema naslova Zadatak je objavljen.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Povratak ne ponavlja Publish; stari uspeh se prikazuje bez nove proslave.  
**Runtime owner porodica:** TASK_REVIEW  
**Relevantni source ulazi:** `src/app/(app)/pregled-zadatka.tsx`, `src/data/aiTaskReviewClientService.ts`, `src/data/locationClientService.ts`, `src/data/aiNeedV2Production.ts`, `src/app/(app)/potrebe/[id]/pregled.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Sačuvan privatni nacrt nikada ne koristi ovaj objavljeni success frame.

### 12.16. `workerAI` — Opiši šta radite
**Domena:** Želim da uskočim — radni profil  
**Postojeća ruta/ulaz:** /profil/razgovor  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Prirodno sastaviti ili izmeniti radnu ponudu bez tehničkog upitnika.  
**Publika/kontekst:** Vlasnik radnog profila  
**Vizuelni obrazac:** Profil po usluzi; jasne kartice usluga sa načinom rada/područjem/dostupnošću. AI samo za uređivanje, ne za čitanje profila.  
**Ikone:** AI assistant + service/work utility  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Početna, radni profil, tema područja/vremena, AI istorija.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Header sa konkretnom temom i istorijom
- Prihvaćene poruke bez parcijalnih profilnih kartica
- Jedna potrebna dopuna
- Composer za tekst i nezavisan glasovni unos
- Plus: Usluge, Područje rada, Raspored i dostupnost
- Tih ulaz u jedan završni pregled prema stvarnom guard-u
**Radnje i odredišta:**
- **Pošalji**
  - Nazad: Abort samo lokalni; read/recover pre narednog
- **Izaberi temu**
  - Nazad: Dismiss vraća slobodan unos
- **Pregledaj profil**
  - Nazad: Back vraća isti chat
- **Napustite / Novi razgovor**
  - Nazad: Ako ishod nepoznat zadržava prethodni
**Sekundarne radnje:**
- Izaberi temu: Usluge, Područje rada, Raspored i dostupnost
- Glasovni unos prema gestu i izabranom slanju
- Pregledaj radni profil
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Opiši kojim poslovima se baviš i gde želiš da radite.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Isti turn intent i bounded recovery; bez ponovnog modela za već sačuvan rezultat.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Promena teme nastavlja istu važeću konverzaciju i čuva potvrđene činjenice drugih tema. Neposlati tekst nije deo potpisanog pregleda niti automatski sačuvan na serveru. Back iz pregleda vraća razgovor; poslovni profil se menja tek prihvaćenom Save komandom i tačnim readback-om. Posle završenog razgovora novo uređivanje otvara novi važeći razgovor nad sačuvanim profilom.  
**Runtime owner porodica:** WORKER_AI  
**Relevantni source ulazi:** `src/app/(app)/profil/razgovor.tsx`, `src/data/workerAiClientService.ts`, `src/ui/workerProfile/WorkerAiPresentation.tsx`, `supabase/functions/uskoci-worker-interview/index.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- REMOTE pokriva i radionicu/provajdera/predaju; BOTH je kompletan očekivani skup istog service ID-ja.
- Ne vraćati obavezne bio/oprema/tim/vozilo/licenca formulare ako nisu potrebni konkretnom toku.

### 12.17. `workerReview` — Pregledaj ponudu
**Domena:** Želim da uskočim — radni profil  
**Postojeća ruta/ulaz:** /profil/razgovor  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Omogućiti potpun pregled i jasno čuvanje/aktivaciju ponude.  
**Publika/kontekst:** Vlasnik radnog profila  
**Vizuelni obrazac:** Profil po usluzi; jasne kartice usluga sa načinom rada/područjem/dostupnošću. AI samo za uređivanje, ne za čitanje profila.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Worker AI review-ready ili nastavak važećeg pregleda.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Ime i sažetak iz zamrznutog pregleda
- Svaka usluga: isti serviceId, očekivani ON_SITE/REMOTE ili BOTH i odgovarajuća predaja
- Područja za dolazak, odvojeno od digitalne ili fizičke predaje
- Dostupnost i stvarna pravila nedelje/izuzetaka
- Poseban status svake usluge i načina rada
- Samo DRAFT: izbor Sačuvan nacrt ili Aktivan profil priprema novi potpisani pregled
- Jedna radnja: Sačuvaj profil / Sačuvaj i aktiviraj profil; ACTIVE: Sačuvaj izmene
**Radnje i odredišta:**
- **Izaberi aktivaciju**
  - Nazad: Posle korekcije čuva poslednji eksplicitni izbor
- **Sačuvaj / Sačuvaj i aktiviraj**
  - Nazad: Busy review ne prelazi u chat dok owner write traje
- **Izmeni**
  - Nazad: Neposlat tekst ostaje; nije uključen u review
- **Učitaj novi pregled**
  - Nazad: Nema ponovnog traženja svih korisničkih činjenica
**Sekundarne radnje:**
- Izmeni konkretnu činjenicu
- Nazad u razgovor
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Isti signed Save/command proveriti readback-om; bez dvostrukog upisa.
- **stale:** Obnovite pregled jer su podaci/izbor aktivacije promenjeni.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Promena activate izbora traži novi važeći review; activate=false ne deaktivira već ACTIVE profil.  
**Runtime owner porodica:** WORKER_AI  
**Relevantni source ulazi:** `src/app/(app)/profil/razgovor.tsx`, `src/data/workerAiClientService.ts`, `src/ui/workerProfile/WorkerAiPresentation.tsx`, `supabase/functions/uskoci-worker-interview/index.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- DRAFT ima obe mogućnosti na istom ekranu, bez naknadnog drugog activation wizard-a.
- ACTIVE ne znači da je svaka nova usluga match-ready; pending pojedinačne usluge vidljivo odvojiti.

### 12.18. `discovery` — Zadaci
**Domena:** Prilike i javni zadatak  
**Postojeća ruta/ulaz:** /zadaci  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pronađi odgovarajući zadatak i vrati se na isto mesto posle detalja.  
**Publika/kontekst:** Prijavljen nalog; odnos prema svakom zadatku se čita zasebno  
**Vizuelni obrazac:** Lista/mapa istog stanja. Kartice skeniraju naslov, osnovu cene, vreme, približno mesto i ljude; detalj otkriva celu priču.  
**Ikone:** search + map/list + filter  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Tab Zadaci; Početna Uskoči i zaradi; kompatibilni /prilike ili /mapa.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Vidljiv header, unos Pretraži zadatke i Filteri
- Mesto/način rada i aktivni izbori; Za mene samo uz važeći profil
- Mapa ili Lista istog ownera; broj iz potvrđenog server scope-a
- Kartica: naslov, iznos/osnova, vreme, približno mesto/remote, potreban broj ljudi, relevantan uslov
- Stalna glavna navigacija
**Radnje i odredišta:**
- **Otvori zadatak** — uslov: Aktuelni account/focus/source; red pripada sadašnjem potvrđenom read-u. OWNER bira sopstvenu rutu; APPLIED/UNKNOWN javni detalj razrešava odnos.
  - Potvrđen rezultat: Otvoren konkretan needId.
  - Vodi na: OWNER → /potrebe/[id]/pregled; ostali → /prilike/[id]
  - Nazad: Nazad obnavlja query/filter/viewport/sheet/scroll/izbor.
  - Oporavak: Overlay error ne briše rezultate; nema prijave dok odnos nije NONE. Map error ima Listu; PAGE error ne poništava validan MAP.
- **Pogledaj zadatak** — uslov: Fresh EXACT read + trenutni selection key.
  - Potvrđen rezultat: Jedan tačan task.
  - Vodi na: Javni ili sopstveni detalj prema relationship-u
  - Nazad: Zatvori vraća isti map viewport; nazad iz detalja isti selection.
  - Oporavak: Stara cena nestaje dok exact read nije potvrđen; mapa i lista se oporavljaju nezavisno.
**Sekundarne radnje:**
- Filteri
- Za Tebe kada važeći read podržava
- Promeni područje
- Lista/mapa kroz isti ekran
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nema zadataka za ove izbore. Promeni filtere ili područje.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Overlay error ne briše rezultate; nema prijave dok odnos nije NONE. Map error ima Listu; PAGE error ne poništava validan MAP.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** GPS odbijen: ručno područje i javno pretraživanje ostaju gde postojeći ugovor dozvoljava.
**Povratak i očuvanje:** Nazad obnavlja query/filter/viewport/sheet/scroll/izbor.  
**Runtime owner porodica:** DISCOVERY  
**Relevantni source ulazi:** `src/app/(app)/zadaci.tsx`, `src/ui/v2/DiscoveryPresentation.tsx`, `src/ui/v2/discovery/DiscoveryV1Route.tsx`, `src/hooks/useDiscoveryWorkArea.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Za Tebe, retrieval/matcher/dispatch imaju važeći F18 area/time ugovor; ručna prijava zadržava svoje granice.
- P6/legacy reader izbor je infrastruktura, korisnik vidi jedan proizvod.

### 12.19. `discoveryFilters` — Pretraga i filteri
**Domena:** Prilike i javni zadatak  
**Postojeća ruta/ulaz:** /zadaci  
**Ciljna UX površina:** Bottom sheet / full-height sheet → **discovery**  
**Konsolidaciona odluka:** Jedan filter panel nad istim list/map stanjem.  
**Cilj korisnika:** Promeni kriterijume i unapred razumi šta će se primeniti.  
**Publika/kontekst:** Korisnik pretrage  
**Vizuelni obrazac:** Lista/mapa istog stanja. Kartice skeniraju naslov, osnovu cene, vreme, približno mesto i ljude; detalj otkriva celu priču.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Filter kontrola na Zadacima.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov, Zatvori, dostupna tastatura
- Pojam odvojen od izbora grada/područja
- Podržani način rada, cena i civilni datum
- Potvrđeni broj rezultata ili precizan loading/error
- Prikaži rezultate; Očisti; odustani bez primene
**Radnje i odredišta:**
- **Prikaži rezultate** — uslov: Validan draft, potvrđen izabrani resolver; broj samo iz preview, ne iz učitanih kartica.
  - Potvrđen rezultat: Primena query/view, novi read.
  - Vodi na: Isti /zadaci
  - Nazad: Nazad prvo zatvara IME; zatvaranje panela čuva ranije primenjene izbore.
  - Oporavak: Preview greška zadržava draft i nudi lokalni retry. Nepotvrđen broj nije 0.
**Sekundarne radnje:**
- Poništite filtere
- Otkaži lokalne izmene
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nema dodatnih izbora nije read-error; ne nuditi nepostojeću kategoriju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Preview greška zadržava draft i nudi lokalni retry. Nepotvrđen broj nije 0.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Nazad prvo zatvara IME; zatvaranje panela čuva ranije primenjene izbore.  
**Runtime owner porodica:** DISCOVERY  
**Relevantni source ulazi:** `src/app/(app)/zadaci.tsx`, `src/ui/v2/DiscoveryPresentation.tsx`, `src/ui/v2/discovery/DiscoveryV1Route.tsx`, `src/hooks/useDiscoveryWorkArea.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Ne dodavati fiktivne cene, udaljenosti ili mode filtere koje reader nema.
- D08 više lokacija ostaje otvorena odluka; filter ne nameće novo pravilo pokrivanja rute.

### 12.20. `taskDetail` — Detalji zadatka
**Domena:** Prilike i javni zadatak  
**Postojeća ruta/ulaz:** /prilike/[id]  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Proceni cenu, vreme, mesto i uslove pre prijave.  
**Publika/kontekst:** Javni ovlašćeni čitalac, sopstveni owner ili prijavljeni/izabrani izvršilac  
**Pravilo uloge:** Owner otvara svoj owner pregled; izvršilac bez prijave dobija Prijavite se; već prijavljen dobija Pogledajte prijavu; unknown odnos ne sme prikazati novi CTA.  
**Vizuelni obrazac:** Lista/mapa istog stanja. Kartice skeniraju naslov, osnovu cene, vreme, približno mesto i ljude; detalj otkriva celu priču.  
**Ikone:** location coral, time blue, money gold, people violet, work teal  
**Mediji:** Fotografije zadatka: 1–3 u intake-u; prikazati samo ako postoje. Tap → fullscreen viewer. Upload/staging/unknown vezani za isti resurs.  
**Ulaz i guard:**
- **Dolazi iz:** Zadaci, obaveštenje ili autorizovani link.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Nazad i naslov/stanje
- Budžet sa osnovom i broj ljudi
- Termin i približno mesto ili Na daljinu
- Jasan opis i dozvoljene fotografije
- Javni profil sa reputacijom odgovarajuće uloge
- Pitanja i odgovori
- Kontekstualni footer
**Radnje i odredišta:**
- **Prijavi se / Pogledaj prijavu / Otvori svoj zadatak** — uslov: Svež odnos; za novu prijavu NONE, primaNovePrijave, validan rok i time authority.
  - Potvrđen rezultat: Dozvoljen sledeći korak.
  - Vodi na: NONE → /prilike/[id]/prijava; OWNER → /potrebe/[id]/pregled; APPLIED → /moje-prijave sa prijavaId
  - Nazad: Back u prethodnu kolekciju, cold fallback Zadaci.
  - Oporavak: UNKNOWN → osveži odnos; closed → druge zadatke. Optional QA/profile errors ostaju u sekciji.
**Sekundarne radnje:**
- Postavi pitanje kada dozvoljeno
- Pogledaj javni profil
- Prijavi sadržaj kroz pravi safety target
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Zadatak nije dostupan; ne prikazivati tuđe/stare privatne podatke.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. Requester reliability M22; javni share link M20.
- **unknown:** UNKNOWN → osveži odnos; closed → druge zadatke. Optional QA/profile errors ostaju u sekciji.
- **stale:** Poslednji javni sažetak čitljiv, nova prijava čeka svežu reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Back u prethodnu kolekciju, cold fallback Zadaci.  
**Runtime owner porodica:** PUBLIC_TASK  
**Relevantni source ulazi:** `src/app/(app)/prilike/[id].tsx`, `src/ui/v2/PublicNeedPresentation.tsx`, `src/ui/qa/useTaskQaInline.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Cena 3.500 RSD ukupno sa snimka je primer, nije hardcoded produkcioni podatak.
- Generic USKOČI korisnik se ne zamenjuje privatnim imenom radi dizajna.

### 12.21. `apply` — Nova prijava
**Domena:** Prijave izvršioca  
**Postojeća ruta/ulaz:** /prilike/[id]/prijava  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pošalji razumljivu konkretnu ponudu uz cenu, ljude i termin.  
**Publika/kontekst:** Izvršilac za dati zadatak, sa potvrđenim pravom prijave  
**Pravilo uloge:** Samo izvršilac. Fiksna cena ne traži pregovaranje; OFFERS traži ponudu. Ako postoji stara unknown komanda, ona se prvo razrešava.  
**Vizuelni obrazac:** Composer pita samo ono što nije već zadato. Review pre slanja. Cena uvek nosi osnovu; satnica se ne pretvara u izmišljeni total.  
**Ikone:** paper-plane/application blue + price/time/people semantic  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Prijavi se sa javnog detalja.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Prvo postojeća nepoznata komanda ako postoji
- Kompaktan task sažetak
- Fiksna deterministička cena ili OFFERS unos sa osnovom
- Koliko ljudi dolazi
- Postojeći/fleksibilni termin i opcion tačan interval
- Opciona poruka; opcioni profil skill opt-in sa odvojenim ishodom
- Pregledaj prijavu
**Radnje i odredišta:**
- **Pregledaj prijavu** — uslov: Nema unresolved journal; aktivan profil; otvoren task/remaining slots; pozitivan ceo RSD i people; validan interval.
  - Potvrđen rezultat: Snimak ponude za potvrdu.
  - Vodi na: Review u composer-u
  - Nazad: Nazad vraća sva polja i scroll bez novog upisa.
  - Oporavak: Sveža promena revizije invalidira pregled; sačuvaj unos i prikaži šta treba proveriti.
- **Pošalji ovu prijavu** — uslov: Isti reviewKey; immutable request; journal sačuvan pre mreže; account/focus isti.
  - Potvrđen rezultat: Receipt {prijavaId,verzija,hash}; opcioni profile write odvojen.
  - Vodi na: Potvrda; potom tačna Moja prijava
  - Nazad: Back u javni detalj čuva neposlat draft u dokazanoj memoriji.
  - Oporavak: Unknown nema novi key; proveri postojeći intent. SQLSTATE-bound refusal tek tada dozvoljava eksplicitno novo sastavljanje.
**Sekundarne radnje:**
- Izmeni ponudu
- Nazad na zadatak
**Destruktivne radnje:**
- Odbacite neposlat nacrt uz potvrdu kada je izmenjen
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Sveža promena revizije invalidira pregled; sačuvaj unos i prikaži šta treba proveriti. Unknown nema novi key; proveri postojeći intent. SQLSTATE-bound refusal tek tada dozvoljava eksplicitno novo sastavljanje.
- **stale:** Uslovi su promenjeni. Pregledaj ih pre ponovnog slanja.
- **permission_denied:** Prijava nije dozvoljena: konkretan razlog iz autoriteta, npr. zatvoreno/popunjeno/neaktivan profil.
**Povratak i očuvanje:** Nazad vraća sva polja i scroll bez novog upisa. Back u javni detalj čuva neposlat draft u dokazanoj memoriji.  
**Runtime owner porodica:** APPLICATION  
**Relevantni source ulazi:** `src/app/(app)/prilike/[id]/prijava.tsx`, `src/ui/v2/ApplicationComposerPresentation.tsx`, `src/data/applicationSelectionClientService.ts`, `src/data/applicationCommandJournal.ts`, `src/data/applicationComposerDraftMemory.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- MY_PRICE deterministički, OFFERS dozvoljeni unos; nema izmišljene HOURLY total vrednosti.
- F13 opcioni upis veštine zahteva merge/CAS; ne pregaziti ceo profil zastarelim nizom.

### 12.22. `applyReceipt` — Prijava je poslata
**Domena:** Prijave izvršioca  
**Postojeća ruta/ulaz:** /prilike/[id]/prijava, /moje-prijave  
**Ciljna UX površina:** Success state / receipt → **apply → applicationDetail**  
**Konsolidaciona odluka:** Potvrda je trenutak toka, ne zasebna stalna destinacija. U navigaciji nema sopstvenu stavku.  
**Cilj korisnika:** Razumi da je prijava stigla i gde se prati.  
**Publika/kontekst:** Podnosilac prijave  
**Vizuelni obrazac:** Composer pita samo ono što nije već zadato. Review pre slanja. Cena uvek nosi osnovu; satnica se ne pretvara u izmišljeni total.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Validan submit receipt/readback.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Potvrda samo za validan receipt
- Poslata cena/osnova, broj ljudi, termin i poruka
- Status eventualne dopune profila
- Pogledaj prijavu; nazad na zadatke
**Radnje i odredišta:**
- **Pogledaj prijavu** — uslov: Receipt prijavaId potvrđen.
  - Potvrđen rezultat: Otvoren tačan application target.
  - Vodi na: /moje-prijave?prijavaId=...&nova=1
  - Nazad: Back vraća smislen prethodni task/collection.
  - Oporavak: Ponovno otvaranje receipt-a je mirno; cleanup greška ne negira uspeh.
**Sekundarne radnje:**
- Nazad na zadatke
- Ponovi samo neuspelu dozvoljenu dopunu profila
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Ponovno otvaranje receipt-a je mirno; cleanup greška ne negira uspeh.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Back vraća smislen prethodni task/collection.  
**Runtime owner porodica:** APPLICATION  
**Relevantni source ulazi:** `src/app/(app)/prilike/[id]/prijava.tsx`, `src/ui/v2/ApplicationComposerPresentation.tsx`, `src/data/applicationSelectionClientService.ts`, `src/data/applicationCommandJournal.ts`, `src/data/applicationComposerDraftMemory.ts`, `src/app/(app)/moje-prijave.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Uspeh je iz validne potvrde, ne HTTP statusa ili promene lokalne kartice.

### 12.23. `applications` — Moje prijave
**Domena:** Prijave izvršioca  
**Postojeća ruta/ulaz:** /moje-prijave  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pronađi prijavu koja čeka odgovor ili tvoju reakciju.  
**Publika/kontekst:** Podnosilac sopstvenih prijava  
**Vizuelni obrazac:** Composer pita samo ono što nije već zadato. Review pre slanja. Cena uvek nosi osnovu; satnica se ne pretvara u izmišljeni total.  
**Ikone:** paper-plane/application blue  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Početna/profil, notifikacija, uspešna prijava.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Čekaju odgovor / Čeka te / Istorija / Sve
- Kartice sa task naslovom, stanjem, iznosom/osnovom, brojem ljudi i terminom
- Tačan cilj iz obaveštenja istaknut bez skrivanja ostatka
- Učitaj još / lokalna page greška
**Radnje i odredišta:**
- **Pogledaj prijavu** — uslov: Owned application iz važećeg scope-a; named target pronađen kroz bounded read.
  - Potvrđen rezultat: Sopstveni detalj/changed review.
  - Vodi na: Lokalni application detail; confirmed agreementId → /dogovor/[id]
  - Nazad: Back zatvara sheet, čuva scope i položaj.
  - Oporavak: Page error zadržava ranije strane; nepotpun named search kaže nije pronađeno u učitanom delu, ne izbrisano.
**Sekundarne radnje:**
- Otvori Dogovor ako izabrana
- Promeni scope
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Još nemaš prijava. Pronađi zadatak.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Page error zadržava ranije strane; nepotpun named search kaže nije pronađeno u učitanom delu, ne izbrisano.
- **stale:** Prijava sa promenjenim uslovima traži eksplicitnu reakciju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Back zatvara sheet, čuva scope i položaj.  
**Runtime owner porodica:** MY_APPLICATIONS  
**Relevantni source ulazi:** `src/app/(app)/moje-prijave.tsx`, `src/ui/v2/MyApplicationsPresentation.tsx`, `src/data/myApplicationsClientService.ts`, `src/data/ru4Production.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Count/scope odgovaraju stvarnom reader-u; ne računati samo trenutno renderovanu stranu.

### 12.24. `applicationDetail` — Tvoja prijava
**Domena:** Prijave izvršioca  
**Postojeća ruta/ulaz:** /moje-prijave  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pročitaj ono što si poslao i reaguj samo na dozvoljenu promenu.  
**Publika/kontekst:** Vlasnik jedne prijave  
**Vizuelni obrazac:** Composer pita samo ono što nije već zadato. Review pre slanja. Cena uvek nosi osnovu; satnica se ne pretvara u izmišljeni total.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Kartica prijave ili tačan notification target.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Status i naziv zadatka
- Poslata ponuda: iznos/osnova, ljudi, interval, poruka
- Trenutni uslovi samo ako owner traži review
- Odvojena vest o replacement objavi bez prenosa prijave
- Pogledaj zadatak; Otvori Dogovor samo uz ID
- Kontekstualni KEEP/UPDATE/WITHDRAW
**Radnje i odredišta:**
- **Zadrži / Izmeni / Povuci** — uslov: Sveža current need revision, response version/hash, allowed action; review učitan.
  - Potvrđen rezultat: Exact response receipt i readback.
  - Vodi na: Ista prijava sa potvrđenim stanjem
  - Nazad: Otkaži edit vraća istu prijavu; dirty intent traži odluku pre drugog notification target-a.
  - Oporavak: Unknown zamrzava body i key; ne otvarati novi composer. Restart parity nije potvrđena memorijskim pending-om.
- **Pogledaj zadatak** — uslov: Prijava ima svoj needId; ne koristi owner route.
  - Potvrđen rezultat: Javni task kontekst.
  - Vodi na: /prilike/[id]
  - Nazad: Nazad u istu prijavu/scope.
  - Oporavak: Zatvoren/nedostupan task ne briše dozvoljeni application receipt.
**Sekundarne radnje:**
- Pregledaj zadatak
- Otkaži neposlate izmene
**Destruktivne radnje:**
- Povuci prijavu uz kratku eksplicitnu potvrdu; izvor.povuciPrijavu
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. Potpun current task pregled pre potvrde M08.
- **unknown:** Unknown zamrzava body i key; ne otvarati novi composer. Restart parity nije potvrđena memorijskim pending-om. Zatvoren/nedostupan task ne briše dozvoljeni application receipt.
- **stale:** Prikaži uporedo stare prihvaćene i nove uslove, eksplicitan KEEP/UPDATE/WITHDRAW.
- **permission_denied:** Više nije moguće menjati/povlačiti; osveži stvarno stanje.
**Povratak i očuvanje:** Otkaži edit vraća istu prijavu; dirty intent traži odluku pre drugog notification target-a. Nazad u istu prijavu/scope.  
**Runtime owner porodica:** MY_APPLICATIONS  
**Relevantni source ulazi:** `src/app/(app)/moje-prijave.tsx`, `src/ui/v2/MyApplicationsPresentation.tsx`, `src/data/myApplicationsClientService.ts`, `src/data/ru4Production.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Istorijski STALE_REVIEW_REQUIRED tok čuva se; ne mešati sa novim replacement-only public edit ugovorom.

### 12.25. `myNeeds` — Moji zadaci
**Domena:** Moje potrebe i izbor ljudi  
**Postojeća ruta/ulaz:** /potrebe  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Vidi šta je objavljeno, šta čeka izbor i gde posao traje.  
**Publika/kontekst:** Naručilac sopstvenih potreba  
**Vizuelni obrazac:** Owner vidi status potrebe, koliko još ljudi treba, prijave i postojeće Dogovore. Kandidat prikazuje ponudu pre profila/dekoracije.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Početna/profil, uspešan Save ili Publish.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Čeka tvoj izbor
- Objavljeno
- Dogovoreno
- Nacrti i Istorija kao jasno odvojeni ulazi
- Sekundarno Objavi zadatak tamo gde korisnik to očekuje
- Paginacija i lokalno osvežavanje
**Radnje i odredišta:**
- **Otvori zadatak** — uslov: Red iz own kolekcije i isti account/focus.
  - Potvrđen rezultat: Vlasnički task read.
  - Vodi na: /potrebe/[id]/pregled; candidate shortcut samo isti ID
  - Nazad: Nazad čuva grupu/scope/listu.
  - Oporavak: Unknown count nije Čeka tvoj izbor; draft publication ishod ne zaključivati iz lokalnog čina.
**Sekundarne radnje:**
- Objavi zadatak
- Promeni scope
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nemaš zadataka u ovom prikazu. CTA zavisi od scope-a, ne uvek isti novi zadatak.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Unknown count nije Čeka tvoj izbor; draft publication ishod ne zaključivati iz lokalnog čina.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Nazad čuva grupu/scope/listu.  
**Runtime owner porodica:** OWN_TASK  
**Relevantni source ulazi:** `src/app/(app)/potrebe.tsx`, `src/app/(app)/potrebe/[id]/pregled.tsx`, `src/ui/v2/NeedPresentation.tsx`, `src/ui/needs/NeedLifecycleActions.tsx`, `src/ui/needs/NeedSearchRecoveryController.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Ne izmišljati nazive/count semantiku pet scope-ova; vezati za R03/source.

### 12.26. `ownTask` — Moj zadatak
**Domena:** Moje potrebe i izbor ljudi  
**Postojeća ruta/ulaz:** /potrebe/[id]/pregled  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Upravljaj jednom objavom bez gubitka njenih ljudi i Dogovora.  
**Publika/kontekst:** Vlasnik zadatka  
**Pravilo uloge:** Samo naručilac/owner. Prijave, preostali broj ljudi i povezani Dogovori pripadaju ovom needId-u; izmena oglasa ne menja postojeće Dogovore.  
**Vizuelni obrazac:** Owner vidi status potrebe, koliko još ljudi treba, prijave i postojeće Dogovore. Kandidat prikazuje ponudu pre profila/dekoracije.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Fotografije zadatka: 1–3 u intake-u; prikazati samo ako postoje. Tap → fullscreen viewer. Upload/staging/unknown vezani za isti resurs.  
**Ulaz i guard:**
- **Dolazi iz:** Moji zadaci, Dogovori grupa ili notification.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov i faza
- Stvarni uslovi/termin/lokacija
- Kanonski popunjeno/preostalo i čekajuće prijave
- Dogovori za ovaj zadatak
- Pitanja kojima treba odgovor
- Primarna radnja prema statusu; ostalo u meniju
**Radnje i odredišta:**
- **Pogledaj prijave** — uslov: Owner, current need, eligible izbor.
  - Potvrđen rezultat: Kandidati za isti task.
  - Vodi na: /potrebe/[id]/kandidati
  - Nazad: Nazad u isti owner overview.
  - Oporavak: Unknown state → osveži; ne nuditi izbor iz stale snapshot-a.
- **Dogovori za ovaj zadatak** — uslov: Confirmed linked IDs i owner uloga.
  - Potvrđen rezultat: Jedan Dogovor ili scoped skup.
  - Vodi na: /dogovor/[id] ili /dogovori scoped needId target
  - Nazad: Nazad na isti task.
  - Oporavak: Ako povezivanje nije pročitano, retry samo te sekcije; ne generički celu listu.
- **Izmeni zadatak** — uslov: Nema popunjenih mesta; status/edit gate i signed replacement ugovor.
  - Potvrđen rezultat: AI priprema; jedan završni pregled.
  - Vodi na: Postojeći conversation route
  - Nazad: Nazad bez upisa starih prijava; replacement stvara novu objavu bez transfera.
  - Oporavak: Nepoznat open/edit identity oporaviti preko postojećeg ownera.
**Sekundarne radnje:**
- Izmeni kroz AI kada dozvoljeno
- Ponovo otvori preostalu potragu kada eligible
**Destruktivne radnje:**
- Zatvori preostalu potragu ili otkaži/obriši tačno označeni entitet prema postojećem owneru, uz posledice
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. Scoped multi-agreement entry M07; waiting-help fields M21.
- **unknown:** Unknown state → osveži; ne nuditi izbor iz stale snapshot-a. Ako povezivanje nije pročitano, retry samo te sekcije; ne generički celu listu. Nepoznat open/edit identity oporaviti preko postojećeg ownera.
- **stale:** Ne potvrditi lifecycle nad zastarelom verzijom.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Nazad u isti owner overview. Nazad na isti task. Nazad bez upisa starih prijava; replacement stvara novu objavu bez transfera.  
**Runtime owner porodica:** OWN_TASK  
**Relevantni source ulazi:** `src/app/(app)/potrebe.tsx`, `src/app/(app)/potrebe/[id]/pregled.tsx`, `src/ui/v2/NeedPresentation.tsx`, `src/ui/needs/NeedLifecycleActions.tsx`, `src/ui/needs/NeedSearchRecoveryController.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- HITNO se ne vraća iz istorijskog modula bez važeće odluke; aktivne consumer-e proveriti pre povlačenja.
- Selection count nije broj klikova; značenje ljudi/mesta/timskog kapaciteta vezati za autoritet.

### 12.27. `taskLifecycle` — Status zadatka
**Domena:** Moje potrebe i izbor ljudi  
**Postojeća ruta/ulaz:** /potrebe/[id]/pregled  
**Ciljna UX površina:** Action sheet + destructive dialog → **ownTask**  
**Konsolidaciona odluka:** Zatvori/Reopen/Delete draft/Cancel su kontekstualne akcije, ne meni-stranica.  
**Cilj korisnika:** Potvrdi tačno jednu promenu potrage ili nacrta.  
**Publika/kontekst:** Vlasnik zadatka  
**Vizuelni obrazac:** Owner vidi status potrebe, koliko još ljudi treba, prijave i postojeće Dogovore. Kandidat prikazuje ponudu pre profila/dekoracije.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Overflow u sopstvenom zadatku.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Tačan naziv radnje i zadatka
- Jedna rečenica posledice
- Postojeći Dogovori i dalje važe gde je to istina
- Nazad i eksplicitni glagol potvrde
- Poseban unknown recovery
**Radnje i odredišta:**
- **Zatvori potragu / Ponovo otvori / Obriši nacrt / Otkaži zadatak** — uslov: Server action, verzija; close/reopen canonical search i closure witness; delete samo draft.
  - Potvrđen rezultat: Potvrđeni receipt+fresh state, nije lokalni boolean.
  - Vodi na: Owner overview ili own collection posle potvrđenog delete-a
  - Nazad: Cancel zatvara modal bez upisa; pending zatvaranje ne poništava komandu.
  - Oporavak: Recovery mount ostaje i kad task row nestane; istorijski reopen receipt nije dokaz sada otvorene potrage.
**Sekundarne radnje:**
- Nazad
**Destruktivne radnje:**
- Obriši nacrt ili otkaži tamo gde stvarni owner dopušta; ne koristiti generičko Obriši za sve
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Recovery mount ostaje i kad task row nestane; istorijski reopen receipt nije dokaz sada otvorene potrage.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Cancel zatvara modal bez upisa; pending zatvaranje ne poništava komandu.  
**Runtime owner porodica:** OWN_TASK  
**Relevantni source ulazi:** `src/app/(app)/potrebe.tsx`, `src/app/(app)/potrebe/[id]/pregled.tsx`, `src/ui/v2/NeedPresentation.tsx`, `src/ui/needs/NeedLifecycleActions.tsx`, `src/ui/needs/NeedSearchRecoveryController.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Poruka potvrde imenuje šta se dešava sa postojećim Dogovorima; nikada ih prećutno ne otkazuje.

### 12.28. `candidates` — Prijave na zadatak
**Domena:** Moje potrebe i izbor ljudi  
**Postojeća ruta/ulaz:** /potrebe/[id]/kandidati  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Uporedi konkretne ponude u okviru jednog zadatka.  
**Publika/kontekst:** Vlasnik konkretnog zadatka  
**Vizuelni obrazac:** Owner vidi status potrebe, koliko još ljudi treba, prijave i postojeće Dogovore. Kandidat prikazuje ponudu pre profila/dekoracije.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Sopstveni zadatak ili notification o prijavi.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naziv taska i kanonska preostala mesta
- Broj prijava iz servera
- Redovi: osoba, ponuda/osnova, ljudi, termin, poruka
- Sort i poređenje u razumljivom opsegu
- Učitaj još / jasno nepotpun skup
**Radnje i odredišta:**
- **Pogledaj prijavu** — uslov: Owned candidate belongs same need revision; account/focus/read current.
  - Potvrđen rezultat: Offer otvoren; viewed tek nakon potvrde.
  - Vodi na: Candidate sheet
  - Nazad: Zatvori sheet → ista lista/sort; cold back → owner task.
  - Oporavak: Notification target pretražiti do bound-a; incomplete nije withdrawn. Viewed failure ne poništava ponudu.
**Sekundarne radnje:**
- Uporedi gde kompletan ograničen skup dozvoljava
- Otvori zadatak
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Još nema prijava. Zadatak ostaje u svom stvarnom statusu.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Notification target pretražiti do bound-a; incomplete nije withdrawn. Viewed failure ne poništava ponudu.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Zatvori sheet → ista lista/sort; cold back → owner task.  
**Runtime owner porodica:** CANDIDATES  
**Relevantni source ulazi:** `src/app/(app)/potrebe/[id]/kandidati.tsx`, `src/ui/v2/ApplicationSelectionPresentation.tsx`, `src/data/applicationSelectionClientService.ts`, `src/data/candidateClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Samo listanje ne označava viewed.
- Sortiranje po ceni ili globalno poređenje tek kada stvarni ograničen skup kompletan.

### 12.29. `candidateDetail` — Ponuda osobe
**Domena:** Moje potrebe i izbor ljudi  
**Postojeća ruta/ulaz:** /potrebe/[id]/kandidati  
**Ciljna UX površina:** Full-height bottom sheet or screen → **candidates**  
**Konsolidaciona odluka:** Brz pregled ponude; ako profil/poruka postanu dugi, sheet može preći u full screen.  
**Cilj korisnika:** Razumi šta osoba nudi i za koliko ljudi.  
**Publika/kontekst:** Naručilac konkretnog zadatka  
**Pravilo uloge:** Samo naručilac/owner vidi ponudu osobe i bira. Broj ljudi je deo ponude, ne izveden iz profila.  
**Vizuelni obrazac:** Owner vidi status potrebe, koliko još ljudi treba, prijave i postojeće Dogovore. Kandidat prikazuje ponudu pre profila/dekoracije.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Konkretna kartica prijave.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Dozvoljeni identitet i javna reputacija
- Cena/osnova i ljudi zajedno
- Termin; poruka cela
- Relevantni alat/vozilo kao informacija
- Pogledaj profil
- Pregledaj izbor ili Otvori postojeći Dogovor
**Radnje i odredišta:**
- **Pregledaj izbor** — uslov: SELECTABLE/mozeIzabrati; fresh need revision i response version/hash; dovoljno mesta.
  - Potvrđen rezultat: Review tačne ponude.
  - Vodi na: Selection review
  - Nazad: Nazad vraća istu ponudu/listu.
  - Oporavak: Fresh state non-selectable objašnjava razlog; pending izbor zadržava originalnu ponudu.
- **Otvori Dogovor** — uslov: Pozitivan authorized readSelectedAgreement.
  - Potvrđen rezultat: Potvrđen agreementId.
  - Vodi na: /dogovor/[id]
  - Nazad: Povratak u originalni task kontekst.
  - Oporavak: Null nije dokaz neuspeha izbora niti dozvola za drugi izbor.
**Sekundarne radnje:**
- Pogledaj javni profil
- Nazad na prijave
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Fresh state non-selectable objašnjava razlog; pending izbor zadržava originalnu ponudu. Null nije dokaz neuspeha izbora niti dozvola za drugi izbor.
- **stale:** Ponuda više nije izabriva: osveži uslove.
- **permission_denied:** Detalji profila nisu dostupni; ponuda se prikazuje samo ako njena prava ostaju.
**Povratak i očuvanje:** Nazad vraća istu ponudu/listu. Povratak u originalni task kontekst.  
**Runtime owner porodica:** CANDIDATES  
**Relevantni source ulazi:** `src/app/(app)/potrebe/[id]/kandidati.tsx`, `src/ui/v2/ApplicationSelectionPresentation.tsx`, `src/data/applicationSelectionClientService.ts`, `src/data/candidateClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Ne dodavati privatno ime/fotografiju kada javni reader nije vratio te podatke.

### 12.30. `selectReview` — Potvrdi izbor
**Domena:** Moje potrebe i izbor ljudi  
**Postojeća ruta/ulaz:** /potrebe/[id]/kandidati  
**Ciljna UX površina:** Full-screen confirmation sheet → **candidateDetail**  
**Konsolidaciona odluka:** Frozen ponuda pre stvaranja Dogovora.  
**Cilj korisnika:** Potvrdi baš ovu ponudu i nastanak Dogovora.  
**Publika/kontekst:** Vlasnik zadatka  
**Vizuelni obrazac:** Owner vidi status potrebe, koliko još ljudi treba, prijave i postojeće Dogovore. Kandidat prikazuje ponudu pre profila/dekoracije.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Izaberi osobu iz konkretne ponude.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Osoba i task
- Ponuda: iznos/osnova, ljudi, termin
- Posledica povezivanja
- Potvrdi izbor / Nazad na ponudu
- Unknown recovery iste komande
**Radnje i odredišta:**
- **Potvrdi izbor** — uslov: Isti review, fresh owner access, response version/hash/capacity, nema konkurentskog pending-a.
  - Potvrđen rezultat: Exact dogovorId receipt.
  - Vodi na: Dogovoreno moment → /dogovor/[id]; Izaberi još samo kada preostaje
  - Nazad: Back pre slanja ništa ne piše; posle pending čuva identitet.
  - Oporavak: Unknown refresh ne pravi novu komandu; cold durability selection nije implementirana. Remaining prikaz je frozen preselection minus chosen (nije dokaz double-count buga).
**Sekundarne radnje:**
- Nazad na ponudu
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Unknown refresh ne pravi novu komandu; cold durability selection nije implementirana. Remaining prikaz je frozen preselection minus chosen (nije dokaz double-count buga).
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Back pre slanja ništa ne piše; posle pending čuva identitet.  
**Runtime owner porodica:** CANDIDATES  
**Relevantni source ulazi:** `src/app/(app)/potrebe/[id]/kandidati.tsx`, `src/ui/v2/ApplicationSelectionPresentation.tsx`, `src/data/applicationSelectionClientService.ts`, `src/data/candidateClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Dogovor se otvara tek sa stvarnim agreementId i dozvolom.

### 12.31. `agreements` — Dogovori
**Domena:** Dogovor i izvršenje  
**Postojeća ruta/ulaz:** /dogovori  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Prati svoje obaveze u obe uloge na jednom mestu.  
**Publika/kontekst:** Isti nalog kao naručilac ili izvršilac po Dogovoru  
**Vizuelni obrazac:** Jedan shared workspace sa role-aware akcijama; važeći uslovi, pending izmena, mesto, tok, poruke i dokazi bez mešanja statusa.  
**Ikone:** handshake line icon  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Tab Dogovori.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Aktivni / Istorija i smisleni filter pažnje
- Task grupa; uloga ovog Dogovora
- Osoba, važeća cena/termin, status i sledeća radnja
- Raspored kao header prečica
- Glavna navigacija
**Radnje i odredišta:**
- **Otvori Dogovor** — uslov: Owned agreement iz potvrđenog read-a.
  - Potvrđen rezultat: Private workspace konkretne saradnje.
  - Vodi na: /dogovor/[id]
  - Nazad: Back vraća aktivni scope/grupu/scroll.
  - Oporavak: Optional source error ne čini ceo skup praznim; background sakriva privatne podatke dok se prava ne obnove.
**Sekundarne radnje:**
- Raspored
- Ocena kada dozvoljena
- Sopstveni zadatak iz grupe
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nemaš Dogovora u ovom prikazu. Ponuditi prikladan put do zadataka/objave.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Optional source error ne čini ceo skup praznim; background sakriva privatne podatke dok se prava ne obnove.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Back vraća aktivni scope/grupu/scroll.  
**Runtime owner porodica:** AGREEMENT  
**Relevantni source ulazi:** `src/app/(app)/dogovori.tsx`, `src/app/dogovor/[id].tsx`, `src/ui/agreements/AgreementWorkspace.tsx`, `src/ui/agreements/AgreementOverview.tsx`, `src/ui/agreements/AgreementCompletionReview.tsx`, `src/data/agreementClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Requester i worker statusi jasno imenovani po konkretnom Dogovoru; ne dve odvojene aplikacije.

### 12.32. `agreementDetail` — Dogovor
**Domena:** Dogovor i izvršenje  
**Postojeća ruta/ulaz:** /dogovor/[id]  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Razumi šta važi za tvoju saradnju i sledeći korak.  
**Publika/kontekst:** Potvrđeni učesnik konkretnog Dogovora  
**Pravilo uloge:** Shared ekran. Backend actionstate + participant role određuju CTA: izvršilac može označiti završetak; naručilac potvrđuje završetak; druga strana odgovara na tuđi predlog izmene; autor predloga samo čeka/povlači gde je dozvoljeno.  
**Vizuelni obrazac:** Jedan shared workspace sa role-aware akcijama; važeći uslovi, pending izmena, mesto, tok, poruke i dokazi bez mešanja statusa.  
**Ikone:** handshake/agreement green-orange + four neutral tab icons  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Lista, obaveštenje, izabrana prijava ili poruke.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Task naslov i druga osoba; uloga samo po Dogovoru
- Pregled / Poruke
- Važeći uslovi: cena/osnova, obim, ljudi, termin ili Bez termina
- Pending izmena odvojeno, jasno ko čeka odgovor
- Lokacija prema dozvoli
- Primarna dozvoljena radnja; izmene/problem/pomoć u meniju
- Veza na izvorni zadatak u odgovarajućem owner/public kontekstu
**Radnje i odredišta:**
- **Otvori pregled** — uslov: UUID/account; active participant and current revision.
  - Potvrđen rezultat: Aktuelan private workspace.
  - Vodi na: Pregled ili tab=poruke prema entry intent-u
  - Nazad: Inbox origin → Poruke; standard cold → Dogovori; nested source task vraća u isti Dogovor.
  - Oporavak: Focus/account guards prethode privatnoj prezentaciji; inaccessible ne prikazuje stari cache.
- **Predloži izmenu** — uslov: actionstate dozvoljava + current form guard.
  - Potvrđen rezultat: Change hub/form za isti agreementId.
  - Vodi na: /dogovor/[id]/izmene?start=propose
  - Nazad: Nazad na isti Dogovor, ne globalni root.
  - Oporavak: Pending journal se oporavlja pre novog predloga.
- **Prijavi problem** — uslov: Participant context + validan narrative + isti prvi intent.
  - Potvrđen rezultat: Prijem problema i aktualizovan workspace.
  - Vodi na: Isti Dogovor
  - Nazad: Odustajanje pre slanja ne piše; unknown izlaz čuva identity.
  - Oporavak: Provera ne menja prvi narrative. Problem zaustavlja automatiku prema authority, ne uvodi novu payment policy.
**Sekundarne radnje:**
- Poruke
- Predloži izmenu
- Prijavi problem
- Otvori dozvoljenu tačnu lokaciju
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Focus/account guards prethode privatnoj prezentaciji; inaccessible ne prikazuje stari cache. Pending journal se oporavlja pre novog predloga.
- **stale:** Pending izmena blokira završetak dok se ne razreši.
- **permission_denied:** Minimalna informacija i dozvoljeni izlaz; nema cache privatne lokacije.
**Povratak i očuvanje:** Inbox origin → Poruke; standard cold → Dogovori; nested source task vraća u isti Dogovor. Nazad na isti Dogovor, ne globalni root.  
**Runtime owner porodica:** AGREEMENT  
**Relevantni source ulazi:** `src/app/(app)/dogovori.tsx`, `src/app/dogovor/[id].tsx`, `src/ui/agreements/AgreementWorkspace.tsx`, `src/ui/agreements/AgreementOverview.tsx`, `src/ui/agreements/AgreementCompletionReview.tsx`, `src/data/agreementClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Samo poruke; nema call/PHONE reveal. EXACT_LOCATION je zaseban dozvoljeni ugovor.
- Izvršilac označava završetak, naručilac potvrđuje; UI ne preskače drugu stranu.

### 12.33. `completionReview` — Završetak posla
**Domena:** Dogovor i izvršenje  
**Postojeća ruta/ulaz:** /dogovor/[id]  
**Ciljna UX površina:** Full-height confirmation sheet → **agreementDetail**  
**Konsolidaciona odluka:** Uloga određuje glagol: izvršilac označava, naručilac potvrđuje.  
**Cilj korisnika:** Potvrdi završetak konkretne saradnje u svojoj ulozi.  
**Publika/kontekst:** Odgovarajući učesnik prema server radnji  
**Pravilo uloge:** Izvršilac: „Označite posao završenim“. Naručilac: „Potvrdite završetak“ ili problem. Ne nuditi ocenu pre completed/eligible stanja.  
**Vizuelni obrazac:** Jedan shared workspace sa role-aware akcijama; važeći uslovi, pending izmena, mesto, tok, poruke i dokazi bez mešanja statusa.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Primarna radnja završetka u Dogovoru.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Osoba, task i prihvaćeni uslovi
- Jasno koja potvrda se sada daje
- Označi završetak ili Potvrdi završetak
- Prijavi problem / Nazad gde dozvoljeno
**Radnje i odredišta:**
- **Označi završetak / Potvrdi završetak** — uslov: Pripadajući participant action; fresh version; nema blokirajućeg pending proposal-a.
  - Potvrđen rezultat: Potvrđen završetak radnika ili completed receipt.
  - Vodi na: Isti Dogovor; rating tek kada eligible
  - Nazad: Nazad pre potvrde ništa ne menja.
  - Oporavak: Unknown zamrzava istu radnju; ponovo pročitaj stanje, ne pretpostavljaj completed po HTTP statusu.
**Sekundarne radnje:**
- Vrati se
- Prijavi problem ako dozvoljeno
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Unknown zamrzava istu radnju; ponovo pročitaj stanje, ne pretpostavljaj completed po HTTP statusu.
- **stale:** Uslovi su promenjeni; novi review pre potvrde.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Nazad pre potvrde ništa ne menja.  
**Runtime owner porodica:** AGREEMENT  
**Relevantni source ulazi:** `src/app/(app)/dogovori.tsx`, `src/app/dogovor/[id].tsx`, `src/ui/agreements/AgreementWorkspace.tsx`, `src/ui/agreements/AgreementOverview.tsx`, `src/ui/agreements/AgreementCompletionReview.tsx`, `src/data/agreementClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Ocena se pojavljuje tek kada je stvarno dozvoljena po završetku.

### 12.34. `amendment` — Predloži izmenu
**Domena:** Dogovor i izvršenje  
**Postojeća ruta/ulaz:** /dogovor/[id]/izmene  
**Ciljna UX površina:** Full-screen subflow → **agreementDetail**  
**Konsolidaciona odluka:** Izmena zaslužuje fokus i očuvanje drafta.  
**Cilj korisnika:** Predloži promenu bez tihog menjanja onoga što je dogovoreno.  
**Publika/kontekst:** Učesnik kome autoritet daje propose  
**Vizuelni obrazac:** Jedan shared workspace sa role-aware akcijama; važeći uslovi, pending izmena, mesto, tok, poruke i dokazi bez mešanja statusa.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Dogovor menu ili postojeći amendment hub.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Ako journal postoji: prvo oporavak
- Važi sada
- Cena i obim prema dozvoljenom patch-u
- Termin: početak i kraj u jasno navedenoj zoni
- Opciono objašnjenje
- Pregledaj predlog
**Radnje i odredišta:**
- **Pregledaj predlog** — uslov: Fresh version; supported nonempty patch; pozitivna int cena; interval validan; netaknuti krajevi zadržavaju originalnu preciznost.
  - Potvrđen rezultat: Normalized review vezan za verziju.
  - Vodi na: Amendment review
  - Nazad: Nazad vraća isti sedmopoljni draft; X/Escape isto.
  - Oporavak: Fresh version change čuva draft ali invalidira review; cold pending traži tačan unos prema hash-u ako telo nedostaje.
**Sekundarne radnje:**
- Nazad
- Sačuvaj unos u dokazanom lokalnom obimu
**Destruktivne radnje:**
- Odbacite neposlat predlog uz potvrdu kada je potrebno
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Fresh version change čuva draft ali invalidira review; cold pending traži tačan unos prema hash-u ako telo nedostaje.
- **stale:** Važeći Dogovor je promenjen; pre/posle obnoviti, stari review nije potvrda.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Nazad vraća isti sedmopoljni draft; X/Escape isto.  
**Runtime owner porodica:** AGREEMENT_CHANGES  
**Relevantni source ulazi:** `src/app/dogovor/[id]/izmene.tsx`, `src/ui/agreements/AgreementActionsScreen.tsx`, `src/ui/agreements/AgreementActionsController.ts`, `src/ui/agreements/agreementActionsModel.ts`, `src/data/agreementClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- SB07 start-only podršku provesti kroz model/writer/read/UI; ne proširivati samo lokalnu validaciju.

### 12.35. `amendmentReview` — Pregled izmene
**Domena:** Dogovor i izvršenje  
**Postojeća ruta/ulaz:** /dogovor/[id]/izmene  
**Ciljna UX površina:** Review screen / full-height sheet → **amendment**  
**Konsolidaciona odluka:** Važi sada vs predloženo; odgovor druge strane na istom review modelu.  
**Cilj korisnika:** Pošalji ili odgovori na tačno jedan predlog.  
**Publika/kontekst:** Predlagač ili primalac prema stvarnoj verziji  
**Pravilo uloge:** Predlagač: pošalji/povuci. Druga strana: prihvati/odbij. „Predloženo“ nikad vizuelno ne zamenjuje „Važi sada“ pre potvrde.  
**Vizuelni obrazac:** Jedan shared workspace sa role-aware akcijama; važeći uslovi, pending izmena, mesto, tok, poruke i dokazi bez mešanja statusa.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Pregled predloga ili otvorena pending izmena.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Ko predlaže i ko odgovara
- Važi sada / Predloženo
- Razlog ako postoji
- Jedna primarna dozvoljena radnja
- Odbij/Povuci samo odgovarajućem učesniku
**Radnje i odredišta:**
- **Pošalji predlog / Prihvati / Odbij / Povuci** — uslov: Aktuelni review identity/version; actor action; persist-before-send.
  - Potvrđen rezultat: Canonical CONFIRMED/REJECTED/ERROR/UNKNOWN.
  - Vodi na: Prikaži aktuelni Dogovor nakon acknowledge+read
  - Nazad: Back pre dispatch-a isti draft/offer; posle dispatch-a čuva journal.
  - Oporavak: UNKNOWN → read-only refresh istog journal-a; eksplicitni exact retry samo kada owner dopusti. Ne prikazivati rejected kao network grešku.
**Sekundarne radnje:**
- Prikaži aktuelni Dogovor
- Nazad
**Destruktivne radnje:**
- Odbij izmenu ili Povuci predlog samo u pripadajućem stanju, uz jasnu potvrdu
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** UNKNOWN → read-only refresh istog journal-a; eksplicitni exact retry samo kada owner dopusti. Ne prikazivati rejected kao network grešku.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Back pre dispatch-a isti draft/offer; posle dispatch-a čuva journal.  
**Runtime owner porodica:** AGREEMENT_CHANGES  
**Relevantni source ulazi:** `src/app/dogovor/[id]/izmene.tsx`, `src/ui/agreements/AgreementActionsScreen.tsx`, `src/ui/agreements/AgreementActionsController.ts`, `src/ui/agreements/agreementActionsModel.ts`, `src/data/agreementClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Pending izmena ostaje vidljiva obema stranama; stari review nikad ne autorizuje noviju verziju.

### 12.36. `agreementCancel` — Otkaži Dogovor
**Domena:** Dogovor i izvršenje  
**Postojeća ruta/ulaz:** /dogovor/[id]/izmene  
**Ciljna UX površina:** Destructive full-height sheet + final dialog → **agreementDetail**  
**Konsolidaciona odluka:** Razlog je obavezan; ne mešati sa zatvaranjem zadatka.  
**Cilj korisnika:** Otkazivanje jedne saradnje uz jasan razlog.  
**Publika/kontekst:** Učesnik kome server dopušta cancel  
**Vizuelni obrazac:** Jedan shared workspace sa role-aware akcijama; važeći uslovi, pending izmena, mesto, tok, poruke i dokazi bez mešanja statusa.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Amendment/action hub.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Koji Dogovor i osoba
- Kratko šta prestaje i šta ostaje
- Razlog
- Pregled otkazivanja
- Otkaži Dogovor / Nazad na unos
**Radnje i odredišta:**
- **Otkaži Dogovor** — uslov: Server cancel permission + version + nonempty razlog; review identity.
  - Potvrđen rezultat: Canonical cancellation receipt.
  - Vodi na: Aktuelni Dogovor sa otkazivanjem
  - Nazad: Nazad vraća isti neposlat razlog; pending izlaz ne briše journal.
  - Oporavak: Cold journal bez teksta može tražiti isti normalizovan razlog; expired permissions ne resetuju payload.
**Destruktivne radnje:**
- Otkaži Dogovor: agreementChangeService.cancel uz važeći review/version i eksplicitnu potvrdu
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Cold journal bez teksta može tražiti isti normalizovan razlog; expired permissions ne resetuju payload.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Nazad vraća isti neposlat razlog; pending izlaz ne briše journal.  
**Runtime owner porodica:** AGREEMENT_CHANGES  
**Relevantni source ulazi:** `src/app/dogovor/[id]/izmene.tsx`, `src/ui/agreements/AgreementActionsScreen.tsx`, `src/ui/agreements/AgreementActionsController.ts`, `src/ui/agreements/agreementActionsModel.ts`, `src/data/agreementClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Ne mešati otkazivanje Dogovora sa zatvaranjem preostale potrage na zadatku.

### 12.37. `messagesInbox` — Poruke
**Domena:** Poruke i grupa  
**Postojeća ruta/ulaz:** /poruke  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pronađi razgovor po zadatku i publici.  
**Publika/kontekst:** Ovlašćeni učesnik razgovora  
**Vizuelni obrazac:** Thread uvek nosi kontekst Dogovora/zadatka. Ljudske poruke bez AI typewriter efekta; status dostave/čitanja samo iz stvarnog ownera.  
**Ikone:** message line icon  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Tab Poruke.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov i glavni shell
- Zadatak kao glavni naslov reda
- Privatno: osoba; grupa: jasno grupa/publika
- Poslednji dozvoljeni sažetak i poznat unread
- Refresh/page recovery
**Radnje i odredišta:**
- **Otvori razgovor** — uslov: Potvrđen kind i authorized target.
  - Potvrđen rezultat: Pravi privatni ili grupni kontekst.
  - Vodi na: Private /dogovor/[id]?tab=poruke&fromInbox=1; grupa /dogovor/[id]/grupa sa potvrđenim context-om
  - Nazad: Back vraća inbox i položaj; cold fallback /poruke.
  - Oporavak: Nedostupan reader nije prazna lista; permission error briše nedozvoljeni sažetak.
**Sekundarne radnje:**
- Osveži
- Otvori Dogovor
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Još nemaš razgovora. Poruke će biti dostupne u Tvojim Dogovorima.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Nedostupan reader nije prazna lista; permission error briše nedozvoljeni sažetak.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Ne nuditi ulaz u grupu/privatni chat bez prava.
**Povratak i očuvanje:** Back vraća inbox i položaj; cold fallback /poruke.  
**Runtime owner porodica:** CHAT_PRIVATE  
**Relevantni source ulazi:** `src/app/(app)/poruke.tsx`, `src/app/dogovor/[id].tsx`, `src/ui/AgreementChat.tsx`, `src/hooks/useAgreementHistory.ts`, `src/hooks/useAgreementOutbox.ts`, `src/hooks/useAgreementPhotos.ts`, `src/data/agreementOutbox.ts`, `src/data/agreementMessageClientService.ts` …  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Poruke tab zavisi od postojećeg build gate-a; ne prikazivati nefunkcionalnu praznu kopiju inboxa.

### 12.38. `chat` — Privatne poruke
**Domena:** Poruke i grupa  
**Postojeća ruta/ulaz:** /dogovor/[id]  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Dogovori detalje s pravom osobom i razumi da li je poruka stigla.  
**Publika/kontekst:** Potvrđeni učesnici jednog privatnog razgovora  
**Pravilo uloge:** Privatni chat samo učesnicima Dogovora; pre Dogovora ostaje Q&A/ponuda kontekst, ne privatni kontakt.  
**Vizuelni obrazac:** Thread uvek nosi kontekst Dogovora/zadatka. Ljudske poruke bez AI typewriter efekta; status dostave/čitanja samo iz stvarnog ownera.  
**Ikone:** message blue; camera/photo violet; mic teal  
**Mediji:** Poruke podržavaju fotografiju i/ili glas samo kada capability to potvrđuje. Upload uspeh nije isto što i poslata poruka.  
**Ulaz i guard:**
- **Dolazi iz:** Poruke tab u Dogovoru, inbox ili notification target.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Header osoba + naziv task-a, Pregled
- Istorija sa danima i stvarnim statusima
- Nove poruke indikator dok se čita starije
- Očuvan composer iznad tastature
- Fotografija/voice samo gde podržani
- Recovery uz konkretnu poruku; vidljiv refresh
**Radnje i odredišta:**
- **Pošalji** — uslov: Participant send capability; <=2000 codepoint validan sadržaj; immutable draft capture; account+agreement.
  - Potvrđen rezultat: Exact message receipt/body/media identity.
  - Vodi na: Isti thread; scroll na latest samo za sopstvenu novu radnju
  - Nazad: Back iz IME prvo tastatura; tab switch/nested modal čuva draft i anchor.
  - Oporavak: Unknown sačuva istu komandu; read-only check cilj M04; photo upload uspeh nije sent message.
- **Označi stvarno viđeno** — uslov: Foreground+focus+permission; izmereni vidljivi incoming redovi, ne samo loaded history.
  - Potvrđen rezultat: Potvrđen read marker; nema lažnog unread smanjenja.
  - Vodi na: Isti thread
  - Nazad: Ne menja scroll.
  - Oporavak: Unknown marker ne potvrđuje da je druga osoba pročitala.
- **Dodaj fotografiju** — uslov: Aktivno send pravo; limit/asset version; upload journal prethodi I/O.
  - Potvrđen rezultat: Staged asset ili exact sent message receipt.
  - Vodi na: Nazad u isti composer
  - Nazad: Cancel uklanja samo dozvoljeni staged intent, čuva raniji tekst.
  - Oporavak: Unknown čita isti upload; izgubljene bytes nisu dokaz da server nije prihvatio; terminalni chat dozvoljava existing recovery.
**Sekundarne radnje:**
- Dodaj fotografiju
- Glas prema platform/build podršci
- Otvori Pregled
- Proveri ishod — ciljna isključivo read-only radnja, pre konačne implementacije povezati stvarni reconcile handler.
- Ponovi slanje iste poruke — odvojena izričita idempotentna writer radnja; isti clientMessageId i isti payload.
**Destruktivne radnje:**
- Otkaži staged upload kada postojeći owner to dozvoljava; bez lažnog unsend-a potvrđene poruke
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Započni dogovor kroz poruke.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. Read-only exact-message reconciliation M04.
- **unknown:** Unknown sačuva istu komandu; read-only check cilj M04; photo upload uspeh nije sent message. Unknown marker ne potvrđuje da je druga osoba pročitala.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Zatvoren/read-only chat jasno zaključava composer bez brisanja dozvoljene istorije.
**Povratak i očuvanje:** Back iz IME prvo tastatura; tab switch/nested modal čuva draft i anchor. Ne menja scroll.  
**Runtime owner porodica:** CHAT_PRIVATE  
**Relevantni source ulazi:** `src/app/(app)/poruke.tsx`, `src/app/dogovor/[id].tsx`, `src/ui/AgreementChat.tsx`, `src/hooks/useAgreementHistory.ts`, `src/hooks/useAgreementOutbox.ts`, `src/hooks/useAgreementPhotos.ts`, `src/data/agreementOutbox.ts`, `src/data/agreementMessageClientService.ts` …  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Tekst do 2000 znakova prema trenutnom owneru; broj/hint samo kada smislen.
- Tuđe poruke nikada nisu AI typewriter; voice/photo imaju svoju potvrdu.

### 12.39. `groupChat` — Grupni razgovor
**Domena:** Poruke i grupa  
**Postojeća ruta/ulaz:** /dogovor/[id]/grupa  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Koordiniraj više ljudi uz jasnu publiku.  
**Publika/kontekst:** Potvrđeni članovi grupe; upravljanje prema server ulozi  
**Vizuelni obrazac:** Thread uvek nosi kontekst Dogovora/zadatka. Ljudske poruke bez AI typewriter efekta; status dostave/čitanja samo iz stvarnog ownera.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Poruke podržavaju fotografiju i/ili glas samo kada capability to potvrđuje. Upload uspeh nije isto što i poslata poruka.  
**Ulaz i guard:**
- **Dolazi iz:** Dogovor/grupa ili inbox.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Task naslov i Grupni razgovor
- Ko vidi poruke / Učesnici
- Poruke sa autorima i sistemskim događajima
- Text composer samo kada send allowed
- Pending komanda i read-first recovery
**Radnje i odredišta:**
- **Pošalji grupi** — uslov: Fresh membership/canSend; 2000 codepoint; hash-matched pending identity.
  - Potvrđen rezultat: Canonical send receipt, pa read; ista komanda ne šalje opet.
  - Vodi na: Isti group thread
  - Nazad: Back na originalni inbox/Dogovor; draft u memoriji, hash journal bez teksta.
  - Oporavak: Restart može zahtevati identičan tekst; no-access čisti roster/history; transient older-page fail može sačuvati samo authorized memory snapshot.
- **Pročitane vidljive poruke** — uslov: 60% vidljivosti,600ms, foreground i current context.
  - Potvrđen rezultat: Sopstveni read marker potvrđen.
  - Vodi na: Isti thread
  - Nazad: Ne resetuje izabranu history page.
  - Oporavak: Nema mark-all na open i nema izmišljene tuđe potvrde.
**Sekundarne radnje:**
- Pogledaj članove
- Privatni razgovor samo sa potvrđenim dozvoljenim ciljem
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Restart može zahtevati identičan tekst; no-access čisti roster/history; transient older-page fail može sačuvati samo authorized memory snapshot. Nema mark-all na open i nema izmišljene tuđe potvrde.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Grupa nije dostupna ili je terminal read-only; ne otkrivati članove neovlašćenima.
**Povratak i očuvanje:** Back na originalni inbox/Dogovor; draft u memoriji, hash journal bez teksta. Ne resetuje izabranu history page.  
**Runtime owner porodica:** CHAT_GROUP  
**Relevantni source ulazi:** `src/app/dogovor/[id]/grupa.tsx`, `src/ui/groups/GroupConversationScreen.tsx`, `src/ui/groups/GroupConversationController.ts`, `src/data/groupConversationService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Privatni i grupni razgovor imaju različitu publiku i dozvole.
- Trenutni foreground sync8000 ms nije dokaz real-time isporuke; UI ne obećava instant.

### 12.40. `groupParticipants` — Učesnici grupe
**Domena:** Poruke i grupa  
**Postojeća ruta/ulaz:** /dogovor/[id]/grupa  
**Ciljna UX površina:** Bottom sheet → **groupChat**  
**Konsolidaciona odluka:** Spisak učesnika i dozvoljeni ulazi u privatne razgovore.  
**Cilj korisnika:** Proveri ko može da pročita poruku.  
**Publika/kontekst:** Ovlašćeni član grupe  
**Vizuelni obrazac:** Thread uvek nosi kontekst Dogovora/zadatka. Ljudske poruke bez AI typewriter efekta; status dostave/čitanja samo iz stvarnog ownera.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Članovi u group headeru.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naziv grupe i objašnjenje publike
- Potvrđeni članovi/uloge
- Samo dozvoljeni privatni prelazi
- Nazad u grupu
**Radnje i odredišta:**
- **Privatni razgovor** — uslov: Context vraća dozvoljen bilateralni agreementId; worker samo svoj, requester kroz authorized picker.
  - Potvrđen rezultat: Pravi privatni thread.
  - Vodi na: /dogovor/[id]?tab=poruke
  - Nazad: Nazad u istu grupu; draft/anchor ostaje.
  - Oporavak: Stale roster zahteva refresh pre nove privatne navigacije; unauthorized ne otkriva članove.
**Sekundarne radnje:**
- Otvori privatni razgovor samo ako context vraća dozvoljen cilj
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Ne prikazivati zero članova kao potvrđenu grupu pri read-error.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Stale roster zahteva refresh pre nove privatne navigacije; unauthorized ne otkriva članove.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Sakrivena lista i povratak.
**Povratak i očuvanje:** Nazad u istu grupu; draft/anchor ostaje.  
**Runtime owner porodica:** CHAT_GROUP  
**Relevantni source ulazi:** `src/app/dogovor/[id]/grupa.tsx`, `src/ui/groups/GroupConversationScreen.tsx`, `src/ui/groups/GroupConversationController.ts`, `src/data/groupConversationService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Lista je iz group context-a, ne rekonstrukcija iz poslatih poruka ili imena u UI-ju.

### 12.41. `rating` — Oceni saradnju
**Domena:** Dogovor i izvršenje  
**Postojeća ruta/ulaz:** /oceni-dogovor  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Daj jednu trajnu ocenu stvarne saradnje.  
**Publika/kontekst:** Učesnik kome backend dopušta ocenu  
**Vizuelni obrazac:** Jedan shared workspace sa role-aware akcijama; važeći uslovi, pending izmena, mesto, tok, poruke i dokazi bez mešanja statusa.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Dogovor ili lista nakon odgovarajućeg završetka.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Task/osoba iz dozvoljenog context-a
- Zvezdice i smisleni opis
- Opcioni server tagovi
- Komentar samo ako podržan
- Ocena je trajna; Pošalji ocenu
- Miran receipt pri ponovnom otvaranju
**Radnje i odredišta:**
- **Pošalji ocenu** — uslov: Eligible completed agreement + 1..5 + valid tags/commentPolicy; isti frozen attempt.
  - Potvrđen rezultat: Exact reviewId potvrđen context readom.
  - Vodi na: Receipt → Dogovor; invalidate given ratings
  - Nazad: Nazad pre submit-a bez ocene; unknown ne menja broj zvezdica/payload.
  - Oporavak: Refused comment objašnjen; ne šalji rating automatski bez korisničkog komentara kao novu nameru.
**Sekundarne radnje:**
- Nazad na Dogovor
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Refused comment objašnjen; ne šalji rating automatski bez korisničkog komentara kao novu nameru.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Ocena trenutno nije dozvoljena; razlog i povratak u Dogovor.
**Povratak i očuvanje:** Nazad pre submit-a bez ocene; unknown ne menja broj zvezdica/payload.  
**Runtime owner porodica:** RATING  
**Relevantni source ulazi:** `src/app/(app)/oceni-dogovor.tsx`, `src/app/(app)/profil/ocene.tsx`, `src/ui/reviews/AgreementReviewScreen.tsx`, `src/ui/reviews/AgreementReviewPresentation.tsx`, `src/data/reviewCommentsClientService.ts`, `src/data/reviewsClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Ne obećavati javnost komentara ako commentPolicy/reader ne potvrđuje put.
- Primljene/date ocene osvežiti nakon potvrđenog ishoda, ne lokalno uvećati broj bez readback-a.

### 12.42. `ratings` — Ocene
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/ocene  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Razumi primljene i date ocene u pravom kontekstu uloge.  
**Publika/kontekst:** Vlasnik naloga; javni prikaz samo u zasebnom dozvoljenom kontekstu  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** star gold  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Profil.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Prosek/broj sa kontekstom uloge
- Primljene / Date
- Tekst samo ako dozvoljen; task/uloga jasno
- Pagination i nezavisni refresh
**Radnje i odredišta:**
- **Osveži** — uslov: Current account/scope.
  - Potvrđen rezultat: Ponovo pročitani konkretni records.
  - Vodi na: Isti scope/lista
  - Nazad: Back na profil; položaj sačuvan.
  - Oporavak: Retry samo failed reader; posle submit-a invalidirati receipt i kad completed IDs isti.
**Sekundarne radnje:**
- Promeni Primljene/Date
- Osveži
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Još nema ocena u ovom prikazu.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Retry samo failed reader; posle submit-a invalidirati receipt i kad completed IDs isti.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Back na profil; položaj sačuvan.  
**Runtime owner porodica:** RATING  
**Relevantni source ulazi:** `src/app/(app)/oceni-dogovor.tsx`, `src/app/(app)/profil/ocene.tsx`, `src/ui/reviews/AgreementReviewScreen.tsx`, `src/ui/reviews/AgreementReviewPresentation.tsx`, `src/data/reviewCommentsClientService.ts`, `src/data/reviewsClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Public-comment put mora biti stvarno povezan prema SB09; own-profile test nije ceo javni tok.

### 12.43. `qa` — Pitanja o zadatku
**Domena:** Prilike i javni zadatak  
**Postojeća ruta/ulaz:** /pitanja-zadatka  
**Ciljna UX površina:** Embedded section + See all screen → **taskDetail / ownTask**  
**Konsolidaciona odluka:** Pitanja su deo konteksta zadatka; puna lista samo kada je potrebna.  
**Cilj korisnika:** Razjasni posao pre prijave bez privatnog kontakta.  
**Publika/kontekst:** Javni čitalac/pitalac ili vlasnik zadatka prema context-u  
**Vizuelni obrazac:** Lista/mapa istog stanja. Kartice skeniraju naslov, osnovu cene, vreme, približno mesto i ljude; detalj otkriva celu priču.  
**Ikone:** question bubble blue  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Detalj zadatka ili obaveštenje.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Task naslov i važeći kontekst
- Javna pitanja/odgovori
- Moje pending pitanje ili owner red za odgovor odvojeno
- Jedna radnja Postavi pitanje/Odgovori
- Prethodne verzije jasno označene
**Radnje i odredišta:**
- **Postavi pitanje / Odgovori** — uslov: Context dovoljava action, need revision fresh, owned question kad odgovor.
  - Potvrđen rezultat: Composer konkretnog pitanja/odgovora.
  - Vodi na: Ista QA ruta/modal
  - Nazad: Nazad na odgovarajući public/own task; cold fallback poznati task.
  - Oporavak: Read failure nije nema pitanja; unauthorized ne nuditi beskrajni retry.
**Sekundarne radnje:**
- Prethodne verzije jasno odvojene
- Nazad na zadatak
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Još nema objavljenih pitanja i odgovora.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Read failure nije nema pitanja; unauthorized ne nuditi beskrajni retry.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Ovaj sadržaj nije dostupan ovom nalogu; nema endless retry-a koji obećava prava.
**Povratak i očuvanje:** Nazad na odgovarajući public/own task; cold fallback poznati task.  
**Runtime owner porodica:** QA  
**Relevantni source ulazi:** `src/app/(app)/pitanja-zadatka.tsx`, `src/ui/qa/TaskQaScreen.tsx`, `src/data/qaRecoveryClientService.ts`, `src/data/qaSubmissionClientService.ts`, `src/data/preselectionQaClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Odgovor koji menja materijalne uslove vodi na izmenu zadatka, ne javno sitno pojašnjenje.

### 12.44. `qaComposer` — Pitanje ili odgovor
**Domena:** Prilike i javni zadatak  
**Postojeća ruta/ulaz:** /pitanja-zadatka  
**Ciljna UX površina:** Bottom sheet composer → **qa**  
**Konsolidaciona odluka:** Jedno pitanje/odgovor, bez napuštanja konteksta.  
**Cilj korisnika:** Pošalji tekst i razumi obradu i vidljivost.  
**Publika/kontekst:** Ovlašćeni pitalac ili vlasnik koji odgovara  
**Vizuelni obrazac:** Lista/mapa istog stanja. Kartice skeniraju naslov, osnovu cene, vreme, približno mesto i ljude; detalj otkriva celu priču.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** QA action.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Kontekst i publika
- Tekst
- Pošalji
- Processing/ready/committed/rejected/stale odvojeno
- Ako materijalna promena: uredi zadatak
**Radnje i odredišta:**
- **Pošalji pitanje / odgovor** — uslov: Validan text/revision/action; durable opaque identity; no unresolved intent.
  - Potvrđen rezultat: COMMITTED tek kad potvrđen; MATERIAL_CHANGE_REQUIRED vodi edit.
  - Vodi na: Ista QA ili owner task edit path
  - Nazad: Zatvori/Back bez nove komande; pending identity ostaje.
  - Oporavak: Read-before-retry; exact normalized reentry po hash-u; 55s bounded processing nije beskonačan loader.
**Sekundarne radnje:**
- Nazad
- Prikaži obrađeni rezultat
**Destruktivne radnje:**
- Otkaži processing/staged komandu samo gde owner omogućava
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Read-before-retry; exact normalized reentry po hash-u; 55s bounded processing nije beskonačan loader.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Zatvori/Back bez nove komande; pending identity ostaje.  
**Runtime owner porodica:** QA  
**Relevantni source ulazi:** `src/app/(app)/pitanja-zadatka.tsx`, `src/ui/qa/TaskQaScreen.tsx`, `src/data/qaRecoveryClientService.ts`, `src/data/qaSubmissionClientService.ts`, `src/data/preselectionQaClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Materijalna promena nikada ne prolazi kao običan odgovor; vraća u stvarni edit/review tok.

### 12.45. `calendar` — Raspored
**Domena:** Raspored i istorija  
**Postojeća ruta/ulaz:** /raspored  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Vidi potvrđene obaveze bez izmišljanja vremena.  
**Publika/kontekst:** Vlasnik naloga sa sopstvenim Dogovorima i radnim profilom  
**Pravilo uloge:** Pun raspored je primarno za izvršioca. Naručilac termin vidi u svom Dogovoru i Početnoj; ne mora da održava ličnu dostupnost.  
**Vizuelni obrazac:** Worker-centric kalendar; mesec/nedelja/dan + „Bez termina“. Requester vidi termine kroz svoje Dogovore, ne treba pun worker kalendar.  
**Ikone:** calendar blue; availability teal  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Dogovori → Raspored; Profil → Moj raspored. Kontekstualni link uz sledeći Dogovor na Početnoj je REV12 predlog.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov i Danas
- Bez termina: stvarni Dogovori bez prihvaćenog početka
- Mesec / Nedelja / Dan
- Naziv perioda i strelice koje menjaju izabranu jedinicu
- Mesec: grid+izabrani dan; Nedelja: sedam dnevnih pregleda; Dan: satni prikaz+čitljiva lista preklopa
- Dostupnost odvojena od prihvaćenih Dogovora
- Arhiva
**Radnje i odredišta:**
- **Otvori Dogovor / Predloži termin** — uslov: Confirmed agreement ID iz relevantnog scope-a; bezterminski ulaz ima propose guard.
  - Potvrđen rezultat: Detalj ili forma za isti Dogovor.
  - Vodi na: /dogovor/[id]; bez termina → /dogovor/[id]/izmene?start=propose
  - Nazad: Nazad na isti datum/prikaz; cold calendar Back → /dogovori.
  - Oporavak: Optional availability error ne briše Dogovore; ista zona za obe strane.
- **Uredi dostupnost** — uslov: Važeći own worker profile; ne menja accepted agreement schedule.
  - Potvrđen rezultat: AI tema time.
  - Vodi na: /profil/dostupnost → /profil/radnik/razgovor?topic=time
  - Nazad: Nazad u raspored sa istim datumom.
  - Oporavak: Ne preskočiti jedan finalni worker review novim direktnim formularom.
**Sekundarne radnje:**
- Prethodni/sledeći mesec, nedelja ili dan prema prikazu
- Danas
- Promeni dostupnost→/profil/radnik/razgovor?topic=time preko postojećeg alias-a
- Arhiva→/arhiva
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nema potvrđenih Dogovora u prikazanom periodu; ne tvrditi da je korisnik slobodan ili nedostupan. Bez termina i dostupnost imaju zasebno poznato stanje.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Optional availability error ne briše Dogovore; ista zona za obe strane. Ne preskočiti jedan finalni worker review novim direktnim formularom.
- **stale:** Ranije potvrđen raspored može ostati označen dok se osvežava.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Back u izvorni kontekst; cold fallback Dogovori. Promena prikaza zadržava civilni dan. Sačuvati UTC autoritet, srpski display policy,23/25h dane i postojeće version/partial granice.  
**Runtime owner porodica:** CALENDAR_ARCHIVE  
**Relevantni source ulazi:** `src/app/(app)/raspored.tsx`, `src/app/(app)/arhiva.tsx`, `src/data/workerCalendarClientService.ts`, `src/ui/calendar/AgendaScreen.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- workerCalendarClientService.readRange + agreementClientService.mojiDogovori; opcioni availability/profile odvojeno.
- Test sa drugom device TZ; UTC Jest nije dokaz finalnog prikaza.

### 12.46. `archive` — Arhiva
**Domena:** Raspored i istorija  
**Postojeća ruta/ulaz:** /arhiva  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pronađi raniji zapis po njegovom stvarnom tipu.  
**Publika/kontekst:** Vlasnik naloga  
**Vizuelni obrazac:** Worker-centric kalendar; mesec/nedelja/dan + „Bez termina“. Requester vidi termine kroz svoje Dogovore, ne treba pun worker kalendar.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Raspored i postojeći archive ulazi.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov
- Filteri Sve / Dogovori / Zadaci / Prijave
- Vremenski grupisani predmeti sa jasnim tipom i poznatim statusom
- Lokalna greška po reader-u uz sačuvane poznate stavke
**Radnje i odredišta:**
- **Otvori zapis** — uslov: Confirmed ArchiveEntry.kind+id.
  - Potvrđen rezultat: Pravi domain zapis.
  - Vodi na: dogovor→/dogovor/[id]; zadatak→/potrebe/[id]/pregled; prijava→/moje-prijave?prijavaId
  - Nazad: Nazad isti archive scope; cold Back→/raspored.
  - Oporavak: Greška jednog izvora ne briše preostale stavke; retry samo failed resources.
**Sekundarne radnje:**
- Promeni vrstu
- Osveži
- Nazad na raspored
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Arhiva je prazna.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Greška jednog izvora ne briše preostale stavke; retry samo failed resources.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Arhiva je readonly presek više domena. Back u izvor; cold fallback Raspored. Ne nuditi Istekli iz generičkog CLOSED jer mapper ne emituje expired. Novi razlog samo uz potvrđen reader ugovor.  
**Runtime owner porodica:** CALENDAR_ARCHIVE  
**Relevantni source ulazi:** `src/app/(app)/raspored.tsx`, `src/app/(app)/arhiva.tsx`, `src/data/workerCalendarClientService.ts`, `src/ui/calendar/AgendaScreen.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- agreement/application/need service ostaju vlasnici; ne pravi se paralelan archive source-of-truth.

### 12.47. `profile` — Profil
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pružiti jedno mesto za identitet, radnu ponudu i nalog.  
**Publika/kontekst:** Vlasnik istog naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** profile neutral  
**Mediji:** Profilna fotografija; fallback inicijali. Nema dekorativne slike koja imitira verifikaciju.  
**Ulaz i guard:**
- **Dolazi iz:** Avatar u shell header-u.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Identitet, fotografija i mesto
- Potvrđene profilne figure i javni profil; ne izmišljati role ocene ili nule
- Tvoj rad: Radni profil, Moj raspored
- Tvoja aktivnost: Moji zadaci, Moje prijave
- Nalog i pomoć: Podešavanja, Pomoć i podrška
**Radnje i odredišta:**
- **Radni profil** — uslov: Tačan missing/draft/active/suspended status i postojeći owner.
  - Potvrđen rezultat: Postojeći radni profil/pregled/AI ulaz; nema globalne promene requester/worker uloge.
**Sekundarne radnje:**
- Profilna fotografija
- Pogledaj javni profil
- Ocene i saradnje
- Moj raspored→/raspored
- Moji zadaci
- Moje prijave
- Podešavanja
- Pomoć i podrška
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nedostajući radni profil ima jasan početak Opiši šta radite.
- **error:** Identity unavailable nije lažno bezimeni nov nalog.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Stari profil čitljiv samo u dozvoljenom account kontekstu.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Jedan identitet. Povratak na prethodni root, cold fallback Početna. Pouzdanost koristi potvrđenu postojeću metriku i ima vidljivo objašnjenje; nedostajući podaci nisu0.  
**Runtime owner porodica:** PROFILE  
**Relevantni source ulazi:** `src/app/(app)/profil.tsx`, `src/app/(app)/profil/podaci.tsx`, `src/app/(app)/profil/fotografija.tsx`, `src/app/(app)/profil/radnik.tsx`, `src/app/(app)/profil/lokacija.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Status radnog profila nije globalna uloga; osnovni nalog ostaje isti.

### 12.48. `personal` — Lični podaci
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/podaci  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Urediti osnovni javni identitet bez mešanja različitih upisa.  
**Publika/kontekst:** Vlasnik naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Profilna fotografija; fallback inicijali. Nema dekorativne slike koja imitira verifikaciju.  
**Ulaz i guard:**
- **Dolazi iz:** Profil ili Podešavanja.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Fotografija sa radnjom Promeni fotografiju.
- Ime za prikaz kao jedino lokalno tekstualno polje za ovu komandu.
- Javni opis i Područje rada kao redovi ka AI temi.
- Ko ovo vidi i Pregledaj javni profil.
- Sačuvaj ime pojavljuje se uz stvarnu izmenu; delimičan rezultat ostaje uz polje.
**Radnje i odredišta:**
- **Sačuvaj ime**
  - Nazad: dirty povratak pita; u toku ne predstavlja zahtev kao odbačen
- **Uredi javni opis**
  - Nazad: isti osnovni profil
**Sekundarne radnje:**
- Promeni fotografiju
- Uredi javni opis kroz AI temu
- Područje rada kroz AI temu
- Pregledaj javni profil
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, rev12_specific, partial  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Pokazati koji deo je sačuvan, bez duplog pisanja potvrđenog dela.
- **unknown:** Proveriti oba postojeća ishoda i nastaviti samo nedostajući.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** dirty povratak pita; u toku ne predstavlja zahtev kao odbačen; RAM ime; komande po postojećim ownerima  
**Runtime owner porodica:** PROFILE  
**Relevantni source ulazi:** `src/app/(app)/profil.tsx`, `src/app/(app)/profil/podaci.tsx`, `src/app/(app)/profil/fotografija.tsx`, `src/app/(app)/profil/radnik.tsx`, `src/app/(app)/profil/lokacija.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Dva imena se ne razilaze neprimetno posle remount-a; sačuvana vrednost čita se od autoriteta.

### 12.49. `avatar` — Fotografija profila
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/fotografija  
**Ciljna UX površina:** Photo picker/editor sheet → **personal / profile**  
**Konsolidaciona odluka:** Fotografija profila je podtok ličnih podataka.  
**Cilj korisnika:** Izabrati i potvrditi jednu profilnu sliku.  
**Publika/kontekst:** Vlasnik naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Profilna fotografija; fallback inicijali. Nema dekorativne slike koja imitira verifikaciju.  
**Ulaz i guard:**
- **Dolazi iz:** Profil fotografija.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Trenutna fotografija ili potvrđeni inicijali/silueta
- Izbor fotografije i stvarno normalizovan lokalni pregled
- Eksplicitno čuvanje ili uklanjanje
- Unknown upload/apply status sa istim identitetom
**Radnje i odredišta:**
- **Sačuvaj fotografiju**
  - Nazad: pre slanja odbaci samo lokalni izbor; ne tvrdi prekid već poslate komande
- **Proveri ishod**
  - Nazad: slika ne nestaje bez razloga
**Sekundarne radnje:**
- Izaberi drugu fotografiju
- Ukloni postojeću fotografiju uz potvrdu
**Destruktivne radnje:**
- Ukloni fotografiju: clearAvatar uz jasnu potvrdu; discardAvatar za staged resurs
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, rev12_specific  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Proveri prethodni upload/postavljanje; novi izbor ne prepisuje nerazrešeni pokušaj.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Dozvola objašnjena, postojeći avatar ostaje.
**Povratak i očuvanje:** pre slanja odbaci samo lokalni izbor; ne tvrdi prekid već poslate komande; stage journal ID; lokalni bajtovi ne preživljavaju svaki blur  
**Runtime owner porodica:** PROFILE  
**Relevantni source ulazi:** `src/app/(app)/profil.tsx`, `src/app/(app)/profil/podaci.tsx`, `src/app/(app)/profil/fotografija.tsx`, `src/app/(app)/profil/radnik.tsx`, `src/app/(app)/profil/lokacija.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Pravi avatar-specifični cancel/reconcile prema SB05; gubitak lokalnih bajtova ima jasan izlaz.

### 12.50. `workerProfile` — Radni profil
**Domena:** Želim da uskočim — radni profil  
**Postojeća ruta/ulaz:** /profil/radnik  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Verno prikazati šta je sačuvano, aktivno i spremno po svakoj usluzi.  
**Publika/kontekst:** Vlasnik radne ponude  
**Pravilo uloge:** Vlasnik uređuje; javni čitalac koristi publicProfile. Usluga, način rada, predaja i područje su per-service gde ugovor tako zahteva.  
**Vizuelni obrazac:** Profil po usluzi; jasne kartice usluga sa načinom rada/područjem/dostupnošću. AI samo za uređivanje, ne za čitanje profila.  
**Ikone:** profile/work teal  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Profil, sačuvan review ili activation ulaz.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Ime i status trajnog profila: DRAFT/ACTIVE/SUSPENDED
- Svaka sačuvana usluga sa sopstvenim mode binding-om, predajom i readiness stanjem
- Sačuvana područja za dolazak
- Sačuvana dostupnost, posebni datumi i zaseban ulaz u dogovorene obaveze
- Glavna radnja prema potvrđenom stanju
- Usluge, Područje rada i Dostupnost vode u odgovarajuću AI temu
**Radnje i odredišta:**
- **Uredi kroz razgovor**
  - Nazad: Povratak obnavlja saved reader i scroll
- **Pregled za aktivaciju**
  - Nazad: Ne menja profil sam ulaz
- **Koristi ime naloga**
  - Nazad: Ostale činjenice ne šalje
**Sekundarne radnje:**
- Usluge
- Područje
- Dostupnost
- Pregledaj konkretan pending status
**Destruktivne radnje:**
- Deaktivacija samo kroz postojeću dozvoljenu komandu i potvrdu; ne kao posledica activate=false Save-a
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Još nisi sastavili radnu ponudu. Opiši šta radite.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Prethodni Save/activation se pomiruje pre nove radnje.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Profil čita autoritativni sačuvani prikaz sa kanonskim per-service binding-om. Ne rekonstruiše javne činjenice iz starog lokalnog review-a niti iz globalnog workModes skupa. Posle Save-a vratiti kontekst/scroll; nakon novog edit ulaza koristiti važeću konverzaciju nad sačuvanim profilom.  
**Runtime owner porodica:** PROFILE  
**Relevantni source ulazi:** `src/app/(app)/profil.tsx`, `src/app/(app)/profil/podaci.tsx`, `src/app/(app)/profil/fotografija.tsx`, `src/app/(app)/profil/radnik.tsx`, `src/app/(app)/profil/lokacija.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- BOTH potpun očekivani skup istog serviceId; jedna uspešna grana ne daje lažnu kompletnu spremnost.

### 12.51. `workerLocation` — Područje rada
**Domena:** Želim da uskočim — radni profil  
**Postojeća ruta/ulaz:** /profil/lokacija  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Urediti stvarno područje kroz postojeći razgovor ili dozvoljeno potvrditi približnu tačku.  
**Publika/kontekst:** Vlasnik radnog profila  
**Vizuelni obrazac:** Profil po usluzi; jasne kartice usluga sa načinom rada/područjem/dostupnošću. AI samo za uređivanje, ne za čitanje profila.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Radni profil tema Područje.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Trenutna potvrđena područja
- Izmeni kroz AI
- Približna mapa samo u dozvoljenoj ON_SITE grani
- Kratko objašnjenje svrhe tačke
- Potvrdi tačku kada relevantno
**Radnje i odredišta:**
- **Izmeni područje**
  - Nazad: Isti razgovor
- **Potvrdi približnu tačku**
  - Nazad: Ne rebazuje stari AI review
**Sekundarne radnje:**
- Nazad na radni profil
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Proveriti istu point komandu; ne izgubiti postojeća workAreas.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Ručni izbor ostaje ako moguć; REMOTE ne dobija obaveznu mapu.
**Povratak i očuvanje:** Administrativni grad, područja dolaska i približna tačka imaju različitu svrhu. Point save menja source hash i čini stari AI pregled zastarelim; ne rebase-ovati zamrznuti review. CITY, RADIUS i COUNTRY ostaju različiti, više područja se ne svodi na legacy jedno.  
**Runtime owner porodica:** PROFILE  
**Relevantni source ulazi:** `src/app/(app)/profil.tsx`, `src/app/(app)/profil/podaci.tsx`, `src/app/(app)/profil/fotografija.tsx`, `src/app/(app)/profil/radnik.tsx`, `src/app/(app)/profil/lokacija.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Više područja se ne svodi tiho na legacy jedno područje; sačuvati potvrđenu semantiku.

### 12.52. `workerAvailability` — Dostupnost
**Domena:** Želim da uskočim — radni profil  
**Postojeća ruta/ulaz:** /profil/dostupnost  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Urediti vreme rada u prirodnoj temi uz očuvanje ostatka profila.  
**Publika/kontekst:** Vlasnik radnog profila  
**Vizuelni obrazac:** Profil po usluzi; jasne kartice usluga sa načinom rada/područjem/dostupnošću. AI samo za uređivanje, ne za čitanje profila.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Radni profil ili Raspored.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Trenutno potvrđeno vreme
- Kratak ulaz u temu
- Opiši promenu
- Nastavi u AI pregled
**Radnje i odredišta:**
- **Izmeni dostupnost**
  - Nazad: Vraća saved profil; nema toasta Sačuvano pre Save
- **Sačuvaj vreme**
  - Nazad: Dogovoreni termini ostaju obaveze
**Sekundarne radnje:**
- Nazad na profil
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Vreme nije navedeno, bez izmišljene stalne dostupnosti.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Mogu odmah važi do eksplicitnog isključenja. Parcijalna izmena dana čuva ostale dane i izuzetke. Dogovoreni termini ostaju zasebne obaveze. Back iz teme ne prikazuje Sačuvano ako nije potvrđen Save.  
**Runtime owner porodica:** PROFILE  
**Relevantni source ulazi:** `src/app/(app)/profil.tsx`, `src/app/(app)/profil/podaci.tsx`, `src/app/(app)/profil/fotografija.tsx`, `src/app/(app)/profil/radnik.tsx`, `src/app/(app)/profil/lokacija.tsx`, `src/app/(app)/profil/dostupnost.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Vremenske zone/TODAY prate postojeći area/time ugovor; ne konvertovati ugovoreni instant proizvoljno.

### 12.53. `settings` — Podešavanja
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/podesavanja  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pronaći nalog, komunikaciju, podatke i pomoć u jasnoj hijerarhiji.  
**Publika/kontekst:** Vlasnik naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** gear neutral  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Profil.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Nalog: Lični podaci, Pristup nalogu
- Tvoje iskustvo: AI razgovori, Obaveštenja, Privatnost i podaci
- Pomoć: Pomoć i podrška, Prijavi grešku, Pravila i saglasnosti, O aplikaciji
- Odjava izdvojena od navigacionih redova
**Radnje i odredišta:**
- **Otvori izabrano podešavanje** — uslov: Postojeća dostupna ruta i account kontekst.
  - Potvrđen rezultat: Jedna jasna destinacija po redu; nema zajedničkog Sačuvaj na hub-u.
**Sekundarne radnje:**
- Pomoć i podrška
- O aplikaciji
- Odjavi se
**Destruktivne radnje:**
- Odjavi se uz obradu aktivnih/unknown radnji prema auth/session owneru
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Link ne sme voditi na praznu nepostojeću rutu.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Back→Profil. Odjava čisti privatni prikaz prema owner-u; ne tvrdi da je unknown server upis poništen. Pojedinačne forme zadržavaju svoje dirty/receipt/readback granice.  
**Runtime owner porodica:** SETTINGS  
**Relevantni source ulazi:** `src/app/(app)/profil/podesavanja.tsx`, `src/app/(app)/profil/obavestenja.tsx`, `src/app/(app)/profil/lozinka.tsx`, `src/app/(app)/profil/o-aplikaciji.tsx`, `src/ui/notifications/PushPreferences.tsx`, `src/data/notificationPreferencesClientService.ts`, `src/data/passwordChangeClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Jedna semantička 2.5D ikona od 32–36 dp po stavci prema registru; back/close/chevron su jednostavne vektorske kontrole.

### 12.54. `password` — Promeni lozinku
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/lozinka  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Promeniti lozinku uz istinit ishod.  
**Publika/kontekst:** Prijavljen vlasnik naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Podešavanja.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Trenutna lozinka, nova lozinka, potvrda.
- Jedna radnja Sačuvaj novu lozinku.
- Greška uz konkretno polje ili nepoznat ishod sa sledećim korakom.
**Radnje i odredišta:**
- **Sačuvaj novu lozinku**
  - Nazad: tajne se brišu pri izlasku; nema obećanja durable drafta
**Sekundarne radnje:**
- Nazad
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, rev12_specific  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Konkretna bezbedna poruka kod polja; bez dump-a server payload-a.
- **unknown:** Ne prikazati promenjeno dok service ne potvrdi; ponuditi postojeći način provere/oporavka.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** tajne se brišu pri izlasku; nema obećanja durable drafta; lozinke samo RAM, nikad u review journal  
**Runtime owner porodica:** SETTINGS  
**Relevantni source ulazi:** `src/app/(app)/profil/podesavanja.tsx`, `src/app/(app)/profil/obavestenja.tsx`, `src/app/(app)/profil/lozinka.tsx`, `src/app/(app)/profil/o-aplikaciji.tsx`, `src/ui/notifications/PushPreferences.tsx`, `src/data/notificationPreferencesClientService.ts`, `src/data/passwordChangeClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Ne hardcode-ovati nova pravila lozinke mimo aktivnog ugovora.

### 12.55. `permissions` — Dozvole uređaja
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/podesavanja  
**Ciljna UX površina:** Contextual education + OS settings → **settings**  
**Konsolidaciona odluka:** Dozvolu tražiti u trenutku potrebe; ekran služi samo za pregled/status.  
**Cilj korisnika:** Razumljivo oporaviti konkretno odbijenu OS dozvolu.  
**Publika/kontekst:** Korisnik pogođene funkcije  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Kontekstualni PermissionRecovery; podešavanja samo ako postojeći ulaz postoji.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naziv funkcije
- Zašto je dozvola potrebna
- Stvarno OS stanje
- Otvori podešavanja kada blokirano
- Alternativni ručni/tekstualni put
**Radnje i odredišta:**
- **Dozvoli / Otvori podešavanja** — uslov: Stvaran OS permission status i podržana platforma.
  - Potvrđen rezultat: Postojeći permission owner; ponovni read pri povratku.
**Sekundarne radnje:**
- Nastavi bez dozvole gde funkcija ima alternativu
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Proveravamo dozvolu, bez prikaza zelenog statusa unapred.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Razlikovati denied/canAskAgain/permanentlyDenied iz stvarnog API-ja.
**Povratak i očuvanje:** Vraćanje iz OS settings ne pretpostavlja da je dozvola odobrena.  
**Runtime owner porodica:** None  
**Relevantni source ulazi:** `src/app/(app)/profil/podesavanja.tsx`, `src/data/authClientService.ts`, `src/data/buildIdentity.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Lokacija, mikrofon, fotografije i push imaju zasebnu svrhu i gate; ne tražiti sve na welcome-u.

### 12.56. `notifications` — Obaveštenja
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /obavestenja  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Razumeti događaj i doći do tačne radnje.  
**Publika/kontekst:** Vlasnik inbox događaja  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** bell orange  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Bell ili push/native ingress.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Sve / Moji zadaci / Moje prijave kao filteri sadržaja.
- Grupe Danas, Juče, datum.
- Događaj + naslov zadatka ako potvrđen + vreme + jedno odredište.
- Nepročitano je dot+reči, ne samo boja.
- Označi sve i pristupačna pojedinačna radnja.
**Radnje i odredišta:**
- **Otvori događaj**
  - Nazad: isti filter/pozicija; unavailable ostaje objašnjen u listi
- **Označi kao pročitano**
  - Nazad: ne otvara sadržaj
**Sekundarne radnje:**
- Podešavanja obaveštenja
- Označi pročitano prema stvarnom owneru
- Osveži
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, rev12_specific  
- **empty:** Nemaš novih obaveštenja, tek nakon uspešnog read-a.
- **error:** Cilj nije dostupan: jasno objasniti i ponuditi relevantan dozvoljen povratak.
- **unknown:** Resolver još nije potvrdio cilj; ne otvoriti nasumičan zadatak/listu kao da je to isti događaj.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** isti filter/pozicija; unavailable ostaje objašnjen u listi; read ack događaja nije automatski read poruka  
**Runtime owner porodica:** NOTIFICATIONS  
**Relevantni source ulazi:** `src/app/obavestenja.tsx`, `src/hooks/useInbox.ts`, `src/data/inboxClientService.ts`, `src/data/activityMessageTargetService.ts`, `src/data/activityApplicationTargetService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Poruke inbox i activity inbox su različite površine.
- Read/markAll samo stvarnim potvrđenim ownerom; suppression/dupliranje/kapacitet reda ostaju R09/F20.

### 12.57. `notificationPreferences` — Obaveštenja — podešavanja
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/obavestenja  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Izabrati šta stiže i povezati ovaj telefon.  
**Publika/kontekst:** Vlasnik naloga u oba konteksta  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Gear iz Obaveštenja ili Podešavanja.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Ovaj telefon: dozvola i povezivanje.
- Kad objavljuješ i Kad uskačeš u jednom ekranu.
- Tihi sati sa lokalno razumljivom zonom.
- Napredno: kategorije, in-app izbor, poslednja provera slanja.
- Sačuvaj izmene samo kada postoji izmena; delimičan/unknown outcome ostaje vidljiv.
**Radnje i odredišta:**
- **Poveži ovaj telefon**
  - Nazad: Ne sada ostavlja izbor; već poslato se proverava
- **Sačuvaj izmene**
  - Nazad: eksplicitna writing politika, bez tihog gubitka
**Sekundarne radnje:**
- Saznajte šta izbor znači
- OS dozvola odvojeno
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, rev12_specific, writing_exit  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Povratak switch-a/partial status prema stvarnom ishodu, bez tihog gubitka.
- **unknown:** Proveri koji deo je sačuvan i nastavi samo nedostajući.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Ne sada ostavlja izbor; već poslato se proverava; postojeći server preferences i device; lokalni draft RAM  
**Runtime owner porodica:** SETTINGS  
**Relevantni source ulazi:** `src/app/(app)/profil/podesavanja.tsx`, `src/app/(app)/profil/obavestenja.tsx`, `src/app/(app)/profil/lozinka.tsx`, `src/app/(app)/profil/o-aplikaciji.tsx`, `src/ui/notifications/PushPreferences.tsx`, `src/data/notificationPreferencesClientService.ts`, `src/data/passwordChangeClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Tekst Ostalo zameniti konkretnim objašnjenjem postojećih događaja, ne izmišljanjem nove preference.

### 12.58. `privacy` — Privatnost i podaci
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/privatnost  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Naći ko vidi podatke i kontrolu koja je potrebna.  
**Publika/kontekst:** Vlasnik naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** shield violet/green  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Podešavanja/podrška.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Ko šta vidi otvara kratko objašnjenje publike.
- Rokovi čuvanja sa potvrđenim pravilima i zasebnim statusom izvršenja.
- Izvoz podataka, Blokirane osobe, Pravila i saglasnosti.
- Zatvaranje naloga na kraju.
**Radnje i odredišta:**
- **Ko šta vidi**
  - Nazad: povratak u isti red
- **Rokovi čuvanja**
  - Nazad: zatvori bez komande
**Sekundarne radnje:**
- Podrška kada relevantna
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, rev12_specific  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** povratak u isti red; bez novih grantova  
**Runtime owner porodica:** PRIVACY  
**Relevantni source ulazi:** `src/app/(app)/profil/privatnost.tsx`, `src/app/(app)/profil/pravna.tsx`, `src/app/(app)/profil/izvoz.tsx`, `src/ui/closure/ClosureDialog.tsx`, `src/data/retentionPolicyClientService.ts`, `src/data/legalClientService.ts`, `src/data/dataExportClientService.ts`, `src/data/accountClosureClientService.ts` …  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- F21 privatne kolone i R10 export/closure gates ostaju netaknuti.

### 12.59. `privacyWho` — Ko šta vidi
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/privatnost  
**Ciljna UX površina:** Informational bottom sheet → **privacy**  
**Konsolidaciona odluka:** Kratko objašnjenje publike i granica.  
**Cilj korisnika:** Kratko razdvojiti javne podatke od posebno autorizovanih.  
**Publika/kontekst:** Vlasnik naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Info kontrola u privatnosti.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Javno: opis objavljenog zadatka i približno mesto po stvarnoj projekciji
- Ovlašćenim učesnicima: tačna lokacija kada odobrena
- Dogovor kroz poruke
- Rad na daljinu/predaja prema stvarnom ugovoru
- Zatvori
**Radnje i odredišta:**
- **Razumem** — uslov: Read-only objašnjenje.
  - Potvrđen rezultat: Zatvoriti modal i vratiti fokus.
**Sekundarne radnje:**
- Otvori važeću Politiku privatnosti
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nije relevantno; objašnjenje je lokalni odobreni copy uz verzionisana pravila.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Nema persistent writer-a; otvaranje nije saglasnost.  
**Runtime owner porodica:** PRIVACY  
**Relevantni source ulazi:** `src/app/(app)/profil/privatnost.tsx`, `src/app/(app)/profil/pravna.tsx`, `src/app/(app)/profil/izvoz.tsx`, `src/ui/closure/ClosureDialog.tsx`, `src/data/retentionPolicyClientService.ts`, `src/data/legalClientService.ts`, `src/data/dataExportClientService.ts`, `src/data/accountClosureClientService.ts` …  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Kontakt ne obećava PHONE reveal; REMOTE ne izjednačavati sa zabranom svake adrese/predaje.

### 12.60. `retention` — Rokovi čuvanja
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/privatnost  
**Ciljna UX površina:** Inline expandable section / detail sheet → **privacy**  
**Konsolidaciona odluka:** Ne zauzima primarnu navigaciju.  
**Cilj korisnika:** Prikazati stvarno važeća pravila čuvanja ili poštenu nedostupnost.  
**Publika/kontekst:** Vlasnik naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Accordion u privatnosti.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Status policy-ja
- Kategorije i stvarni rokovi kada objavljeni
- Link na važeći dokument
- Odgovarajući retry/povratak
**Radnje i odredišta:**
- **Proveri stanje kada smisleno** — uslov: Reader status dozvoljava osvežavanje.
  - Potvrđen rezultat: retentionPolicyClientService.readStatus/readExecutionStatus.
**Sekundarne radnje:**
- Zatvori odeljak
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Rokovi čuvanja trenutno nisu dostupni.
- **error:** Rokovi čuvanja nisu učitani. Pokušaj ponovo. Ne izjednačavati read-error sa potvrđeno neobjavljenom politikom.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Policy mismatch se jasno prikazuje; ne koristiti staru verziju za novu saglasnost.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Ostaje unutar istog ekrana; ne resetovati scroll pri expanded promeni.  
**Runtime owner porodica:** PRIVACY  
**Relevantni source ulazi:** `src/app/(app)/profil/privatnost.tsx`, `src/app/(app)/profil/pravna.tsx`, `src/app/(app)/profil/izvoz.tsx`, `src/ui/closure/ClosureDialog.tsx`, `src/data/retentionPolicyClientService.ts`, `src/data/legalClientService.ts`, `src/data/dataExportClientService.ts`, `src/data/accountClosureClientService.ts` …  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Ne izmišljati broj dana ili automatsko brisanje koje nije efektivno.

### 12.61. `legal` — Pravila i saglasnosti
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/pravna  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pronaći važeće dokumente i pravi status prihvatanja.  
**Publika/kontekst:** Vlasnik naloga; auth pravni read gde dozvoljen  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Podešavanja, privatnost, About ili auth.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Lista dokumenata
- Naziv/verzija/datum iz bundle-a
- Status saglasnosti
- Otvori dokument
- Prikaz nedostupnosti umesto lažnog sadržaja
**Radnje i odredišta:**
- **Pročitaj dokument** — uslov: Važeći legal bundle i dozvoljeni dokument.
  - Potvrđen rezultat: Otvoriti stvaran tekst/paket i povezati sa read statusom.
**Sekundarne radnje:**
- Pokušaj ponovo za prolazni read failure
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, unpublished, reader_error  
- **empty:** Samo potvrđen UNPUBLISHED: Dokumenti još nisu objavljeni. Nema kontrole prihvatanja.
- **error:** Reader ERROR: Dokumenti nisu učitani. Pokušaj ponovo. Ne tvrditi da dokumenti nisu objavljeni.
- **unknown:** Proveravamo dostupnost dokumenata. Ne pretpostavljati ni objavljenu ni neobjavljenu verziju.
- **stale:** Nova verzija zahteva novi stvarni pregled; stari acceptance nije prenosiv.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Čitanje i prihvatanje su različite radnje; vraćanje ne označava automatski prihvaćeno.  
**Runtime owner porodica:** PRIVACY  
**Relevantni source ulazi:** `src/app/(app)/profil/privatnost.tsx`, `src/app/(app)/profil/pravna.tsx`, `src/app/(app)/profil/izvoz.tsx`, `src/ui/closure/ClosureDialog.tsx`, `src/data/retentionPolicyClientService.ts`, `src/data/legalClientService.ts`, `src/data/dataExportClientService.ts`, `src/data/accountClosureClientService.ts` …  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- SB03 READ_REQUIRED ima upotrebljiv nastavak i eksplicitan nov pristanak.

### 12.62. `legalConsent` — Pregled i prihvatanje dokumenta
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/pravna  
**Ciljna UX površina:** Full-screen document → **legal**  
**Konsolidaciona odluka:** Dokument mora imati verziju, scroll i jasan acceptance state.  
**Cilj korisnika:** Prihvatiti baš pregledani važeći dokument.  
**Publika/kontekst:** Korisnik kome je saglasnost potrebna  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Otvoreni legal dokument/READ_REQUIRED.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naziv i verzija
- Čitljiv skrolabilni ceo važeći tekst
- Sažetak onoga što se prihvata
- Prihvati kada stvarni ugovor dopušta
- Povratak bez lažnog prihvatanja
**Radnje i odredišta:**
- **Prihvati** — uslov: Odgovarajući pročitan bundle/hash i važeća revizija.
  - Potvrđen rezultat: legalClientService.acceptReviewedBundle; readAcceptance potvrđuje tačan ishod.
**Sekundarne radnje:**
- Nazad na dokumente
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Dokument se promenio: otvori aktuelnu verziju.
- **unknown:** Proveravamo saglasnost sa istim paketom; ne novi acceptance druge verzije.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Tok ne sme izgubiti koji dokument je pročitan između prikaza i komande.  
**Runtime owner porodica:** PRIVACY  
**Relevantni source ulazi:** `src/app/(app)/profil/privatnost.tsx`, `src/app/(app)/profil/pravna.tsx`, `src/app/(app)/profil/izvoz.tsx`, `src/ui/closure/ClosureDialog.tsx`, `src/data/retentionPolicyClientService.ts`, `src/data/legalClientService.ts`, `src/data/dataExportClientService.ts`, `src/data/accountClosureClientService.ts` …  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Ne zatvarati pravni gate pomoću lokalnog accepted boolean-a.

### 12.63. `export` — Kopija Tvojih podataka
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/izvoz  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Zatražiti i preuzeti sopstvenu kopiju podataka.  
**Publika/kontekst:** Vlasnik naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Privatnost i podaci.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Jedna kratka svrha pre zahteva.
- Posle zahteva: status, datum i stvarne faze Zahtev/Priprema/Preuzimanje.
- Spremna kopija: format, veličina i rok.
- Jedna primarna radnja po fazi; otkazivanje/opoziv odvojeno.
**Radnje i odredišta:**
- **Zatraži kopiju**
  - Nazad: ne otvara novi ID za timeout
- **Preuzmi kopiju**
  - Nazad: otkazivanje izbora foldera nije failed export
**Sekundarne radnje:**
- Proveri stanje
- Podrška kada relevantna
**Destruktivne radnje:**
- Otkaži ili opozovite kopiju samo u dozvoljenom stanju: cancelExport/revokeExport
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, not_available, request_failed, status_read_error, rev12_specific, requested, processing, ready_available, ready_unavailable, expired, cancelled, download_started  
- **empty:** Nisi tražili kopiju podataka, samo nakon potvrđenog praznog statusa.
- **error:** Read-error i policy-unpublished imaju različit naslov i sledeći korak.
- **unknown:** Postojeći request/command ishod nije poznat. Proveravamo prethodni zahtev, sa istim identitetom; nije ni FAILED ni NOT_AVAILABLE.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Izvoz trenutno nije dostupan zbog stvarne kapije, bez tvrdnje da se može forsirati.
**Povratak i očuvanje:** ne otvara novi ID za timeout; trenutni request ref nije durable; dodatna orkestracija/journal implementaciona delta  
**Runtime owner porodica:** PRIVACY  
**Relevantni source ulazi:** `src/app/(app)/profil/privatnost.tsx`, `src/app/(app)/profil/pravna.tsx`, `src/app/(app)/profil/izvoz.tsx`, `src/ui/closure/ClosureDialog.tsx`, `src/data/retentionPolicyClientService.ts`, `src/data/legalClientService.ts`, `src/data/dataExportClientService.ts`, `src/data/accountClosureClientService.ts` …  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- F19 workAreas u svim kopijama/projekcijama; novi izgled ne otvara zabranjen gate.

### 12.64. `closure` — Zatvaranje naloga
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/privatnost, modal:ClosureEntry  
**Ciljna UX površina:** Full-screen destructive flow → **privacy**  
**Konsolidaciona odluka:** Višekorakna provera obaveza i unknown recovery.  
**Cilj korisnika:** Jasno pokazati prepreke, posledice i stvarni napredak zatvaranja.  
**Publika/kontekst:** Vlasnik naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Privatnost: ClosureEntry full-screen modal.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov i kratak smisao
- Potvrđene obaveze/blokade
- Pregled posledica kada spreman
- Eksplicitna nepovratna potvrda tek u dozvoljenoj fazi
- Stvarni status obrade
**Radnje i odredišta:**
- **Pregledaj zatvaranje / Proveri stanje** — uslov: Važeći policy/closure review i stvarni dozvoljeni koraci.
  - Potvrđen rezultat: accountClosureClientService.prepare, closureExecutionClientService.review/read.
**Sekundarne radnje:**
- Otvori potvrđene obaveze
- Nazad kada dozvoljeno
**Destruktivne radnje:**
- Zatvori nalog: closureExecutionClientService.start tek uz konkretan review/hash i eksplicitnu potvrdu
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, obligations_blocked, preview_error, policy_not_available  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Held/failed ima konkretnu dozvoljenu akciju, bez lažnog izbrisano.
- **unknown:** Prethodni start nije potvrđen: Proveri ishod iste operacije; ne pokretati novi start i ne prikazivati nalog zatvorenim.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Zatvaranje naloga trenutno nije dostupno. Tvoj nalog i podaci ostaju sačuvani, ako to stvarno stanje potvrđuje.
**Povratak i očuvanje:** Prepare nije zatvaranje. Pending/held/failed/complete se čitaju od autoriteta; Back ne poništava remote start.  
**Runtime owner porodica:** PRIVACY  
**Relevantni source ulazi:** `src/app/(app)/profil/privatnost.tsx`, `src/app/(app)/profil/pravna.tsx`, `src/app/(app)/profil/izvoz.tsx`, `src/ui/closure/ClosureDialog.tsx`, `src/data/retentionPolicyClientService.ts`, `src/data/legalClientService.ts`, `src/data/dataExportClientService.ts`, `src/data/accountClosureClientService.ts` …  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Postojeći full-screen modal je stvarna površina iako nema poseban URL.
- Pravne/private/export/closure kapije ostaju efektivne.

### 12.65. `blocked` — Blokirane osobe
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/blokirani  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pregledati svoje blokade i dozvoljeno odblokirati konkretnu osobu.  
**Publika/kontekst:** Vlasnik outgoing block liste  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Privatnost ili podrška.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov
- Kompaktna prazna ilustracija ili stvarna lista
- Dozvoljeni identitet
- Odblokiraj
- Kratko objašnjenje efekta
**Radnje i odredišta:**
- **Odblokiraj** — uslov: Sopstveni potvrđeni outgoing block i važeći target.
  - Potvrđen rezultat: safetyClientService.setBlock/readBlock; potvrđen receipt/readback.
**Sekundarne radnje:**
- Nazad
- Otvori bezbednosnu pomoć
**Destruktivne radnje:**
- Odblokiranje ima eksplicitnu potvrdu promene; nema automatskog safety report-a
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nemaš blokiranih osoba.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Proveravamo promenu blokiranja.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Ne otkrivati da je druga osoba blokirala Tebe; incoming block ostaje privatan.
**Povratak i očuvanje:** ListMyBlocks je autoritet; unknown proverava isti target/command.  
**Runtime owner porodica:** SAFETY  
**Relevantni source ulazi:** `src/app/(app)/bezbednost.tsx`, `src/app/(app)/profil/blokirani.tsx`, `src/ui/safety/SafetyScreen.tsx`, `src/data/safetyClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Blokiranje i prijava su odvojeni ishodi; receipt izveštaja znači prijem, ne rešenje.
- Odblokiranje ne vraća automatski ranije povučenu lokacijsku saglasnost.

### 12.66. `safety` — Prijavi ili blokirajte
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /bezbednost  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Prijaviti ponašanje i zasebno upravljati kontaktom sa osobom.  
**Publika/kontekst:** Ovlašćeni korisnik sa stvarnim target kontekstom  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** shield/warning coral  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Profil/zadatak/Dogovor prema source ulazima.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Tačno potvrđena osoba/kontekst ili pošten generički naziv.
- Blokiranje i posledica, bez obaveznog povezivanja sa prijavom.
- Privatna prijava: kategorija, kratak razlog, opcioni opis.
- Potvrda prijema; pristup podršci za drugo pitanje.
**Radnje i odredišta:**
- **Pošalji privatnu prijavu**
  - Nazad: RAM tekst ne preživljava blur; proveri stari ID
- **Blokiraj osobu**
  - Nazad: Vrati je nova revisioned komanda
**Sekundarne radnje:**
- Pogledaj blokirane osobe
- Nazad
**Destruktivne radnje:**
- Blokirajte osobu samo kao zasebna eksplicitna setBlock akcija sa objašnjenjem
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, rev12_specific  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Proveri prijavu ili blokiranje odvojeno, prema pogođenoj komandi.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Target nije dostupan: nema izmišljanja identiteta.
**Povratak i očuvanje:** RAM tekst ne preživljava blur; proveri stari ID; opaque command ID durable; narrative nikad u ruti/storage  
**Runtime owner porodica:** SAFETY  
**Relevantni source ulazi:** `src/app/(app)/bezbednost.tsx`, `src/app/(app)/profil/blokirani.tsx`, `src/ui/safety/SafetyScreen.tsx`, `src/data/safetyClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Outgoing/incoming privacy očuvana; ne prikazati drugoj strani sadržaj prijave.

### 12.67. `help` — Podrška
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /podrska  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pronaći odgovor ili stvarno podneti zahtev podršci.  
**Publika/kontekst:** Vlasnik naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** life-ring/support blue  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Profil/podešavanja/problem ulaz.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Vaši zahtevi: kompaktan status ili lista
- Česta pitanja sa čitljivom hijerarhijom
- Bezbednost i podaci
- Novi zahtev u stabilnom footer-u
**Radnje i odredišta:**
- **Novi zahtev** — uslov: support capabilities potvrđuje canCreate.
  - Potvrđen rezultat: /podrska/novi sa dozvoljenim kontekstom.
**Sekundarne radnje:**
- Otvori zahtev
- FAQ
- Blokirane osobe
- Privatnost i podaci
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nemaš zahteva za podršku. FAQ ostaje upotrebljiv.
- **error:** Greška zahteva ne mora sakriti lokalni odobreni FAQ.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Podrška trenutno nije dostupna prema capabilities; jasan pošten nastavak.
**Povratak i očuvanje:** Povratak vraća scroll; postojeći zahtevi se čitaju iz inbox-a, bez izmišljene SLA.  
**Runtime owner porodica:** SUPPORT  
**Relevantni source ulazi:** `src/ui/support/SupportController.ts`, `src/data/supportCaseClientService.ts`, `src/ui/support/SupportInboxScreen.tsx`, `src/ui/support/SupportNewScreen.tsx`, `src/ui/support/SupportDetailScreen.tsx`, `src/app/(app)/podrska/index.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Postojanje forme nije operativna podrška; R12 mora potvrditi odgovornog operatera i obradu.

### 12.68. `supportRequest` — Novi zahtev
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /podrska/novi, /profil/prijava-greske  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Poslati razumljiv privatni zahtev sa namerno izabranim kontekstom.  
**Publika/kontekst:** Podnosilac zahteva  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** support blue  
**Mediji:** Koristiti samo postojeći podržani kontekst/prilog; ne uvoditi generičan media upload bez writer-a.  
**Ulaz i guard:**
- **Dolazi iz:** Podrška ili prijava greške/povezani Dogovor.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Tema već postavljena iz konteksta, promenljiva gde dozvoljeno.
- Konkretan prilog i njegova publika; izabrana poruka odvojeno uklonjiva.
- Naslov, opis, opcioni željeni ishod.
- Pošalji privatni zahtev; status uz ovu radnju.
- Potvrda #broj i Otvori zahtev.
**Radnje i odredišta:**
- **Pošalji privatni zahtev**
  - Nazad: pre send dirty pita; posle send recover ne discard
- **Proveri ishod**
  - Nazad: ne šalje ponovo
**Sekundarne radnje:**
- Promeni temu
- Pregledaj priloženi kontekst
**Destruktivne radnje:**
- Odbacite neposlat nacrt uz jasnu odluku; ne brisati poslat unknown command
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, rev12_specific  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Sačuvati smislen unos; pravni/permission razlog ne maskirati kao mrežnu grešku.
- **unknown:** Proveravamo prethodni zahtev; nema drugog CREATE-a.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** pre send dirty pita; posle send recover ne discard; samo ID/kind/hash durable; narrative RAM  
**Runtime owner porodica:** SUPPORT  
**Relevantni source ulazi:** `src/ui/support/SupportController.ts`, `src/data/supportCaseClientService.ts`, `src/ui/support/SupportInboxScreen.tsx`, `src/ui/support/SupportNewScreen.tsx`, `src/ui/support/SupportDetailScreen.tsx`, `src/app/(app)/podrska/novi.tsx`, `src/app/(app)/profil/prijava-greske.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Dijagnostika ima tačan zahvaćeni build, bez privatnih payload-a/tajni.
- Odvajanje dijagnostike od textbox-a mora očuvati stvarni payload i validaciju.

### 12.69. `supportDetail` — Zahtev podršci
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /podrska/[id]  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pročitati odgovor, dopuniti isti predmet ili tražiti ponovni pregled odluke.  
**Publika/kontekst:** Podnosilac ili posebno ovlašćeni operater  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Koristiti samo postojeći podržani kontekst/prilog; ne uvoditi generičan media upload bez writer-a.  
**Ulaz i guard:**
- **Dolazi iz:** Podrška inbox, receipt ili dozvoljeno obaveštenje.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov+broj+status.
- Kontekst, poruke, događaji i odluka u svom trenutku.
- Stalan composer ako allowedActions dozvoljava.
- Odluka jasno kaže šta stvarno menja.
- Zatraži ponovni pregled samo uz odgovarajuću odluku/capability.
**Radnje i odredišta:**
- **Pošalji dopunu**
  - Nazad: draft se ne briše zbog tuđe poruke; gubitak fokusa ima stvarnu RAM granicu
- **Zatraži ponovni pregled**
  - Nazad: dirty sheet pita pre odbacivanja
**Sekundarne radnje:**
- Osveži
- Otvori dozvoljeni povezani kontekst
- Žalba samo kada stvarna action postoji
**Destruktivne radnje:**
- Zatvori zahtev ili povuci radnju samo ako owner nudi, uz posledice
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied, rev12_specific  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Proveri istu reply/close/appeal komandu.
- **stale:** Novi snapshot pre moderacione/žalbene odluke.
- **permission_denied:** Slučaj nije dostupan ovom nalogu; bez otkrivanja sadržaja drugoj strani saradnje.
**Povratak i očuvanje:** draft se ne briše zbog tuđe poruke; gubitak fokusa ima stvarnu RAM granicu; ID/hash durable, telo RAM  
**Runtime owner porodica:** SUPPORT  
**Relevantni source ulazi:** `src/ui/support/SupportController.ts`, `src/data/supportCaseClientService.ts`, `src/ui/support/SupportInboxScreen.tsx`, `src/ui/support/SupportNewScreen.tsx`, `src/ui/support/SupportDetailScreen.tsx`, `src/app/(app)/podrska/[id].tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Prijem zahteva nije obećanje rešenja; status je iz detail reader-a.

### 12.70. `supportOperator` — Rad podrške
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /podrska/operator  
**Ciljna UX površina:** Internal operator surface → **help/supportDetail**  
**Konsolidaciona odluka:** Nije deo potrošačke aplikacije; izdvojiti iz customer IA.  
**Cilj korisnika:** Dati ovlašćenom operateru pregled i dozvoljene akcije nad stvarnim slučajevima.  
**Publika/kontekst:** Samo serverom potvrđen operator; nije običan korisnički tab  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Postojeći autorizovani ulaz.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Operator status i scope
- Potvrđena lista slučajeva
- Filteri iz postojećeg ugovora
- Otvori slučaj
- Claim/decision unutar detail-a
**Radnje i odredišta:**
- **Preuzmi predmet / Pošalji odgovor / Donesi odluku / Zatvori predmet prema capabilities** — uslov: Potvrđen operator i aktuelni allowedActions; claim/version/idempotent identity
  - Potvrđen rezultat: Svaka komanda ima zaseban potvrđen ishod. Odgovor ne zaključuje predmet; odluka sama ne menja Dogovor, iznos, ocenu ili povraćaj.
**Sekundarne radnje:**
- Osveži
- Vrati se ličnoj podršci
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nema slučajeva u izabranom opsegu.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Claim/decision komande oporaviti po istom controlleru.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Nemaš pristup ovom prikazu.
**Povratak i očuvanje:** Uloga operatera nije lokalni switch; gubitak prava odmah uklanja privatni sadržaj.  
**Runtime owner porodica:** SUPPORT  
**Relevantni source ulazi:** `src/ui/support/SupportController.ts`, `src/data/supportCaseClientService.ts`, `src/ui/support/SupportInboxScreen.tsx`, `src/ui/support/SupportNewScreen.tsx`, `src/ui/support/SupportDetailScreen.tsx`, `src/app/(app)/podrska/operator.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Podrazumevani javni UI ne promoviše operator ulaz svim korisnicima; prava potvrđuje server.

### 12.71. `about` — O aplikaciji
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /profil/o-aplikaciji  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Objasniti svrhu, pomoć i pouzdan identitet izdanja bez tehničkog preopterećenja.  
**Publika/kontekst:** Svi odgovarajući korisnici  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Podešavanja.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Kompaktan postojeći logo
- Pomoć počinje dogovorom.
- Dve kratke namere sa posebnim ikonama
- AI pregled/potvrda objašnjenje
- Pravila/privatnost/podrška
- Verzija
- Tehnički podaci disclosure
**Radnje i odredišta:**
- **Otvori željeni dokument/pomoć** — uslov: Stvarna dostupna veza.
  - Potvrđen rezultat: Postojeći pravni/support cilj.
**Sekundarne radnje:**
- Prikaži/kopirajte tehničke podatke
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Nedostupne dodatne mogućnosti ne prikazivati kao aktivne.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Build/source/native/OTA podaci očuvani kod BuildIdentity ownera; kratki prikaz ne briše puni hash.  
**Runtime owner porodica:** SETTINGS  
**Relevantni source ulazi:** `src/app/(app)/profil/podesavanja.tsx`, `src/app/(app)/profil/obavestenja.tsx`, `src/app/(app)/profil/lozinka.tsx`, `src/app/(app)/profil/o-aplikaciji.tsx`, `src/ui/notifications/PushPreferences.tsx`, `src/data/notificationPreferencesClientService.ts`, `src/data/passwordChangeClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Zadržati aktuelni green/orange U+osobe/pin logo; ne vraćati kengura iz stare memorije.
- Kopiranje dijagnostike bez tajni i privatnih payload-a.

### 12.72. `aiHistory` — AI razgovori
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /ai-istorija  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pronaći i bezbedno nastaviti stvaran razgovor ili pročitati zatvorenu istoriju.  
**Publika/kontekst:** Vlasnik naloga  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Podešavanja ili AI header.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov
- Namena: zadatak/radni profil prema stvarnom purpose-u
- Lista sa stvarnim statusom i datumom
- Aktivni nastavak ili zatvoreni transkript
- Paginacija
**Radnje i odredišta:**
- **Nastavi**
  - Nazad: Nazad na istu purpose listu
- **Pročitaj**
  - Nazad: Povratak na istoriju, ista svrha
- **Starije poruke / više razgovora**
  - Nazad: Greška kasnije strane ne briše učitano
**Sekundarne radnje:**
- Promeni namenu
- Nazad
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nemaš razgovora u ovom prikazu.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Tuđa ili nedozvoljena istorija se ne prikazuje.
**Povratak i očuvanje:** Closed transcript ne otvara novi AI turn. Nastavak proverava autoritativno stanje umesto starog lokalnog review-a.  
**Runtime owner porodica:** AI_HISTORY  
**Relevantni source ulazi:** `src/app/(app)/ai-istorija/index.tsx`, `src/app/(app)/ai-istorija/[conversationId].tsx`, `src/data/aiHistoryClientService.ts`, `src/data/aiHistoryMessagesClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- AdmittedClosedHistory/retireClosedHistory granice ostaju; ne direktan proizvoljan URL do privatnog transkripta.

### 12.73. `aiTranscript` — Sačuvani razgovor
**Domena:** Profil, nalog i bezbednost  
**Postojeća ruta/ulaz:** /ai-istorija/[conversationId]  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Pročitati dozvoljen zatvoreni transkript bez ponovnog modela ili pogrešne potvrde.  
**Publika/kontekst:** Vlasnik admitted closed history konteksta  
**Vizuelni obrazac:** Settings-list estetika sa obojenim semantičkim 2D ikonama; pravna/bezbednosna stanja su čitljiva i mirna, bez hero ilustracija osim empty states.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** AI istorija.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov i namena
- Mirna hronološka istorija
- Status zatvorenog razgovora
- Nazad na istoriju
**Radnje i odredišta:**
- **Nastavi**
  - Nazad: Nazad na istu purpose listu
- **Pročitaj**
  - Nazad: Povratak na istoriju, ista svrha
- **Starije poruke / više razgovora**
  - Nazad: Greška kasnije strane ne briše učitano
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Razgovor nije dostupan u ovom kontekstu.
- **error:** Lokalizovati grešku na pogođenu sekciju. Pokušaj ponovo koristi postojeći reader/writer i ne briše ispravan sadržaj.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Ako context admission više nije validan, vratiti na istoriju.
- **permission_denied:** Privatan sadržaj ukloniti prema owner ugovoru; objasniti Pristup više nije dostupan i ponuditi dozvoljen povratak, bez otkrivanja tuđih detalja.
**Povratak i očuvanje:** Nema composer-a za zatvoreni razgovor; nema replay word reveal ili novog Save-a iz stare kartice.  
**Runtime owner porodica:** AI_HISTORY  
**Relevantni source ulazi:** `src/app/(app)/ai-istorija/index.tsx`, `src/app/(app)/ai-istorija/[conversationId].tsx`, `src/data/aiHistoryClientService.ts`, `src/data/aiHistoryMessagesClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Read-only transkript ne stvara novi provider poziv; account guards očuvani.

### 12.74. `taskPhotos` — Fotografije zadatka
**Domena:** Treba mi neko — AI objava  
**Postojeća ruta/ulaz:** /fotografije-zadatka  
**Ciljna UX površina:** Full-screen gallery/editor → **newTaskAI / ownTask**  
**Konsolidaciona odluka:** Jedna kolekcija fotografija istog zadatka; pregled, staging i recovery.  
**Cilj korisnika:** Pregledati/dodati stvarne fotografije istog zadatka i razrešiti svaki upload.  
**Publika/kontekst:** Vlasnik task conversation/photo konteksta  
**Vizuelni obrazac:** Chat je sadržaj, ne dekoracija. Kratak uvod, jedna sledeća AI potreba, media/location inline, završni pregled kao floating review card.  
**Ikone:** photo/image violet  
**Mediji:** Fotografije zadatka: 1–3 u intake-u; prikazati samo ako postoje. Tap → fullscreen viewer. Upload/staging/unknown vezani za isti resurs.  
**Ulaz i guard:**
- **Dolazi iz:** AI composer/review ili postojeći photo route.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Naslov
- Jedna zajednička PhotoGrid
- Staged/processing status po fotografiji
- Dodaj fotografiju
- Viewer
- Povratak u odgovarajući razgovor/pregled
**Radnje i odredišta:**
- **Izaberi fotografije**
  - Nazad: Back dopušten uz tačan recovery status
- **Proveri fotografiju**
  - Nazad: Ne dodaje nov resurs radi provere
- **Ukloni/otkaži**
  - Nazad: Unknown ostaje vidljiv
**Sekundarne radnje:**
- Otvori fotografiju
- Promeni izvor
- Nazad
**Destruktivne radnje:**
- Ukloni/otkaži konkretan staged prilog prema postojećem owneru
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Gubitak medijskih bajtova ne lažira sačuvanu sliku.
- **unknown:** TaskPhotoRecovery za konkretan upload; bez duplog resursa.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** PermissionRecovery sa objašnjenjem i alternativom.
**Povratak i očuvanje:** Fotografija dodata inline i ovde je isti resurs; nema druge kolekcije. Cold-link Back vraća u pripadajući razgovor kada dozvoljen.  
**Runtime owner porodica:** TASK_MEDIA  
**Relevantni source ulazi:** `src/app/(app)/fotografije-zadatka.tsx`, `src/ui/media/useTaskPhotoUploads.ts`, `src/data/mediaClientService.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Photo-only claim/complete payload kanonski usklađen SB15; ne gasiti hash proveru.

### 12.75. `publicProfile` — Profil saradnika
**Domena:** Prilike i javni zadatak  
**Postojeća ruta/ulaz:** /prilike/[id], /potrebe/[id]/kandidati  
**Ciljna UX površina:** Full screen  
**Cilj korisnika:** Proceni dozvoljeni javni profil u kontekstu konkretne ponude/saradnje.  
**Publika/kontekst:** Ovlašćeni javni čitalac ili naručilac ponude  
**Vizuelni obrazac:** Lista/mapa istog stanja. Kartice skeniraju naslov, osnovu cene, vreme, približno mesto i ljude; detalj otkriva celu priču.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Profilna fotografija; fallback inicijali. Nema dekorativne slike koja imitira verifikaciju.  
**Ulaz i guard:**
- **Dolazi iz:** Autor zadatka ili kandidat.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Dozvoljena fotografija/ime
- Javni opis i usluge koje reader vraća
- Reputacija sa stvarnim brojem
- Javni komentari samo uz podržan read put
- Nazad na ponudu/zadatak
**Radnje i odredišta:**
- **Vrati se na ponudu/zadatak** — uslov: Prethodni kontekst i dalje dozvoljen.
  - Potvrđen rezultat: Zatvoriti postojeći sheet/detail bez gubitka izbora.
**Sekundarne radnje:**
- Prijavi/blokirajte samo uz potvrđen safety target
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Nema dodatnih javnih podataka, uz očuvane potvrđene elemente.
- **error:** Pokušaj ponovo samo za lokalni read-error.
- **unknown:** Ako postoji poslata komanda, ishod još nije potvrđen: Proveri stanje nastavlja isti identitet i isti nepromenjeni intent, bez automatski novog upisa. Kod read-only prikaza nepoznati rezultat nije prazna lista.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Profil nije dostupan; ne prikazivati privatne fallback podatke.
**Povratak i očuvanje:** Javni profil je opciono odvojen read; private/unavailable ne sme otkriti skrivene kolone ili srušiti celu ponudu.  
**Runtime owner porodica:** PUBLIC_TASK  
**Relevantni source ulazi:** `src/app/(app)/prilike/[id].tsx`, `src/ui/v2/PublicNeedPresentation.tsx`, `src/ui/qa/useTaskQaInline.ts`, `src/app/(app)/potrebe/[id]/kandidati.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- F21 privatne kolone nikada nisu UI convenience fallback.
- SB09 javni komentar ne izmišljati iz own-profile props.

### 12.76. `exactLocation` — Mesto Dogovora
**Domena:** Dogovor i izvršenje  
**Postojeća ruta/ulaz:** /dogovor/[id]  
**Ciljna UX površina:** Bottom sheet + full-screen map when needed → **agreementDetail**  
**Konsolidaciona odluka:** Tačna lokacija je permissioned podtok Dogovora.  
**Cilj korisnika:** Dobij ili podeli mesto sa tačno određenom osobom.  
**Publika/kontekst:** Ovlašćeni učesnici konkretnog Dogovora  
**Pravilo uloge:** Pristup zavisi od Dogovora i dozvole; približno mesto nije isto što i privatna tačna lokacija.  
**Vizuelni obrazac:** Jedan shared workspace sa role-aware akcijama; važeći uslovi, pending izmena, mesto, tok, poruke i dokazi bez mešanja statusa.  
**Ikone:** location coral + privacy lock violet  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** AgreementContactPlace lokacijska radnja.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Koji podatak i kome
- Približno mesto kao kontekst
- Status dozvole
- Tačna adresa samo uz grant ili eksplicitna current-location potvrda
- Poruka kojom se traže detalji, bez automatskog slanja
**Radnje i odredišta:**
- **Pogledaj mesto / Podeli lokaciju** — uslov: Current participant + zaseban location consent; capture GPS samo na izričitu radnju.
  - Potvrđen rezultat: Authorized payload sa recipient/lease/grant identity.
  - Vodi na: Location panel ili ista privatna poruka
  - Nazad: Nazad pre slanja ništa ne deli; request-address samo puni draft.
  - Oporavak: Unknown zadržava identity/hash i prvo čita; lost permission briše private bytes.
**Sekundarne radnje:**
- Poruke za dogovor detalja
**Destruktivne radnje:**
- Povlačenje lokacijskog pristupa samo kada postojeći ugovor dozvoljava
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Greška pripada pogođenom read-u ili komandi. Sačuvaj dozvoljeni potvrđeni sadržaj i vidljiv povratak. 
- **unknown:** Unknown zadržava identity/hash i prvo čita; lost permission briše private bytes.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Tačna lokacija nije dostupna ovom nalogu.
**Povratak i očuvanje:** Nazad pre slanja ništa ne deli; request-address samo puni draft.  
**Runtime owner porodica:** AGREEMENT  
**Relevantni source ulazi:** `src/app/(app)/dogovori.tsx`, `src/app/dogovor/[id].tsx`, `src/ui/agreements/AgreementWorkspace.tsx`, `src/ui/agreements/AgreementOverview.tsx`, `src/ui/agreements/AgreementCompletionReview.tsx`, `src/data/agreementClientService.ts`, `src/ui/agreements/AgreementContactPlace.tsx`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- EXACT_LOCATION odvojen od PHONE, phoneOTP i slobodnog teksta poruke.

### 12.77. `deepLink` — Otvaranje dozvoljenog odredišta
**Domena:** Sistem i pristup  
**Postojeća ruta/ulaz:** INTERNAL_NATIVE_INTENT  
**Ciljna UX površina:** System/infrastructure state  
**Konsolidaciona odluka:** Ne prikazivati kao stalnu destinaciju u navigaciji.  
**Cilj korisnika:** Bezbedno rešiti ulazni link i vratiti smislen izlaz kada cilj više nije dostupan.  
**Publika/kontekst:** Prijavljen ili neprijavljen korisnik  
**Vizuelni obrazac:** Mirna auth površina; 2.5D samo na welcome hero-u. Jedna dominantna akcija, bez dekorativnih kartica oko formulara.  
**Ikone:** Neutralna utility ikona + semantička boja samo kada nosi značenje podatka  
**Mediji:** Nema obaveznog medija; ne dodavati dekorativnu fotografiju ako ne pomaže odluci.  
**Ulaz i guard:**
- **Dolazi iz:** Native intent, push, recovery ili signup link.
- **Mora biti poznato:** Važeći nalog kada je ruta privatna; konkretni ID/namena/revizija iz postojećeg entry ownera. Nema prenosa tajni kroz route parametre.
- **Ako nema prava/konteksta:** Postojeći dozvoljeni root ili auth; povratnu nameru očuvati samo u granicama važećeg ugovora.
**Raspored od vrha nadole:**
- Kratko proveravanje ako potrebno
- Auth kada potreban
- Tačan dozvoljeni cilj ili jasna nedostupnost
- Odgovarajući povratak
**Radnje i odredišta:**
- **Nastavi / Nazad na dozvoljeni prikaz** — uslov: Validiran path, context i prava; bez prosleđivanja tajnih tokena.
  - Potvrđen rezultat: Postojeći +native-intent/target resolver; ne generički arbitrary router push.
**Sekundarne radnje:**
- Prijavi se kada potrebno
**Stanja koja moraju biti projektovana:** ready, loading, empty, error, unknown, stale, permission_denied  
- **empty:** Prazno stanje tek nakon uspešnog čitanja; navesti šta nedostaje i jednu odgovarajuću sledeću radnju.
- **error:** Link nije važeći ili sadržaj više nije dostupan.
- **unknown:** Cilj se proverava, bez prikaza pogrešne kartice.
- **stale:** Poslednji potvrđeni podaci mogu ostati vidljivi sa jasnim stanjem osvežavanja; osetljiva nova komanda čeka važeću reviziju.
- **permission_denied:** Dozvoljeni fallback bez otkrivanja tuđih podataka.
**Povratak i očuvanje:** Sačuvati dozvoljenu nameru kroz auth; expired/invalid nema beskrajni loop.  
**Runtime owner porodica:** None  
**Relevantni source ulazi:** `src/app/+native-intent.tsx`, `src/data/signupConfirmationReturn.ts`  
**Done za ovaj ekran/površinu tek kada:**
- Povezati prikaz, postojeći owner, komandu, autoritativni rezultat i tačan povratak; nema demonstracionog writer-a u aplikaciji.
- Proveriti sve projektovane relevantne state varijante, velik font, tastaturu i screen reader na odgovarajućem kandidatu.
- Account/focus/revision i dozvole ostaju kod postojećih vlasnika; screenshot/prototip nije runtime potvrda.
- Native cilj obuhvata Android i iOS, sa zasebnim dokazima; suženje samo novom izričitom vlasničkom odlukom. Platform-gated mogućnost mora imati istinit nedostupan prikaz na drugoj platformi.
- Mark-read događaja i stvarno čitanje poruke nisu ista radnja.

## 13. Konačan red implementacije dizajna
1. **Shell + dva workspace-a + Početna.** Ne dirati duboke tokove dok korisnik ne može jasno da uđe u „Treba mi neko“ ili „Želim da uskočim“.
2. **Golden requester tok:** newTaskAI → review → publish → ownTask → candidates → selectReview → Dogovor.
3. **Golden worker tok:** discovery → taskDetail → apply/review → applicationDetail → Dogovor.
4. **Dogovor kompletno:** Pregled/Poruke/Tok/Dokazi, amendment, completion, location, problem, cancellation.
5. **Raspored + dostupnost** i tačan return context.
6. **Profil, settings, privacy, support** i sve recovery grane.
7. **Čišćenje starih ikonika/routes** tek posle reference scan-a i zamene svih caller-a.
8. **Native dokaz**: 360/390/430dp, text scale 1/1.3/2, keyboard, screen reader, reduced motion, offline/unknown, Android+iOS.
## 14. Kriterijum da je UX zaista završen
- Svaka radnja ima jedan jasan glagol i poznat rezultat.
- Svaki Back vraća korisnika bez gubitka dozvoljenog drafta.
- Unknown outcome nikada automatski ne pravi novu komandu.
- Cena ima istu osnovu na kartici, prijavi, kandidatu i Dogovoru.
- Javno mesto i privatna tačna lokacija se ne mešaju.
- Task edit ne menja potpisane Dogovore.
- Worker availability ne menja već prihvaćen termin.
- Male ikonice su čiste 2D; 2.5D se koristi kao naglasak, ne kao univerzalni jezik.
- Ekran ne postoji samo zato što postoji ruta; surface mora odgovarati mentalnom modelu korisnika.
- Dizajnirano, implementirano i runtime dokazano se vode kao tri odvojena statusa.
## 15. Referentni obrasci koje preuzimamo samo kao princip
- Airbnb 2025/2026: mirna početna, itinerary-like kontekst, poruke vezane za rezervaciju, profile i vizuelna dubina bez pretrpavanja.
- Airtasker: potreba → ponude → izbor → privatna komunikacija tek posle assignment-a; scope/time/budget kao osnovne informacije zadatka.
- Taskrabbit: potreba/lokacija → poređenje relevantnih ljudi → chat/confirm; jasan mali broj koraka.
- Thumbtack: search/chat/hire kao veoma čista mentalna sekvenca.
USKOČI ne preuzima njihove payment, escrow ili kontakt politike; koristi samo UX principe koji odgovaraju sopstvenom poslovnom ugovoru.
