# USKOČI — tehnički dokazi, vlasnici i granice zaključaka

**Presek: 27. oktobar 2026. Revizija dokumentacije: 10.** Poslednji potpuni živi server pregled je revizija 7. Revizija 9 je obuhvatila ciljanu proveru izvora izdanja i tada važećih zvaničnih uslova prodavnica; revizija 10 objedinjuje dva plana, sve preciznije uslove i punu dokaznu podlogu, bez novog izvršenja aplikacije ili servera. Ovaj dokument je tehnička referenca za objedinjeni izveštaj i kasniji rad u Codexu: povezuje nalaze sa postojećim vlasnicima koda, stvarno izvršenim proverama i konkretnom granicom koja još treba da se zatvori. Oznake F01–F21, SB01–SB15 i X01–X06 imaju jedno značenje u celom paketu. Redosled izvođenja pripada planu za Codex; redosled odeljaka ovde služi pronalaženju dokaza.

## 1. Identitet izvora i način čitanja dokaza

Merodavni izvor ove analize je [USKOCI-EAN na commitu a9692e11942609bab9406215c3e407d79589dafa](https://github.com/uskocibusiness-boop/USKOCI-EAN/tree/a9692e11942609bab9406215c3e407d79589dafa), grana `feature/uskoci-cisto`. Lokalni koren je `/workspace/scratch/f356024cf009/audit/deep-review/source`. Sve putanje `src/…`, `supabase/…`, `scripts/…` i `app.config.js` u nastavku odnose se na taj koren i taj commit, osim izričito označenog instaliranog izvora. Brojevi redova su orijentiri u tom zamrznutom sadržaju.

U serverskim navodima **requester Edge / NEED** označava `supabase/functions/uskoci-ai-interview/index.ts`, **worker Edge / WORKER** označava `supabase/functions/uskoci-worker-interview/index.ts`, a **BG** označava `supabase/functions/_shared/backgroundTaxonomyArchitect.mjs`. Skraćeni SQL prefiksi `20261021104455…`, `20261021103732…`, `20261019104047…` i `20260913044510…` označavaju pune imenovane migracije u odeljcima 2 i F04–F06, u direktorijumu `supabase/migrations/`.

Korisnikov snimak „O aplikaciji” pokazuje verziju **1.0.0**, izvor **fcef803e719ba5663f6cfd8fbd5a601e08a3479b**, runtime `uskoci-v1-preview-r1`, kanal `preview` i aktivno OTA ažuriranje sa prefiksom `01a163c4`. Taj izvor je odvojeno pribavljen i poređen. Snimak nije hash celog APK-a niti ekstrakcija stvarno učitanog OTA JavaScript-a i njegovih ugrađenih zastavica. Izvorna oznaka, stari build profil i izgled ekrana ipak daju konkretnu osnovu za praćenje instaliranog P6 readera. [N01]

**Nivoi dokaza koji se koriste:**

| Oznaka | Šta je utvrđeno | Granica |
|---|---|---|
| Izvor | Pročitan konkretan caller, uslov, decoder ili SQL telo | Ne dokazuje da je baš ta verzija izvršena na telefonu |
| Izolovana proba | Izvršen pravi modul/handler ili SQL telo uz kontrolisani I/O i pomoćne funkcije | Ne zamenjuje pravi model, celu bazu, native renderer ili završni Save |
| Živa definicija/metapodaci | Read-only preuzeta definicija, deployment sadržaj, verzija ili agregat | Čitanje definicije nije izvršavanje poslovnog RPC-a |
| Živi log | Stvarno zabeležena serverska greška/HTTP ishod | Bez request ID veze ne pripisuje se automatski konkretnoj slici/nalogu |
| Snimak uređaja | Zaista vidljiv sadržaj i zaklanjanje na dostavljenoj slici | Ne pokazuje sve prethodne dodire, font scale ili native događaje |
| Preneti dokaz + jednak SHA | Starija reprodukcija i sveže poređenje nepromenjenog izvora | Jednak sadržaj nije novo izvršavanje niti potvrda sadašnjeg deployment-a |

Analiza nije menjala proizvod, migracije, build ili deployment. Nisu slati pravi modelski zahtevi niti poslovni SQL upisi. Pozitivan karakterizacioni test može da znači da je postojeći kvar uspešno reprodukovan; ne znači da je kvar popravljen.

### Završeno čitanje i aktuelna fizička granica

Jedinstveni registar sada ima potpuno semantičko pokriće svih 3.335 tekstualnih putanja / 626.320 redova i odvojeno obnovljen vizuelni pregled 99 binarnih resursa. Polaznih 1.207 tekstualnih fajlova / 188.167 redova i završnih 2.128 / 438.153 ne preklapaju se pri konačnom brojanju. Direktni FULL, identičan ranije FULL sadržaj, ceo diff nad FULL bazom i kompletan strukturisani pregled ostaju označeni pojedinačno. Generisanje pregleda, parsiranje ili hash sami nisu semantičko čitanje. Originalni Downloads masterplan nije dostupan i nije obuhvaćen ovom tvrdnjom.

Z01 zatvara čitanje 680 public/private tela: 418 veza na identičan pročitani source i 262 direktne/diff/payload provere. Novi otisci potvrđuju ista tela/definicije/ACL, a Z12 dodaje dve potpuno pročitane `rls_private` funkcije koje koriste aktuelne Need politike. Revizija 7 proširuje prethodni katalog od 168 tabela/1.642 kolone na 169 table granica/1.652 kolone uključivanjem `realtime.messages`, uz devet sekvenci. Sada su pročitani svi relevantni tekući izrazi i njihove veze: 446 default/generated, 1.103 constraints, 91 policy i 173 trigger deklaracije. Metod i jedinstvene definicije su u Z12. Nije izvršen schema replay. Jedini NOT VALID u proširenom obuhvatu je managed Realtime payload CHECK; raniji uži nalaz o validiranim aplikacijskim ograničenjima ne proširuje se na svaki interni Supabase objekat.

Svi preuzeti kandidati, testovi i skripte su pročitani, ali nisu zbog toga ponovo izvršeni. Kopije starog SQL-a, `NOT APPLIED` naslovi i istorijski PASS moraju se porediti sa sadašnjim telima, ugovorom i stvarnim zaključnim uslovom testa. To razdvajanje je deo nalaza SB14, ne prećutno spuštanje kriterijuma za spremnost proizvoda.

### Ciljani nastavak: namera, aktivni tok i dokaz završetka

Revizija 4 ponovo ukršta 14 korisničkih tokova, svih R01–R12, 45 tačnih izvornih putanja za testnu matricu i sedam ciljnih odluka. Broj jedinstvenih izvornih putanja ponovo povezanih u ovoj ciljanoj proveri je 91; njihovi SHA-256 otisci su provereni. One su već deo punog registra i ne sabiraju se kao novi fajlovi. Proverena je stvarna deklarativna CI selekcija, bez pokretanja testova. GitHub ref ostaje isti; read-only upit od 27.10.2026. u 11:45:31 UTC potvrđuje svih 680 istih tela/definicija/ACL-ova. Edge metadata ostaje na istim 15 verzija, uključujući NEED151/WORKER104/post-save5/push37. To nije nova provera svakog živog table/default/policy izraza niti novo preuzimanje svakog Edge tela.

[Z09 — jedinstveni trag namere i testova](dokazi/namena_i_testovi/intent_review.json) čuva tačne source putanje i opsege, odluke, minimalne pozitivne i failure slučajeve, uslove odabranih lokalnih komandi, tragove izvora i ograničenja. Nema nove glavne F grupe niti novog PASS-a aplikacije. Matrica je operativna selekcija po zadatku, ne bezuslovan spisak svih testova za brisanje.


### Revizija 5 — izvršna preciznost i svežina

Sva tri korisnička dokumenta ponovo su pročitana i ukrštena kao jedna radna specifikacija. GitHub HEAD ostaje a9692e1; svih 3.434 registrovana source SHA-256 otiska ponovo odgovara checkout-u. Read-only presek 27.10.2026. u 12:53:03 UTC ima istih 680 body/definition/ACL trojki i istih 15 Edge deployment metapodataka. To nije novi download svakog Edge bundle-a, puna provera svih policy izraza ili runtime izvršenje.

Z10 sadrži mapu svih 42 nalaza, R11 podzadatke, normalizovan indeks svih source putanja, konkretne cleanup pakete i ciljane poslovne/UX odluke. Izvorne preporuke ostaju sačuvane; operativna normalizacija nije proglašena novim nezavisnim punim čitanjem ili konačnom deletion allowlist-om. Stari pending disposition za devet već FULL pročitanih putanja razrešen je u novoj projekciji; istorijska oznaka ostaje vidljiva.

Repo-prijavljeni testovi: STATUS.md:13 navodi 621/14.131 za 26.10; USKOCI_CISTO_STATUS_I_KONTINUIRANI_PLAN_26-10-2026.md:20,50 navodi noviji 622/14.143 za nastavak 27.10. Sadašnji statički Jest path skup ima 622 fajla, AI Node glob 37, a registar 796 test/proof oznaka. Te mere se ne sabiraju niti predstavljaju broj nepotrebnih testova. Nijedan navedeni istorijski runner rezultat nije ponovo izvršen u reviziji 5.


### Revizija 7 — završen dodatni tekući serverski pregled

Revizija 6 je odredila posao; revizija 7 ga je izvršila bez izmene aplikacije ili baze. Z11 je objedinjeni receipt, Z12 tekući schema/Auth dokaz, Z13 kompletan Edge i classifier/cache pregled, Z14 operativni lanci, Z15 migration/performance/dependency podloga i Z16 zajednički manifest. Svih 42 osnovnih F/SB/X oznaka ostaje povezano sa R01–R12; nove tačne pojedinosti nisu proglašene zasebnim završenim popravkama.

S02/S05 obuhvata svih 65 jedinstvenih default/generated izraza sa 446 vezivanja, 703 jedinstvene constraint definicije sa 1.103 vezivanja (628 CHECK/482 jedinstvena CHECK izraza), 91 policy definiciju i 173 trigger deklaracije. Struktura/ACL: 167 public/private tabela, storage.objects, realtime.messages i devet sekvenci; 1.652 table kolone odnosno 1.679 column zapisa sa sekvencama. Nema public/private view-a, niti application enum/domain tipa u public/private/rls_private. Efektivna prava 169 tabela, 680 funkcija, osam relevantnih šema uključujući dodatni rls_private, devet uloga, 25 memberships, 27 default ACL i 12 bezbednih role settings su ukršteni. Dve RLS definicije su sveže pročitane cele; 28 ciljanih public/private tela ponovo je pročitano uz aktuelni hash, bez novog brojanja svih 680 kao zasebnog čitanja.

S03 pokriva svih 15 deployed Edge paketa: 69 pojava/48 jedinstvenih sadržaja. Metod: 36 exact-hash prenosa punog čitanja, sedam potpunih semantičkih diffova, dve CRLF/LF razlike i tri cela disabled stub-a. Svih 52 current Edge/shared source SHA ostaje isto. Kod prihvata Gemini Developer API `v1beta` generateContent/streamGenerateContent i pin `gemini-3.8-flash`; stvarne tajne i efektivni flagovi nisu čitani. Uslovna dual grana nije time proglašena sveže potvrđenom runtime konfiguracijom.

S04/S06 prati šest operativnih lanaca, tri privatna bucketa, 12 Storage politika, publication/consumer put i sva tri cron-a. Ukupno 135 operativnih odluka obuhvata različite vrste objekata, ne 135 runtime funkcija. Dvadeset pet ciljanih SQL tela ponovo je čitano, dok source receipt razlikuje full/excerpt/search, a postojeći test ulazi nisu izvršeni. Detalji SQL/HTTP/stale-push/false-binding agregata su u Z14. Strukturisan katalog 364 indeksa i svi performance advisor zapisi ne predstavljaju nezavisno produkciono workload merenje svakog indeksa; jedan tačan duplikat ima zaseban dokaz u Z15.

Manifest Z16 obuhvata fizičke identitete, pročitane definicije, reference i konzervativne odluke, sa 14 proširenih zapisa SV01–SV14. Dodatni schema/operational/Edge pogledi u istom manifestu pokazuju konkretnu svrhu i preostali uslov; preklopljeni pogledi se ne sabiraju kao jedinstveni objekti. Kataloška i leksička mapa nije potpun graf dinamičkog SQL-a, starih klijenata ili spoljnog operativnog poziva. Nijedno brisanje nije destructive_action_ready.

**Granice koje ostaju:** kompletna Auth management konfiguracija nije dostupna kroz oglašene alate; Edge env/gates nisu očitani; nema čistog DB replay-a, pravog modela/cache/countTokens poziva, poslovnog E2E, uređaja, load/delivery/cost dokaza. Pregled novih ekrana i konačan opis tri ugla ostaju za kasnije. Precizno preostalo ograničenje nije sakriveno oznakom „sve provereno”.

### Dokazni indeks

Relativni linkovi vode u isti paket, do izvornih receipata, SQL snimaka i registara čitanja.

| Oznaka | Sadržaj |
|---|---|
| P01 | [Zbir proveravanja](dokazi/prethodna_etapa/verification_summary.json), [Jest rezultati](dokazi/prethodna_etapa/offline_ui_test_results.json), [Jest log](dokazi/prethodna_etapa/offline_ui_test_run.log) |
| P02 | [Capture/ACK log](dokazi/prethodna_etapa/direct_background_capture_receipt.log), [completion/lifecycle log](dokazi/prethodna_etapa/direct_background_completion_lifecycle.log), [karakterizacija valute](dokazi/prethodna_etapa/direct_currency_correction_characterization.log) |
| P03 | [Katalog — izvršivi probe](dokazi/prethodna_etapa/server_catalog_probe.mjs), [rezultat](dokazi/prethodna_etapa/server_catalog_probe_result.json), [agregati kataloga](dokazi/prethodna_etapa/catalog_metrics.json) |
| P04 | [Živa SQL tela](dokazi/prethodna_etapa/live_sql_definitions.sql), [pregled/katalog definicije](dokazi/prethodna_etapa/live_review_catalog_definitions.json), [revalidacija 42 funkcije](dokazi/prethodna_etapa/live_42_function_revalidation.json) |
| P05 | [Poređenje source/deployed sadržaja](dokazi/prethodna_etapa/live_source_parity.json), [Edge verzije](dokazi/prethodna_etapa/edge_versions.json) |
| P06 | [Requester čitanje](dokazi/prethodna_etapa/requester_read_ledger.json), [worker čitanje](dokazi/prethodna_etapa/worker_semantic_read_ledger.json), [server čitanje](dokazi/prethodna_etapa/server_read_ledger.json), [deadline flag proba](dokazi/prethodna_etapa/requester_deadline_flag_probe.json) |
| P07 | [Prenos SB/X nalaza i SHA poređenje 72 fajla](dokazi/prethodna_etapa/requester_secondary_source_parity.json) |
| P08 | [Ranija price-display proba](dokazi/prethodna_etapa/price_display_reproduction.json) i [izvor ranije probe](dokazi/prethodna_etapa/price_display_reproduction.mjs); istorijski handler + sintetički I/O, uz proveru kontinuiteta relevantnih delova. |
| P09 | [Material snapshot parity](dokazi/prethodna_etapa/price_basis_material_parity.json), [replacement parity](dokazi/prethodna_etapa/price_basis_replacement_body_parity.json), [ranije živo material telo](dokazi/prethodna_etapa/live_private_need_material_snapshot.sql), [replacement material](dokazi/prethodna_etapa/live_private_task_replacement_material.sql) i [stage telo](dokazi/prethodna_etapa/live_private_stage_task_replacement.sql). |
| P10 | [Ranije živo Need trigger telo](dokazi/prethodna_etapa/live_need_category_trigger_final.json), [uključen trigger](dokazi/prethodna_etapa/live_need_category_trigger_enabled_final.json), [raniji worker sync](dokazi/prethodna_etapa/live_worker_capability_sync_prior.json); nepromenjena tela potvrđena u P04 revalidaciji 42 funkcije. |
| H01 | Prenete izolovane reprodukcije: [ocene](dokazi/prethodna_etapa/review_refresh_reproduction.json), [pravne saglasnosti](dokazi/prethodna_etapa/legal_changed_bundle_reproduction.json), [proof build](dokazi/prethodna_etapa/build_proof_reproduction.json), [fotografija bez teksta](dokazi/prethodna_etapa/photo_only_reproduction.json) |
| N01 | [Trenutni ref](dokazi/nova_etapa/branch_ref.json), [instalirani commit](dokazi/nova_etapa/installed_commit.json), [spisak preuzetih starih fajlova](dokazi/nova_etapa/installed_source_downloads.json), [staro/novo poređenje](dokazi/nova_etapa/installed_to_current_compare.json) |
| N02 | [Živi discovery RPC](dokazi/nova_etapa/live_public.rpc_discovery_v1.sql), [živi legacy reader](dokazi/nova_etapa/live_public.rpc_list_open_tasks_v3.sql), [discovery logovi](dokazi/nova_etapa/discovery_log_evidence.json), [migration metapodaci](dokazi/nova_etapa/migration_metadata.json) |
| N03 | [Discovery validacija](dokazi/discovery/validation_receipt.json), [3 route karakterizacije](dokazi/discovery/characterization_results.json), [5 boolean dijagnostičkih slučajeva](dokazi/discovery/boolean_error_probe_result.json), [8 stari/novi decoder slučajeva](dokazi/discovery/installed_decoder_probe_result.json), [live/baseline jednakost](dokazi/discovery/live_baseline_comparison.json), [read ledger](dokazi/discovery/read_ledger.json) |
| N04 | [AI proba](dokazi/ai/semantic_completion_probe.mjs), [AI rezultati](dokazi/ai/semantic_completion_probe.json), [poređenje živih definicija](dokazi/ai/semantic_completion_definition_parity.json), [AI read ledger](dokazi/ai/semantic_completion_read_ledger.json) |
| N05 | [Živa exact projekcija](dokazi/nova_etapa/live_private.taxonomy_review_exact_projection_v1.sql), [živi worker completion](dokazi/nova_etapa/live_public.rpc_complete_worker_ai_turn_service.sql), [živi signed worker prepare](dokazi/nova_etapa/live_public.rpc_prepare_worker_ai_review_taxonomy.sql) |
| N06 | [Layout read ledger](dokazi/layout/layout_read_ledger.json), [baseline/candidate poređenje tela](dokazi/layout/baseline_candidate_body_comparison.json) |
| S01–S03 | [Početna greška zadataka](dokazi/slike/01-zadaci-greska.jpg), [prazna mapa i panel greške](dokazi/slike/02-mapa-panel.jpg), [identitet aplikacije](dokazi/slike/03-identitet-aplikacije.jpg) |
| Z01 | [680 trenutnih tela i reference potpunog čitanja](dokazi/zavrsni_pregled/function_body_review.json) |
| Z02 | [Kandidati: puna čitanja, svrha, status i current cross-check](dokazi/zavrsni_pregled/candidate_review.json) |
| Z03 | [Klijentski i preneti pregledi: individualni smisao i granice dokaza](dokazi/zavrsni_pregled/client_review.json) |
| Z04 | [Proof skripte: individualni dokazi, istorija i ograničenja](dokazi/zavrsni_pregled/proof_review.json) |
| Z05 | [Root registri, dekodirani payload-i i dodatnih 35 SQL pregleda](dokazi/zavrsni_pregled/root_review.json) |
| Z06 | [Sveži katalog i aktuelna konfiguracija/readiness naspram istorije](dokazi/zavrsni_pregled/live_catalog_crosscheck.json) |
| Z07 | [Obnovljen pregled 99 binarnih i 18 SVG resursa](dokazi/zavrsni_pregled/asset_review.json) |
| Z08 | [Konačna potpunost, jedinstveno brojanje i verifikacija hash-eva](dokazi/registar/coverage_summary.json) |
| Z09 | [Namena, 14 tokova, 12 testnih zadataka, ciljane odluke i svežina](dokazi/namena_i_testovi/intent_review.json) |
| Z10 | [Izvršivost svih nalaza, normalizovan cleanup, odluke i nepromenjeni izvor/server](dokazi/izvrsivost/readiness_review.json) |
| Z11 | [Završni serverski obuhvat i granice](dokazi/server_final/server_review.json) |
| Z12 | [Tekući schema, izrazi, prava i Auth](dokazi/server_final/schema_review.json) |
| Z13 | [Svi deployed Edge sadržaji, katalog i cache](dokazi/server_final/edge_review.json) |
| Z14 | [Šest operativnih lanaca i sveži agregati](dokazi/server_final/operations_review.json) |
| Z15 | [Poreklo migracija, performance i dependency](dokazi/server_final/migration_performance.json) |
| Z16 | [Jedinstveni serverski manifest SV01–SV14](dokazi/server_final/change_manifest.json) |
| Z17 | [Poređenje plana i semantička pokrivenost 42/19/14 jedinica](dokazi/provera_plana/comparison_review.json) |
| Z18 | [Izvorna ograničenja i konkretni poslovi pripreme izdanja](dokazi/provera_plana/release_review.json) |
| Z19 | [Objedinjavanje dva rev9 plana, punih dokaza i završna provera rev10](dokazi/objedinjavanje_rev10/merge_review.json) |

## 2. Vlasništvo nad stanjem i granice koje treba sačuvati

### Naručilac

| Stanje/radnja | Merodavni vlasnik | Tačno značenje |
|---|---|---|
| Razgovor i identitet pokušaja | `src/app/(app)/nova.tsx:50–325`; `src/data/aiTurnIntentJournal.ts:4–37` | Prvi send otvara razgovor stabilnim ključem. Journal čuva identifikatore, ne privatni body. PROCESSING, retry i unknown imaju različite dozvoljene nastavke. |
| Generacija i nalog | `src/hooks/useOwnedEditor.ts:27–119`; `src/app/(app)/nova.tsx:34–42,112–118,217–224` | Kasni callback ne stiče ovlašćenje ponovnim povratkom na isti account ID; bitni su i revision/fokus/generacija. |
| Spremnost završne kartice | `src/ui/v2/draftSummary.ts:52–66`; `src/ui/v2/IntakePresentation.tsx:381–399,476–477,511–517`; `src/contracts/needFactsV2.ts:16–19,67–69` | Potpun predlog, mesto/tačke i blokade odlučuju prikaz. Tekstualni `need.category` je obavezan, a skriva se iz korisničke liste nedostajućih činjenica. Nedostatak tog teksta može sakriti karticu bez jasnog sledećeg koraka. Kartica ne čeka neposredno canonical `category_id` niti opšti classification READY. Sistem treba da dovrši svoj podatak. |
| Ulaz u pregled | `src/app/(app)/nova.tsx:539,558–567`; `src/data/aiTaskReviewClientService.ts:354–369` | `canReview` je blaži od uslova završne kartice. Prepare upisuje zamrznuti review; još ne prihvata i ne objavljuje Need. Neposlat tekst ne postaje deo pregleda. |
| Prihvat/privatni nacrt/objava | `src/app/(app)/pregled-zadatka.tsx:119–340`; `src/data/aiTaskReviewClientService.ts:127–268,297–405` | `canAccept`, classificationState i geografska spremnost su odvojeni. SaveDraft prihvata bez automatskog evaluate/publish. PUBLISHED receipt traži readback istog Need-a/revizije pre završnog uspeha. |
| Razgovorna mapa | `src/ui/location/ConversationPointAsk.tsx:165–224` | Potvrda svakog pina odmah ide na server uz očekivanu reviziju; START može biti sačuvan dok END još nedostaje. |
| Mapa u pregledu | `src/ui/location/NeedLocationForm.tsx:63–104,139–145`; `src/app/(app)/pregled-zadatka.tsx:302–316` | Pojedinačna potvrda je lokalna; „Primeni potvrđene tačke” priprema novi review. Povratak bez primene ne znači sačuvan skup. Ta dva map toka ne mogu se zameniti bez očuvanja ovog značenja. |

Nema parcijalnih kartica u aktivnom razgovoru: to je postojeće route pravilo. Direktni test ili designLab scene sa karticom ne menjaju taj ugovor. Sačuvan neposlat tekst pri Back/refocus odnosi se na zadržanu montiranu rutu; nije obećanje da svaki znak preživljava gašenje procesa. [P01, P06]

Deadline prepare proširenje ostaje uslovna kompatibilnost: `src/data/aiTaskReviewClientService.ts:352,359–362` bira posebne `rpc_prepare_ai_task_review_deadline` / `rpc_prepare_ai_task_review_deadline_taxonomy` samo kada je javni build flag doslovno `true`. Read-only provera nije našla ta dva RPC-a, a pregledani tracked build/config i audit runtime nisu pokazali uključenu opciju. To je gate pre budućeg uključivanja, ne dokaz da običan sadašnji prepare endpoint nedostaje; efektivni flag starog APK/OTA nije time očitan. [P04, P06]

### Izvršilac

| Stanje/radnja | Merodavni vlasnik | Tačno značenje |
|---|---|---|
| Tema i ispravka | `src/app/(app)/profil/razgovor.tsx:32–52,212–225,359–363,411–424` | Promena teme sama ne šalje poruku i ne pravi novi razgovor. Ispravka vraća u isti razgovor. |
| Turn/readback | Ista ruta `:96–126,170–189,227–247`; `src/data/workerAiClientService.ts` | Stabilan identitet, readback i zaštita novijeg neposlatog unosa od kasnog odgovora. |
| Priprema i Save | Ruta `:249–292,354–379`; `src/data/workerAiClientService.ts:307–311` | Svež review iste revizije + canAccept + eksplicitni Save + saved receipt. DRAFT može odmah izabrati Save+activate; nije obavezan prethodni zaseban DRAFT Save. |
| `activate=false` | `src/data/workerAiClientService.ts:220–225` | Čuvanje bez zahteva za aktivacijom; ne deaktivira već ACTIVE profil. Zato ACTIVE rezultat u tom slučaju nije sam po sebi greška. |
| Classification READY | `src/data/workerAiClientService.ts:134–198`; `src/ui/workerProfile/WorkerAiPresentation.tsx:154–183` | Kandidati i mode parovi su pripremljeni za review. To još nije Save, admission, binding ili matching autoritet. |
| Pending nova usluga | Review + outbox/binding sloj | Nova promena ne dobija autoritet unapred. Nije automatski dokaz da sve ranije potvrđene usluge prestaju da rade. |
| Područja | `src/contracts/workerAreas.ts:1–33`; worker Edge `:202–203,503–515` | Do pet CITY/RADIUS ili jedno COUNTRY područje. RADIUS zahteva eksplicitnu kilometražu od centra mesta. `areaRequests` se razrešava na serveru; nezavisna jasna izmena ne treba da nestane zbog neuspešnog geokodiranja. |

### Semantički i trajni autoritet

Predlog modela i capture imaju `authority:NONE`. Za postojeći posao koristi se stvarni ID iz kataloga; za novu kategoriju SQL writer pravi zapis i vraća ID preko `INSERT … RETURNING`, a model ne izmišlja trajni UUID. Potpisani review, korisnički Save/Accept, admission receipt i reviziono vezivanje imaju različite uloge. Zadržati account/revision/digest ograde, idempotentnost, zaštitu od kasnog odgovora i odvojenu saglasnost za način rada. Relevantni vlasnici su `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql:717–1021,1024–1317,1318–1471`, `supabase/functions/_shared/taxonomyPostSaveWorker.mjs:25–76` i oba signed review klijenta. [P04, N04, N05]

### Tekuće serverske granice koje treba sačuvati i dovršiti

**Pristup i sesija.** F21 je ponovo potvrđen. Široki table SELECT nad needs ne poništavaju uži column grantovi; row policy i column/table grant imaju različite uloge. Dve rls_private funkcije — `need_participant_can_read(uuid)` i `p6_discovery_test_world_accounts()` — potrebne su za sadašnje politike, sa authenticated USAGE/EXECUTE i bez anon/service pristupa. Private šema nema običan anon/auth table pristup. Authenticator `pgrst.db_pre_request=public.rpc_closure_api_guard` je sveže potvrđen; taj hook se odnosi na Data API, ne automatski na Storage/Realtime. Efektivan hook nije dokaz završene erasure mogućnosti.

**Prava za sužavanje.** Postgres/public default ACL automatski daje široke table/function/sequence grantove. Od public tabela, 17 ima bar jednu anon, a 19 bar jednu authenticated TRUNCATE/TRIGGER/REFERENCES dozvolu. Ovo nije dokaz udaljenog SQL/DDL execution puta ili demonstriranog napada. Urediti i budući default i konkretne postojeće grantove, sa namerno javnim `rpc_get_legal_bundle()` i potrebnim authenticated ulazima. Kod legacy delete-a postoje PUBLIC i role EXECUTE; samo anon revoke ne zatvara PUBLIC grant.

**Auth i PHONE.** Fresh advisor potvrđuje disabled leaked-password zaštitu; sadašnji password tok je čini relevantnom. JWT/session rotation/MFA/signup/provider/redirect/SMTP/rate-limit management vrednosti nisu ustanovljene. Pročitani `rpc_set_contact_grant`, `rpc_reveal_contact` i `grant_is_ownable` još imaju PHONE put. Zatvoriti novu PHONE saglasnost/reveal prema „Samo poruke”, uz istorijsku revokaciju i receipt kompatibilnost. EXACT_LOCATION, phone OTP prijava i slobodan tekst poruke su različiti ugovori.

**Storage.** Sva tri bucketa su private: profile-media 5 MiB, agreement-voice 4 MiB i data-export-artifacts 8 MiB, sa pregledanim MIME ograničenjima. Owner-prefix politike, restrictive v5/voice zabrane, account-open granica i Edge/SQL vlasništvo deluju zajedno. Čuvaju se immutable server putanja, hash/veličina, generation/lease, jednom priznata dispatch namera i pozitivan readback; unknown upload nije dovoljan razlog za drugi POST ili brisanje journal-a. SB04/SB05 ostaju ciljane klijentske popravke oporavka.

**Realtime.** Aplikacijska publikacija sadrži `agreement_invalidations_v1(agreement_id,revision)`; sedam ostalih stavki su servisne realtime particije. Pročitani policy i potrošači `agreementInvalidationService.ts`, `useAgreementIncomingRefresh.ts`, `useConversationInbox.ts` koriste Postgres Changes kao hint za autoritativno ponovno čitanje, sa account/focus/session ogradama. Hint nije poruka ni ovlašćenje za mark-read. Group event/refresh ostaje odvojen nedovršen posao; odsustvo private Broadcast politike nije automatski greška ovog toka.

**Zatvoreni lifecycle.** Novi safe config/digest upit daje false za retention source, export binding i closure erasure binding. Čuvaju se exact snapshot, owned download, authorization pre vraćanja bajtova, nezavisna potvrda Storage/Auth operacije i finalizacija tek po važećim rezultatima. Šest DEV tabela bez PK ostaje u sadašnjim lifecycle zavisnostima. Popraviti projektore/kopije/inventare i dokazati važeći binding; ne podizati feature gate ili menjati očekivani digest radi prolaza. Z12/Z14/Z16 imaju tačne vlasnike i uslove.

## 3. Glavni nalazi F01–F21

### F01 — Lista sopstvenih zadataka ima neusaglašen wire ugovor

**Vlasnici:** `src/data/ownTasksPage.ts:11–71`, `src/data/needClientService.ts:179–194`, `src/app/(app)/potrebe.tsx:56`; `supabase/migrations/20261025000000_baseline_core_client_rpcs.sql:435–488`, funkcija `rpc_list_my_needs_page`.

Klijent očekuje ALL/ACTIVE/DRAFTS/HISTORY/WAITING, pet brojača na prvoj strani i snake_case task dokument. Živi/baseline RPC prihvata samo ALL/ACTIVE/HISTORY, uključuje DRAFT u ACTIVE, nema `counts` i vraća camelCase stavke. Prazna prva strana pada zbog brojača; dodavanje samo brojača nije dovoljno jer neprazna strana i nastavak ne odgovaraju task decoderu. Tracked preview/production uključuju paged put.

**Dokaz:** source + živa definicija [P04], tačna jednakost baseline tela starijem pkg045a ugovoru i čitanje EX04a dopune [N06]. Nije dokaz da svaki instalirani klijent ima istu zastavicu niti kada je raniji EX04a eventualno prepisan.

**Zatvaranje:** jedan ugovor za sve scope-ove, praznu/nepraznu prvu i sledeću stranu, count particiju, cursor i poslovni oblik stavke. Stvarni server izlaz mora proći pravi decoder. Ovo je lista sopstvenih zadataka, odvojena od discovery kvara F15.

### F02 — Satnica nema isto značenje kroz sve faze

**Vlasnici:** `validate_need_v2_fact`; requester Edge `supabase/functions/uskoci-ai-interview/index.ts:1076–1091`; živi `private.assert_application_price_v5`; `supabase/proofs/ai/currency_correction_characterization.test.mjs:271–279`.

Fact validator prihvata HOURLY, Edge za metadata PER_HOUR uklanja price predloge i traži cenu celog posla, a kasniji application price writer za MY_PRICE prihvata null/TOTAL/PER_PERSON i odbija drugu osnovicu kao UNKNOWN_PRICE_BASIS. OFFERS ima zasebnu granu: nije tačno da svaki njegov slučaj pada po istom pravilu. [P02, P04]

Dodatna verzijska granica je instalirani discovery decoder: TOTAL/PER_PERSON/null prihvata, HOURLY odbija; trenutni decoder ga prihvata. Jedna takva stavka obara ceo PAGE decode. Osam kontrolisanih stari/novi slučajeva to potvrđuje; nije čitan sadržaj korisnikovih živih zadataka, pa se HOURLY ne proglašava uzrokom slika. [N03]

**Zatvaranje:** izričito podržan domen cene/jedinice/valute/trajanja mora proći razgovor, review, prijavu, izbor i Dogovor, uz kompatibilnu isporuku starim podržanim klijentima. Ne pretvarati satnicu u total ili EUR u RSD bez korisnikove odluke.

### F03 — Korekcija valute može ostaviti staru potvrđenu cenu

**Vlasnici:** requester guard `index.ts:989–993`; fact writer i osnovni V2 review; `supabase/proofs/ai/currency_correction_characterization.test.mjs:219–270`.

Posle potvrđenih 5.000 RSD/TOTAL, korekcija „mislio sam evre” daje opravdano razjašnjenje bez lažne konverzije, ali ne povlači stari RSD fact. On ostaje CONFIRMED, osnovni review ga prikazuje uz canSaveDraft=true, a sledeći nezavisni ALLOW može ukloniti warning. Nova eksplicitna RSD vrednost je pozitivna kontrola koja superseduje stari iznos. OFFERS promena sama ostavlja stare amount/basis činjenice; canonical Save ima dodatno ponašanje.

**Dokaz:** pravi guard + izdvojena SQL tela u PGlite-u, sa minimalnim helperima [P02]. Nisu izvršeni ceo signed accept, Save ili publication; nije dokazana stvarna objava pogrešne cene.

**Zatvaranje:** korekcija značenja cene atomarno povlači ili vraća na potvrdu staru saglasnost; isti nerešeni/novi sadržaj preživljava review i kasnije poslovne faze. Zeleni karakterizacioni test čuva dokaz kvara, ne potvrdu proizvoda.

**Zaseban price-display podslučaj:** ranija izolovana proba na 5e7790e šalje „Cena je 100 RSD.”, a sintetički provider vraća `need.price_rsd=100`, `displayValue="100 EUR"` i evidence „100 RSD”. Stvarni handler prosledio je oba podatka completion-u i vratio HTTP200. Relevantne cele funkcije `parseV2Output` i `guardConversationTurn` ostale su identične do a969; četiri SQL evidence fajla imaju iste hash-eve. Cela novija Edge datoteka ipak nije ista, pa ovo ostaje preneta reprodukcija uz proveru tačnog kontinuiteta, bez novog izvršavanja. [P08]

Aktuelni parser je NEED `:685–706`, a `src/ui/objava/reviewFacts.ts:52–55` formatira cenu iz broja kroz `novac`. Zbog tog formattera nije potvrđen pogrešan prikaz EUR u glavnom pregledu. Normalizovati prezentacionu kopiju uz očuvan tipizovani iznos i dokazati stvarne potrošače; ne pomešati ovaj slučaj sa zastarelom potvrđenom cenom posle korisničke korekcije.

### F04 — Parcijalan katalog može postati „potpun” keš

**Vlasnici:** `supabase/functions/_shared/backgroundTaxonomyArchitect.mjs:267–350`; `rpc_taxonomy_query_catalog_service`, `supabase/migrations/20261019104047_taxonomy_parent_navigation_and_mode_admission.sql:178–352`.

Fallback ROOTS/CHILDREN koristi limit 100, ne prati nextCursor i ima šest serija po 32 roditelja bez dokaza završenog reda. Nevažeća strana može biti preskočena. Rezultat se indeksira kao full; kasniji potpun snapshot iste version/fingerprint vraća stari parcijalni objekat.

**Izvršeno:** 202 čvora → 200; naknadni potpuni snapshot → isti objekat 200; malo stablo sa NEED-shaped CHILDREN HTTP503 → 1/2 bez exception-a; pozitivna kontrola 2/2. NEED helper vraća failure envelope, WORKER helper za HTTP failure baca; ne izjednačavati njihove sve greške. [P03]

Snapshot limit 4 MiB naspram handler limita 512 KiB i mode-less pretci su dodatne statičke granice. DEV agregat od 153 established čvora, najviše 12 dece i dubina 5 ne pokazuje trenutno prekoračenje. **Zatvaranje:** dokaz potpunosti ili jasno tehničko nedovršenje; nepotpuno stablo ne predstavlja se modelu kao celina i ne blokira kasniji potpun keš.

### F05 — Semantički identitet, nova grana i sintaksička prepreka nisu spojeni u jedan aktivan ugovor

**Vlasnici:** `supabase/functions/_shared/backgroundTaxonomyArchitect.mjs:365–402,468–569,595–637,778–847`; `supabase/functions/_shared/classificationGeminiShadow.mjs:43–63`; requester Edge `:499–500,1447–1462`; worker Edge `:287–333`; `taxonomy_review_candidate_projection_v2` i batch writer.

Exact canonical naziv i upisani alias imaju deterministički put. Glavni requester prompt već normalizuje opis u naziv konkretne usluge, pa nije tačno da nema semantičke obrade. Preostali smislen sinonim van canonical/alias skupa nema dovršen BG reuse/admission put: schema requester odluke nema pun REUSE/categoryId izlaz, a neprihvaćen REUSE vraća `SEMANTIC_REUSE_ADMISSION_UNAVAILABLE`. Kontrolni probe potvrđuje alias uspeh i taj neuspeh za neupisan sinonim. [N04]

SQL podržava CREATE_NEW_BRANCH i višestepeni path; aktivni BG builder proizvodi jedan CREATE_CHILD pod postojećim roditeljem. Bogatiji full-snapshot ugovor sa canonical imenovanjem, novom granom i očuvanjem kroz obične odgovore postoji u shared modulu, ali ga dual foreground put zaobilazi. Postojanje instrukcije u repozitorijumu zato ne dokazuje da je aktivni handler primenjuje.

`taxonomy_risk_triage_v1` naziv bez razmaka automatski šalje u NEEDS_CLARIFICATION. Stvarni SQL probe daje `Sisanje` → NEEDS_CLARIFICATION, `Sisanje kose` → LOW_RISK_CANDIDATE, bez aktivnih risk pravila. Ta provera utiče i na EXTEND_MODE usluge/postojećeg naziva (`20261019104047…:430–447`; `20261021104455…:899–901`), ne samo na novi list.

**Zatvaranje:** jedan proverljiv aktivan ugovor za isti smisao/isti ID, stvarno novo/mesto u stablu i opravdano razjašnjenje. Čuvati scope/safety/ID integritet i korisničku potvrdu ponude; ukloniti izjednačavanje broja reči sa značenjem. Ne stvarati duplikat za svaki sinonim, ne izmišljati UUID i ne uvoditi ručni katalog za korisnika.

**ID posle klasifikatora: dva postojeća SQL vlasnika.** `needs_sync_taxonomy_category_trigger_fn` radi kao `BEFORE INSERT OR UPDATE OF category`, traži canonical ključ bez alias-a i za `/` pokušava poslednji naziv putanje; neprepoznat neprazan tekst može postaviti ID na NULL. Ranije živo telo i uključen trigger su u P10, a P04 revalidira isti body MD5 `3244c0fd784d722ece2e3ace8688bfe7`. Source `supabase/migrations/20261013193000_uskoci_needs_category_sync_trigger.sql:4–22` nema živi slash fallback. Potpisani Need binder `20261021104455…:1270–1316` proverava owner/revision/ID konflikt i menja samo `category_id`; sam ne pokreće UPDATE-OF-category trigger.

Worker sync iz `20261021104455…:1752–1834` bajtno odgovara ranijem živom telu; P04 potvrđuje MD5 `8bfb57431cd6a6fcff2e1e80fe8b5fbc`. Jedinstven canonical naziv ili registrovan alias zadržava postojeći ID. Neregistrovano preimenovanje može ga izostaviti iz retained skupa i opozvati capability/opt-in; dodavanje nepoznate usluge uz zadržanu staru ne opoziva sve. Sync ne stvara niti oživljava novi autoritet. Izričito povlačenje mora ostati delotvorno. Trigger owner je `supabase/migrations/20261014093000_uskoci_worker_profile_authoritative_capability_sync.sql:131–147`.

Proširiti A03/A07 na canonical/registrovan/neupisan sinonim, pogrešnog roditelja sa stvarnim završnim listom, ID-only binder, novo dodavanje uz očuvan stari naziv, izričito povlačenje i zastarelu listu. Nije izvršen novi poslovni upis; ovo je pročitani SQL lanac sa prenetim živim telima i njihovom revalidacijom. [P04, P10]

**F05 dopuna: vernost stabla u promptu.** Snapshot SQL sortira po canonical_key/id, a oba BG prompta koriste samo uvlačenje po path dužini, label, ID i modes. ParentId/path/aliasi se izostavljaju. Svež agregat ima prvi element koji nije koren, 73 children-before-parent, 31 noncontiguous podstablo i 25 nelisnih čvorova koji nisu prvi u sopstvenom podstablu. To dokazuje nedostatak strukture ulaza, bez izvršenog modelskog odgovora. Popraviti kompaktan eksplicitan id/parentId/label/aliases/modes/isLeaf ugovor ili validan preorder. `20261023200000_taxonomy_snapshot_and_turn_hints.sql:35–53`; `backgroundTaxonomyArchitect.mjs:360–363,590–593`; Z13.

### F06 — Klasifikacija može ostati nedovršena i posle uspešnog modelskog odgovora

**Vlasnici:** requester Edge `:1530–1641`, worker Edge `:517–615`; capture `20261021104455…:1318–1471`; worker prepare `supabase/migrations/20261021103732_worker_equipment_retired_signed_policy.sql:225–420`; completion `20260913044510…:157–198`; `supabase/functions/_shared/taxonomyPostSaveWorker.mjs:25–76`.

Source a969 ima stvarnu lifecycle popravku: devetosekundni rok počinje pri BG startu, neuspešan/nevažeći completion prekida neodvojeni rad, a potvrđen uspeh dopušta bounded capture posle zatvaranja stream-a. ACK se proverava, dijagnostika je fiksna i bez privatne proze. To treba sačuvati. Abort lokalnog transporta nije dokaz udaljenog rollback-a ili povraćaja modelskog troška. [P02]

I dalje nema pouzdanog trajnog pre-review rada za izgubljeni prvi predlog. Novi handler testovi potvrđuju da ista usluga posle store/capture failure-a ne pokreće automatski novi pokušaj. Builder `failures/unresolvedServices` se uglavnom ne prenose u trajan status; `.catch(()=>null)` može ostaviti samo odsustvo rezultata.

**Nov potvrđen slučaj bez provider failure-a:** worker hint vezuje ceo `candidate|revision|base_hash`; svaki uspešan turn povećava revision, čak i finish `patch:{}`. BG se pokreće samo za skills/mod/handoff promenu podržanu tekućom porukom ili pending pitanje. Pregled traži novi puni otisak; continuity fallback važi samo za netaknutu sesiju sa revision=0 sa precizno sačuvanim potpisanim izborom. [N04, N05]

Izolovano izvršenje svežeg živog completion tela potvrđuje revision 1→2, jednak kandidat, dva važeća hint-a→nula tekućih hintova, exact status REVIEW_REQUIRED. Stari redovi nisu fizički obrisani. Signed prepare telo je sveže pročitano i byte-equal migraciji, ali ceo prepare/Save/binder nije izvršen.

Requester ima uži analog: trigger prati service/scope/mode/handoff, dok `ai_task_review_source` sadrži sve facts/messages/turns (`20260912213702…:69–82`; media wrapper `20260912224647…:318–327`). Običan budžet/vreme odgovor može učiniti predlog nove grane ili moda zastarelim bez novog BG rada. Existing exact/alias kategorija naručioca može se i dalje rešiti iz činjenica; ovo nije tvrdnja da svaki requester nastavak ruši klasifikaciju. Taj deo je statički lanac, bez dodatnog end-to-end izvršenja.

Save sam ne rekonstruiše propušten plan. Outbox reconciler zahteva nonempty candidates + fingerprint (`20261021104455…:1983–2005`); pending reconciler beleži nezavršen review (`:2025–2069`). **Zatvaranje:** relevantni semantički rezultat se bezbedno revalidira/revezuje na tekuću reviziju, ili trajno dovršava; stvarna promena poništava stari rezultat. Statusi tehničkog prekida, stvarnog pitanja i validnog predloga ostaju različiti. Ne uklanjati stale/account ograde i ne uvoditi blanket category_id uslov za svaki Save.

### F07 — Dodatni model poziv nema zatvoren zaseban obračun

**Vlasnici:** requester Edge `:1430,1493–1503`; worker Edge `:335–342,623–630`; BG `:41–57,406–425,638–657`.

Glavni provider ima rezervaciju/settlement; BG direktno fetch-uje i parser ne prenosi usageMetadata u odgovarajući zaseban attempt/settlement tok. Nema posebnog operation ID/onUsage ugovora na tom pozivu. To je statički jaz, ne dokaz stvarnog prekomernog računa. Exact/cache i trigger mogu izbeći poziv; nije svaka poruka obavezno dva modela.

**Zatvaranje:** svaki stvarni BG pokušaj ima budžet, identitet, poznat ili izričito nepoznat obračunski ishod; uspeh, abort, gubitak odgovora i retry ne prepisuju ili dupliraju račun glavnog poziva. Retry iz F06 mora poštovati isti ugovor.

**Transport i potpunost izlaza:** BG `:41–57` čita telo kroz `res.json()` bez ograničenja bajtova. Nedostajući `finishReason` prolazi, dok prisutan završetak različit od STOP već odbija. Shared `supabase/functions/_shared/geminiTaskStream.ts:250–335` traži potvrđen STOP i ograničava telo na 524.288 bajtova. BG direktni pozivi `:406–427,638–659` imaju `maxOutputTokens:1024` i thinking override samo za model čije ime sadrži 2.5; shared request normalizacija `geminiTaskStream.ts:92–113` ima svoj low-thinking ugovor. Razliku treba uskladiti gde je primenljivo, bez tvrdnje da je određena realna modelska sesija zato pogrešila.

Devetosekundni BG rok već postoji. Parser već spaja tekstualne delove i vraća tipizovane bezbedne greške; ne vraćati stare tvrdnje da nema timeout-a, čita samo prvi deo ili izlaže sirovu grešku. Zatvaranje transporta uključuje nedostajući STOP, preveliko telo, truncation, prekid i pozitivan potpun odgovor, uz zaseban usage/attempt ishod.

**Odvojeni STT obračun:** `supabase/functions/uskoci-speech-session/index.ts:75–88` oslobađa test rezervaciju ako nema transkripta. `proxy.ts:10–31,139–155` već može proslediti audio i vratiti `audioBytes>0`; release helper je `supabase/functions/_shared/aiTestBudget.ts:69–88`. Sva tri fajla su istog hash-a kao u ranijem pregledu. Odsustvo teksta nije dokaz odsustva provider obrade. Potrebna je odluka po dispatch/usage dokazu ili izričito nepoznatom ishodu. Ovo je statički rizik internog obračuna, bez potvrđenog pogrešnog računa, i nije isti sistem kao SB04 voice-upload journal.

### Konkretan ugovor keširanja celog stabla

Z13 povezuje aktuelni snapshot SQL, verzionisanje, kompletan Edge loader i oba potrošača. U `loadFullCatalogTree` puno preuzimanje snapshot-a prethodi poređenju memorijskog cache ključa. Sadašnji pogodak zato štedi deo rekonstrukcije, ali ne izbegava taj RPC i payload. Keš je memorija pojedinačne instance, ne trajni globalni izvor. Prema [Edge ograničenjima](https://supabase.com/docs/guides/functions/limits), worker ima konačan vek; [waitUntil](https://supabase.com/docs/guides/functions/background-tasks) ne pretvara pozadinsko obećanje u trajni red.

Read-only agregat 27.10. u 14:41:05 UTC, sastavljen po istom snapshot CTE-u bez pozivanja poslovnog RPC-a, ima version 11/fingerprint `ba726547356009e7e59fdd405adf1b1c`: 153 ukupno/ESTABLISHED/root-reachable/snapshot čvora, 120 listova, jedan koren, devet BOTH čvorova, nula strukturnih čvorova bez sopstvenog moda, dubinu pet, najviše 12 sibling čvorova i 17 alias redova/različitih alias prikaza. SQL JSONB text envelope je 71.388 bajta, category array 71.113, a sadašnja prompt-tree serijalizacija 13.168 UTF-8 bajta/13.071 codepoint. To nisu HTTP compression veličina, tokenizer rezultat, trošak ili latency merenje.

| Sloj | Ciljni vlasnik i ugovor | Obavezna granica |
|---|---|---|
| Baza | Važeća taksonomija i canonical ID; verzija i fingerprint celog semantičkog sadržaja. | Promena naziva, aliasa, mode/scope/parent pravila menja relevantan identitet; verzija se proverava pri prijemu plana. |
| Edge snapshot | Potpun immutable objekat, uslovni snapshot RPC sa malim NOT_MODIFIED odgovorom, single-flight po instanci i atomska zamena. | Hladan start, propala strana, promena verzije tokom učitavanja i stari parcijalni cache ne smeju dati lažno potpun indeks. |
| Gemini kontekst | Stabilan zajednički prefiks; explicit cachedContent samo za stvarno podržani model/API i ekonomičan sadržaj. | Nije pristup Edge memoriji; model zahteva novi generation poziv za novu klasifikaciju. |
| Semantički rezultat | Ponovna upotreba istog razrešenog značenja za važeći nalog/uslugu/mode/handoff, uz novu vezu prema review-u. | Ne prenositi staru saglasnost na stvarno izmenjenu nameru, drugi nalog ili nepotpun BOTH. |
| Trajan posao | Evidentiran nedostajući prvi plan, lease/attempt/retry/rok i idempotentni capture. | Restart ili gubitak ACK-a ne proizvode dupli upis ili neograničeno ponavljanje modela. |

[Google cache vodič](https://ai.google.dev/gemini-api/docs/caching) razlikuje implicitni i eksplicitni cache. Za Gemini 3.8 Flash implicitni prag je 4.096 input tokena; pogodak nije garantovan. API porodica i stvarno izabrani model moraju se ponovo proveriti pri implementaciji, bez tihog prelaska na Interactions API, gde je sada dokumentovan samo implicitni cache. [Explicit cache API](https://ai.google.dev/api/caching) vezuje nepromenljiv sadržaj za konkretan model i vreme isteka; [generateContent](https://ai.google.dev/api/generate-content) prihvata `cachedContent` referencu. Proverena podrška ne znači da je cache u sadašnjem USKOČI kodu već ugrađen.

Kandidat za explicit cache sadrži samo katalog i zajedničke instrukcije, nikada korisnički razgovor, nalog ili privatni profil. Ključ obuhvata projekat, katalog version/fingerprint, tačan model, verziju prompt/response ugovora i svrhu ako se instrukcije razlikuju. Registry ne sme računati na trajnost Edge memorije; kreiranje identičnog provider cache-a mora biti ograničeno i objedinjeno kroz lease/idempotency. Novi snapshot postaje aktivan tek kada je potpun. Potvrđen cache miss, istek ili odbijen nevažeći cache imaju jedan ograničen fallback ili ponovno kreiranje, uz potpun snapshot i kontrolu budžeta; nemaju petlju niti prelazak na prazno stablo. Timeout ili izgubljen odgovor već poslatog generate zahteva nije dozvola da se taj plaćeni zahtev automatski ponovi. Njegov nepoznat ishod ostaje zasebno zabeležen.

Pri odluci o eksplicitnom cache-u meriti tačne tokene, veličinu celog stabilnog prefiksa, učestalost reuse-a, TTL i cenu skladištenja. Ova analiza nije zvala model ili countTokens i nije merila buduću uštedu. Za generateContent obračun koristiti njegov stvarni `usageMetadata`: `promptTokenCount` već uključuje cached ulaz, `cachedContentTokenCount` je njegov deo, a `candidatesTokenCount`, `thoughtsTokenCount` i ukupni zbir imaju odvojeno značenje. Cached tokene ne sabirati dva puta. Zapisati i trošak/ishod cache create/refresh, neuspešnog pokušaja i nepoznatog provider ishoda. Naziv polja iz druge API porodice ne prepisivati u ovaj parser.

**Redosled optimizacije baze:** sadašnji META ponovo izračunava fingerprint i eligible count; njegovo ime ne znači O(1). Postojeći SQL fingerprint nije digest svih prompt bajtova: ne uključuje neposredno display label, alias label i scope vrednosti. Pre NOT_MODIFIED/provider-cache upotrebe dopuniti relevantni stamp/content digest, tako da promena prikaza uz isti normalized key ne zadrži stari prefiks. Uslovni odgovor postojećeg snapshot vlasnika prvo uklanja nepotreban puni payload i bezuslovni prefetch po poruci. Ako merenje opravda unapred izračunat stamp/payload, održavati ga atomarno pri svakoj relevantnoj category/mode/alias izmeni ili koristiti izričito dirty stanje koje nije važeći snapshot. Ne uvoditi dodatnu materijalizovanu kopiju pre nego što su svi pisci obuhvaćeni. Nepovezana promena globalne verzije može dozvoliti postojeću bezbednu revalidaciju istog semantičkog plana; ne uvoditi opšte odbacivanje svake stare oznake umesto te provere.

**Memorijski cache i pitanje:** sadašnji novel-decision ključ nema fingerprint/model/prompt verziju ni ograničenje veličine/isteka; clarification mapa nema eviction. Dodati ograničen život/veličinu i razdvojiti otkazivanje jednog waitera od zajedničkog load-a. Prefetch i builder sada mogu napraviti dva snapshot poziva za isti dual turn. Worker builder može pozvati Gemini i za ceo već poznati spisak; obraditi samo stvarno promenjene/nerešene jedinice uz očuvan kompletan review. Stablo trenutno dolazi posle promenljivih service/scope delova prompta; stabilan javni prefiks treba postaviti prvi. Ovo su kodom potvrđene prilike za poboljšanje, bez tvrdnje o izmerenom curenju memorije ili već dokazanom novčanom gubitku.

Pozitivni dokaz mora pokazati da stabilna verzija ne preuzima ceo katalog ponovo, da nov razgovor dobija isti važeći ID i da oba moda opstaju. Negativni dokaz obuhvata hladan start, paralelni miss, nepotpuno listanje, izmenu aliasa/mode-a, provider expiry/mismatch, promenu modela/prompta, stale plan i nepotpun BOTH. Merenja latencije razdvojiti na foreground, load/catalog, background model i SQL capture; ukupno trajanje i tačnost imaju prednost nad samim brojem AI poziva.

### F08 — Worker mode ugovor nije jedinstven; nepotpun BOTH može postati READY

**Vlasnici:** `supabase/functions/_shared/workerServiceModeContext.mjs:40–78`; `supabase/functions/_shared/serviceExecutionInstruction.mjs:7–14`; BG `:595–637,683–688,733–845`; worker capture `index.ts:578–589`; signed prepare `20261021103732…:268–286`; exact projection [N05].

Glavni shared ugovor dopušta inherentno jasan početni mode konkretne nove usluge; BG traži eksplicitno ponuđen/sačuvan mode i kaže da vrsta posla nije dokaz. Sačuvani izbor ima prednost nad nagađanjem; citat USER poruke dokazuje poreklo, ne potpuno razumevanje saglasnosti.

Za izričit BOTH builder traži dva moda, ali provider schema ima mode po item-u i prompt ne nalaže jasno oba item-a. Izolovana proba pravog buildera i sveže exact SQL projekcije: provider ON_SITE-only → jedan proposal + REMOTE failure → **READY samo ON_SITE**. Pozitivna kontrola sa dva item-a daje READY oba moda. Capture proverava `proposals.length>0`, ne očekivanu celovitost. [N04]

To nije tvrdnja da BOTH uvek pada niti zaobilaženje Save saglasnosti: korisnik i dalje potvrđuje prikazani review. Problem je gubitak prethodno izražene namere. REMOTE obuhvata rad kod sebe/radionicu i fizičku predaju, ne samo digitalno. Izostavljen handoff nije `{required:false}`; BG handoff polja se trenutno ne koriste kao saglasnost, već se uzima foreground/saved izbor.

**Zatvaranje:** kompletan očekivani skup service–mode–handoff za reviziju; isti canonical ID za oba moda; delimičan rezultat ostaje jasno nedovršen; nepogođeni potvrđeni izbori ostaju. Uskladiti prompt/validator/prepare, uz server proveru potpunosti van samog prompta.

### F09 — Završetak worker razgovora nema autoritativan signal

**Vlasnici:** worker Edge `:195–207`; `src/app/(app)/profil/razgovor.tsx:404–433`; worker snapshot/decoder.

`hasProfileContent` govori da postoji sadržaj, ne da je intervju završen. Snapshot nema interviewComplete signal. Poziv modela na pregled, `review.canAccept`, classification READY i saved receipt imaju različita značenja.

**Zatvaranje:** kompletni potrebni podaci prirodno vode jednom završnom pregledu; jedna stvarna nejasnoća vodi jednom pitanju. Opciono bio/kalendar ne odlažu završetak; „to je to” nije automatski Save. Zadržati isti završni izbor Save/Save+activate i postojeće account/focus granice.

### F10 — Sačuvani profil prikazuje manje značenja nego review

**Vlasnici:** `src/ui/workerProfile/WorkerAiPresentation.tsx:147–237`; `src/app/(app)/profil/razgovor.tsx:364–379`; `src/ui/workerProfile/WorkerProfileSaved.tsx:51–100,103–135`; `src/ui/workerProfile/WorkerProfilePresentation.tsx:131–155`; `src/hooks/useWorkerExecutionModes.ts:7–29`.

Review pokazuje mode/handoff po usluzi i pending tekst; to ostaje neposredno posle Save. Tek `/profil/radnik` koristi zbirni mode receipt bez per-service handoff/classificationState ulaza. To je gubitak detalja u prikazu, ne dokaz da je baza izgubila podatke ili sve stare sposobnosti.

Tekst „čeka potvrdu kategorija” u review-u izlaže unutrašnji posao korisniku. Samo običan REVIEW_REQUIRED nema isti reload CTA kao istek/catalog problemi (`src/app/(app)/profil/razgovor.tsx:355,379`). Profil sa workAreas može dobiti i poseban legacy poziv za potvrdu pina; nije dokaz prepisivanja područja, ali odnos dva ulaza nije jasan.

**Zatvaranje:** postojeći profil pokazuje istu bitnu per-service nameru i konkretno čekanje; copy govori da li osoba treba nešto da odgovori ili sistem završava obradu. Jedan merodavan smisao područja/pina, bez dodatnog obaveznog formulara i bez lažnog matching obećanja iz ACTIVE statusa.

### F11 — Izgubljeni abandon ACK u pregledu nema odgovarajući readback

**Vlasnici:** `src/app/(app)/pregled-zadatka.tsx:119–160,225,370–388,566–594`; `src/data/aiTaskReviewClientService.ts:69`; `src/hooks/useOwnedEditor.ts:101–110`; prepare RPC-jevi [P04].

Unbound pregled bez Need-a/komande šalje abandon. Ako server završi ABANDONED, a ACK se izgubi, „Proveri” ide opštim review read-om. Bez komande pokušava novi prepare, koji odbija status različit od OPEN. Copy tada može reći da je razgovor sačuvan i da se učita njegov zadatak, iako Need ne postoji. Uspešna grana inače pravilno proverava tačan ABANDONED authoritative receipt (`src/data/aiNeedV2Production.ts:421–428`).

**Dokaz:** source i živa prepare tela; postojeći test `review-exits-and-place:351–363` proverava refusal/ponuđen Proveri, ne ceo uspešan-abandon/lost-ACK/Proveri sled. Nije izazvano na živom nalogu; Back postoji i nije dokazana blokada cele aplikacije.

**Zatvaranje:** čitanje ishoda iste operacije razlikuje ABANDONED od OPEN bez novog write-a, review-a ili lažnog Need-a. Abandon ostaje promena statusa, ne tvrdnja o fizičkom brisanju svih podataka.

### F12 — Više guard-ova može tražiti više razjašnjenja odjednom

**Vlasnici:** requester natural guard; `src/data/__tests__/ai-natural-server-guard.test.ts:299–308`.

Kombinacija ponavljanih smena i satnice/dnevnice sastavlja više poruka. Postojeći test već očekuje oba sadržaja; nije praznina u kojoj takav primer nikad nije pomenut. To je requester nalaz, ne automatski worker incident.

**Zatvaranje:** jedan vlasnik bira sledeću najvažniju nejasnoću, zadržava drugu i sve jasne činjenice. Broj upitnika nije semantic acceptance kriterijum; jedna rečenica može tražiti više različitih odluka.

### F13 — Posle uspešne prijave sledi moguć zastareo profilni upis

**Vlasnici:** `src/app/(app)/prilike/[id]/prijava.tsx:152–186`, naročito 173–179; `src/data/workerProfileClientService.ts:38–68`.

Posle success receipt-a i await čišćenja application journal-a, opcioni izbor „dodaj veštinu” šalje celu ranije uhvaćenu `pending.profile.vestine` listu plus kategoriju. Pre te druge radnje nema nove provere izvornog account/revision konteksta. Adapter uzima trenutnu sesiju pri pozivu. Korisnikov izbor postoji; on ne autorizuje zastarelo prepisivanje cele liste ili prelazak u drugi nalog.

**Dokaz:** konkretan statički niz; nije izazvan živi incident. **Zatvaranje:** vezana namera za tačnu uslugu i vlasnika, aktuelna dozvoljena revizija ili kontrolisan odvojeni tok. Proveriti paralelnu izmenu liste, A→B→A i kasni callback. Ne menjati već potvrđenu prijavu zbog neuspeha ove sporedne radnje.

### F14 — Source, Edge, SQL i instalirani klijent su različiti potvrđeni preseci

U preuzetim Edge paketima NEED v151, WORKER v104 i post-save v5 poređene su 43 pojave fajlova: 29 potpuno istih, 33 istih posle LF normalizacije, 10 sa kodnim razlikama, odnosno 7 jedinstvenih putanja. Razlike obuhvataju handlere, BG, mode context, shadow, phase timing i post-save entry. Source lifecycle poboljšanja ne prenose se automatski na te deployment-e. [P05]

Instalirani source fcef803 je sada identifikovan oznakom na snimku i odvojenim GitHub sadržajem; efektivne zastavice učitanog OTA bundle-a nisu ekstrahovane. Trenutni EAS P6 flag 0 naspram instaliranog izvora sa flagom 1 menja reader; samo postavljanje na 0 ne znači popravljen P6 proizvod. Za završni dokaz treba zabeležiti konkretan source, stvarni Edge sadržaj/verzije, SQL/flagove, APK/OTA i uređaj. [N01–N03]

Sveža AI SQL provera: exact body MD5 `68eea7a2a923f558f2c27cc6c58f7073` identičan izvornom dokazu; signed worker prepare MD5 `b1fea09e43410257f8d731cbee444ec6` identičan migraciji; worker completion se razlikuje samo u dva SQLSTATE literala 40001→PT409. To su hash-evi **tela**, ne cele pg_get_functiondef reprezentacije. Izvršeni su samo fresh completion/exact u fixture-u. [N04, N05]

**Zatvaranje:** dokaz za jednu stvarnu isporučenu kombinaciju i podržane stare klijente; zeleni CI ili isti broj verzije sami nisu dovoljni.

**Sačuvana ispravka price-basis sumnje:** poslednje source telo `private.need_material_snapshot`, `supabase/migrations/20260910130851_clean_w02_resolved_location_authority.sql:407–450`, nema `priceBasis`; ranije read-only preuzeto živo telo ga ima. Source SHA ostaje isti kao u prethodnom dokazu. `need_full_edit_snapshot` u `20260904230000_clean_ru4_ai_edit_conversation.sql:5–21` nadograđuje snapshot, a `task_replacement_material` u `20261021101527_staged_task_replacement_noop_guard.sql:3–22,30–42` čuva i poredi sadržaj pri no-op proveri. [P09]

Zato je ranija sumnja da sama promena osnovice mora biti ignorisana na živom serveru **povučena**. Otvorena je reproduktivnost izvora i provera podržane price-basis-only izmene kroz signed review/replacement. P04 revalidira stage body, ali ne revalidira material snapshot niti replacement-material helper; njih ne označavati kao sveže pročitana živa tela ove završne etape.

**Granica grantova i istorije:** `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql:12` daje `service_role` prava nad svim javnim rutinama. To može proširiti ranije uske dozvole/revoke nad konkretnim wrapperima. Noviji migration metadata u N02 sadrži identitet te migracije; istorijska SOURCE_ONLY oznaka ne znači da taj identitet sada ne postoji. Sam zapis primene ne dokazuje tačne izvršene statement bajtove ni današnji efektivni ACL. Proveriti relevantne dozvole pre njihove naredne promene; nije dokazan anon/authenticated pristup, korisnički incident ili javno otvaranje privilegovane uloge.

Migration identitet, rekonstrukcija snimljenih izjava, original-byte jednakost i današnje telo funkcije različiti su dokazi. `20260830191500_clean_p0_authoritative_fixes.sql` nosi RECORDED_STATEMENT_RECONSTRUCTION za sedam izjava; registar čuva tu provenijenciju, bez tvrdnje o identičnim originalnim bajtovima. Konkretni bootstrap/fixture uslovi su u odeljku 8.

### F15 — Instalirani P6 klijent traži MAP koji živi discovery RPC ne podržava

**Vlasnici instaliranog i sadašnjeg identičnog reader lanca:** `src/data/discoveryV1MarketplaceAdapter.ts:33–51` → `src/data/discoveryV1ScreenSession.ts:132–149` → `src/data/discoveryV1Owner.ts:135–155,195–217` → `src/data/discoveryV1ClientTransport.ts:38`. Server: `rpc_discovery_v1`; baseline `supabase/migrations/20261025000000_baseline_core_client_rpcs.sql:71–236`.

U instaliranom izvoru preview/production P6 flag je 1. Onsite ruta startuje PAGE, zatim world-seed MAP, čak i kada PAGE nema stavke. „Na lokaciji” i prisutno „Za mene” na slici dodatno odgovaraju P6 putu. Živi RPC prihvata samo PAGE/EXACT_PUBLIC i za MAP/PLACES baca `P6_MODE_NOT_IMPLEMENTED`/22023. Funkcijsko telo je byte-identično reduced baseline telu. [N01–N03, S02]

Agregatni logovi 27.10.2026. 06:40–06:56 UTC, pribavljeni tokom audita, sadrže 6 discovery HTTP 200, 5 HTTP 400 i 5 odgovarajućih PostgreSQL `P6_MODE_NOT_IMPLEMENTED` grešaka, uz 3 uspeha zasebnog legacy endpointa. Na slikama je 07:51, ali bez datuma/vremenske zone, a sva tri EXIF zapisa su prazna. Podudarnost sa ovim prozorom postoji samo ako su slike od 27.10. i telefon koristi Europe/Belgrade; nije predstavljena kao dokazana vremenska korelacija. To je dokazana klijent/server nekompatibilnost i podudarna živa greška. Nema request ID korelacije sa konkretnim telefonom, pa se ne tvrdi da je svaki log red zahtev sa slike.

Isti live filter whitelist ne prima opcione `forMe`/`minBudgetRsd` ključeve; PLACES je takođe odbijen. „Za mene” na slici nije selektovano, pa taj dodatni lom nije neophodan uzrok viđenog stanja. Stari decoder/HOURLY rizik opisan je u F02.

**Zatvaranje:** usklađen PAGE/MAP/PLACES/EXACT_PUBLIC i filter ugovor, sa kompatibilnošću podržanih klijenata i regresionim gate-om nad stvarno migriranom bazom. Ne primenjivati slepo star candidate niti menjati privilegije da bi se zaobišao nepodržan mode. Flag 0 je druga putanja sa drugačijim funkcijama i skaliranjem, ne završetak ove popravke.

Ta druga putanja ima konkretnu granicu: `src/app/(app)/zadaci.tsx:82–96` preko `src/data/supabaseIzvor.ts:216–278` čita celu otvorenu kolekciju u stranicama od 200, najviše 25 strana, sa ukupnim route deadline-om od 15 s i zahtevima `p_bbox=null`, `p_filters={}`. Core page/ordering/item validacija je stroga; jedna nevažeća stavka ili neuspešna strana može odbiti kolekciju. Opcioni profil/urgency enrichment ima odvojeno degradiranje i nije proglašen uzrokom bez dokaza. P6 „Za mene” se time ne dobija. Ovaj caller lanac objašnjava zašto promena zastavice nije ekvivalentna očuvanju svih mogućnosti i ponašanja.

### F16 — Jedna read greška uklanja mapu; retry menja oblik greške, HALF zaklanja veliku poruku

**Vlasnici:** `src/ui/v2/discovery/DiscoveryV1Screen.tsx:98–118,155–170,206–209,257,277–295`; `src/ui/v2/DiscoveryPresentation.tsx:566–567,620–635,1398–1416,1538–1571`; `DiscoveryListState`; `DiscoveryListSheet`; `src/ui/system/StateView.tsx:53–108`; `_layout` navigacija.

Transport većinu server razloga svodi na DISCOVERY_V1_READ_FAILED. Screen koristi globalni error i za MAP-only failure. `mapShown = where !== 'remote' && !loading && !error` tada uklanja native renderer i ostavlja običnu podlogu. PAGE može imati 50 ispravnih redova, a ekran ipak kaže da zadaci nisu učitani. To je izvršivo potvrđeno, bez native rendera. [N03]

Početni restore failure ne commit-uje snapshot: dobija se samostalna velika poruka. Retry prolazi execute/finally/commit i objavljuje snapshot čak i uz isti failure: sada se vidi discovery shell, filteri i sheet greška. Tri React karakterizacije potvrđuju taj prelaz za PAGE ili MAP failure. Slike odgovaraju oba oblika; stvarni niz korisnikovih dodira nije poznat.

Isti `mapShown` bira `compact` poruke. Error ga postavlja na false baš kada je poruka u ograničenom sheet-u. Full StateView ima ilustraciju 96, title/copy i padding 48/32; compact koristi 48 i manji tipografski/padding skup. Početni error/loading koriste HALF kada nema zapamćenog `view.sheet`; zapamćeni položaj ima prednost. Automatski izbor visine se tokom error stanja preskače. Na slici je polovičan položaj stvarno vidljiv. Donja navigacija stoji preko sadržaja. End padding rezerviše kraj skrola, ali ne čini ceo blok odmah vidljivim u HALF. Na slici 02 navigacija zaklanja deo objašnjenja; veliki retry nije ceo vidljiv i nastavlja se ispod donje granice snimka. Ne pripisuje se svaki nedostajući piksel samo navigaciji. Vidljivi header retry postoji, pa nije tačno da nema nijedne dostupne radnje. [S01, S02, N06]

Lokacijsko dugme ostaje aktivno za onsite i bez mape; može spustiti sheet na PEEK bez rešavanja read greške. Trenutni izvor menja +/peek/navigation detalje, ali zadržava ključni lanac error→mapShownfalse→compactfalse. Nadogradnja source-a sama nije dokaz rešenja.

**Zatvaranje:** razdvojiti PAGE/MAP/PLACES/preview ishode, očuvati upotrebljive podatke i geografiju gde je renderer raspoloživ; prikazati bounded failure i retry baš te operacije. Prilagoditi poruku stvarnom HALF/FULL/PEEK prostoru, velikom tekstu i navigaciji. Proveriti oba početna/retry stanja na native uređaju. Ne pripisivati ovaj uzrok Gemini klasifikaciji ili nedokazanom Google API ključu.

### F17 — Trenutna legacy dijagnostika prikazuje boolean „true”

**Vlasnici:** `src/data/focusedResource.ts:1,61–69`; `src/app/(app)/zadaci.tsx:132`; `src/ui/v2/DiscoveryPresentation.tsx:1398`; `DiscoveryListState`.

Resource odbaci exception i čuva `error:boolean`. Ruta ga zatim tretira kao objekat sa message ili `String(resource.error)`, pa za auth, SQL permission, contract, mrežu i deadline dobija tekst `true`. Svih 5 slučajeva potvrđeno je pravim focusedResource kodom uz sintetički reader. [N03]

Ovo je legacy nalaz trenutnog izvora, odvojen od instaliranog P6 ekrana koji taj prop nema. **Zatvaranje:** bezbedan dijagnostički kod zadržati odvojeno od UI booleana; korisniku dati tačno kratko objašnjenje i odgovarajući retry. Dodavanje dužeg tehničkog teksta u postojeći HALF blok ne rešava F16.

### F18 — Prefilter, saved-area i TODAY vreme mogu izgubiti dozvoljenog kandidata

**Nivo:** statički trag current source + read-only current body/config, bez poslovnog izvršavanja ili brojanja pogođenih naloga. **Dokazi:** Z01, Z02, Z06; individualni nalazi C-LIVE-01–04 i C-LIVE-09.

| Vlasnik / aktuelni body MD5 | Proveren sadržaj | Posledica |
|---|---|---|
| `private.candidate_profile_ids_v1b` / `9a2437fd9d6bed07c8338d12501e5cba` | `match-v1b-remote-waves-20261007/candidate.in-transaction.sql:92–162`; krug 300000m, zatim no-preference/no-geography fallback | Postojeća udaljena legacy tačka izbacuje kandidata pre primene novog saved-area autoriteta. |
| `private.candidate_profile_ids` / `5414fa5a122e2055c71dd37993a6ad83` | `proofs/match_category_fallback/live-candidate-stream.sql:31–94`, ista prostorna pretpostavka | Važi i za aktuelni uncapped delegate; ne svoditi nalaz samo na dormant numerički cap. |
| `private.dispatch_config_v1b` / `7aa34ff0b5f4a3637c433bec317c1c13` | Vrednost workerDailyCap≥1000 pretvara u NULL | Current podešavanje1000 znači isključen dnevni cap; funkcija delegira uncapped putu. |
| `private.worker_area_fit_v1` / `4dd025df4d3d4092a13e06329837ae58` | Migracija `20261023210000…:95–113`; empty/REMOTE→NULL, non-STATIONARY/non-RS→false | Svaki sačuvan workAreas skup aktivira ovu strožu fizičku granicu. |
| `private.worker_need_fit_v1` / `9db80655bfbc9719440bd26459904ab0` | Signed gate, REMOTE handoff, saved area, tek bez područja legacy fallback | False iz saved-area evaluatora ne popravlja se starom profilnom tačkom. |
| `worker_need_match_v1` / `ef94ef7de07a347824ace68789f08c41` | Koriste ga `dispatch_cheap_candidate_admitted` i `discovery_for_me_v1` | Utiče na automatske preporuke i Za mene. |

Aktivni klijent prihvata STATIONARY, POINT_TO_POINT, MULTI_STOP, AREA_BASED i REMOTE: `needClientService.ts:48–76`, `aiTaskReviewClientService.ts:175–196`, `aiNeedV2Ui.ts:165–185`. To nije pet podjednako podržanih area pravila na serveru. Ne proizvesti proizvoljnu reprezentativnu tačku za REMOTE/rutu da bi stari krug prošao.

**Sačuvana granica ručne prijave:** `match_detail_without_calendar` (`efd50886ff898f45129d33231761d189`) svrstava service/area/time preference u dispatchBlockers, dok responseAllowed ima nezavisne hard gates. `rpc_submit_response` (`14c17e882265084cf73456557c6cb3b6`) i `rpc_select_response` (`5556d638e3befbe9739344b57d94d46a`) proveravaju responseAllowed, svet, vlasnika, reviziju, cenu, termine i postojeća ograničenja. F18 nije ovlašćenje da se ručna prijava dodatno zaključa.

**Treći podslučaj — TODAY_FLEXIBLE i kasnija dostupnost:** current `worker_need_time_tier_v1` MD5 `a845d98b624ae4ac8ec33159beb8bb17`, migracija `20261023210000…:254–436`, uklonio je prethodnu posebnu TODAY granu pri dodavanju empty-calendar fallback-a. Za važeći TODAY sa oba endpoint-a NULL, `available_now=false` i stvarnim AVAILABLE/weekly terminom kasnije danas, ne izvodi dnevni prozor. `availability_is_future` traži oba endpoint-a; poslednji period fallback važi samo za FIXED_WINDOW. TimeTier zato ostaje NULL, pa current fit/match/Za mene/dispatch odbija taj par. `available_now=true` i dalje može dobiti tier1. Obuhvaćen je i već započet ograničeni TODAY sa slobodnim preostalim delom dana; nisu svi TODAY ili fleksibilni zadaci pokvareni.

Ovo je dostižan current ugovor: `aiNeedV2Ui.ts`, `aiTaskReviewClientService.ts`, validator `20261023220000` i Edge publicNeed dopuštaju TODAY/null granice; current publication čuva granice; sveža `needs` ograničenja i write/location guard nemaju dodatnu zabranu. `need_search_time_admitted_v1` (`0fd72e9…`, pun hash u Z01) prihvata TODAY do izvedenog kraja dana. Potrebna je jedna vremenska interpretacija vezana za dan objave, sa očuvanim empty-calendar fallback-om gde je nameran. Dokazati sada/kasnije, NULL granice, započet interval, prelaz dana/poslovnu zonu, UNAVAILABLE i stvarni konflikt, istek i obične TOMORROW/WEEK/FIXED slučajeve. Z02/C-LIVE-09 sadrži ceo trag; nema izvršenog matching poziva ili čitanja stvarnog radnika.

**Zatvaranje:** candidate retrieval mora biti bez lažno negativnog izbacivanja u odnosu na merodavan area predicate, uz bounded čitanje, stabilno redosledno/fair ponašanje, remote rotaciju, per-revision dedupe i postojeće budžete. Matrica: stara tačka>300km + COUNTRY; udaljeni izričiti CITY/RADIUS; više oblasti; bez tačke; svaka podržana fizička topologija; REMOTE/handoff; druga zemlja samo prema izričitom tržišnom ugovoru. Stari MAP/PLACES single-circle forMe nije gotova zamena.

### F19 — `workAreas` nedostaje current export i arhivskom projektoru

**Nivo:** field-level current trace, bez čitanja poslovnih redova/izvoza. Z01/Z02, C-LIVE-05 i `work_area_export_trace`.

Current `private.data_export_worker_candidate_v5(jsonb)` ima body MD5 `aa9c5f1b7ab4711cda7cb16905de55a4`, definiciju `13805d515dff783e9be2083a4884f4cb` i 2.559 karaktera. Njegov whitelist nema `workAreas`. Current `data_export_snapshot` (`c3bde16e2175c7ec33c1a171e0ad04a3`) u migraciji `20261021104455…:424–555` koristi ga za workerAiDrafts/profile na473 i workerAiReviews/profile na475. workerAiSaves na483 iznosi reviewId/createdAt, pa nije alternativna puna kopija. Current `closure_taxonomy_project_v1` (`bf004f543c92940845b570d8860288cc`) istim helper-om filtrira arhivski/reset candidate i review.profile.

WA01 od26.10 zaista čuva canonical, server-resolved workAreas u kandidat/review/source hash putu. WAR01 `worker-area-integrated-20261021/candidate.sql` predlaže širi paket12funkcija, ali current tela dokazuju samo delimičnu primenu njegovih ideja. Odgovarajuće polje u predloženom projektoru847–853 jeste korisna namera; stari dvanaestostruki pin i ceo paket nisu važeća primena.

**Sačuvati:** gate `DATA_EXPORT_POLICY_NOT_READY` pre novog upisa kada nema važećeg binding-a; dokazani idempotent replay; scope vlasnika; source/program/certificate granice. Current retention_source/export_bound/erasure_bound nisu spremni. **Zatvaranje:** ista područja i tipovi u živom nacrtu, review-u i reset/arhivskim kopijama, sa pozitivnim/tuđim nalogom i potpunim autorizovanim izvoznim rezultatom; erasure zasebno proveriti. Nije dokazan stvarni nepotpun isporučen izvoz ili curenje erasure-a.

Cityless REMOTE-only aktivacija je još samo predlog: current review/activation traže city, a submit/select nezavisno zahtevaju city dužine≥2. Ako cilj dopušta potpuno REMOTE bez fizičkog grada, svi ti vlasnici moraju se uskladiti. Promena samo jednog starog activation wrapper-a nije dovršen tok.

### F20 — Kapacitet push reda, suppression i exact-target ugovor

**Nivo:** current SQL + current deploy sadržaj + cron metapodaci + stvaran UI caller. Nije nov provider/device/load test. Z01/Z02/Z06, C-LIVE-06–08.

| Podslučaj | Potpuno proverena veza | Kriterijum zatvaranja |
|---|---|---|
| Kapacitet redovnog tick-a | `rpc_claim_push_transport(text)` (`f70229927ca68419e5ca735a5b64b2e9`) skenira64, vraća jedan attempt; transport index zove once(RECEIPT) i once(SEND) jednom, niz jednog slanja, total25s | Bounded loop/batch ili drugo izričito rešenje sa dovoljnim dokazanim kapacitetom, uz lease/UNKNOWN/receipt/target invariants i bez resend-a zbog nepoznatog ishoda. |
| Vezivanje sa rasporedom | `edge_worker_tick_v5` (`7d03dc2c31a629785b5f222786bf4dd9`) uslovno enqueue-uje HTTP ili vraća NOT_CONFIGURED/IDLE; active job2 je minute; current dispatch remote talasi300/1000, interval30min, stop5odgovora | Kapacitet rasporeda se poredi sa dolaskom posla; minuta je cadence, nije dokaz da je događaj dostavljen za minut. |
| Već prijavljen izvršilac | Current cheap/detailed matcher, emitter, dispatch, suppression i begin ne kompenzuju odsutan active same-revision response uslov | Ručna prijava pre prve prilike, prior revision, withdrawn/rejected/selected, trka response/dispatch i obična prva isporuka. |
| PUSH on / IN_APP off | Nezavisni switch `PushPreferences.tsx:485–486`, edit77–85/save255–270; current message i opportunity resolver traže unsuppressed IN_APP | Tačan vlastiti PUSH target/relevantna internal receipt autorizacija bez potajnog uključivanja IN_APP; proveriti oba tipa, obe uloge, expiry i opozvanu sesiju. |

Deployed Edge v37 je tačno jednak source-u: index SHA256 `fa53ecd3623bd26edc81479bbbc207690b54977e861d589f00e039af4cb73a44`; shared notification-copy `a66cccb7e5d8a7500f905fd5d7e7df95a90eac0afbf9e9172714f926b498a731`. Šest aktivnih leases i60claims/s su plafoni zaštite, ne dokaz batch slanja. Redovni lane ima najviše jedan SEND pokušaj po invocation-u pri minutnom cron-u; dodatni service pozivi/gates/retry/suppression/provider potvrda su zasebni.

Historical EX06D-F5 izričito je NOT APPLIED, pa ovo nije tvrdnja da je potvrđena stara popravka izgubljena. Fallback wave fixture nema worker_account_id u response tabeli i ne seje već prijavljenog radnika: njegove PASS tvrdnje ne pokrivaju ovaj podslučaj. Current begin (`fc2dcc23f986d667ef61159ebc435228`) čuva token-first lock/lease/session/Need/revision/world provere, ali targeted delivery statusRESPONDED i dalje prihvata. OPPORTUNITY resolver (`ac726…`, ceo hash u Z01) ima istu IN_APP zavisnost. Očuvati postojeće gates i cleanup starih24h provider tickets; ne uključivati slanje kao deo ove analize.

**Group događaj u F20:** aktuelni group sender MD5 `422795cdb5822e1b4dbaf5c6acf34ffb` odgovara `clean_v5_group_conversation` i upisuje message, immutable visibility i receipt bez `emit_event`; sveži katalog nema trigger na `private.group_messages_v5`, a current inventar nema `group_activity_target_v1`. Predlog `group-message-events-20261021` povezuje emit/resolve/suppression/mark sa tačnom vidljivošću, ali nije aktuelna implementacija. Njegov `proof.rollback.sql:52–54` uključuje PUSH bez postavljanja IN_APP=false, pa ne zatvara nezavisne postavke ni native tap. Ne mešati ovaj nedovršeni događaj sa ispravnim osnovnim slanjem poruke ili kompatibilnim group-message izuzetkom u baseline mark funkciji.

**Sveži operativni dokaz:** sva tri cron-a imaju po 10.080 SQL uspeha u sedam dana i 1.440 u poslednja 24 sata. Retained HTTP agregat ima 360 odgovora 200 u 08:44–14:43 UTC, ne puni 24h ni razvrstane endpoint-e. Pending HTTP queue je tada nula. Poslednji push TICK_OK je 23.10. u 22:23:01 UTC, dakle stale po 300s pravilu; status je UNKNOWN/STALE_RUNTIME_OBSERVATION. Ne tvrditi ni trenutnu readiness ni dokazani potpuni kvar. Z14 čuva SELECT, vreme i safe agregate, bez headers/token/payload čitanja. Postsave handler ne parsira body action, pa odsustvo stringa tick u cron3 nije greška. Deployed catch za stream/UTF-8 retryability se razlikuje od a969 i mora se uskladiti kontrolisano.

### F21 — Authenticated table SELECT poništava granicu tri privatne Need kolone

**Nivo:** sadašnji efektivni ACL + kompletne relevantne current policy/guard definicije; bez čitanja poslovnih redova. Z02/C-LIVE-10 i Z06/`needs_private_column_privileges` beleže 27.10.2026. u 10:40:05 UTC: authenticated schema USAGE=true, table SELECT=true i SELECT=true za `requester_account_id`, `remaining_search_closed_by_account_id`, `remaining_search_close_reason`; anon table SELECT=false. World-helper i account-open izvršne dozvole postoje.

Izvor je `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql:6`, `GRANT SELECT ON TABLE public.needs TO authenticated`. PKG045b je prethodno ukinuo table SELECT i dao 38 javnih kolona bez te tri privatne. Kolonski grantovi ne oduzimaju širi table grant. `needs_public_discovery` dopušta ne-vlasnikov PUBLISHED/SELECTION red u istom TEST/REAL svetu; restrictive `v5_closed_account_visibility` proverava otvoren nalog pozivaoca. RLS ne maskira kolone.

`rpc_read_task` i `needClientService.ts:201` ostaju bezbedno projektovani, ali direct exposed-table request nije vezan za taj RPC. `rpc_close_remaining_search` je i dalje owner-authorized: zahteva postojeći Dogovor i delimično izabranu pokrivenost, prihvata PUBLISHED/SELECTION/ACTIVE, upisuje razlog/actor/vreme bez promene statusa. Konkretan javni scenario razloga je SELECTION sa zatvorenom preostalom pretragom. ACTIVE/historijski nejavni redovi nisu deo ovog nonowner discovery nalaza; za njih važe zasebne owner/participant politike. Nema dokaza o anonimnom ili cross-world curenju niti stvarnoj eksfiltraciji.

**Zatvaranje u prvom paketu:** uspostaviti eksplicitnu javnu kolonsku/projekcionu granicu, uz analizu sadašnjih invoker reader-a, RLS owner helper-a, sopstvenih prikaza i closure schema/certificate posledica. Ne izvršiti slepi REVOKE niti zastareli PKG045b. Synthetic current-role test mora odbiti sve tri kolone kroz direct/alias/filter/order/wildcard i dozvoliti javni/sopstveni potrebni prikaz; uključiti drugi svet i zatvoren nalog. Istorijski `p6_http_boundary` preko Auth/HTTP proverava requester_account_id, a `p6_world_boundary_proof` lokalnim SQL rolama sva tri granta i javni whitelist; to su valjane stare granice, ne današnji PASS.

### Završni dokaz migracionog porekla i performansnih preporuka

Z15 beleži svih 193 source migracija i 314 trenutnih ledger zapisa. Isti ID postoji za 93 source fajla; 100 source ID-jeva nema isti DB ID, a 221 DB ID nema isti source ID. Po imenu se poklapa 94 source migracije; 97 nema ni isto ime ni verziju. Od 314 DB zapisa, 219 ima NULL statements. Samo 39 source fajlova je bajtno identično sačuvanim statements spojenim novim redom. Ovi brojevi označavaju poreklo, ne 100 unapplied migracija i ne zahtev za ledger repair.

| Source ID | DB ID | Naziv | Potpuno pročitana razlika |
|---|---|---|---|
| 20261026145430 | 20261026145706 | worker_ai_signed_work_areas | Samo dodatni završni CRLF; sva tri funkcijska tela ista. |
| 20261026150020 | 20261026150106 | worker_ai_area_source_continuity | Samo dodatni završni CRLF; telo funkcije isto. |
| 20261026150523 | 20261026150745 | classification_hint_revision_fence | Samo dodatni završni CRLF; sva četiri funkcijska tela ista. |

F14 zahteva odvojena dva puta: determinističku izgradnju novog izolovanog okruženja i kontrolisanu nadogradnju postojećeg DEV-a. Porediti definicije, grantove, policy/default izraze, triggere, indekse i potrebne referentne podatke. Ne izvoditi restore/repair na živom sistemu radi usklađivanja broja. Tri istorijske proof migracije sa fixture preduslovima ostaju poseban bootstrap problem iz odeljka 8; njihova pročitana prisutnost nije dokaz neuspeha svake obnove.

**Savetnici:** 325 security stavki u šest grupa i 136 performance stavki u pet grupa su nov trenutni presek, dok ranijih 322 ostaje istorijski. Svih 136 performansnih preporuka dobilo je zapis i vezu sa konkretnom tabelom, trenutnim indeksima i pronađenim funkcijskim referencama. 93 FK bez pokrivajućeg indeksa traže stvaran relevantan query/delete plan; 18 ponovljenih auth/current_setting poziva u RLS može se optimizovati samo uz očuvanu semantiku; pet permissive preklapanja može namerno predstavljati OR dozvoljenih publika. Trinaest indeksa sa nula evidentiranih scan-ova nije automatski za brisanje. Sedam snapshot tabela bez PK prvo zahteva odluku o životu i zavisnostima podataka.

Statistika je sa DEV-a: 167 public/private tabela, oko 25 MB sa njihovim indeksima/TOAST-om, ne veličina celog projekta. `n_live_tup`/`n_dead_tup` su procene. PostgreSQL je 17.6; zabeleženi globalni reset statistike je 20.08.2026. u 19:53:32 UTC, ali pojedinačni reset nije isključen. `track_functions=none`, pa nema osnove da se funkcija proglasi mrtvom na osnovu odsutnog broja poziva. Ovaj teret rada nije reprezentativan produkcioni benchmark.

**Dokazivo preklapanje indeksa:** `private.work_taxonomy_service_scopes_lookup` i `work_taxonomy_service_scopes_pkey` imaju btree nad `(category_id, normalized_scope)`, iste kolacije, klase, smer, broj ključnih/ukupnih atributa, tablespace i reloptions, bez izraza/predikata. Lookup je nonunique/nonprimary, bez constraint-a; PK je unique i vezan za primarni ključ. Lookup je validan/ready, 8.192 bajta, nula scan-ova. Povlačenje obuhvata novu migraciju, source kontrolu, proveru eksplicitnih index/hint zavisnosti i očuvanu unikatnost/lookup; PK ostaje. To nije nalog da se uklone ostali indeksni kandidati.

**Stare tabele sa sadašnjim potrošačima:** šest od sedam DEV snapshot/backup tabela je u `closure_taxonomy_inventory_v1`, `closure_redaction_relations_v5` i `closure_redaction_patch_v5`. `dev_phase1_20261014_needs_snapshot` dodatno čitaju `closure_taxonomy_snapshot_guard_v1` i dinamički `closure_taxonomy_scope_v1`. Za `dev_phase1_20261014_catalog_snapshot` nije pronađena qualified referenca u trenutnim telima; to nije dokaz odsustva istorijske/operativne potrebe. Povlačenje mora prvo promeniti kodirane inventare, guard i scope, sačuvati nužan audit/rollback dokaz i ponovo proveriti export/closure, pa tek potom ukloniti tabelu.

`pg_depend` ima 6.168 relevantnih veza; dodatni indeks iz svih 680 prethodno pročitanih, sveže identičnih tela sadrži kvalifikovane reference. U src/ i Edge source-u nađeno je 95 literalnih `.rpc` mesta u 87 imena. To nije potpun pozivni graf: generički transport, string tela, nekvalifikovani i dinamički nazivi, stari klijenti i operativni pozivi imaju posebnu proveru. [PostgreSQL dokumentacija](https://www.postgresql.org/docs/current/ddl-depend.html) izričito opisuje granicu praćenja zavisnosti u tekstualnim telima. Z16 zato čuva i nerešeni uslov umesto lažne dozvole za brisanje.

## 4. Baseline migracija: šta je kompatibilno, šta treba precizno uskladiti

Pročitano je svih 778 redova `supabase/migrations/20261025000000_baseline_core_client_rpcs.sql`. Pored F15, jedanaest drugih RPC-jeva poređeno je sa aktivnim potrošačima i relevantnim prethodnim telima. Nije utvrđeno da svih 12 funkcija regresira. Telo funkcije ne obuhvata automatski ACL, pomoćne tabele, triggere ili sve žive redove. Nijedan poslovni writer nije izvršen. [N06]

| RPC; baseline redovi | Aktivni klijent | Sadašnji zaključak |
|---|---|---|
| `rpc_get_worker_execution_modes`;241–258 | `src/data/workerExecutionModeClientService.ts:47–76` | Kompatibilan profileId/confirmed/modes/timestamp ugovor; zbirni mode receipt nije entitlement. |
| `rpc_get_my_task_relations`;262–315 | `src/data/supabaseIzvor.ts:388–413`; `src/data/taskRelation.ts:50–74` | Kompatibilno 1–100 ID, OWNER/APPLIED i overlay stanje; odsutno postaje NONE tek posle uspešnog čitanja. |
| `rpc_read_safety_target`;322–347 | `src/data/safetyClientService.ts:86–104` | Osnovni ugovor kompatibilan. Opcioni displayName nedostaje; decoder dozvoljava null, tracked release profil ne uključuje odgovarajući flag. Nije potvrđen aktivni blokirajući kvar. |
| `rpc_read_task`;354–408 | `src/data/needClientService.ts:48–147,197–206`; `src/data/supabaseIzvor.ts:416–457` | Kompatibilan snake_case detalj sa schedule/topology/requirements/capacity/price_basis. Sačuvati ga pri F01 popravci. |
| `rpc_list_my_tasks`;415–428 | `src/data/needClientService.ts:158–175` | Kompatibilna lista rpc_read_task dokumenata sopstvenog naloga; zasebna od paged F01. |
| `rpc_list_my_needs_page`;435–488 | `src/data/ownTasksPage.ts`; `src/data/needClientService.ts:179–194` | F01: scope/count/wire nesklad. EX04a dopuna ne sme biti ignorisana pri sklapanju aktuelnog ugovora. |
| `rpc_get_my_agreement_review_v2`;496–516 | `src/data/reviewCommentsClientService.ts:83–94,149–164`; `src/data/reviewsClientService.ts:47–67` | Kompatibilan context, tag catalog, comment policy/max 500 i sopstveni komentar. |
| `rpc_submit_agreement_review_v2`;523–587 | `src/data/reviewCommentsClientService.ts:97–103,172–209` | Kompatibilni argumenti/receipt, request ID i hash-replay zaštite. Write pročitan, nije izvršen. |
| `rpc_list_review_comments_v1`;594–651 | `src/data/reviewCommentsClientService.ts:106–137,217–240` | Kompatibilni items/author/cursor/hasMore; null je dozvoljeno nedostupno stanje. |
| `rpc_mark_agreement_messages_read`;658–683 | `src/data/supabaseIzvor.ts:500–505` | Kompatibilan integer receipt i novije izuzimanje group_message_id; direct chat ne zatvara grupna obaveštenja. |
| `rpc_list_my_agreements_page`;690–777 | `src/data/agreementClientService.ts:46–148,580–657` | Kompatibilan keyset/currentVersion/terms/ratingDue; zadržava noviji phone-consent guard. Null workspace-only akcije/ID polja u listi nisu nova regresija. |

Popravka treba da sastavi tačne aktuelne ugovore Discovery i paged own tasks, uz očuvanje navedenih novijih ponašanja. Cela istorijska migracija ili candidate skup nisu bezbedna jedinica za slepi rollback.

## 5. SB01–SB15: preostali konkretni poslovi ostatka aplikacije

Ovi nalazi imaju preneti dokaz i sveže poređenje izvora [P07]. Od 72 obuhvaćena fajla, 71 je bajtno isti cb6→a969. Intervju Edge se promenio, ali tri image-only fragmenta SB15 ostala su ista. To potvrđuje opstanak analizirane logike, ne nov runtime incident. Za svaku stavku ostaje tačno imenovana granica prihvatanja.

| ID | Vlasnik i potvrđeni problem | Dokaz, ograničenje i uslov zatvaranja |
|---|---|---|
| **SB01 Početna** | `src/ui/home/HomePresentation.tsx:361–362,418–425`; `src/app/(app)/index.tsx:102–104`. „Otvori zadatak” sa moje prijave vodi na owner pregled tuđeg zadatka; kontrola `src/app/(app)/moje-prijave.tsx:360` koristi javnu priliku. | Preneti statički caller + SHA. Nije dokazan bypass server ovlašćenja. Voditi na `/prilike/[id]`; owner put ostaje za sopstveni zadatak. |
| **SB02 Ocene** | `src/ui/reviews/useGivenRatings.ts:43–64`, `src/ui/reviews/useReceivedReviews.ts:37–50`, `src/app/(app)/profil/ocene.tsx:23–49`, `src/data/focusedResource.ts:104–108`. Isti skup završenih Dogovor ID-eva ne invalidira promenjenu datu ocenu; primljene nemaju obnovu prve strane na običnom povratku. | Pravi hook-ovi sa mock servisom; remount/reload pozitivna kontrola [H01]. Invalidirati posle potvrđene ocene/povratka uz account granice i očuvan poslednji dobar sadržaj. Nije telefon. |
| **SB03 Pravila** | `src/ui/legal/legalReview.ts:25–29,53–114`; `src/app/(app)/profil/pravna.tsx:72–76`. Stari unknown pokušaj + novi TERMS/PRIVACY hash + ponovljeni ABSENT može trajno ostaviti READ_REQUIRED i posle remount-a. | Pravi kontroler, sintetički I/O, 4 ABSENT čitanja / 1 upis [H01]. Autoritativno završiti/otkazati stari pokušaj, zatim nova eksplicitna saglasnost. Jedan ABSENT ne dokazuje da zakasneli zahtev ne postoji. |
| **SB04 Glasovne poruke** | `src/features/voiceMessages/voiceMessageComposer.ts:365–372`; `supabase/functions/uskoci-media/index.ts:174–176`; `supabase/candidates/chat_voice_b1a_feature_chain.sql:323–334`; `src/data/agreementVoiceClientService.ts:102–109`; `src/data/voiceBinaryRead.ts:25–26`; `src/data/serverReceipt.ts:65–69`. Restore uklanja identitet na ABSENT i ne pokazuje PROCESSING/STAGED predmet; spoljašnji read budžet od 15 s skraćuje unutrašnjih 30 s. | Preneti source/živi SQL snimak, bez korisničkog incidenta. Server cancel/reconcile pre povlačenja identiteta i vidljiv oporavak; jedan timeout/abort vlasnik. Foto uzor je `src/hooks/useAgreementPhotos.ts`. |
| **SB05 Avatar** | `src/app/(app)/profil/fotografija.tsx:62–105,117–147,164–218`; `src/ui/profile/ProfilePhotoPresentation.tsx:85–108`. UPLOAD journal postoji, RAM bajtovi izgubljeni, receipt odsutan: nova slika blokirana, discard traži READY asset. | Statički; server-primljen upload može se oporaviti. Avatar cancel/reconcile mora potvrditi stari ishod pre nove selekcije. `src/ui/media/useTaskPhotoUploads.ts:209–226` je obrazac, ali njegov conversation uslov nije avatar API. |
| **SB06 Podrška** | `src/ui/support/useSupportController.ts:24–36`; `src/ui/support/SupportDetailScreen.tsx:44–47,65–68,84`; `src/ui/support/SupportNewScreen.tsx:78–82,133–170`. Background incarnation reset briše neposlat formular/odgovor; detail Back nema reply upozorenje. | Statički i ranije pročitan reset test. Nacrt istog naloga i upozorenje pri namernom izlasku; čuvati reset privatnih podataka na promenu naloga i posle potvrđenog slanja. |
| **SB07 Izmena Dogovora** | `src/ui/agreements/AgreementActionsScreen.tsx:31–45,93–104`; `src/ui/agreements/agreementActionsModel.ts:91–96`. Povratak briše neposlat razlog/predlog; novi termin traži i kraj iako prethodni domen poznaje start bez kraja (`src/ui/v2/draftSummary.ts:18–31`). | Statički, bez bypass upisa. Nacrt vezati za account/Dogovor/verziju i obnoviti review; kraj termina uskladiti kroz ceo ugovor, ne samo ukloniti UI validaciju. |
| **SB08 Obaveštenja** | `src/ui/notifications/PushPreferences.tsx:98–103,189–283`; `src/app/(app)/profil/obavestenja.tsx:24–31,39–73`. Jedna radnja piše REQUESTER pa WORKER; Back ne koristi writing pa drugi korak može stati nakon prvog. | Statički; ne tvrdi se lažan receipt. Pročitati oba stvarna ishoda i nastaviti preostali, ili jedna atomska komanda sa revizijama; sprečiti zbunjujući izlazak usred promene. |
| **SB09 Javni komentar** | `src/ui/reviews/ReviewCommentField.tsx:18,78`; `src/ui/reviews/ReviewCommentsSection.tsx:41–77`; `src/ui/system/PublicProfileSheet.tsx:102–150`; `src/app/(app)/profil/ocene.tsx:50–57`. Obećan komentar na profilu nije povezan sa aktivnim javnim prikazom. | Caller dokaz, bez curenja podataka. Povezati odobren javni prikaz ili promeniti obećanje. `reviewCommentsClientService` context/submit su aktivni i ostaju. |
| **SB10 Osvežavanje poruka** | `src/ui/AgreementChat.tsx:515–533,736`. Montirani refresh button ima height 0 / opacity 0 / hidden overflow. | Statički; screen-reader fokus nije fizički reprodukovan, postoji poseban vidljiv error retry. Radnju prikazati ili uredno povući uz dostupnu alternativu; providnost nije accessibility politika. |
| **SB11 Discovery recovery/keš** | `src/data/discoveryV1SearchOwner.ts:151–164`; `src/ui/v2/discovery/recentSearches.ts:56–69`; `src/ui/v2/detail/useTaskFit.ts:18,36–44`. PLACES decode exception preskače busy reset; recent-search prerano označi nalog učitanim; fit key ne pokriva sve promene kraja/pina/mode. | Statički, dodatno različito od F15/F16. Nije dokaz lošeg živog PLACES odgovora; običan detail refresh šalje null pa fit uslov nije svaki refresh. Finalize loading, loaded tek po prihvaćenom read-u i jasan fit invalidation ugovor. |
| **SB12 Vremenska zona** | `src/ui/v2/ApplicationComposerPresentation.tsx:472`; `src/ui/v2/MyApplicationsPresentation.tsx:160–161`; `src/ui/agreements/agreementListModel.ts:198–206`; `src/ui/agreements/AgreementActionsPresentation.tsx:32–33,284`. Prijava može koristiti uređajnu, Dogovor ugovorenu zonu. | Statički; bez uređaja u drugoj zoni. Jedna eksplicitna politika prikaza/izmene uz očuvan instant i jasno obeleženu relevantnu zonu. |
| **SB13 Map/motion detalji** | `src/ui/v2/DiscoveryPresentation.tsx:499–515,558–572,1561–1571`; `src/ui/v2/discovery/mapControls.ts:44–53`; `src/ui/location/LocationPointEditor.tsx:168–197,520`; `src/ui/location/ResolvedPinMap.tsx:163–164,263–268,340`; `src/ui/entry/EntryWelcome.tsx:47–74`. Nearby copy/camera, zaklonjene kontrole, blur draft, reducedMotion lifecycle i skriven raster readiness. | Statički; F16 posebno ima slike. SVG pin je vidljiv, ali nevidljivi raster može mark failed za celu pin mapu i kontroliše drag. Nije dokazan uzrok discovery slike. Razdvojiti readiness odgovornosti i očuvati funkcionalni pin/drag pre povlačenja rastera; proveriti native dostupnost/pokrete. |
| **SB14 Proof build/validator** | `app.config.js:35–36,75–91`; `scripts/check-eas-preview.cjs:84–87`; `package.json:66`; `scripts/verify-native-patches.cjs:27,204–306`; `.github/workflows/ci-clean.yml`. Proof flag izostavi plugin koji preinstall zahteva; opcioni --repo očekuje povučeni workflow/granu. | Istorijska proba običan preview PASS/proof FAIL [H01], SHA jednak. Nije kvar običnog APK-a/npm ci. Uskladiti namenski proof i validator, sačuvati consent i proveru native patch bajtova. |
| **SB15 Fotografija bez teksta** | `supabase/functions/uskoci-ai-interview/index.ts:1298,1362,1578`; `src/data/aiNeedV2Production.ts:382–418`; `src/app/(app)/nova.tsx:392–411`; `20260913044510…:78–108`. Claim hash dobija zamenski tekst, complete originalni prazan. | Istorijski pravi handler sa sintetičkim SQL/provider I/O: photo-only 502, text kontrola 200 [H01]. Ceo Edge sada nije isti, tri relevantna fragmenta jesu [P07]. Glavni UI foto radi odvojeno; nije kvar svake fotografije. Uskladiti kanonski sadržaj claim/complete bez slabljenja idempotency zaštite; novo izvršenje posle popravke. |

## 6. X01–X06: manji, precizno ograničeni nalazi

| ID | Vlasnik i nalaz | Granica i prihvatanje |
|---|---|---|
| **X01 Safety ključ** | `src/ui/safety/SafetyScreen.tsx:145–155,214–218,253–257`: nevažeći persistent ključ ostaje, forma zatvorena uz ponovljen savet da se ekran otvori. | Preneti static + SHA [P07]. Bezbedan konkretan oporavak korumpiranog identiteta, uz očuvanje važeće neizvesne prijave. |
| **X02 Dva imena** | `src/app/(app)/profil/podaci.tsx:29–32,40–55,66–88`; `src/ui/profile/writeWorkName.ts:23–34`: requester pa worker upis; lokalni retry druge faze se ne rekonstruiše posle novog mount-a. | Jedan autoritet ili trajno proverljiv oporavak stvarne razlike. Nije dozvola da se pogrešno prepiše novije ime. |
| **X03 Decoder/receipt** | `src/data/applicationClientService.ts:71–78` propušta NaN; `src/data/ru4Production.ts:115–134` ima preslab service receipt. | `src/app/(app)/moje-prijave.tsx:235–244` dodatno odbija nedovoljan receipt, pa nije dokaz lažnog uspeha te rute. Konačna/validna polja garantovati na servisnoj granici. |
| **X04 Konfiguracija** | `src/data/supabaseClient.ts:8–21` ima fallback; `src/data/authAvailabilityClientService.ts:27–29`, `src/data/productionLocationResolver.ts:9–10` i drugi read/stream potrošači zahtevaju env. | Jedan konfiguracioni vlasnik. Nije dokaz da env nedostaje u sadašnjoj instalaciji. |
| **X05 Demo reset** | `src/data/lazniIzvor.ts:55–61,153–157,603–616`: reset ne obnovi mutable kandidate dodate prijavom. | Resetovati ceo fixture katalog. Ovo je test/demo izolacija, ne produkcioni zapis. |
| **X06 Stari toast** | `src/ui/safety/blockOutcome.ts:31–33`; `src/ui/safety/SafetyScreen.tsx:63–78`: potvrđeni toast može izaći bez poslednje spoljne account provere. | Undo proverava account/revision (`blockOutcome:23,37,45`). Nalaz je lifetime prikaza, ne neovlašćen write; sprečiti tuđ/stari toast bez slabljenja potvrđenog Undo. |

## 7. Čišćenje prema stvarnim potrošačima

| Odluka | Vlasnik/podskup | Dokaz i uslov |
|---|---|---|
| Sačuvati | `useOwnedEditor`, request journal-i, signed review/digest, idempotent Save/publish i readback | Aktivne rute ih koriste. To su ograde od kasnih rezultata i nepoznatih ishoda, ne suvišna administracija. |
| Objediniti ugovor | Dual BG naspram explorer/shadow/direct/research putanja | Isti smisao, mode, cena, nova grana i obračun moraju biti provereni u aktivnoj putanji. Ne dodavati treći klasifikator radi sakrivanja razlika. |
| Sačuvati aktivne formatere | `src/data/aiNeedV2Ui.ts` | `pregled-zadatka` koristi factLabel/priceAmountRowValue; `reviewFacts` factLabel/factReviewValue/slotLabel; review client slotLabel; Intake safetyMessage; SupportReferenceView factLabel. Ceo modul nije mrtav. |
| Uslovno povući manual helper podskup | `factEditorKind`, `factChoices`, `editorCorrection`, `correctionFromText`, timestamp/list helpers, `amountDigits` | Non-test src pretraga nalazi definicije/interne pozive, ne aktivni obični editor. Proveriti podržane stare potrošače pre uklanjanja. |
| Uslovno povući dormant explicit-mode API | `prepareConfirmed`, `explicitWorkerModes`, `workerExplicitModeReviewEnabled`; `src/data/workerAiClientService.ts:36–45,280–305` | Non-test src self-reference; aktivni route test očekuje odsustvo dodatne mode forme. SQL kompatibilnost starog klijenta je poseban uslov. |
| Odvojiti demo namenu | `WorkerAiCard` | Jedini pronađen mount `src/designLab/dizajn-ai.tsx:177`; worker aktivni chat daje card()=>null. Demo nije razlog za vraćanje parcijalnih kartica; aktivni `WorkerAiReviewDetails` iz istog fajla ostaje. |
| Uslovno povući | `capturedParts`, `capturedSpeech`; `src/ui/workerProfile/workerProfileFacts.ts:64–78` | Nema spoljnog non-test src caller-a u obuhvaćenoj pretrazi. To nije autoritativni signal završetka. |
| Sačuvati aktivnu kompatibilnost | `src/app/(app)/profil/radnik.tsx`, `src/ui/workerProfile/workerProfileDraft.ts`, `src/ui/workerProfile/WorkerProfilePresentation.tsx:159–193` | Stara manual forma je povučena, ali name-adoption i uncertain-write recovery ostaju aktivni (`radnik:282–323`). Ime legacy nije dokaz za brisanje fajla. |
| Uskladiti copy i ulaze | `src/data/reviewFactProblem.ts:10`; `src/app/(app)/pregled-zadatka.tsx:343–352,517–533`; saved work-area/pin ulazi | Prošao termin se menja u razgovoru, ne u starom lokalnom editoru. Uskladiti ton i oblast/pin značenje bez novog obaveznog koraka. |
| Sačuvati istoriju, jasno indeksirati | Primenjene migracije, candidate/proof materijal, operativne beleške | Istorijska SQL funkcija ili dokaz nisu mrtav UI. CURRENT/HISTORICAL/REJECTED razdvajanje treba da spreči korišćenje starog candidate-a kao sadašnjeg ugovora. |

Legacy `inferWorkerExecutionModes` jeste keyword/city heuristika, ali aktivna worker ruta je poziva samo kada classificationState nedostaje (`src/app/(app)/profil/razgovor.tsx:282–285`). Signed READY/PENDING put je preskače. Ne opisivati sve današnje modove kao telefonsko nagađanje po ključnim rečima.

Za ekrane sa mapom treba sačuvati razliku prikaza i potvrde: MapLibre/OpenFreeMap, native/web varijanta, scene/focus owner i pin revision. GPS dozvola za „Moja lokacija” nije opšti uslov svakog prikaza mape. Prazan discovery rezultat sam po sebi ne gasi geografiju; F15/F16 su konkretniji razlozi dostavljenih stanja. S03 identifikuje About ekran, ali ne predstavlja pregled svih ostalih ekrana.

**Detaljne odluke po fajlu** sačuvane su u [jedinstvenom registru](dokazi/registar/consolidated_read_register.json): namena, KEEP/REPAIR/CONSOLIDATE/REMOVE_CANDIDATE/ARCHIVE_CANDIDATE, obrazloženje, pozivaoci i granice ranijeg dokaza. Tabela iznad je izbor važnih odluka; ne zamenjuje svaki pregledani zapis. Registar čuva i manje copy/helper nalaze, npr. objašnjenje mikrofona, zajednički voice formatter, neprimenjeni Text.balance, kao i uske ListSkeleton/RadarIcon/brand kandidate. Aktivni delovi mešovitih modula, poput textWidth/TITLE_SIZE i sheet konfiguracije, ne brišu se zajedno sa starim delom. Pre rada proveriti zapis i sadašnje pozivaoce.

### Dopunjene odluke o povlačenju i postojećim vlasnicima

`SelectionRequestRegistry` u `src/lib/selectionIdempotency.ts:31` nema non-test caller-a. Sačuvati stvarni izbor u `src/app/(app)/potrebe/[id]/kandidati.tsx`: memorijski `session.pending`, zamrznutu komandu, isti ključ i `readSelectedAgreement`. Odvojeni trajni `applicationCommandJournal` pripada prijavi radnika. Izbor nije time proglašen trajnim preko gašenja procesa; to je korekcija preciznosti, ne nov dokazan kvar. Stari `workTrustModel.statsView` nema običnog potrošača, dok `publicTrustFacts` služi javnom profilu i detalju zadatka. `manualAvailability`, `BrandScene`, `useBrandClock`, `useEntryIntro` pripadaju designLab-u; aktivna dostupnost je AI tok, a ulaz koristi tri premium PNG-a. To su pojedinačne preporuke za izolovanje ili povlačenje, bez vraćanja ručnih UI-ja iz testova.

`supabase/candidates/temporal-conflict-freezing-v1.sql` je nepovezan prototip sa starim schedule/resource/team poljima; terminalni aggregate SELECT nema INTO/RETURN u PL/pgSQL. Funkcija `private.candidate_projection(uuid)` ne postoji u current680inventaru niti ima current qualified caller. Aktivni `need_candidate_states_v5`/candidate RPC vlasnici ostaju. Ovaj prototip ne dokazuje kvar trenutnog kalendara.

Current legacy `rpc_delete_abandoned_intake_conversation` (`5829cbb6998255adae020793dd18ff33`) ima širok EXECUTE uz auth.uid/owner provere, ali prve referencirane tabele `public.need_facts_v2` i `public.ai_conversation_messages` ne postoje. Ne može se dokazati validan napad ignorisanjem te činjenice; izvršenje zapinje pre kasnijeg statusnog rizika. Nema source caller-a. Uslovno povlačenje zahteva proveru starih klijenata i zavisnosti, bez izvršavanja brisanja nad korisničkim podacima.

Stare rollback.preimage.sql kopije više funkcija ponegde spajaju `pg_get_functiondef` izlaze bez SQL terminatora. To je preimage evidencija, ne spremna revert komanda. Stare široke grantove i anon SECURITY DEFINER navode proveravati po objektu i unutrašnjem guard-u; ne menjati ACL/RLS da se samo umanji broj advisor upozorenja. Izvori i pojedinačni uslovi: Z01–Z06.

### Precizna jedinica povlačenja

Za `workerProfileDraft.ts` uski kandidati su `foldTerm`, `hasTerm` i `toggleTerm`; `workerDraft`, `workerCommand`, `workerReadbackMatches`, `nameForSave` i povezani recovery/name-adoption ostaju. Za `workTrustModel` kandidat je `statsView`, dok `publicTrustFacts` i `memberSincePhrase` imaju stvarne javne potrošače. Za dormant worker explicit-mode podskup odsustvo non-test src caller-a ostaje uslovna preporuka: stari APK i serverski ugovor proveravaju se pre retirement-a. Primenjene SQL migracije čuvaju istoriju; kandidat, rollback preimage i demonstracioni ekran imaju zasebnu namenu. Z09 beleži ponovljene pretrage i tačne izvore.


### Normalizovana operativna projekcija i konkretni paketi

Z10/cleanup.normalized_path_index čuva svih 3.434 originalnih putanja, source SHA, original_disposition, action_family, decision_status, required_preconditions i veze sa radnim paketima. Normalizacija polazi od 719 različitih slobodnih oznaka; mnoge su različite rečenice za istu vrstu rada. Zadržana evidencija punog čitanja ne menja se.

912 stavki ima NEEDS_TARGETED_ADJUDICATION za izvršno povlačenje. To su uglavnom potrebe da se istorijski dokaz ili kopija odvoji od aktuelne zaštite i da se prevežu potrošači; nije broj nepročitanih fajlova niti broj potvrđenog viška. Destruktivna spremnost ne izvodi se iz same akcione kategorije. Ključni konkretni paketi ispod imaju tačne ciljeve, očuvano, razlog, preuslove i pozitivnu/negativnu kontrolu u istom JSON-u.

| Paket čišćenja | Veza sa radom | Tačna jedinica promene | Šta ostaje |
|---|---|---|---|
| C01 — Nereferencirani template resursi | R11 | Ukloniti 21 označeni template/placeholder resurs iz aktivnog stabla zajedno sa eventualnim suvišnim asset unosima. | Aktivne app-icon/premium-entry/reference-entry resurse, fontove, njihove manifeste i install generisanje. |
| C02 — Stari ručni izbor veština | R08, R11 | Povući foldTerm, hasTerm i toggleTerm i test koji postoji samo radi tog quick-pick editora. | workerDraft, workerCommand, workerReadbackMatches, nameForSave i aktivni recovery/name-adoption; AI izmena profila. |
| C03 — Ručni editor činjenica pored aktivnih AI formattera | R08, R11 | Povući factEditorKind, factChoices, editorCorrection, correctionFromText, amountDigits i njihove isključivo interne manual helper-e kada se testovi prevežu. | factLabel, priceAmountRowValue, factReviewValue, slotLabel i safetyMessage sa svim aktivnim pregled/support potrošačima. |
| C04 — Stari card i layout podskupovi | R11 | Povući nekorišćene CardHead/CardDecision/CardFoot/CardBriefFoot/CardRequirement/CardPerson/CardPlaces/CardNext/CardNote/CardWaitingLine/CardFootLine; uz njih stari headBeside/wrapTitle/titleColumn i test-only requesterPrijava podskup. | Aktivne task/status/capacity/rating/spoken helper-e, CardStatus/CardStatusLine/CardTitle/WaitingDot, textWidth/font tabelu/TITLE_SIZE i stvarno odvojene requester/worker kompozicije. |
| C05 — Nepovezani selection registry i privatna stats alternativa | R11 | Povući SelectionRequestRegistry sa isključivo njegovim testom, te statsView/reliabilityNeeds podskup gde je bez običnih potrošača. | Stvarni requester izbor u kandidati ruti: memorijski session.pending, frozen command, isti ključ i readSelectedAgreement; odvojeni trajni applicationCommandJournal radnika; publicTrustFacts/memberSincePhrase. |
| C06 — Duplikat identičnog testa | R11 | Ukloniti jednu od dve identične provere prvog dolaska redova (588–604 i 606–622 na analiziranom izvoru). | Jednu kompletnu proveru: najviše šest prvih animiranih redova; topla lista i promena filtera bez ponovljene animacije. |
| C07 — Stari ulazni motion i design-only reference | R11 | Iz aktivnog izvora i default suite-a povući isključivo napuštenu BrandScene/V49/useEntryIntro referencu sa njenim testovima i starim token allowance-om; design scenu ukloniti ili prevezati u jednom zahvatu. | Aktivni EntryWelcome, premium PNG, BrandAssets/BrandRaster, potrebni brandParts/BRAND_PARTS i postinstall generisani font/reference-entry ulazi dok ih potrošači koriste. |
| C08 — V1 AI portovi i fake AI | R04, R08, R11 | Povući legacy V1 intake/confirm/publish port i njegove override-e kao zajedničku celinu; izdvojiti fixture-e koje još trebaju tekućim testovima. | Aktivni V2 razgovor, signed review/Save/publish, aktivne ne-AI komande/readere centralnog Izvor porta i smislen reset demo stanja. |
| C09 — Nepovezani owner-review builder i eksplicitni CI ulaz | R04, R11 | Premestiti ili povući source-only Gate A builder i isključivo njegov synthetic test zajedno sa eksplicitnim CI pozivom, posle prenosa važećih scenarija. | Aktivni potpisani review/prepare/Save/binder, revalidaciju identiteta i kompletan BOTH; ne smanjiti potrebnu zaštitu samo uklanjanjem CI reda. |
| C10 — Aktivne i alternativne AI strategije | R04, R06, R11 | Posle odabira i dokaza ciljnog postojećeg toka povući nepodržane alternativne flag grane, njihove izvozove i retired-only testove. | Puni semantički ugovor, nove grane, isti ID, oba moda, stvarnu saglasnost i postojeće granice potrošnje/timeout-a; foreground razgovor i pozadinski posao mogu imati različite potrebne uloge. |
| C11 — Messages-only povlačenje PHONE delova | R11, R12 | Povući PHONE metode/portove i positive-feature testove koje važeći proizvod više ne podržava; povezati sa posebnom kompatibilnom serverskom migracijom. | Poruke, važeći tačan lokacijski grant i njegove privatnosne provere; istorijski negativni test da stari klijent ne može vratiti povučenu PHONE mogućnost. |
| C12 — Nepovezane buduće GPS i permission putanje | R09, R11 | Iz aktivnog opsega povući controller/prototip i testove koji samo dokazuju nezakačenu buduću mogućnost; potrebno generičko GPS/permission ponašanje zadržati kod aktivnog vlasnika. | Aktivni exact-location grant, native location helpers i postojeći push enrollment/permission tok. |
| C13 — Javni komentari: ugovor pre povlačenja čitača | R11 | Odluku o starom prikazu doneti zajedno sa SB09: povezati potvrđen javni komentar ili uskladiti obećanje i izdvojiti neaktivni public-list podskup. | Aktivni context/submit servis, ocene i stvarna privatnost publikovanja; ne izbrisati ceo reviewComments servis. |
| C14 — Testovi povučenih pravila i istorijski oracle | R04, R07, R08, R11 | Razdvojiti stare 11-stem/fee/HITNO/equipment/license i kopirane oracle pretpostavke; povući retired-only pozitivna očekivanja iz default acceptance-a. | Važeće privacy/ownership/canonical identity/budget granice i korisne sintetičke slučajeve prevezane na sadašnji ugovor. |
| C15 — Aktuelni kvar kao zelena karakterizacija | R02, R06, R07, R11 | Posle konkretne popravke promeniti završno očekivanje sa ponavljanja kvara na ispravan rezultat; zadržati precizan ulaz/prekid koji je kvar reprodukovao. | Reprodukciju stare RSD potvrde, neuspešnog capture-a, MAP failure posle uspešne liste i nove ocene uz iste ID-jeve. |
| C16 — Dokazi, kandidati i zamrznuti generatori | R01, R11, R12 | Za svaku historical/candidate grupu zadržati minimalan manifest sa commitom, hash-em, namenom i zamenom, a nepotrebne kopije izbaciti iz aktivne grane kada nisu input tekućeg build/test/replay-a. Ne održavati drugu arhitekturu u kandidatima. | Primenu i poreklo stvarno korišćenog SQL-a, nužne fixtures i dokazive rollback preimage reference, te aktuelne minimalne canary/replay alatke. |
| C17 — Test i build katalog posle čišćenja | R11, R12 | Uskladiti package scripts, eksplicitne CI putanje, Jest selekciju, TypeScript includes i generisanje sa odlukama o aktivnom/istorijskom sadržaju. Premeštanje u archive samo po sebi ne isključuje __tests__ glob ni **/*.ts include. | Obavezne tekuće safety/regression/integrity provere i pouzdan install/build iz zaključanih zavisnosti. |
| C18 — Potpuno identične premium slike i njihove kopije | R11 | Konsolidovati tri potvrđena byte-identical para na aktivni premium-entry vlasnički put i prevezati ostale potrošače/provenance; zatim ukloniti višak kopija iz aktivnog stabla. | Isti pikseli/izgled i sve stvarne upotrebe; canonical premium-entry put se predlaže zato što je aktivni ulazni vlasnik. |
| C19 — Identični SQL i proof blizanci | R11, R12 | Kod byte-identical candidate/migration i ponovljenih proof kopija izabrati primenjenu migraciju ili jasno određen evidencioni vlasnički zapis; prevezati aktuelne testove i manifest linkove, pa ukloniti suvišnu aktivnu kopiju kada nema nezavisnu funkciju. | Primenjene migracije i njihov originalni hash; tačan istorijski run/commit identitet i sadržaj potreban za audit/replay/rollback. |


**C01 — ciljevi i uslov:** Osvežiti referenciranje u app/EAS/Metro/native konfiguraciji, generatorima i dinamičkim putanjama; isti basename u drugom folderu nije isti asset.

Putanje: `assets/entry-splash-empty.xml`; `assets/images/android-icon-background.png`; `assets/images/android-icon-foreground.png`; `assets/images/android-icon-monochrome.png`; `assets/images/expo-badge-white.png`; `assets/images/expo-badge.png`; `assets/images/expo-logo.png`; `assets/images/favicon.png`; `assets/images/icon.png`; `assets/images/logo-glow.png`; `assets/images/react-logo.png`; `assets/images/react-logo@2x.png`; `assets/images/react-logo@3x.png`; `assets/images/splash-icon.png`; `assets/images/tabIcons/explore.png`; `assets/images/tabIcons/explore@2x.png`; `assets/images/tabIcons/explore@3x.png`; `assets/images/tabIcons/home.png`; `assets/images/tabIcons/home@2x.png`; `assets/images/tabIcons/home@3x.png`; `assets/images/tutorial-web.png`.

Dokaz posle promene: Nema nepostojeće require/import/config putanje. Install/build proverava aktivne ulazne resurse. Novi native izgled ikone/ulaza odgovara cilju; veličina APK-a meri se zasebno.

**C02 — ciljevi i uslov:** Potvrditi tačne simbole, import-e i podržane ugovore; ne brisati ceo workerProfileDraft.ts.

Putanje: `src/ui/workerProfile/workerProfileDraft.ts`; `src/ui/workerProfile/__tests__/worker-profile-terms.test.ts`; `src/app/(app)/profil/radnik.tsx`.

Dokaz posle promene: Nema mrtvih exporta/importa starog quick-pick-a. Ime, readback i neizvestan Save čuvaju važeće ponašanje. Testni skup više ne zahteva ukinuti ručni editor.

**C03 — ciljevi i uslov:** U svakom testu odvojiti zaštitu aktivnog prikaza od očekivanja ukinutog ručnog unosa; sačuvati korekciju kroz isti razgovor.

Putanje: `src/data/aiNeedV2Ui.ts`; `src/data/__tests__/aiNeedV2Ui.test.ts`; `src/data/__tests__/ru2-ai-v2-ui.test.ts`; `src/data/__tests__/w02-capability-terms.test.ts`.

Dokaz posle promene: Pregled, podrška i AI prikaz imaju iste važeće labele i novčano značenje. Nema novih lokalnih writer-a činjenica. Relevantne pozitivne i negativne provere ostaju.

**C04 — ciljevi i uslov:** Povezati svaki uklonjeni export sa testom i aktivnom zamenom; ne spajati različite uloge samo radi manjeg broja komponenti.

Putanje: `src/ui/v2/TaskFace.tsx`; `src/ui/v2/cardHeadFit.ts`; `src/ui/v2/CandidateFace.tsx`; `src/ui/v2/PrijavaCard.tsx`.

Dokaz posle promene: Sve aktivne kartice i koraci Dogovora čuvaju iznos, broj ljudi, status i pristupačnost. Testovi ne zahtevaju više napuštenu vizuelnu implementaciju. Type/build nema preostalih import-a.

**C05 — ciljevi i uslov:** Rekoncilovati noviju odluku u registru i proveriti sve tip/export potrošače; ne izjednačiti memorijsko pending stanje i trajni journal.

Putanje: `src/lib/selectionIdempotency.ts`; `src/lib/__tests__/selectionIdempotency.test.ts`; `src/ui/profile/workTrustModel.ts`; `src/ui/profile/__tests__/work-trust-model.test.ts`.

Dokaz posle promene: Prijava i izbor ostaju zaštićeni od ponavljanja u svom stvarnom obimu. Javni profil i poverenje zadržavaju autoritativne podatke. Uklonjeni test ne umanjuje pokriće stvarnog ruta/servis toka.

**C06 — ciljevi i uslov:** Pre izmene osvežiti tačne granice testa; nema potrebe menjati proizvod radi uklanjanja duplikata.

Putanje: `src/data/__tests__/agreement-collection-presentation.test.tsx`.

Dokaz posle promene: Ostaje jedna identična smislena provera i svi ostali različiti slučajevi. Broj slučajeva se smanji za jedan tek nakon stvarnog runner izveštaja.

**C07 — ciljevi i uslov:** Sačuvati jedan jasno označen dizajn dokaz samo ako služi aktuelnom vizuelnom cilju; proveriti install/build i putanju potrebnog fonta.

Putanje: `src/ui/entry/BrandScene.tsx`; `src/ui/entry/BrandSceneReview.tsx`; `src/ui/entry/entryV49Math.ts`; `src/ui/entry/entryV49Notes.ts`; `src/hooks/useEntryIntro.ts`; `src/data/__tests__/entry-brand-scene-clock.test.tsx`; `src/data/__tests__/entry-v49-reference.test.ts`; `src/data/__tests__/entry-intro-hook.test.tsx`; `src/ui/system/__tests__/one-token-source.test.ts`; `src/designLab/dizajn-profil.tsx`; `scripts/sync-entry-reference-assets.cjs`.

Dokaz posle promene: Aktivni welcome/splash ostaje tačan na uređaju. Jest više ne zahteva staru animaciju. Install iz čistog checkout-a ne zavisi od obrisanog izvora.

**C08 — ciljevi i uslov:** Prvo ukloniti/rebindovati legacy članove porta i test potrošače. Proveriti konfiguracije koje mogu izabrati test/dev izvor.

Putanje: `src/data/aiCommandOverrides.ts`; `src/data/aiProductionOverrides.ts`; `src/data/productionAuthorityOverrides.ts`; `src/data/lazniAi.ts`; `src/data/index.ts`; `src/data/ports.ts`; `src/data/lazniIzvor.ts`.

Dokaz posle promene: Nema V1 slanja ili objave iz aktivne kompozicije. Postojeći V2 put i ostale Izvor funkcije rade. Retired-only testovi ne vraćaju ručne V1 činjenice.

**C09 — ciljevi i uslov:** R04 mapira svaku korisnu proveru na aktivnog vlasnika i proverava stvarni Edge bundle; CI izmenu prikazati sa zamenom.

Putanje: `supabase/functions/_shared/classificationOwnerReview.mjs`; `supabase/proofs/dynamic_taxonomy/classification-owner-review.test.mjs`; `.github/workflows/ci-clean.yml`.

Dokaz posle promene: Nema dangling CI putanje. Istovetne važeće invariants proverava aktivni put. Synthetic istorijska projekcija se više ne predstavlja kao dokaz stvarnog Save-a.

**C10 — ciljevi i uslov:** Isti korpus, merena tačnost/latencija/trošak, kompatibilnost starog podržanog build-a i usklađeni source/Edge deploy.

Putanje: `supabase/functions/_shared/classificationExplorer.mjs`; `supabase/functions/_shared/classificationGeminiShadow.mjs`; `supabase/functions/_shared/taxonomyScopedShadow.mjs`; `supabase/functions/uskoci-ai-interview/index.ts`; `supabase/functions/uskoci-worker-interview/index.ts`.

Dokaz posle promene: Jedan dokumentovan aktivan ugovor i popis dozvoljenih konfiguracija. Neaktuelna strategija nema runtime/CI ulaz. Svi R04/R06 slučajevi imaju dokaz preko aktivnog puta.

**C11 — ciljevi i uslov:** Proveriti stare native/OTA klijente i server grantove, current source ugovor i namenu svake testne tvrdnje.

Putanje: `src/data/contactClientService.ts`; `src/data/ports.ts`; `src/data/__tests__/m04-privatnost-kontakt.test.ts`; `src/ui/agreements/AgreementContactPlace.tsx`; `STATUS.md`.

Dokaz posle promene: Aktivan i podržani stari klijent poštuju messages-only ugovor. Tačna lokacija ostaje zasebno autorizovana. Nema nove zabrane teksta poruke bez posebne poslovne odluke.

**C12 — ciljevi i uslov:** Inženjerska preporuka je izolovati neaktivnu buduću referencu; aktiviranje nove GPS SHARE funkcije bio bi poseban proizvodni opseg.

Putanje: `src/data/agreementCurrentLocationService.ts`; `src/ui/agreements/AgreementLocationController.ts`; `src/data/__tests__/v5-agreement-current-location-controller.test.ts`; `src/data/__tests__/v5-agreement-current-location-service.test.ts`; `src/ui/permissions/notificationAsk.ts`; `src/ui/permissions/__tests__/permission-sites.test.ts`.

Dokaz posle promene: Default produktni testovi ne zahtevaju nezakačen prototip. Aktivni permission i lokacijski tokovi zadržavaju svoju proveru. Nema dangling import-a ni izgubljenog native helper-a.

**C13 — ciljevi i uslov:** Utvrditi važeću publiku komentara; ako se menja obećanje proizvoda, prikazati korisniku konkretnu odluku, ne sakriti je pod cleanup.

Putanje: `src/ui/reviews/ReviewCommentsSection.tsx`; `src/ui/reviews/__tests__/review-comments-section.test.tsx`; `src/data/reviewCommentsClientService.ts`.

Dokaz posle promene: Tekst pri slanju i stvarna dostupnost komentara saglasni. Submit/context i rating tok ostaju. Retired-only testovi ne nameću drugu publiku.

**C14 — ciljevi i uslov:** Za svaku tvrdnju navesti aktuelni izvor pravila, ili da je istorijska kompatibilnost; otkriti optional/skip/NULL slučajeve koji mogu lažno proći.

Putanje: `src/data/__tests__/ex06-corpus-contract.test.ts`; `supabase/proofs/pkg051/pkg051_proof.mjs`; `supabase/proofs/match_category_fallback/source.test.mjs`.

Dokaz posle promene: Test više ne vraća ukinutu funkciju. Neophodan safety invariant ostaje u tekućoj proveri. Istorijski PASS ima označen stari source/runtime i nije release gate.

**C15 — ciljevi i uslov:** Test i popravka u istom pregledljivom radu, uz pozitivnu kontrolu; ne menjati assertion samo da trenutni kod prođe.

Putanje: `supabase/proofs/ai/currency_correction_characterization.test.mjs`; `supabase/proofs/ai/background_capture_receipt.test.mjs`; `src/data/__tests__/discovery-v1-route-lifecycle.test.tsx`; `src/ui/reviews/__tests__/use-given-ratings.test.tsx`.

Dokaz posle promene: Isti slučaj sada dokazuje željeno ponašanje. Uspešan redovni tok i relevantni neuspeh ostaju. CI rezultat ima jasnu semantiku.

**C16 — ciljevi i uslov:** Za frozen generator prvo utvrditi da li se koristi kao rekonstrukcija/potpisni dokaz; ne regenerisati primenjeni bundle. Prevezati putanje u current kontrolama na minimalan potreban izvor.

Putanje: `README.md`; `STATUS.md`; `supabase/candidates/ex04a_own_tasks_page.sql`; `supabase/candidates/temporal-conflict-freezing-v1.sql`; `supabase/proofs/push_single_target/promotion/expected-prelocation-surface.json`.

Dokaz posle promene: Default build/test/deploy nema staru install/apply/revert putanju. Jedan manifest vodi do tačnog starog izvora i aktuelne zamene. Izolovan replay/current bootstrap radi bez uklonjenih slučajnih kopija.

**C17 — ciljevi i uslov:** Svaki uklonjeni test ili CI ulaz mora imati razlog RETIRED_RULE/DUPLICATE/REPLACED_BY_CURRENT/EXPLICIT_HISTORICAL_ONLY; nikakvo opšte isključivanje na osnovu sporosti ili failure-a.

Putanje: `package.json`; `jest.config.cjs`; `tsconfig.json`; `.github/workflows/ci-clean.yml`; `scripts/sync-entry-reference-assets.cjs`; `supabase/migrations/check_migration_integrity.py`.

Dokaz posle promene: Runner list/count pre-posle, zbir trajanja i relevantno pokriće uz isti environment. Nema neselektovanog obaveznog testa ni testnog fajla koji štiti samo napušteni UI. Dependency lock i install/build su koherentni; paket se uklanja samo kad nema potrebnog runtime/build/test potrošača.

**C18 — ciljevi i uslov:** Proveriti literalne/dinamičke import-e, asset manifest/generator i dizajn galerije; ne ukloniti putanju pre rebind-a.

Putanje: `assets/brand/premium-entry/discover.png`; `assets/brand/premium-entry/logo.png`; `assets/brand/premium-entry/publish.png`; `assets/brand/uskoci-dimensional-20261003.png`; `assets/illustrations/uskoci-discover-v3.png`; `assets/illustrations/uskoci-task-launch-v2.png`.

Dokaz posle promene: Izgled aktivnog ulaza i svih drugih potrošača ostaje isti. Install/build proverava novi jedinstveni izvor. Saopštiti stvarne repo byte rezultate; APK veličina se zasebno meri.

**C19 — ciljevi i uslov:** Za svaku grupu zabeležiti canonical source i sve putanjske zavisnosti. Frozen istorijski runner ne prepraviti da glumi tadašnji drugačiji izvor; sačuvati istorijski manifest ili commit referencu.

Putanje: `supabase/candidates/ai-location-01-20261002/before-edge/src/contracts/needFactsV2.ts`; `supabase/candidates/ai-location-01-20261002/before-edge/supabase/functions/_shared/aiTestBudget.ts`; `supabase/candidates/ai-location-01-20261002/before-edge/supabase/functions/_shared/geminiTaskStream.ts`; `supabase/candidates/ai-location-01-20261002/location_reply_candidate.sql`; `supabase/candidates/ai-location-01-20261002/src/contracts/needFactsV2.ts`; `supabase/candidates/ai-location-01-20261002/supabase/functions/_shared/aiTestBudget.ts`; `supabase/candidates/ai-location-01-20261002/supabase/functions/_shared/geminiTaskStream.ts`; `supabase/candidates/ai-location-01-20261002/supabase/functions/_shared/locationReply.ts`; `supabase/candidates/ai-location-01-20261002/supabase/functions/uskoci-ai-interview/index.ts`; `supabase/candidates/closure-current-20261021/helpers.sql`; `supabase/candidates/closure-current-20261021/migration-with-proof.sql`; `supabase/candidates/closure-taxonomy-20261018/helpers.sql`; `supabase/candidates/dynamic-taxonomy-20261011/ai-catalog-context-deep-ancestry-v2.sql`; `supabase/candidates/dynamic-taxonomy-20261011/create-child-v2-forward-dev.sql`; `supabase/candidates/dynamic-taxonomy-20261011/create-new-branch-v3-forward-dev.sql`; `supabase/candidates/dynamic-taxonomy-20261011/need-binder-selection-hotfix-dev-v1.sql`; `supabase/candidates/dynamic-taxonomy-20261011/need-review-versioned-optin-dev-20261016.sql`; `supabase/candidates/dynamic-taxonomy-20261011/signed-binding-requeue-dev-v1.sql`; `supabase/candidates/ex05-rc02-20261002/rc02_candidate.sql`; `supabase/candidates/pkg023j_home_attention.sql`; `supabase/candidates/published-edit-guard-20261021/candidate.sql`; `supabase/candidates/worker-personal-profile-edge-20261003/proof/dialogue_fixture.mjs`; `supabase/candidates/worker-personal-profile-edge-20261003/task/after/src/contracts/needFactsV2.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/task/after/supabase/functions/_shared/aiTestBudget.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/task/after/supabase/functions/_shared/geminiTaskStream.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/task/after/supabase/functions/_shared/locationReply.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/task/before/src/contracts/needFactsV2.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/task/before/supabase/functions/_shared/aiTestBudget.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/task/before/supabase/functions/_shared/geminiTaskStream.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/task/before/supabase/functions/_shared/locationReply.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/task/before/supabase/functions/uskoci-ai-interview/index.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/worker/after/supabase/functions/_shared/aiTestBudget.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/worker/after/supabase/functions/_shared/geminiTaskStream.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/worker/before/supabase/functions/_shared/aiTestBudget.ts`; `supabase/candidates/worker-personal-profile-edge-20261003/worker/before/supabase/functions/_shared/geminiTaskStream.ts`; `supabase/functions/_shared/pushNotificationCopy.mjs`; `supabase/migrations/20260907100000_clean_n08_notification_preferences.sql`; `supabase/migrations/20260907110000_clean_d03_message_retry.sql`; `supabase/migrations/20260907120000_clean_ai_need_draft_safety_authority.sql`; `supabase/migrations/20260908120000_clean_p0e_completion_guards.sql`; `supabase/migrations/20260908130000_clean_p1_legal_consent_ledger.sql`; `supabase/migrations/20260908140000_clean_p4_processor_map_registry.sql`; `supabase/migrations/20260908150000_clean_p3_retention_schedule_registry.sql`; `supabase/migrations/20260908160000_clean_p2_data_export_requests.sql`; `supabase/migrations/20260908170000_clean_d0140a_policy_bundle_registration.sql`; `supabase/migrations/20260910153005_clean_p2_export_delivery_authority.sql`; `supabase/migrations/20260910162955_clean_p3_retention_execution_authority.sql`; `supabase/migrations/20261016172724_dev_need_review_taxonomy_versioned_20261016.sql`; `supabase/migrations/20261016185402_dev_signed_taxonomy_binding_requeue_20261016.sql`; `supabase/migrations/20261016185727_dev_signed_need_binder_selection_20261016.sql`; `supabase/migrations/20261017223855_create_child_v2_signed_review_dev_20261018.sql`; `supabase/migrations/20261017230303_taxonomy_root_branch_v3_20261018.sql`; `supabase/migrations/20261017230429_taxonomy_deep_ancestry_v2_20261018.sql`; `supabase/migrations/20261021095622_published_task_edit_containment.sql`; `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql`; `supabase/operations/dev-alpha/ledger/20260919221214_dev_alpha_pkg023j_home_attention.sql`; `supabase/operations/dev-alpha/ledger/20261002172532_dev_alpha_ex05_rc02_media_cancel_lock_order.sql`; `supabase/operations/dev-alpha/ledger/20261002185306_dev_alpha_ai_location_01_contextual_map_dialogue.sql`; `supabase/proofs/ai/ai_draft_authority_candidate.sql`; `supabase/proofs/ai/dialogue_fixture.mjs`; `supabase/proofs/completion/p0e_completion_guards_candidate.sql`; `supabase/proofs/legal/p1_legal_consent_candidate.sql`; `supabase/proofs/legal/p2_data_export_candidate.sql`; `supabase/proofs/legal/p2_export_delivery_candidate.sql`; `supabase/proofs/legal/p3_retention_execution_candidate.sql`; `supabase/proofs/legal/p3_retention_schedule_candidate.sql`; `supabase/proofs/legal/p4_processor_map_candidate.sql`; `supabase/proofs/notifications/d03_message_retry_candidate.sql`; `supabase/proofs/notifications/n08_preferences_candidate.sql`; `supabase/proofs/policy/d0140a_bundle_registration_candidate.sql`; `supabase/proofs/push_single_target/promotion/edge-before/functions/_shared/pushNotificationCopy.mjs`; `supabase/proofs/push_single_target/promotion/edge-candidate/functions/_shared/pushNotificationCopy.mjs`; `supabase/proofs/push_single_target/promotion/edge-candidate/functions/uskoci-push-transport/index.ts`; `supabase/proofs/push_single_target/promotion/live-certificate-checked.json`; `supabase/proofs/push_single_target/promotion/live-edge-capture.json`; `supabase/proofs/push_single_target/promotion/live-preflight-capture.json`; `supabase/proofs/push_single_target/promotion/live-surface-capture.json`; `supabase/proofs/push_single_target/promotion/recapture-20261009/capture.json`; `supabase/proofs/push_single_target/promotion/recapture-20261009/cert.json`; `supabase/proofs/push_single_target/promotion/recapture-20261009/edge.json`; `supabase/proofs/push_single_target/promotion/recapture-20261009/surface.json`; `supabase/proofs/push_single_target/supabase/functions/_shared/pushNotificationCopy.mjs`; `supabase/proofs/push_single_target/supabase/functions/uskoci-push-transport/index.ts`.

Dokaz posle promene: Current kontrole i isolated bootstrap ne zavise od uklonjene kopije. Istorijski run/commit ostaje proverljiv. Nema slepog izvršavanja starog apply/revert kandidata.

## 8. Izvršene provere iz prethodnih etapa: obim i značenje

| Skup | Rezultat | Stvarni domet |
|---|---:|---|
| Deset prioritetnih Jest suite-ova |873/873 PASS | Prave rute/komponente/adapteri, uz njihove mock granice. Requester 177+133+43+89=442; ostalih 431 je podskup istog zbira 873, ne dodatni zbir. [P01] |
| Background capture/ACK |40 PASS | Pravi handleri u VM/transpile harness-u; synthetic auth/RPC/model. Proverene potvrde, tačni ID-jevi, no Save/publish/admission/push; followup potvrđuje odsustvo retry-ja. |
| Completion/lifecycle |16 PASS | Deferred completion, abort i synthetic timer; nije izmerena živa latencija od 9 s ni gašenje instance. |
| Background runner |5 PASS | Promise/warning/getter/waitUntil zaštite. Broj postoji u tool evidenciji/zbirnom receiptu; zaseban direct stdout nije trajno sačuvan. |
| Valuta/satnica |9 poslovnih podtestova + roditeljski test =10 Node rezultata | Izolovani guard/SQL. Ukupno 71 Node reported uključuje taj parent; ponovljene wrapper run-ove ne sabirati. [P01, P02] |
| Katalog |4 kontrolisana slučaja | Pravi neizmenjen modul, bez mreže/provider poziva. PASS uključuje reprodukovan parcijalan cache. [P03] |
| Četiri discovery suite-a |63/63 PASS | opportunities-read, cancellation, transport, route lifecycle. Mock server ima MAP/PLACES; green ne dokazuje live podršku. [N03] |
| Ranije izvršena discovery karakterizacija |3/3 PASS | Pravi React route/coordinator, presentation stand-in; potvrđuje global error i initial/retry snapshot razliku, bez native geometrije. |
| Boolean/decoder probe |5 +8 potvrđenih slučajeva | Pravi moduli, kontrolisani failure/row podaci; ne tvrdi sadržaj stvarne PAGE sa telefona. |
| AI semantička proba |PASS | Pravi builder/mode parser, 3 sintetička provider odgovora, fresh exact/completion SQL u PGlite-u, kontrolisani auth/patch/hash helpers. Ceo prepare/Save/binding nije izvršen. [N04] |
| Layout |Pročitani kod/diff/test rasponi + 3 stvarne slike | Pokušaj test-run-a bez lokalnog node_modules nije izvršio layout testove; ne predstavlja FAIL proizvoda ni novi PASS. Native merenje nije obavljeno. [N06, S01–S03] |

Route testovi su već ozbiljni i ne treba ih izmišljati od nule. `ai-owned-intake-screen` zamenjuje AI service i mapu; `v5-review-screen` zamenjuje ceo review service; worker route test zamenjuje service/journal/voice. `ai-conversation-layout` montira shell sa ručno zadatim card props. `ai-conversation-arrival` proverava UI dolazak poruke/announcement, ne početak modelskog zahteva. Prolaz se proširuje samo preko konkretne nedokazane granice.

### SB14: konkretne granice samih testova

| Provera | Šta zaista nedostaje | Uslov zatvaranja |
|---|---|---|
| `supabase/proofs/dynamic_taxonomy/gemini-real-provider-smoke.mjs:86–88,135–139` | Poslata schema zahteva classificationShadowJson, ali vraćeni izlaz proverava samo ako polje postoji; odsutno polje može doći do PASS. | Obavezno prisustvo i validan sadržaj pre PASS-a. Smoke i dalje dokazuje samo wire/schema kompatibilnost svog sintetičkog sadržaja. |
| `need-review-signed-source.test.mjs:4,19`, `worker-signed-review-source.test.mjs:8–10,49`, `classification-gemini-shadow-source.test.mjs:30,58–75`, svi u `supabase/proofs/dynamic_taxonomy/` | Čitaju staged SQL ili stringove. Oznaka provider-proven u source testu ne izvršava model; source regex ne izvršava potpis, transakciju ni aktuelni SQL owner. | Sačuvati korisne source ograde, pinovati istorijski dokaz i vezati aktuelnu integracionu proveru za stvarno migrirani owner. |
| `src/data/__tests__/worker-profile-read.test.ts:67–77` | Foreign-Auth i kasni Auth slučajevi proveravaju mockFrom, a stvarni čitač koristi mockRpc (`:15,24`). Odbijanje rezultata jeste provereno, odsustvo kasnog RPC-a nije tim assertion-om. | Negativnu tvrdnju postaviti na stvarni pozivni port. Ovo samo po sebi nije dokaz neovlašćenog produkcionog poziva. |

Ovi fajlovi su ponovo statički provereni na a969. U kontroli objedinjavanja nisu pokretani novi testovi ili stvarni model; prethodni PASS brojevi ostaju isti. Detalji ranijih backend/data test analiza dopunjeni su u postojeći registar, kao istorijski zapisi sa proverom hash-a, bez podizanja nivoa novih čitanja.

### SB14: završna provera smisla celog dokaznog korpusa

Sve naredne skripte su pročitane u celini, sa ugrađenim kodom, uslovima prolaza i izlaza; **nisu ponovo izvršene u ovoj etapi**. Pojedinačni source/hash/body odnosi i detaljne beleške nalaze se u Z02–Z05. Dobar lokalni dokaz ostaje dobar unutar svoje granice; ne proširuje se na ceo proizvod.

| Dokaz/oblast | Šta zaista pokriva | Šta ne sme da postane završni PASS |
|---|---|---|
| Klijentski map/pills/Discovery testovi | Stvarni izrazi/konverzija, stanje loading/failure, očuvanje validnih podataka | Native MapLibre kamera/render, realan MAP endpoint ili geometrija panela. Skeleton test ima fiksnu aritmetiku; tab navigator zamenjuje stranice Text stubovima. |
| Ocene, legal replay, voice/avatar | Cache/receipt/helper scenariji koji su zaista posejani | Isti finished IDs ne simuliraju novu ocenu; isti a/b hash ne simulira novu pravnu verziju; memorijski storage i vraćen STAGED nisu gubitak procesa/bajtova i ABSENT reconcile. |
| Photo/group draft | ABSENT cancel/tombstone i retention, izričito sačuvan group draft pri blur/background | Ne prenosi se na drugi support/Dogovor editor bez sopstvenog owner dokaza. |
| D12 runner | Stvarni P5 offer→select→markdone→confirm nema fixture fallback; šest current comment tela odgovara, ali tri auth RPC-a sada imaju i service_role ACL pa stari strogi postflight nije current PASS | Agreement seed i client loader mogu fallback; auto-complete gap vraća success, ratingDue ima slabiji fallback; završni PASS ne zahteva sve gaps/residuals/notVerified prazne. Nije dokazano da je neki istorijski run upotrebio fallback. |
| EX06 R2/R3 | Stvarni HTTP rok, pg_blocking_pids, query_start i DB vreme; neki readback/cancel/helper current body ostaje identičan | Ceo current time/wave/tick lanac posle kasnijih izmena; stari strogi ACL pin posle dodatog service_role granta. |
| EX06 S03 | Shape, fixture readback, prva runda, stvarni delivery count i negativni uzrok su unapređeni | Exit0 je moguć za PARTIAL/SMOKE_ONLY; FINDINGS obara samo uz strict, pin drift nije sam završni neuspeh. Stari equipment/experience kanon je uklonjen iz current MATCH-V1. |
| Push single-target promotion | Source/program99→108, exact pins, null-safe/cardinality, invocations, inverse rollback-probe i stvarna istorijska primena9.10 | Ne dokazuje novu OPPORTUNITY primenu. Provider je presretnut/simuliran; closure predicate nije erasure executor; stari NOT APPLIED naslov je prevaziđen. |
| D03 notifications retry | Stvarni holder/waiter, pg_blocking_pids i advisory lock; tačno jedna poruka/događaj za isti ključ | Staro85→86telo je promenjeno. 27PNG/XML postojanja ili report hash/booleans ne izvršava native telefon. |
| P6 full/page/spatial/exact | Scope, javni whitelist, keyset, datumsku liniju/polove, map buckets i exact landing izvan prvih200 | Direktne replica fixture inserte ne zvati realnim publish tokom; PAGE-only očekuje MAP_MODE_NOT_IMPLEMENTED. |
| P6 30k benchmark | Planiranih720SQLuzoraka/8grana, concurrency1,3warmups,30k sintetičkih redova i kontrolisan RLS | Nije nov benchmark, mreža/device/concurrency; više <> JSON assertova je NULL-nebezbedno. |
| Taxonomy/match fallback | Korisne strict-consent/revision i wave/helper kontrole | Nije svaki fixture signed Save/native consent; response fixture bez worker_account_id ne pokriva već prijavljenu osobu. Aggregate counts nisu kompletna par-po-par matrica. |
| AF22/Auth/Storage | Stvarni lokalni Auth/Storage, lost ACK, locks i ograničen canary imaju dokaznu vrednost | Ne znače pravnu sertifikaciju, sadašnji source bind ili autorizaciju aktivacije; stari certifikat ne obuhvata svaki novi voice/media scope. |
| B24/calendar | Predložene retry/lock i 40001 vs business PT409 granice; neki stvarni Auth waiters | Stand-in boolean trigger ili istorijski40P01 nisu stvarni sadašnji business gate. Trenutni68writer bodies nisu stare identične preimages. |
| B3c realtime/closure runner | Četiri stvarne lokalne Auth sesije, websocket registracije/CDC slot, known message + heartbeat negativne kontrole, expiry/revoke/closure na postojećem socket-u; zaseban worker closure za obe uloge | Finite/local, deviceProven=false; sintetički residual cache posle cancel-a dokazuje non-vacuous brisanje, ali ne sadašnju punu erasure/izvoz spremnost ili F19. |
| Kodirani payload/voice templates | Celo dekodirano telo, precizne meta/scope/rollback kontrole, no-data uslovi | Placeholder fragment nije samostalan rollback; ime constraint-a/LIKE nije pun strukturni dokaz. |
| Provider/AI/corpusi | Parsiranje, guard, oracle i kontrolisani model izlazi | 12-byte JPEG, Deno/provider mock ili stable ID provera nisu realan model, prava slika ili izvršena konkurencija. Stare hourly/one-person/11stem očekivane vrednosti nisu sadašnji kanon. |

**Dodatne proverene granice:** EX06 S04 `lib/sql.mjs` stavlja `emitEventReplay` među READ_BUILDERS, iako SELECT poziva `private.emit_event`, koji može upisati event/delivery ako dedupe red ne postoji. Test koji samo traži odsustvo INSERT/UPDATE/DELETE reči to ne otkriva. S04 judgeProbe ne zahteva stvarne preconditions/redove; PD3 bilo koji suppression razlog može prihvatiti kao MET, a PD1/PD2 neuspešno uklanjanje razloga svrstati kao REFUTED/MET. Poređenje 60 pinova daje 43 ista i 17 promenjenih, uključujući sedam CORE članova; to nije sadašnji integracioni PASS. EX06B trenutno work_kinds telo i dalje odgovara primenjenom B telu, iako ne odgovara starom S04 preimage-u. Ne proglasiti svaku razliku novom regresijom.

Legal P1 zaista proverava v1→v2 i odbijanje starog request ključa, ali ne zatvara SB03 klijentski unknown-readback tok sa novom verzijom. P2 izvoz izričito ne pokriva edge gateway, fizički uređaj, production scheduler ni kompletnost celog naloga; njegovi tadašnji 18 datasets/14 classes i realni grant/race dokazi ne pokrivaju novo workAreas polje. P3 ima 16 lokalnih slučajeva sa stvarnim brisanjem i dve lock interleaving probe, ali samo AI_ABANDONED_UNBOUND adapter; ne dokazuje UI abandon, account closure ili izvršenje svih klasa. P4 istorijski READY za 14 klasa/tri providera nije današnja aktivacija.

`ex06b_lib.test.mjs` bezuslovno čita sada obrisani `.github/workflows/ex06b-alias-proof.yml`; više P6 harness-a takođe traži obrisane workflow fajlove. Njihov stari PASS nije prolaz exact HEAD-a. Zamenu određuje stvarni sadašnji CI caller, uz očuvanje smisla dokaza.

**Promene proverivača koje su potrebne:** obavezna polja/rezultati i tačna kardinalnost; `IS DISTINCT FROM` ili drugi izričiti NULL-safe uslov gde NULL ne sme proći; razlikovati PARTIAL/SKIP/NOT VERIFIED od PASS-a; sačuvati stvarni RPC/decoder umesto tihog fallback-a u završnom kriterijumu; proveriti current telo i aktivni CI caller. CUR01 može preskočiti stage-specific grane ako je proof_stage NULL; statički JSON/string assertion ne zamenjuje izvršni scenario. Opisani testni nedostatak sam ne dokazuje pogrešan produkcijski rezultat.

**Native/provider S03 i cost granice:** EX07/S03 izričito ostavlja E12 recovery, P14 opoziv sesije i OS čuvanje URL-a kao OBSERVATION. Njegov workflow contract izuzima `src` izmene iz trigger-a; stari PASS zato nije svaka naredna promena klijenta. Provider near-miss test gradi accepted iz EXACT, dok core vraća FOREIGN_ECHO, pa prazna accepted lista sama ne dokazuje odbijanje; raw variants ostaju izvor provere. P6 repeatability PASS potvrđuje validnost 720 uzoraka, čak uz neuspešan performance screening, i izričito ne prihvata produkcioni SLA; finalcost wrapper ima stroži zaključni uslov. Istorijski RLS-components runner ponavlja PK uzorke pri četvrtoj fazi, a world-guard probe ima bare SQL echo umesto psql komande. To su konkretni kvarovi dijagnostičkih alata, ne dokaz kvara današnjeg proizvoda.

**Bezbedan domet istorijskih harness-a:** p0d03 može DROP pre guard-a nad DB_URL; ru1 koristi DROP i sintetički migration ledger; pkg010 menja cron/replay pre pune guard provere, sa PGHOSTADDR izuzetkom i bez pouzdanog finally; neki EX06 helperi pauziraju cron, brišu schedule redove ili prekidaju tuđe duge lokalne backend-e. To nisu read-only dijagnostike. Pre budućeg izvršavanja: dokazano sopstvena izolovana baza, guard pre prve mutacije, sopstveni fixture scope, bounded timeout i obavezno vraćanje stanja. Current worker_profile_licenses harness pokazuje bolji source/marker/rollback obrazac. Nisu tražena nova ovlašćenja niti izvršene ove skripte u analizi.

**Chat i concurrency zaključci:** B1b closure runner ima stvarne lokalne SQL/Storage/worker korake za obe uloge, sa sopstvenim voice redakcijama i očuvanim peer/foreign sadržajem. Media Edge Auth je emuliran; istorijski 52-dataset V5_9 roster ne zatvara F19. Exact-message resolver proof izričito očekuje UNAVAILABLE kada je IN_APP suppressed/off ili zamenjen PUSH kanalom, uz pushTransportProven=false. Transport proof presreće Expo, koristi izolovan queue, jedan uređaj i uključen IN_APP; zato ne zatvara F20 kapacitet i nezavisne postavke.

EX05 S02 ima 41 od 42 tela identično sadašnjosti; current cancel je promenjeni CORE. Istorijski RC02-F1/F2 strukturno su adresirani redosledom advisory→conversation FOR UPDATE→asset FOR UPDATE, uz ponovno vlasničko čitanje, tombstone i PT409. To nije novi konkurentni runtime PASS. Stari scratch-control dodaje lock pre advisory, a current popravka dodaje drugo čitanje posle advisory; ne kopirati stari kontrolni patch. EX05_S01 ima 54 od 60 istih tela; promenjeni su važni push/ACK/inbox vlasnici. Njegov renderer uzima poslednji isti basename bez SHA/runId veze, prihvata result=PASS i sa praznim checks, a RECORDED karakterizaciju tretira kao prolaz. Konačni dokaz mora vezati tačan run, sadržaj i obavezne provere.

**EX04 i F01:** od 25 istorijskih pinova 16 je LF-identično sadašnjim telima, devet promenjeno, uz dodatni ACL drift. Current paged reader je stari pre-EX04A `dad1de…`, ali helper `own_task_counts` već je EX04A `01d695…`. Zato kompletan stari apply odbija postojeći helper; nova popravka mora uskladiti baš preostali javni reader i decoder, uz očuvanje već postojećeg brojača. Home rating `1703b04…` i eligible oracle `75a8b78…` su i dalje isti. Z02/C-PROOF02 sadrži pun trag. Ovo dodatno objašnjava zašto se cela baseline migracija ili ceo istorijski kandidat ne vraćaju kao jedan paket.

**AI manifest i byte-check:** frozen AI manifest sada ima dva od deset identičnih fajlova, sedam promenjenih i jedan obrisani workflow. Runner se zaustavlja sa `FROZEN_SOURCE_CHANGED`; to je zastareo/neupotrebljiv sadašnji gate, ne lažni uspeh. EX07/S06 generator i njegov library test normalizuju CRLF pri `--check`, iako naziv kaže byte-for-byte; zaseban stvarni runner čita sirove bajtove i odbija CR. Zato taj pojedinačni generator-check nije pun bajtni dokaz, ali nije ni proboj svih gate-ova. Uskladiti raw-byte hash/line-ending proveru. S06 dodatni safety-name kandidat ostaje predlog; postojeći generički UI fallback već radi.

**Discovery-grad:** sintetičkih do 40.000 zadataka, dva naloga i do 32 istovremene petlje čitanja nije dokaz 40.000 korisnika ili sadašnjeg kapaciteta. Sačuvati proveru celog odgovora/cursora, hladnih i toplih merenja, ponavljanih/različitih lokacija, otkaza i nepotpunih merenja. Current RPC `a5ce63c8…` razlikuje se od istorijskog pina `a9b09859…`, dok fold helper `41353abe…` ostaje isti uz ACL promene. Rebase dokaz na stvarnog owner-a, javnu privatnost, workAreas i current klijentski rok od 15 s; stari prozor posmatranja od 90 sekundi nije prihvaćeno korisničko čekanje. Z02/C-PROOF03 sadrži tačan trag.

**Aktuelne korekcije istorijskih zaključaka:** D12 kasniji README beleži stvarnu primenu, iako naslov i raniji tekst ostaju source-only. R01 consent-validity čitači su current; to ne vraća PHONE UI. Inbox implementacija postoji i ima active caller; razlika je116CRLF u izvornom telu plus poseban ACL delta. Current export zahtev proverava nespreman policy pre inserta. Ne proglašavati već primenjene zaštite nepostojećim na osnovu imena istorijskog fajla.

### Operativna matrica testova za R01–R12

**Stvarna selekcija sadašnjeg CI-ja:** `package.json:73` pokreće Jest; `jest.config.cjs:26` bira `**/__tests__/**/*.test.ts?(x)`. Jedini praćeni workflow `.github/workflows/ci-clean.yml:35–68` dodaje Node glob `supabase/proofs/ai/*.test.mjs` i 13 imenovanih taxonomy testova. Deno korak je `check` bez izvršavanja, a Python korak proverava migracioni izvor. `.mjs` fajl ne ulazi u Jest samo zato što se zove test. To je statički potvrđena selekcija, ne svež CI run. [Z09](dokazi/namena_i_testovi/intent_review.json)

`taxonomy-postsave-worker.test.mjs` i `worker-finish-mode-completeness.test.mjs` nisu izabrani tim Node komandama. `v5_media_deno_runtime.test.ts` takođe nije deo prikazanog Jest/Deno izvršavanja. Njihovo uključivanje određuje relevantan zadatak; ne uključivati celu istoriju ili mutirajuće harness-e u svaki CI. Globalni Jest setup koristi UTC i legacy HITNO flag, a poseban `urgent-hidden-in-v1` test uklanja flag i čuva odsustvo te opcije u V1.

**PASS karakterizacije nije završno prihvatanje:** `currency_correction_characterization.test.mjs:219–245,275–279` čuva reprodukciju stare potvrđene cene i satničkog nesklada; `background_capture_receipt.test.mjs:174–176` čuva reprodukciju odsustva automatskog ponavljanja. Oba su u aktuelnom CI glob-u. Posle popravke sačuvati reprodukcioni scenario, a kriterijum uspeha promeniti u željeni ishod. `interview_voice_one_question.test.mjs:1–13` proverava prompt tekst, a `worker_signed_areas_sql.test.mjs:1–46` SQL stringove: korisne source ograde ostaju na tom nivou.

Odluke u narednoj matrici: **sačuvati** korisnu nameru testa; **popraviti** pogrešnu ili slabu proveru; **dopuniti** tačno odsutnu vezu; **uskladiti istorijski alat** sa sadašnjim vlasnikom; **uslovno povući** tek nakon provere preostalih potrošača. Predložene lokalne komande i preduslovi su u Z09; ovde nije izvršena nijedna. Odsustvo iz CI selekcije samo po sebi nije istorijski ili beskoristan status.

#### R01 — Privatnost čitanja i tačan isporučeni ugovor

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `supabase/proofs/discovery/p6_http_boundary.mjs` (60–70, 125–136) | **Sačuvati nameru; uskladiti alat sa sadašnjim vlasnikom.** Stvarni lokalni Auth/PostgREST i zabrana direktnog čitanja requester_account_id. Istorijski predecessor/replay; ne pokriva sadašnje tri kolone i sve oblike pristupa. |
| `supabase/proofs/discovery/p6_world_boundary_proof.mjs` (101–111, 238–256) | **Sačuvati nameru; uskladiti alat sa sadašnjim vlasnikom.** SQL uloga/RLS i sva tri privatna column granta; granica svetova. Nije aktuelni Auth/HTTP dokaz, nema zatvorenog viewer naloga u istorijskom prolazu. |
| `src/data/__tests__/build-identity.test.tsx` (17–28, 48–58) | **Sačuvati i dopuniti.** Dozvoljena javna polja identiteta i embedded/OTA oznaka. Ne dokazuje da je baš taj APK/OTA na telefonu niti kompatibilnost živog SQL-a. |

**Najmanji nedostajući scenario:** Dva sintetička naloga istog sveta, tuđ PUBLISHED/SELECTION zadatak sa razlogom zatvorene pretrage; proveriti direct/alias/filter/order/wildcard za tri privatne kolone i normalne javne/sopstvene readere.

**Uslov završetka:** Sva tri interna polja ostaju nedostupna tuđem nalogu; javni prikaz i legitimni sopstveni čitači rade na istim važećim funkcijama.

**Pozitivna/negativna granica:** Drugi svet, anoniman/zatvoren nalog i pogrešna/istekla sesija ostaju odbijeni; validan vlasnik dobija dozvoljeni sopstveni prikaz.

**Domet i povlačenje:** Ne pokretati istorijski PKG045b ili ceo P6 replayer kao popravku. Sačuvati smisao testa, zameniti samo polazni/current owner i nužne fixture-e.

#### R02 — Discovery, mapa i istinita greška

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `src/data/__tests__/discovery-v1-client-transport.test.ts` (7–12, 23–34, 59–74) | **Sačuvati i dopuniti.** Tačan RPC, abort, 15s rok, stabilni kodovi greške. Mock RPC ne dokazuje ponuđene MAP/PLACES/filter mogućnosti servera. |
| `src/data/__tests__/discovery-v1-route-lifecycle.test.tsx` (25–44, 64–84, 314–329) | **Sačuvati scenario; popraviti očekivanje i dopuniti.** Stvarna ruta/coordinator uz lažni server; sadašnji test prihvata ceo error ekran kad MAP zakaže. Posle popravke očekivati odvojenu grešku mape uz očuvanu validnu listu; bridge je zamenjen stubom. |
| `src/data/__tests__/discovery-presentation.test.tsx` (3006–3027, 3571–3583) | **Sačuvati i dopuniti.** Prazan P6 prikaz i raspored list/pill/nav prema zadatim merama. Ne dokazuje native MapLibre, stvarni server ni HALF preklapanje sa dostavljenih slika. |

**Najmanji nedostajući scenario:** Hladan ulaz: pravi PAGE odgovor prolazi decoder, MAP se kontrolisano odbije; zatim isti slučaj kroz Retry. Ponoviti na telefonu u HALF stanju, velikim fontom.

**Uslov završetka:** Lista i filteri ostaju upotrebljivi; stanje podloge/pinova razlikovano; objašnjenje i dugme vidljivi; povratak MAP uspeha ne resetuje korisnički izbor.

**Pozitivna/negativna granica:** Prazan uspešan PAGE nije greška; oba neuspešna čitanja ne prikazuju lažni broj 0; REMOTE ne traži fizičku mapu.

**Domet i povlačenje:** Mock MAP podrška nije razlog da se ukloni test; zadržati ga kao rutu i dodati ugovornu granicu. Postojeće global-error očekivanje uskladiti sa novim ponašanjem.

#### R03 — Moji zadaci i straničenje

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `src/data/__tests__/own-tasks-page-client.test.ts` (9–13, 30–56, 122–128) | **Sačuvati i dopuniti.** Pravi decoder/mapNeed sa modelovanom payload strukturom, pet counts i prazna stranica. Ručno pripremljen payload ne otkriva stari camelCase/no-counts odgovor živog reader-a. |
| `src/data/__tests__/own-tasks-pager.test.ts` (29–60, 175–182, 217–226) | **Sačuvati.** Fokus, cursor, dedupe, kasni/account odgovor i counts samo prve strane. To nije izvršenje SQL reader-a. |
| `supabase/proofs/ex04/ex04a_proof.mjs` (98–109, 169–193, 209–213) | **Sačuvati nameru; uskladiti alat sa sadašnjim vlasnikom.** Stvarni lokalni RPC i poređenje pet scope-ova sa klijentskim pravilom; outsider/anon. Stari apply očekuje preimage oba vlasnika; sada helper own_task_counts već sadrži EX04A, javni reader ne. |

**Najmanji nedostajući scenario:** Za svaki od pet scope-ova pročitati praznu i nepraznu prvu stranu, zatim nastavak kroz važeći SQL i stvarni ownTasksPage/mapNeed decoder.

**Uslov završetka:** Značenje scope-a, svih pet counts, cursor i oblik svake stavke odgovaraju prikazu; kasnija strana ne menja counts.

**Pozitivna/negativna granica:** Tuđ korisnik nema tuđe zadatke; pogrešan cursor/scope odbijen, običan validan prazan rezultat prihvaćen.

**Domet i povlačenje:** Ne vraćati ceo stari EX04A paket; rebase testa na trenutni helper i promeniti samo nedostajući reader ugovor.

#### R04 — Identitet usluge i celovit semantički rezultat

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `supabase/proofs/ai/background_taxonomy_scope.test.mjs` (130–162, 164–198) | **Sačuvati i dopuniti.** Pravi BG builder sa kontrolisanim transportom čuva scope/identitet u posejanim primerima. Ne zatvara signed prepare/Save/binder ni neupisani sinonim/new-branch tok. |
| `supabase/proofs/dynamic_taxonomy/classification-gemini-shadow.test.mjs` (1–25) | **Sačuvati.** Parser/planner i service/mode ugovor sa kontrolisanim odgovorima. Odvojena putanja ne dokazuje da aktivni dual handler poziva isti ugovor. |
| `src/data/__tests__/worker-ai-client.test.ts` (127–175, 197–235) | **Sačuvati i dopuniti.** Signed review dekoder, oba moda jednog servisa, child/main grana, stari/novi RPC izbor. Ručno konstruisan review ne dokazuje da ga aktuelni SQL tako proizvodi. |
| `supabase/proofs/dynamic_taxonomy/gemini-real-provider-smoke.mjs` (83–89, 128–140) | **Popraviti proveru.** Wire/schema smoke i kontrola pojedinih vraćenih polja. classificationShadowJson se proverava samo ako postoji; mora zahtevati obavezno prisustvo pre PASS-a. |

**Najmanji nedostajući scenario:** Preneti već pronađene audit reprodukcije u ciljnu regresiju: nepotpun katalog pa kompletna ista verzija; neupisani sinonim istog servisa; izričit BOTH sa jednim vraćenim modom; uspešna klasifikacija pa „to je to”.

**Uslov završetka:** Pun katalog nije zamenjen parcijalnim kešom; isti smisao zadržava ID; očekivani parovi su kompletni ili izričito nedovršeni; nepromenjeni servis ostaje razrešen kroz prepare/Save/readback.

**Pozitivna/negativna granica:** Stvarna promena servisa/mode/handoff odbacuje stari rezultat; novi DB ID nastaje tek iz dozvoljenog writer-a; nema tihog dupliranja sinonima.

**Domet i povlačenje:** Bogati full-snapshot i dual BG ne pretvoriti u treći klasifikator. Source regex provere zadržati, ali nisu dokaz izvršene SQL semantike.

**Revizija 7, dodatni potreban dokaz R04:** u postojećim pravim builder/handler testovima obuhvatiti alfabetni red koji nije DFS i dokazati da model input čuva svakog roditelja, alias i očekivani mode skup. Potom proveriti potpun/nepotpun/NOT_MODIFIED snapshot, paralelni miss, otkazan waiter, rename uz isti normalizovani ključ i stvarnu promenu fingerprint-a. `supabase/proofs/ai/classification-full-catalog-edge.test.mjs` u pregledanom fixture-u koristi `https://db.invalid`; to ne uključuje exact-DEV dual selector oba handlera. Zato njegovi direct/shadow testovi ne dokazuju BG put. `background_taxonomy_failures.test.mjs` koristi stvarne BG buildere uz sintetički transport: sačuvati te failure/consent slučajeve i dopuniti semantičku strukturu. Ne dodavati novi paralelni testni sistem ili pravi mrežni poziv; tokom buduće lokalne provere svaki nenajavljen poziv mora biti odbijen fixture-om. Nijedan takav test nije izvršen u reviziji 7.

#### R05 — Područje, vreme i pravi izbor kandidata

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `supabase/proofs/ai/worker_signed_areas_sql.test.mjs` (1–8, 10–30, 33–46) | **Sačuvati i dopuniti.** Regex provera SQL izvora: writer, validator, stale-source kontinuitet, privatni helperi. Sam test ne izvršava SQL, save ili matching. |
| `src/data/__tests__/worker-area-route.test.tsx` (97–115, 142–167) | **Sačuvati.** Potvrda grube tačke/revizije i REMOTE ograničenje u stvarnoj ruti sa servisnim zamjenama. Nije current saved-area matcher niti dokaz da početni izbor ne gubi radnika. |
| `src/data/__tests__/w02-worker-availability-client.test.ts` (25–43, 75–88, 115–133) | **Sačuvati.** Normalizacija, expected revision i conflict zaštita. Ne izvršava current TODAY time-tier ili automatski dispatch. |
| `supabase/proofs/match_category_fallback/dispatch-prefilter-assert.sql` (1–20) | **Sačuvati nameru; uskladiti alat sa sadašnjim vlasnikom.** Istorijske prefilter kontrole nad namenskim fixture-om. Treba current definicije i sačuvana područja; stari aggregate nije cela matrica dozvoljenih parova. |

**Najmanji nedostajući scenario:** Radnik ima udaljenu staru profilnu tačku ali važeće COUNTRY/CITY/RADIUS područje; TODAY bez uskih bounds uz „slobodan kasnije danas”. Isti mali skup provesti kroz retrieval, matcher, Za mene i dispatch.

**Uslov završetka:** Dozvoljeni radnik nije izgubljen pre area evaluacije; svi slojevi daju istu odluku i vreme.

**Pozitivna/negativna granica:** Zaista van područja/vremena odbijen; ručna prijava i izbor zadržavaju svoja zasebna pravila; REMOTE nema izmišljeni fizički radius.

**Domet i povlačenje:** Ne preuzimati stare obavezne equipment/team/experience ili sve-slot politike iz fixture-a.

#### R06 — Trajan nastavak i trošak pokušaja

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `supabase/proofs/ai/background_capture_receipt.test.mjs` (150–191) | **Sačuvati reprodukciju; promeniti cilj posle popravke.** Pravi handleri u kontrolisanoj I/O probi; neispravan ACK/diagnostika i postojeće odsustvo ponovnog pokušaja. 174–176 izričito očekuje da nepromenjeni input ne pokrene retry; posle odobrene popravke taj kriterijum mora postati dokaz trajnog nastavka. |
| `supabase/proofs/ai/taxonomy_provider_budget.test.mjs` (8–28, 36–56) | **Sačuvati i dopuniti.** Stvarni budget modul u VM-u: jednom settlement, unknown usage i otpornost na logging failure. Ne dokazuje da odvojeni aktivni BG fetch uopšte koristi taj budget owner. |
| `supabase/proofs/dynamic_taxonomy/taxonomy-postsave-worker.test.mjs` (3–34, 36–51, 75–89) | **Sačuvati; dodati relevantnoj CI selekciji.** Post-Save worker protokol i receipt/lease/retry granica, sa lažnim RPC transportom. Nije trenutno u CI Node izboru; nije trajni PRE-review posao niti stvarni SQL lease. |
| `src/data/__tests__/ai-turn-intent-journal.test.ts` (1–24) | **Sačuvati i dopuniti.** Account-isolated stabilni identitet pokušaja; stale clear ne briše drugi command. Memorijski AsyncStorage mock nije dokaz gašenja procesa na telefonu. |

**Najmanji nedostajući scenario:** Kontrolisani gubitak capture/store ACK-a, gašenje pa nastavak procesa sa istom namerom. Odvojeno uspešan, prekinut i usage-unknown stvarni BG pokušaj.

**Uslov završetka:** Trajan posao ostaje vidljiv i bounded; isti uspešan pokušaj se prepoznaje readback-om; nema automatskog ponavljanja već izvršenog plaćenog poziva; svaki stvarni attempt ima poseban poznat/unknown obračun.

**Pozitivna/negativna granica:** Promena revizije/naloga odbija stari nastavak; nedostajući STOP ili prevelik/truncated odgovor ne postaje gotov rezultat.

**Domet i povlačenje:** Post-Save queue i pre-review recovery imaju različit zadatak; jedan postojeći PASS ne zamenjuje drugi.

**Revizija 7, dodatni potreban dokaz R06:** provider cache miss/expiry/rejection razlikovati od unknown ishoda već poslatog generate zahteva. Dokazati da cached ulaz nije dva puta sabran, da BG prolazi request/response cap i isti verifikovani usage decoder, da model/prompt/content promena invalidira rezultat i da worker ne plaća ponovno pronalaženje već važećeg canonical ID-ja. Eksplicitni cache uključiti samo posle tokenizer/reuse/TTL odluke; sada nema izmerenog token/cost PASS-a. Provera postsave catch-a ide kroz isti logical request key i postojeći retry/terminal model.

#### R07 — Cena, odustajanje i dodatni profilni upis

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `supabase/proofs/ai/currency_correction_characterization.test.mjs` (192–195, 219–245, 271–279) | **Sačuvati reprodukciju; promeniti cilj posle popravke.** Izolovana stvarna Edge/SQL tela reprodukuju zadržanu staru potvrđenu cenu i HOURLY nesklad. To je current CI test koji NAMERNO prolazi kada se postojeći kvar reprodukuje. |
| `src/data/__tests__/application-proportional-price.test.ts` (1–32) | **Sačuvati.** Nezavisan celobrojni oracle i proporcionalni TOTAL/razni modovi. Nije potvrda konačne poslovne odluke o satnici/valuti niti celu writer putanju. |
| `src/data/__tests__/review-exits-and-place.test.tsx` (352–380) | **Sačuvati i dopuniti.** Odbijen/unknown abandon i UX readback radnja sa mocked service. Dopuniti slučaj stvarno ABANDONED bez zasebnog Need-a i razrešenje kroz pravi read port. |
| `src/data/__tests__/application-composer-read.test.tsx` (120–130) | **Sačuvati i dopuniti.** Uspešna prijava ostaje uspešna ako opcioni profile save zakaže. Ne pokriva paralelno izmenjene skills i A→B→A između success-a i dodatnog upisa. |

**Najmanji nedostajući scenario:** Tri odvojena mala slučaja uz njihove vlasnike: „5000 RSD”→„mislio sam EUR”; izgubljen uspešan abandon ACK; kasni opcioni dodaj-veštinu posle paralelne promene profila/naloga.

**Uslov završetka:** Stara cena gubi važeću saglasnost bez izmišljenog kursa; ABANDONED se potvrdi bez novog prepare/write; dodatna usluga ne pregazi noviju listu niti drugi account.

**Pozitivna/negativna granica:** Validna nova RSD cena se potvrđuje; OPEN nije lažno napušten; pozitivan save veštine u istoj važećoj reviziji ostaje moguć.

**Domet i povlačenje:** Ne zadržavati test koji očekuje stari kvar kao završni acceptance; očuvati njegovu reprodukciju u jasno označenoj istoriji ili pretvoriti assertion u željeno ponašanje.

#### R08 — Prirodan završetak i veran sačuvani rezultat

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `src/data/__tests__/worker-ai-conversation-recovery.test.tsx` (79–124, 152–157) | **Sačuvati i dopuniti.** Prazan/resumed chat, last-good offline stanje, jedna provera i odsustvo parcijalnih kartica. Servis i journal su testne zamene; nije dokaz autoritativnog completion signala u stvarnom toku. |
| `src/ui/workerProfile/__tests__/worker-ai-review.test.tsx` (34–57, 73–96) | **Sačuvati i dopuniti.** Per-service mode/handoff pregled i signed no-write policy bez stare obavezne opreme. Pregled sa zadatim props ne dokazuje da sačuvani profil prikazuje isti sadržaj. |
| `supabase/proofs/dynamic_taxonomy/worker-finish-mode-completeness.test.mjs` (1–31, 33–42) | **Sačuvati; dodati relevantnoj CI selekciji.** Jedna završna smernica i vidljivost nerazrešenih usluga bez implicitne potvrde. Trenutno nije u CI izboru; helper nije dokaz završetka/Save/binding cele ponude. |
| `supabase/proofs/ai/interview_voice_one_question.test.mjs` (1–13) | **Sačuvati i dopuniti.** Regex provera da zajednička prompt instrukcija traži jedno pitanje, pamti jasne podatke i ne tvrdi Save autoritet. Ne izvršava model ni guard; prisustvo rečenice u promptu ne dokazuje stvarni razgovor ili kombinaciju više nejasnoća. |

**Najmanji nedostajući scenario:** Naručilac/radnik u jednoj poruci daje više jasnih činjenica; zatim „to je to”. Radnik ima više usluga, dva moda iste usluge i konkretan handoff; posle Save ponovo otvoriti sačuvani profil.

**Uslov završetka:** Sve poznate činjenice ostaju; najviše jedno stvarno potrebno razjašnjenje; jedan smislen pregled; završetak dolazi iz autoritativnog stanja; sačuvani prikaz verno prenosi service/mode/handoff.

**Pozitivna/negativna granica:** Zaista nepoznat obavezan podatak ostaje jasno označen; nijedan „imam neki sadržaj” boolean nije dovoljan za završenost.

**Domet i povlačenje:** Ne vraćati ukinute mode/equipment/bio formulare zato što ih istorijski fixture očekuje.

#### R09 — Obaveštenja, poruke i tačno odredište

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `src/data/__tests__/notification-preferences-client.test.ts` (17–50, 91–105) | **Sačuvati.** Odvojene postavke, owner/CAS, neizvestan ishod i bez tihog opt-in-a. Ne dokazuje server resolver kada je PUSH on / IN_APP off. |
| `src/data/__tests__/message-push-ingress.test.tsx` (34–85) | **Sačuvati i dopuniti.** Owned događaj, poslednji tap, unavailable bez nagađanja i hladan foreground povratak. Resolver i native notification su zamene; ne zatvara stvarni provider/device tap. |
| `src/data/__tests__/v5-group-conversation-controller.test.ts` (17–57) | **Sačuvati.** Čitanje/upis kontrolera, istorija i kasni odgovor/permission granice. Sam message upis ne stvara događaj za obaveštenje. |
| `supabase/proofs/chat/exact_message_event_resolver_proof.mjs` (293–316) | **Sačuvati nameru; uskladiti očekivanje.** Istorijska stvarna SQL granica eksplicitno odbija suppressed/off IN_APP i PUSH kanal. Ako željena nezavisna PUSH postavka ostaje podržana, potreban je novi bezbedan dokaz cilja; ne uključivati IN_APP potajno. |

**Najmanji nedostajući scenario:** Primalac već odgovorio istoj reviziji, drugi nije; PUSH uključen/IN_APP isključen; grupna poruka stvara tačan događaj. Mali bounded burst meri drain/send/receipt, a stvarni tap otvara tačnu poruku.

**Uslov završetka:** Nema nepotrebnog istog opportunity slanja; nema duplog slanja posle nepoznatog ACK-a; oba preference izbora poštuju se; group i exact-message odredište autoritativni.

**Pozitivna/negativna granica:** Zatvoren nalog/istekla sesija/nevidljiva poruka ostaju UNAVAILABLE; namerno isključen push se ne šalje.

**Domet i povlačenje:** Istorijski Expo-intercepted transport ostaje vredan lokalni dokaz; ne koristiti ga kao dokaz stvarnog kapaciteta ili telefonskog tap-a.

#### R10 — Život podataka i pravne saglasnosti

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `src/data/__tests__/p1-legal-client.test.ts` (35–57, 61–85) | **Sačuvati i dopuniti.** Bundle decode, stabilan request i poruka o version drift-u. Dopuniti unknown prihvat starog bundle-a nakon pojave novog sadržaja u montiranom UI toku. |
| `src/data/__tests__/p2-data-export-delivery-client.test.ts` (85–93, 109–149, 151–165) | **Sačuvati.** Auth/transport rokovi, neizvestan upis i exact streamed bytes. Uspelo byte delivery ne dokazuje potpunost polja celog izvezenog naloga. |
| `supabase/proofs/legal/p1_legal_consent_proof.mjs` (1–20) | **Sačuvati nameru; uskladiti alat sa sadašnjim vlasnikom.** Istorijski lokalni server consent/replay dokaz. Nije current UI unknown readback niti celokupan pravni lifecycle. |
| `supabase/proofs/legal/p2_data_export_proof.mjs` (1–20) | **Sačuvati nameru; uskladiti alat sa sadašnjim vlasnikom.** Istorijski local export/grant/race dokaz nad tadašnjim roster-om. Stari dataset spisak ne obuhvata novo workAreas polje ni sve današnje arhivske kopije. |

**Najmanji nedostajući scenario:** Sačuvati sintetički profil sa workAreas, izvesti i pregledati svaku current živu/arhivsku projekciju; povući grant i proveriti kasni pokušaj; zasebno legal-v1 unknown→v2 sadašnji UI.

**Uslov završetka:** Potvrđena namera ostaje u izvozu/kopijama; opoziv važi; zatvaranje ima pravi status; stara saglasnost ne potvrđuje novi dokument.

**Pozitivna/negativna granica:** Nespremne export/erasure/readiness veze ostaju zatvorene; tuđ nalog ne dobija artefakt; stariji request ne oživljava opoziv.

**Domet i povlačenje:** Ne aktivirati gate na osnovu starog READY/certifikata; rebase starog dokaza mora pratiti celu izmenjenu projekciju.

#### R11 — Preostali ekrani i usko povlačenje

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `src/ui/reviews/__tests__/use-given-ratings.test.tsx` (35–64, 84–108) | **Ispraviti očekivanje keša; sačuvati scenario.** Čitanje/greške i postojeće pravilo da isti Dogovor ID-jevi ne čitaju nove ocene. 51–55 treba dopuniti stvarnom novom ocenom uz iste ID-jeve i očekivanim invalidiranjem, ne samo remount-om iste liste. |
| `src/data/__tests__/worker-profile-read.test.ts` (1–24, 67–77) | **Popraviti proveru.** Mapiranje profila i odbijanje stranog/kasnog Auth rezultata. Negativni no-query assertion proverava mockFrom iako aktivni port koristi mockRpc. |
| `src/ui/support/__tests__/SupportScreens.test.tsx` (90–128) | **Sačuvati i dopuniti.** Privatan support formular i retained callback/command guard. Dopuniti unsent tekst kroz blur/focus/remount prema odobrenoj nameri, ne pretpostavljati da ga drugi editor čuva. |
| `src/data/__tests__/urgent-hidden-in-v1.test.tsx` (1–28) | **Sačuvati.** V1 build bez flag-a nema HITNO, čak i ako legacy podaci postoje. Jest setup globalno uključuje legacy flag; ovaj poseban test ga namerno uklanja. |

**Najmanji nedostajući scenario:** Za svaki SB/X vlasnik samo njegov konkretan propust: ocena promenjena uz iste ID-jeve, stvarni kasni RPC port, support/Dogovor neposlat tekst, avatar sadržaj ili skrivena refresh radnja.

**Uslov završetka:** Izmenjeni vlasnik zatvara imenovanu rupu; aktivni formatter/recovery/native patch ostaju očuvani; uklonjen podskup nema aktivnog/podržanog starog caller-a.

**Pozitivna/negativna granica:** Prazan/foreign/istekao rezultat ostaje odbijen, pravi sačuvani sadržaj ne nestaje, screen-reader ne fokusira nevidljivu radnju.

**Domet i povlačenje:** Ne brisati ceo legacy/shadow/proof fajl; test koji štiti povučeni UI arhivirati tek posle caller/kompatibilnost analize, a koristan aktivni deo ostaje.

#### R12 — Stvarna celina i izdanje

| Postojeća provera | Odluka i stvarna granica |
|---|---|
| `.github/workflows/ci-clean.yml` (35–68) | **Sačuvati aktivni CI uz tačan nivo dokaza.** npm ci/native patch; tsc; Deno check bez izvršavanja; Jest; izabran Node; Python source integrity. Nema izvršavanja stvarnog modela, migrirane baze, build/deploy ili telefonske putanje. To je namerni offline gate, ne release-ready dokaz. |
| `supabase/proofs/ai/clean_ci_coverage.test.mjs` (9–35) | **Sačuvati; dopuniti relevantan manifest.** Regex proverava Deno komandu i sedam izričitih Node puteva; odbija secrets/deploy/continue-on-error. Ne proverava sav relevantni Node test korpus ni produkcijski ishod; dopuniti samo zadatkom odabrane neophodne testove. |
| `supabase/proofs/d12/d12_proof.mjs` (168–186, 1086–1087, 1683–1683) | **Sačuvati stvarni osnovni tok; popraviti završni kriterijum.** Stvarni poslovni P5 i jasne istorijske gap beleške imaju vrednost. Konačni result zavisi od failures/skipped, ne svih gaps/notVerified; kompletna readiness tvrdnja zahteva obavezne grane bez fallback-a. |
| `scripts/check-eas-preview.cjs` (80–90) | **Uskladiti konfiguracionu proveru.** EAS preview preinstall konfiguraciona ograda. Uskladiti namenski proof build sa stvarnim plugin/native patch validatorom; nije nalog da se zaštita isključi. |

**Najmanji nedostajući scenario:** Poznat source/SQL/Edge/flags/APK/OTA presek, dva naloga/obe uloge: opis→pregled→objava→pronalaženje→prijava→izbor→Dogovor→poruke/završetak→ocena; jedan kontrolisani prekid i account switch.

**Uslov završetka:** Vidljivi rezultat odgovara sačuvanom i dostupan je drugoj ulozi; izmereno stvarno čekanje/ukupan provider trošak; release izlaz TEST sveta i readiness jasno provereni.

**Pozitivna/negativna granica:** Nema duplog poslovnog upisa ni tuđeg/stale sadržaja posle prekida/promene naloga; povlačenje sesije prekida pristup.

**Domet i povlačenje:** Stari native/screenshot/benchmark wrapperi samo uz rebase identiteta i proveren zaključni uslov. Ne sabirati sve PASS brojeve u oznaku gotovog proizvoda.


### Merenje stvarnog čekanja

`PROVIDER` meri streaming modelski poziv: NEED `:856–860`, WORKER `:484–487`. `NEED_COMPLETE` / `WORKER_COMPLETE` mere SQL completion: `:1577–1585` / `:559–561`. Prikazani tekst ostaje iza uspešne potvrde upisa: NEED `:1634–1637`, WORKER `:610–611`. Nijedna od tih metrika sama ne meri prvi korisni prikaz, canonical readback, render ili vreme do pregleda. Potrebna su odvojena, pravilno imenovana merenja celine; ovo nije merenje novih p50/p95 vrednosti.

### F14: konkretan preduslov obnove prazne baze

| Source proof migracija | Očekivani prethodni sadržaj |
|---|---|
| `20260901105922_clean_completion_and_writer_authenticated_proof.sql:15–28` | Potpuno pokriven aktivni Dogovor; inače AUTH_PROOF_FIXTURE_REQUIRED. |
| `20260901113333_clean_ai_interview_turn_authenticated_proof.sql:10–20` | Otvoren NEED_INTAKE; inače AI_TURN_PROOF_FIXTURE_REQUIRED. |
| `20260901114029_clean_ai_fact_supersession_and_human_correction.sql:154–160` | Otvoren razgovor sa aktivnom činjenicom; inače AI_SUPERSESSION_PROOF_FIXTURE_REQUIRED. |

Sve tri su u `supabase/migrations/` i istog hash-a kao u ranijem punom pregledu. Potreban je dokumentovan, izolovano proveren bootstrap/fixture plan. Ceo replay nije izvršen i nije utvrđeno da li prethodni koraci zadovoljavaju sve ove uslove. Zato nije dokazan ni neuspeh svake prazne instalacije ni potpuna reproduktivnost. Namerni rollback proof upisa nije nalaz trajnog zagađivanja podataka. Sačuvati primenjenu istoriju; stare proof komande ne izvršavati na živom sistemu samo zbog njihovog položaja u folderu.

## 9. Corpus prihvatanja povezan sa vlasnicima

Ovo su merila završnog ponašanja, ne tvrdnja da svi slučajevi danas padaju i ne nalog za novo široko ponavljanje testova. Svaki slučaj koristi postojeću pozitivnu pokrivenost i najkraći dodatni dokaz preko navedene granice.

| Scenario | Očekivano ponašanje i potrebna granica |
|---|---|
| **A01 Korekcija valute** |5.000 RSD→„mislio sam evre”: stara cena gubi status važeće saglasnosti; nema izmišljenog kursa/OFFERS. F03 guard→writer→signed review→accept/objava. |
| **A02 MY_PRICE satnica / OFFERS** |Jedinica ostaje ista kroz podržan domen; OFFERS zaseban izbor. F02 validator/Edge/application writer i stari podržani decoder. |
| **A03 Sinonim i tekstualni writer** |„Oprati prozorska stakla” za postojeće „Pranje prozora” bez upisanog alias-a: isti ID i isti scope, bez fasade/novog duplikata. F05 model→provera→review→binding; proveriti i Need text-trigger, canonical/registrovan/neupisan alias, pogrešnu parent putanju i ID-only binder. |
| **A04 Stvarno nova usluga** |Opravdan parent ili potrebna nova grana/path, konkretan smisao i stvarni DB ID; jasnoća ne zavisi od razmaka u nazivu. Predlog nije aktivna sposobnost pre potvrde. F05. |
| **A05 BOTH** |Časovi online i kod polaznika: oba moda, isti ID; kontrolisano izostavljanje REMOTE ne daje lažno potpun rezultat. F08 builder→review→Save. |
| **A06 Radionica/predaja** |Popravka računara kod izvršioca, donošenje/preuzimanje u Novom Sadu: REMOTE sa tim handoff-om, bez ON_SITE/kurira/svetske isporuke po pretpostavci. F08/F10. |
| **A07 Bogat profil** |Osam usluga: ukloniti jednu, dodati jednu, promeniti jedan mode; sve nepogođene usluge i handoff ostaju. Biografija se menja samo gde postaje netačna. Rename/sync ne gubi postojeći ID zbog neupisanog sinonima; nepoznato dodavanje uz staru uslugu ne ukida sve; izričito povlačenje ostaje delotvorno. F05/F06/F08. |
| **A08 Više područja** |Novi Sad 30 km ostaje, Subotica CITY→Beograd CITY; bez izmišljenog radijusa/GPS adrese. Stvarni resolver→workAreas→signed Save/readback/matching; ne tiho legacy svođenje. |
| **A09 ACTIVE + pending** |Pokazati konkretno čekanje nove promene, ne pripisati joj autoritet iz ACTIVE i ne ugasiti nezavisne stare potvrđene izbore bez server pravila. F06/F10. |
| **A10 Izgubljen Save/publish ACK** |Isti command/owner/digest, canonical readback, bez novog modela/evaluacije/objave pri samom povratku. DRAFT Save i aktivacija/objava ostaju odvojeni izbori. |
| **A11 Izgubljen abandon ACK** |ABANDONED+Proveri potvrđuje napuštanje bez novog prepare/write; OPEN kontrola ne daje lažan uspeh. F11. |
| **A12 Moji zadaci** |Svih 5 scope-ova, counts, prazna/neprazna prva i naredna strana/cursor, pravi task oblik kroz pravi decoder. F01. |
| **A13 Parcijalan katalog** |Neuspeli CHILDREN na malom stablu i nextCursor slučaj; potpun kasniji snapshot zamenjuje parcijalno. Nema lažnog „usluga ne postoji”. F04. |
| **A14 Dovršavanje klasifikacije** |Tehnički BG/capture prekid dobija bounded trajni nastavak. Uspešan BG zatim vreme→područje→„to je to” čuva tačan plan; stvarna usluga/mod promena odbacuje stari. F06/F07; per-attempt obračun. |
| **A15 Jedno pitanje** |Satnica + ponavljane subote: zadržati jasan posao, tražiti jednu sledeću odluku, sačuvati drugu nejasnoću. F12. |
| **A16 A→B→A/fokus** |Kasni turn/review/Save i F13 sporedni upis ne ožive samo zbog istog account ID-ja; ne brišu novi unos niti tuđu/noviju listu. |
| **A17 Tačna isporuka** |Source/Edge/SQL/flags/APK/OTA/device zabeleženi; obe uloge završe dogovorene tokove uz pravi readback. Kvalitet modela, latencija i trošak zahtevaju stvarno ograničeno merenje. F14. |
| **A18 Prirodan završetak** |Routing poznat +„to je to” vodi jednom pregledu bez obaveznog bio/kalendar/mode formulara; zaista obavezno nepoznato daje jedno pitanje. F09 i requester readiness. |
| **A19 Instalirani discovery ugovor** |Matrica podržani stari native/OTA × ciljni novi klijent × stvarni backend: cold onsite PAGE+MAP, prazno/popunjeno, pan/next page, PLACES, forMe/minimum budget, EXACT_PUBLIC, HOURLY politika i REMOTE bez MAP zahteva. F15/F02, uz očuvane ACL/anchor/cancel granice. |
| **A20 Greške u raspoloživom prostoru** |Isti failure na prvom ulazu i retry; PAGE uspeh/MAP failure; HALF/FULL/PEEK, mali ekran/veliki font, native map failure odvojeno. Objašnjenje i akcija vidljivi, lokacijsko dugme smisleno. F16. |
| **A21 Bezbedna dijagnostika** |Auth/permission/contract/network/deadline imaju razlikovljiv interni razlog, prikladan kratak korisnički tekst i retry; nema literalnog true ni privatnog provider/SQL sadržaja. F17. |
| **A22 Buduća dostupnost i izuzetak** |Izričita dostupnost od budućeg datuma ili jedan kalendarski izuzetak menja pravi kalendar/matching samo u traženom opsegu; druga pravila ostaju. Zona, lokalni datum i instant ostaju tačni, uključujući promenu sata. Nije novo obavezno pitanje u intervjuu niti nov dokaz kvara. |
| **A23 Privatnost, izvoz i zatvaranje** |Autorizovani izvoz, opoziv granta, javna privatnost i završetak zatvaranja imaju potvrđen status/readback. Kasni pokušaj ne obnavlja povučeni pristup; važeće zadržavanje podataka nije isto što i javna dostupnost. Sačuvan raniji kriterijum, bez tvrdnje da je ceo tok sada izvršen. |

Za SB/X slučajeve uslov zatvaranja je u njihovom redu, kod konkretnog vlasnika. Cilj je proverljiv poslovni i korisnički rezultat kroz tačno utvrđenu granicu. Dodatni nepovezani PASS, promenjen tekst bez popravljenog stanja ili sama jednakost hash-a ne zatvaraju nalaz.

### Dodatni obavezni prihvatni slučajevi završnog čitanja

F21 prvo traži obnovljenu granicu privatnih kolona uz funkcionalne javne/sopstvene čitače. F18 traži istu listu dozvoljenih parova područje/topologija/vreme u retrieval→matcher→Za mene→dispatch, uz ručni submit/select koji zadržava svoje granice. F19 traži workAreas u svakoj živoj/arhivskoj projekciji i potpunu novu proveru izvoza/zatvaranja pre aktivacije. F20 traži kapacitet reda, same-revision response suppression i stvarni cilj pri PUSH on/IN_APP off. Pozitivne kontrole su običan prvi kandidat, validna stara sačuvana usluga, oba moda istogID-a, namerno isključen push i opravdano odbijena tuđa/istekla radnja.

Globalna provera čuva trenutne signed service-scope consent, saved review/request identitet, reviziju, account/world i kalendar. Current TOTAL je srazmeran covered/original slots; stare testove koji traže all-slots politiku prevoditi na važeći ugovor. Availability testovi sa New York uređajem često namerno očekuju Europe/Belgrade poslovnu politiku; nisu sami dokaz buga vremenske zone ili globalne podrške. OWNER_PERSONAL/OWNER_BUSINESS trenutno pripadaju TEST svetu kao namerna DEV izolacija; release izlaz je izričit preduslov, ne tiha data promena.

### A24/A25 — dve izričite regresione granice celog toka

**A24, zamena javne objave:** `pregled-zadatka.tsx:201–210` i replacement decoder opisuju odvojenu novu objavu. Aktuelni `rpc_publish_need_canonical` odgovara telu u `20261021101159_staged_task_replacement.sql:812`, a `cancel_replaced_task` telu na `:639`; trenutni `finalize_task_replacement` dodatno odbija `NO_MATERIAL_CHANGE`. U istom publish pozivu finalizacija zatvara staru objavu i prijave pre potvrde nove, uz transakcioni rollback pri kasnijoj grešci. Nema prenosa tuđe prijave na nove uslove. To je SOURCE ugovor potvrđen aktuelnim body tragom i novim poređenjem otisaka, ne nov runtime PASS. R07/R08/R12 treba da sačuvaju uspešnu, odbijenu, neizmenjenu i prekinutu zamenu, bez gašenja prethodne objave pre uspeha. Z09 čuva četiri precizna body odnosa.

**A25, samo poruke:** STATUS već određuje povlačenje PHONE mogućnosti iz Dogovora. Aktivni `AgreementContactPlace` vodi u Poruke i odvojeno čuva lokacijsku dozvolu. Završni dokaz R11/R12 mora obuhvatiti server i podržane stare klijente; slobodno kucanje broja u poruci nije automatski nova moderaciona zabrana. To je zatvaranje važeće namere, bez vraćanja stare opcije iz istorijskih testova.

### Obavezna ispravnost, tehnički izbor i nova poslovna politika

R07a rešava zastarelu potvrdu unutar postojećeg RSD/OFFERS domena, bez čekanja proširenja valuta. R07b precizira ceo HOURLY ugovor kroz broj ljudi i trajanje, a novi valutni domen je zasebna poslovna odluka. R08 mora verno prikazati sačuvanu ponudu po usluzi; raspored, količina odmah vidljivih detalja i prikaz potrebnih stanja konkretizuju se u obaveznoj UX specifikaciji R08/R11. R04 bira postojeći AI put po istom semantičkom korpusu i merenju: korisnik ne bira interne zastavice. Mapa može dobiti pregledljiv dizajnerski predlog, dok su tačnost potvrde i trajnost podataka već obavezni. Ove stvari ne blokiraju nezavisne potvrđene popravke. Dokazi i preporuke D01–D07 su u Z09.

### Potpuna veza nalaza sa izvršnim zadatkom

| Nalaz | Primarni rad | Povezani rad | Predmet promene kod postojećeg vlasnika |
|---|---|---|---|
| F01 | R03 | — | Uskladiti pet scope-ova, counts, cursor i tačan wire oblik javnog reader-a i decoder-a. Napraviti usku novu migraciju prema sadašnjem reader-u; ne vraćati ceo istorijski EX04a kandidat. |
| F02 | R07 | R12 | Nakon zaključivanja podrške za satnicu uskladiti HOURLY/PER_HOUR kroz fact validator, writer, review, objavu, prijavu, izbor, Dogovor i dekodere. Ne uklanjati samo TOTAL guard. |
| F03 | R07 | — | R07a: povući zastarelu potvrđenu cenu i zadržati dosledan važeći RSD/OFFERS ugovor. Nepodržana valuta ostaje nerešena do dozvoljene potvrde; ne uvoditi EUR, kurs ili OFFERS po pretpostavci. Proveriti naknadnu validnu RSD korekciju kroz stvarni review/Save/publish. |
| F04 | R04 | — | Iterirati nextCursor do potvrđenog završetka uz kontrolu ponovljenih kursora, grešaka, verzije/fingerprint-a i kompletne cache jedinice. Delimično stablo ne dobija status celog. |
| F05 | R04 | R08 | Izabrati jednog aktivnog semantičkog vlasnika prema istom korpusu i merama; dozvoliti semantički reuse postojeće grane i smislen predlog nove hijerarhije. Uskladiti bind ID-a i kategorijski tekst, worker rename/sync i sve čitaoce; tek posle parity dokaza povući suvišan put. |
| F06 | R06 | R04, R12 | Pre implementacije definisati tačan minimalan trajni zapis rada: account/conversation, draft revision, ulaz/fingerprint, scope, očekivani mode parovi, pokušaj/budget, stanje i rezultat. Omogućiti ograničen nastavak i kada prvi plan nije nastao. Existing post-save outbox povezati gde je primenljiv, ne nazivati ga rešenjem za nepostojeći plan. |
| F07 | R06 | — | Uskladiti jednog timeout/abort vlasnika i budžet logičkog pokušaja; BG čitanje mora proveriti potpunost/STOP/body limit i beležiti usage ili UNKNOWN. STT rezervaciju ne oslobađati samo zato što nema transkripta, već po dokazu dispatch/usage. |
| F08 | R04 | R08 | Iz ulazne namere izvesti ceo očekivani skup service×mode pre provider odgovora; validirati potpunost skupa nezavisno od uspešnog podskupa. BOTH ne sme postati dva nepovezana service ID-a. |
| F09 | R08 | — | Izvesti finish/readiness iz obaveznih potvrđenih poslovnih činjenica i statusa semantike, pa povezati isti kriterijum u Edge, decoder i ekran. |
| F10 | R08 | — | Povezati trajni per-service/per-mode read model sa sačuvanim profilom; prikazati ono što je upravo potvrđeno, uključujući smislen scope. Ne oživljavati stari lokalni manual draft kao drugi vlasnik. |
| F11 | R07 | — | Posle unknown abandon čitati isti review/request i razlikovati OPEN/ABANDONED/UNKNOWN; omogućiti proveru i tačan nastavak bez novog prepare-a. |
| F12 | R08 | — | Birati sledeću relevantnu nejasnoću i ograničiti sastavljeni odgovor na jedno pitanje; proveriti rezultat poruke, ne samo string instrukcije. |
| F13 | R07 | — | Ukloniti slepi upis starog celog skills niza; koristiti autoritativno ograničen merge/CAS sa account revision ili vezati postojeći vlasnik koji to već garantuje. |
| F14 | R12 | R01 | Za svaku isporuku snimiti source SHA, dependency lock, migration ledger/function bodies/ACL, Edge bundle versions+hashes, flags, build/OTA/runtime i dokaz uređaja. Razlike rebase-ovati po vlasniku; proveriti clean isolated schema bootstrap, jer istorijske proof migracije očekuju fixture stanje. |
| F15 | R02 | — | Uskladiti PAGE/MAP/PLACES i exact/filter/paging ugovor između aktivnog transporta, decoder-a i javne funkcije, uz eksplicitnu politiku kompatibilnosti podržanog starog klijenta. |
| F16 | R02 | R11, R11e native regression | Odvojiti dostupnu listu od MAP/PLACES/native-style greške i specificirati prvi read, retry bez snapshot-a i parcialni uspeh. Za HALF/FULL/PEEK panel nacrtati/stilizovati error i CTA unutar dostupne visine i navigacionih insets. |
| F17 | R02 | — | Sačuvati bezbedan tip razloga greške od data vlasnika do UI-ja i mapirati ga na razumljivu radnju; interne detalje ostaviti u dijagnostici. |
| F18 | R05 | R11, R12 | Uskladiti candidate_profile_ids/v1b, dispatch konfiguraciju, area-fit i time-tier. Retrieval mora biti nadskup stvarno podobnih radnika; koristiti potpisano područje, ne stari jedan profilni pin. Za STATIONARY/POINT_TO_POINT/MULTI_STOP/AREA_BASED eksplicitno zaključati koji postojeći topološki predicate važi. |
| F19 | R10 | — | Pratiti workAreas i izvedene/private/archive kopije kroz oba export sloja, consent revocation i closure projection. Dodati minimalne postojeće adaptere/kolone, ne vraćati ceo stari WAR01 kandidat. |
| F20 | R09 | R12 | Usaglasiti push-only target resolver bez IN_APP zavisnosti, emit/writer za stvarne event tipove i isključivanje već prijavljenog radnika iste revizije iz prve opportunity ponude. Kapacitet meriti stvarnim scheduler claim/send/receipt ciklusom, ne batch deklaracijom. |
| F21 | R01 | — | Novom uskom migracijom ukloniti konflikt širokog table SELECT i eksplicitnih public projekcija/privatnih kolona. Pre toga popisati invoker/owner read korisnike i closure binding; ne menjati ACL naslepo. |
| SB01 | R11a | — | Uvesti/vezati razlikovan public opportunity target za karticu moje prijave; povezati ga na postojeću /prilike/[id] rutu. |
| SB02 | R11b | — | Invalidirati datu ocenu posle potvrđenog upisa i obnoviti prvu stranu primljenih ocena na definisan povratak, uz scope/revision ključeve. |
| SB03 | R10 | — | Autoritativno završiti/otkazati staru consent operaciju pre prihvatanja novog TERMS/PRIVACY hash-a; obezbediti izlaz iz READ_REQUIRED stanja i eksplicitan nov pristanak. |
| SB04 | R11c | — | ABSENT posle pokušaja ne zaboraviti pre server cancel/reconcile; izložiti PROCESSING/STAGED oporavak i uskladiti jedan deadline/abort owner. |
| SB05 | R11c | — | Definisati avatar-specifičan reconcile/cancel starog upload-a i osloboditi novu selekciju tek posle tačnog završetka; ne kopirati conversation-only task photo API. |
| SB06 | R11d | — | Razdvojiti neposlat nacrt od poslate durable komande; očuvati nacrt istog account/context/revision pri običnom background/povratku i upozoriti pri namernom izlasku. |
| SB07 | R11d | — | Vezati neposlat razlog/predlog za account, agreement i version; očuvati i ponovo proveriti review. Start-only podršku zaključiti i provesti kroz model/writer/read/UI, ne samo oslabiti validProposal. |
| SB08 | R09 | — | Ili vezati postojeći atomski autoritet za oba role scope-a ili trajno pročitati oba ishoda i nastaviti samo nedostajući; Back mora uzeti writing/unknown u obzir. |
| SB09 | R11b | — | Odrediti podržan javni put do komentara, vezati postojeći read/service/UI ili uskladiti obećanje sa stvarnim proizvodnim pravilom. Test sopstvenog profila koji ne šalje comments props ne dokazuje ceo javni tok. |
| SB10 | R09 | — | Prikazati refresh kao stvarnu dostupnu radnju ili ukloniti montiranu fokusabilnu kontrolu uz očuvanu dostupnu alternativu. |
| SB11 | R02 | R11, R11a regression | Finalize placePaging/controller i kod decode izuzetka; loaded recent account označiti tek nakon prihvaćenog read-a ili dati ponovljiv fallback; fit ključ mora uključiti sva relevantna revision/mode/pin/end polja. |
| SB12 | R11e | R05 | Povezati jedan eksplicitan policy prikaza/izmene ugovorenog vremena; označiti relevantnu zonu i čuvati UTC instant. Testirati drugim TZ okruženjem, jer sadašnji Jest setup UTC prikriva razliku. |
| SB13 | R11e | R02, R08, R12 | Razdvojiti style/raster readiness od funkcionalnog SVG pin/drag gde vlasnik to dozvoljava; uskladiti Nearby copy/camera, panel insets, blur draft i reduced-motion lifecycle. Odluku o uklanjanju rastera doneti tek nakon native drag dokaza. |
| SB14 | R11g | R12 | Uskladiti namenski proof build sa plugin/patch zahtevom i current repo/workflow; svako dokazno izvršenje vezati za runId/source/input/checks. Osvežiti samo pogođene istorijske harness-e i stroge završne uslove. |
| SB15 | R11c | R06 | Definisati jedan kanonski payload za claim i complete uključujući photo-only tekst i attachment identity; primeniti ga na obe strane bez isključivanja hash provere. |
| X01 | R11c | — | Za nevalidan lokalni identitet obezbediti konkretnu kontrolisanu obnovu sa proverom/objašnjenjem i čišćenjem samo korumpiranog lokalnog zapisa; za validan unknown zadržati server reconciliation. |
| X02 | R11d | — | Naći jedan postojeći autoritet ili uvesti usku trajnu/revision-aware koordinaciju dve stvarne promene, tako da se posle mount-a prepozna i razreši delimičan ishod. |
| X03 | R11f | — | Na servisnoj granici validirati finite vrednosti i sva polja potvrđenog receipt-a; klijentskim potrošačima garantovati jedinstven tačan tip. |
| X04 | R11f | — | Povezati sve read/stream/resolver potrošače na jedan eksplicitni config owner sa istim permitted fallback/required-env pravilom i proverom build-a. |
| X05 | R11h | — | Izolovati početni fixture i pri reset-u obnoviti sve mutable kandidate i povezane kolekcije. |
| X06 | R11c | — | Proveriti account+revision neposredno pre objave potvrđenog toast-a, u postojećem lifecycle owner-u. |

### Tačne putanje vlasnika i dokaznih ulaza po zadatku

Ovaj indeks uključuje runtime vlasnike, konfiguraciju, migracioni izvor i odabrani dokazni ulaz. Proof putanja nije zato proglašena aktivnim runtime vlasnikom. Z10 uz svaku vezu čuva simbol/opseg, SHA i nivo dokaza; postojeći test ostaje neizvršen u ovoj etapi.

| Zadatak | Putanje |
|---|---|
| R01 | `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql`; `supabase/proofs/discovery/p6_http_boundary.mjs` |
| R02 | `src/app/(app)/zadaci.tsx`; `src/data/discoveryV1ClientTransport.ts`; `src/data/discoveryV1MarketplaceAdapter.ts`; `src/data/discoveryV1Owner.ts`; `src/data/discoveryV1ScreenSession.ts`; `src/data/discoveryV1SearchOwner.ts`; `src/data/focusedResource.ts`; `src/ui/system/StateView.tsx`; `src/ui/v2/DiscoveryPresentation.tsx`; `src/ui/v2/detail/useTaskFit.ts`; `src/ui/v2/discovery/DiscoveryV1Screen.tsx`; `src/ui/v2/discovery/recentSearches.ts`; `supabase/migrations/20261025000000_baseline_core_client_rpcs.sql` |
| R03 | `src/data/needClientService.ts`; `src/data/ownTasksPage.ts`; `supabase/migrations/20261025000000_baseline_core_client_rpcs.sql` |
| R04 | `supabase/functions/_shared/backgroundTaxonomyArchitect.mjs`; `supabase/functions/_shared/classificationGeminiShadow.mjs`; `supabase/functions/_shared/serviceExecutionInstruction.mjs`; `supabase/functions/_shared/workerServiceModeContext.mjs`; `supabase/functions/uskoci-worker-interview/index.ts`; `supabase/migrations/20261013193000_uskoci_needs_category_sync_trigger.sql`; `supabase/migrations/20261019104047_taxonomy_parent_navigation_and_mode_admission.sql`; `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql` |
| R05 | `src/contracts/workerAreas.ts`; `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql`; `supabase/proofs/match_category_fallback/live-candidate-stream.sql` |
| R06 | `supabase/functions/_shared/backgroundTaxonomyArchitect.mjs`; `supabase/functions/_shared/geminiTaskStream.ts`; `supabase/functions/_shared/taxonomyPostSaveWorker.mjs`; `supabase/functions/_shared/taxonomyProviderBudget.ts`; `supabase/functions/uskoci-ai-interview/index.ts`; `supabase/functions/uskoci-speech-session/index.ts`; `supabase/functions/uskoci-speech-session/proxy.ts`; `supabase/functions/uskoci-worker-interview/index.ts`; `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql` |
| R07 | `src/app/(app)/pregled-zadatka.tsx`; `src/app/(app)/prilike/[id]/prijava.tsx`; `src/contracts/projections.ts`; `src/data/aiTaskReviewClientService.ts`; `src/data/applicationClientService.ts`; `src/data/workerProfileClientService.ts`; `src/hooks/useOwnedEditor.ts`; `src/ui/objava/reviewFacts.ts`; `supabase/functions/uskoci-ai-interview/index.ts`; `supabase/proofs/ai/currency_correction_characterization.test.mjs` |
| R08 | `src/app/(app)/profil/razgovor.tsx`; `src/data/__tests__/ai-natural-server-guard.test.ts`; `src/data/workerAiClientService.ts`; `src/hooks/useWorkerExecutionModes.ts`; `src/ui/workerProfile/WorkerAiPresentation.tsx`; `src/ui/workerProfile/WorkerProfilePresentation.tsx`; `src/ui/workerProfile/WorkerProfileSaved.tsx`; `supabase/functions/uskoci-ai-interview/index.ts`; `supabase/functions/uskoci-worker-interview/index.ts` |
| R09 | `src/app/(app)/profil/obavestenja.tsx`; `src/ui/AgreementChat.tsx`; `src/ui/notifications/PushPreferences.tsx`; `supabase/functions/_shared/pushNotificationCopy.mjs`; `supabase/functions/uskoci-push-transport/index.ts` |
| R10 | `src/app/(app)/profil/pravna.tsx`; `src/ui/legal/legalReview.ts`; `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql` |
| R11 | `.github/workflows/ci-clean.yml`; `app.config.js`; `scripts/check-eas-preview.cjs`; `scripts/verify-native-patches.cjs`; `src/app/(app)/index.tsx`; `src/app/(app)/moje-prijave.tsx`; `src/app/(app)/nova.tsx`; `src/app/(app)/profil/fotografija.tsx`; `src/app/(app)/profil/ocene.tsx`; `src/app/(app)/profil/podaci.tsx`; `src/data/agreementVoiceClientService.ts`; `src/data/aiNeedV2Production.ts`; `src/data/applicationClientService.ts`; `src/data/authAvailabilityClientService.ts`; `src/data/lazniIzvor.ts`; `src/data/productionLocationResolver.ts`; `src/data/ru4Production.ts`; `src/data/serverReceipt.ts`; `src/data/supabaseClient.ts`; `src/features/voiceMessages/voiceMessageComposer.ts`; `src/ui/agreements/AgreementActionsPresentation.tsx`; `src/ui/agreements/AgreementActionsScreen.tsx`; `src/ui/agreements/agreementActionsModel.ts`; `src/ui/agreements/agreementListModel.ts`; `src/ui/entry/EntryWelcome.tsx`; `src/ui/home/HomePresentation.tsx`; `src/ui/location/LocationPointEditor.tsx`; `src/ui/location/ResolvedPinMap.tsx`; `src/ui/profile/ProfilePhotoPresentation.tsx`; `src/ui/profile/writeWorkName.ts`; `src/ui/reviews/ReviewCommentField.tsx`; `src/ui/reviews/ReviewCommentsSection.tsx`; `src/ui/reviews/useGivenRatings.ts`; `src/ui/reviews/useReceivedReviews.ts`; `src/ui/safety/SafetyScreen.tsx`; `src/ui/safety/blockOutcome.ts`; `src/ui/support/SupportDetailScreen.tsx`; `src/ui/support/SupportNewScreen.tsx`; `src/ui/support/useSupportController.ts`; `src/ui/system/PublicProfileSheet.tsx`; `src/ui/v2/ApplicationComposerPresentation.tsx`; `src/ui/v2/DiscoveryPresentation.tsx`; `src/ui/v2/MyApplicationsPresentation.tsx`; `src/ui/v2/discovery/mapControls.ts`; `src/ui/v2/draftSummary.ts`; `supabase/functions/uskoci-ai-interview/index.ts`; `supabase/functions/uskoci-media/index.ts`; `supabase/migrations/20260913044510_clean_v5_unknown_ai_turn_exit.sql` |
| R12 | `app.config.js`; `eas.json`; `supabase/migrations/20261021101527_staged_task_replacement_noop_guard.sql`; `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql` |


### Granica detaljnosti plana i odluke

Matrica zatvara mapiranje svih nalaza prema imenovanim vlasnicima i potrebnim proverama. Ne proglašava svaki red budućeg patch-a unapred ispravnim niti svaki ekran finalno dizajniranim. R08/R11 zahtevaju specifikaciju stanja, podataka, radnji, copy-ja, povratka i mobilnih uslova pre zatvaranja UI zadatka. R12 tek dokazuje stvarni objavljeni ugovor, model i uređaje.

R07b ima materijalnu poslovnu granicu HOURLY osnovice. Deo R05 ima materijalnu granicu područja za rute/više lokacija. Predložena rešenja u odluci ostaju predlozi, uz pozitivne primere i jasno navedene nezavisne zadatke koji mogu napredovati. Dodatna valuta i cityless REMOTE nisu obavezni deo poznate popravke. Izbor AI puta i uklanjanje dokazano mrtvog helper-a su inženjerski posao unutar važeće namere.


## 10. Kontrola prenosa prethodnih analiza

Ova tabela objašnjava gde je ranije znanje ugrađeno. To nije ponovna nezavisna potvrda svake istorijske tvrdnje; važeći nivo dokaza, kasnije ispravke i poslednji izvor određeni su iznad.

| Raniji analitički deo | Mesto u ovom paketu | Šta je usklađeno |
|---|---|---|
| Početni AI/client izveštaj i source delta | F02–F13; vlasnici u odeljku 2; čišćenje u 7 | Stare mode/schema/fallback dijagnoze koje je noviji izvor promenio nisu vraćene kao sadašnji kvarovi. |
| Semantički pregled celog aktivnog app/data/UI i SQL istorije | F01–F07/F13/F14, SB01–SB15, X01–X06; registar | Sačuvani konkretni uzroci, cleanup obrazloženja i razlika izvora, živog tela i uređaja. |
| Dopuna analize testova i ugovora | Odeljak 8 i istorijski detalji postojećeg registra | Vraćene konkretne rupe smoke/source/mock provera; nema tvrdnje da su ti testovi ponovo izvršeni ili popravljeni. |
| Dubinski requester/worker/server pregled | F01–F14, vlasnici i A01–A18 | Sačuvani Save+activate izbor, pending/readback granice, cena, trajni nastavak i korisnički smisao. |
| Klasifikaciona namera, mapa i tri dostavljena snimka | F05–F08, F15–F17, A19–A21 | Ranija nepoznanica mape precizirana konkretnim P6/server neskladom; nije izmišljena per-device korelacija. |
| Raniji završni uslovi dostupnosti i privatnosti | A22/A23 i Codex završni paket | Vraćeni konkretni prihvatni scenariji; nisu proglašeni novim kvarovima ili obaveznim formularima. |

**Provera registra:** 297 UI +254 data +51 data/UI +9 UI/backend zapisa, ukupno 611 poređenja, ima odgovarajuću putanju i doslovno sačuvano izvorno obrazloženje; nema izgubljene putanje ili obrazloženja u tom skupu. To nisu jedinstvena nova čitanja niti provera svake rečenice starih izveštaja. Dodatno su sačuvani detalji ranijih backend/data test evidencija tamo gde je ranije ostala samo namena ili odluka.

**Šta je dopunjeno pri ovoj kontroli:** F03 price-display dokaz; F05 Need trigger/worker rename-sync; F07 transport, potpunost i STT obračun; F14 povučena price-basis sumnja, grant/provenance i konkretni bootstrap uslovi; SB14 granice samih dokaza; A22/A23; precizne veze ka odluci po fajlu. Svi ti delovi uneti su u postojeće dokumente i isti završni paket. Nije napravljen novi konkurentski izveštaj.

Glavni PDF/Markdown daje celovitu čitljivu sliku. Ova referenca i jedinstveni registar sadrže više detalja za izvršenje i proveru; ceo ZIP je predaja Codexu. Aplikacioni source, deployment i poslovni podaci nisu menjani. Budući izvor se ponovo proverava prema novom HEAD-u; paket nije automatski živi nadzor repozitorijuma.

### Završni prenos bez novih korisničkih dopuna

Z01–Z08 i jedinstveni registar dopunjuju iste dokumente. Ranija obrazloženja i korekcije nisu prepisana generičkim FULL statusom. Root328, originalni client549, candidate/proof scope-ovi i njihovi transferi računaju se po jednoj putanji; 680currentbody i99binary su odvojene dimenzije. Potpunost čitanja je završena na ovom source snapshot-u. Potpunost proizvoda ostaje dokaziva tek imenovanim implementacionim i runtime/device prolazima.

Revizija 4 ugrađuje nameru i testnu selekciju u iste dokumente. Prethodni A01–A23 ostaju, A24/A25 su regresione granice, a ne nove grupe kvara. Detaljan J01–J14 trag je u Z09; izvršni sažetak je u planu.

Revizija 7 je pročitala i usaglasila sva tri završna dokumenta, izvršila dodatni serverski pregled i dodala Z11–Z16 u isti paket. Istorijski rezultati i povučene sumnje ostaju istorijski; novi agregati/definicije/ograničenja imaju svoje vreme i metod. Nema izvršene aplikacijske popravke, nove model/device provere ili automatske deletion allowlist-e.

## 11. Usaglašavanje jedinstvenog plana i preciznost završnih uslova

Z19 beleži reviziju 10: priloženi objedinjeni plan, naš poslednji rev9 plan, stvarno primenjene korekcije, punu mapu dokaza i završnu proveru prenosa. Njihove organizacione prednosti su objedinjene; ne postoje dva aktivna plana. Svih 14 SV grupa sada je čitljivo razrađeno i u operativnom §7.3, a izvorni Z16 i ostali registri ostaju u ZIP-u.

Z17 čuva ranije ulazne SHA-256 otiske dostavljenog MD/PDF-a, svih polaznih rev7 dokumenata, semantički crosswalk 42 nalaza / 19 C / 14 SV i odluke o dopuni. Z18 sadrži ciljano pročitane izvorne vlasnike i granice izdanja. U ovoj etapi nije pokrenut novi Supabase audit, model, aplikacioni test, build ili deploy. Poslednji živi serverski dokaz ostaje Z11–Z16 iz revizije 7; njihovi interni document hash-evi identifikuju tadašnju reviziju. Najnoviji MANIFEST identifikuje sadašnje datoteke.

### 11.1. Ishod kontrole potpunosti

| Skup | Provereni odnos | Rezultat i granica |
|---|---|---|
| F01–F21, SB01–SB15, X01–X06 | Nalaz → tačan vlasnik → R zadatak → potreban dokaz. | Sve 42 grupe imaju mesto; F03 current acceptance je ispravljen zbog neodobrenog EUR značenja. |
| C01–C19 | Tačna jedinica povlačenja, sačuvani deo, caller/test/build prevezivanje. | Svih 19 ostaje; C06 je jedan it-blok, C11 čuva istorijsku zabranu PHONE, C17 usklađuje selekciju, C19 čuva primenjenu istoriju. |
| SV01–SV14 | Fizički objekt, zavisnosti, zamena, kompatibilnost, redosled i pozitivni/negativni uslovi. | Svih 14 ostaje; SV08 čuva revokacije/receipt istoriju, SV10 razlikuje sedam no-PK kopija od zasebne KEEP reset arhive. |
| Rev8 §7/8 | Oblasti i obrazac radnje naspram stvarnih ruta i ekran-stanja. | Usvojeno kao obavezan izlaz R08/R11/R12; nije proglašeno završenom inventurom ili dizajnom. |
| Rev8 §13–15 | Izdanje i operativa naspram stvarnih build/native ograničenja. | Razrađeno kroz R12a–j; pojačano konkretnim preview-only i Android-only source dokazima. |
| Oba rev9 plana → rev10 | Organizacija priručnika, preciznost radnji, punih 14 SV zapisa i svi dokazni prilozi. | Jedan plan, 20 oblasti i 16 polja radnje; izvorna pokrivenost i važni detalji ostaju sačuvani. |

Nijedan od ovih brojeva nije dokaz da je svih 912 uslovnih retirement putanja spremno za brisanje. Revizija 8 izričito traži očuvanje starog detaljnog plana i ne ponavlja sve njegove pojedinosti. Pravilno je integrisana, a ne upotrebljena kao zamena koja bi izbacila C/SV/testne uslove.

### 11.2. Preciznost korisničkih potvrda

- **Requester:** `src/data/aiTaskReviewClientService.ts` čuva isti prepare/accept digest za SaveDraft i Publish; Publish dodatno prolazi evaluate/publish. Potvrda PUBLISHED uključuje tačan command status, published status, ALLOW i isti Need/reviziju; ruta pregleda dodatno proverava readback. ACCEPTED/EVALUATING/EVALUATED/UNKNOWN nisu objava. Tačne opsege i SQL granicu čuva [AI/UX crosswalk](dokazi/provera_plana/ai_ux_review.json).
- **Worker:** `src/data/workerAiClientService.ts` u prepare vezuje activate. `rpc_save_worker_ai_review` upisuje profil/lokaciju/dostupnost i traženu aktivaciju u jednoj transakciji, pa tek zatim završava razgovor i receipt. `rpc_complete_worker_profile` ponovo baca grešku; ne postoji nezavisan potvrđen Save koji bi u ovom istom pozivu preživeo neuspelu aktivaciju. Za activate=true decoder traži ACTIVE. ACK može biti izgubljen posle uspeha, što traži readback iste komande.
- **Requester izbor:** postojeći `session.pending`, frozen payload, stabilan ključ i `readSelectedAgreement` ostaju. Worker journal ne preslikavati kao drugi requester writer bez potrebe. Dodatno dokazati kapacitet i uslove prema domenu.
- **AI UX:** ne menjati pravilo „nema parcijalnih kartica” u „nema obaveznih parcijalnih kartica”; AI persiranje ostaje usklađeno sa instrukcijom. Kanonski identitet i BOTH/handoff pravila imaju prednost nad primerom skraćenog teksta.
- **F03:** trenutni izvršni cilj je uklanjanje stale potvrde i ispravan nastavak u postojećem cenovnom ugovoru. Izolovana EUR korekcija reprodukuje kvar; ne odobrava novu valutu. Prethodno pogrešan acceptance ostaje u istoriji Z10, a važeća projekcija više ne protivreči R07a.
- **R09:** idempotentni događaj/receipt nije tvrdnja o exactly-once fizičkoj dostavi. Izgubljen provider ACK, nezavisne preference, authorization i stvarni tap ostaju zasebni scenariji.

### 11.3. Stvarni vlasnici pripreme izdanja

| Izvor / vlasnik | Pročitana granica | Konkretna obaveza u planu |
|---|---|---|
| `scripts/build-contract.cjs`; `app.config.js` | Production profil ili OTA target se bezuslovno odbija; DEV ugovor čuva tačan URL i potrebne zastavice. | R12c uvodi odvojene proverene profile i dozvoljene kombinacije, uz negativne kontrole; R12b obezbeđuje backend. |
| `package.json`; `scripts/check-eas-preview.cjs`; `eas.json` | EAS preinstall ide kroz validator koji podržava samo Android preview, tačan projekat/package/runtime i Firebase preview ugovor. | R12c ne uklanja validator, već usklađuje hook i validatore svih namerno podržanih profila/platformi. |
| `app.json`; `app.config.js` | Nema konfigurisanog ios.bundleIdentifier; production package grana ne znači da je production build dopušten. | R12e identitet/signing/capabilities; R12c Firebase/APNs/OTA prema stvarnoj platformi. |
| `src/features/voice/useHoldToTalk.ts`; `src/features/voice/nativeSpeechAdapter.ts`; `src/features/voice/expoPcmCapture.ts`; `modules/uskoci-voice/expo-module.config.json` | Aktivni AI capture inicijalizuje se samo na Androidu; iOS daje unavailable. Alternativni Expo PCM put takođe je Android-only. | R12e dovršava i dokazuje iOS AI govor za puni opseg; ne prenositi taj nalaz automatski na odvojene Dogovor glasovne priloge. |
| Android/Expo config i native artefakt | U pregledanom praćenom izvoru nema eksplicitnog targetSdk/compileSdk dokaza. versionCode 36 je drugi podatak. | R12d dokazuje resolved/native manifest i stvarni dostavljeni AAB; 16 KB/native zavisnosti i dozvole proverava na artefaktu. |

Z18 daje pune stvarne putanje, opsege, hash-eve, postojeće proverne ulaze i predlog pozitivnih/negativnih scenarija. Testove ne izvoditi iz imena niti pisati drugi validator samo radi zelenog testa. Kod odobrene implementacije sačuvati uspešan preview tok, dodati dozvoljeni production/iOS slučaj tek uz njegov ugovor i odbiti pogrešan backend/profil/platformu/kanal/paket. Nije izvršena izgradnja niti je potvrđeno da postojeći native artefakt ispunjava nove store uslove.

Postojeći konkretni testni ulazi su `src/data/__tests__/pkg002-app-config.test.ts`, `src/data/__tests__/build-identity.test.tsx`, `src/data/__tests__/ex04-test-page-limit-guard.test.ts`, `src/data/__tests__/native-push-device.test.ts`, `src/features/voice/__tests__/nativeSpeechAdapter.test.ts` i `src/features/voice/__tests__/holdToTalk.test.ts`. Zadržati odgovarajuće aktivne provere iz `.github/workflows/ci-clean.yml` i `scripts/verify-native-patches.cjs`. Proširiti postojeće vlasničke testove za konkretan promenjen rizik; mali novi izvršni config-contract test opravdan je samo ako postojeći ulazi ne mogu da provere pozitivnu i negativnu matricu. Test sa mock native portom nije FCM/APNs ili iOS mikrofon dokaz.

Produkcioni Android push traži svoj Firebase/FCM identitet: `app.config.js` čuva Google services samo za preview package, a preview validator zahteva njegovog tačnog klijenta. Namenski proof/inert plugin nesklad ostaje SB14/R11g. Z18 povezuje i spoljne mape (`src/ui/location/ResolvedPinMap.types.ts`, `src/data/productionLocationResolver.ts`), email/redirect, javne linkove, kvote modela i operativne vlasnike. Njihov source put nije potvrda udaljene konfiguracije ili dostupnosti; operativni plan §6, R12 i §10 zahteva konkretan owner/status/datum/dokaz.

### 11.4. Izvori prodavnica i njihovo ograničenje

[Politike izdanja](dokazi/provera_plana/release_policy_sources.json) beleže zvanične URL-ove, datum, kratku proverenu tvrdnju i neproverenu lokalnu primenljivost. Operativni plan §10 povezuje ih sa stvarnim izlazima; §12 određuje gde su dokazi u paketu. API/SDK zahtev nije dokaz trenutne konfiguracije, nalog izdavača nije pregledan, a prolaz kroz zatvoreno testiranje ili pripremljen paket nije odobrenje prodavnice. Pri predaji ponoviti relevantnu proveru pravila. Nova dokumentaciona provera ne menja vremenski domet prethodnih živih dokaza.
