# USKOČI — objedinjeni izveštaj o stanju i plan dovršavanja

**Datum:** 27.10.2026.  
**Revizija dokumentacije:** 10 — objedinjena oba rev9 plana, precizirani postojeći zadaci i vraćena puna dokazna podloga u jednu predaju. Poslednji potpuni živi serverski pregled ostaje vremenski označen revizijom 7; ova revizija nije novo izvršenje aplikacije ili baze.  
**Repozitorijum:** `uskocibusiness-boop/USKOCI-EAN`  
**Grana:** `feature/uskoci-cisto`  
**Analizirani trenutni izvor:** `a9692e11942609bab9406215c3e407d79589dafa`  
**Izvor prikazan na telefonu:** `fcef803e719ba5663f6cfd8fbd5a601e08a3479b`  
**Obim:** svih 3.335 praćenih tekstualnih fajlova, 99 binarnih resursa, tri korisnikova snimka, svih 680 trenutnih public/private funkcija i dve dodatne RLS pomoćne funkcije, aktuelni izrazi/prava baze, svih 15 Edge paketa, operativni agregati DEV-a, kontrolisane lokalne probe i razrađen plan završavanja. Bez izmene aplikacije, poslovnih upisa, stvarnog AI poziva, migracije ili objave.

Ovo je **jedan važeći objedinjeni izveštaj**. Prethodni nalazi i nove provere ugrađeni su u odgovarajuća poglavlja; ne postoji zasebna dopuna koju treba čitati da bi se saznao drugačiji zaključak. `CODEX_PLAN_RADA.md` služi izvršavanju budućih odobrenih zadataka, a `TEHNICKI_DOKAZI.md` proveri vlasnika koda, scenarija i granica dokaza. PDF i ovaj tekst su dva formata istog izveštaja. Jedinstveni operativni plan takođe ima MD i PDF sa istim sadržajem; nalazi i istorijski dokazi ostaju povezani kroz isti ZIP.

## 1. Glavni zaključak jednostavnim jezikom

**Dubinski pregled praćenog sadržaja sada je dovršen. Glavni problem je u vezama između delova sistema: ono što razgovor razume, pregled potvrdi ili profil sačuva ne dolazi uvek nepromenjeno do sledećeg koraka.** Zato je moguće da pojedinačna funkcija radi i da test bude zelen, a da čovek na telefonu ostane bez mape, izgubi spreman pregled ili ne dobije odgovarajuću priliku. To ne zahteva novu aplikaciju od početka; zahteva precizno dovršavanje sadašnjih vlasnika i dokaz celih tokova. [E32] [E40] [E41] [E43]

**Slike su omogućile da se problem sa mapom veže za konkretnu neusklađenost aplikacije i servera. Istovremeno je produbljena AI analiza pokazala da sistem može izgubiti upotrebljivost već uspešne klasifikacije tokom sasvim običnog nastavka razgovora.** To su dva odvojena problema; oba zahtevaju dovršavanje veze između postojećih delova sistema. [E26] [E27] [E30]

Prikazani izvor i kontrole na telefonu upućuju na P6 put, čiji kod traži podatke za mapu. Objavljena funkcija prihvata listu zadataka, ali ne prihvata zahtev za mapu. Vraća `P6_MODE_NOT_IMPLEMENTED`. U pregledanom prozoru server je zabeležio pet takvih grešaka. Ekran zatim prikazuje savet o internetu, uklanja mapu i u pola otvorenog panela smešta veliku poruku čiji donji deo prekriva navigacija. To daje konkretno objašnjenje sklopa problema sa slika. Agregirani zapisi nisu povezani sa pojedinačnim zahtevom tog telefona; datum i vremenska zona fotografija nisu očitani iz metapodataka. [E26] [E27] [E28]

Kod AI-ja pronađen je još važan uzrok zabune oko „oporavka”. Za novi profil izvršioca klasifikacija može već postojati. Sledeća poruka, čak i „to je to” koja ne menja sadržaj, podigne reviziju razgovora. Pregled više ne prepoznaje prethodni rezultat kao važeći, dok se klasifikator ne pokreće ponovo jer se usluga nije promenila. U izolovanoj probi sa stvarnim funkcijama kandidat je ostao isti, broj odgovarajućih hintova pao je sa dva na nulu i pregled je završio u `REVIEW_REQUIRED`. Model u tom scenariju nije morao ništa pogrešno da razume. [E30]

Druga proba je potvrdila da izričito tražena ponuda **na lokaciji i na daljinu** može dobiti samo jedan uspešan predlog i ipak postati `READY` za taj jedan način. Nedostaje provera celog traženog skupa. To je dokaz nedostatka između komponenti, bez tvrdnje da je takav profil zaista sačuvan na korisnikovom telefonu ili da je preskočena njegova završna potvrda. [E30]

**USKOČI ima razvijenu osnovu i nema razloga za prepisivanje od početka.** Postoje razgovori obe uloge, pregledi, čuvanje i objava, prijave, Dogovori, poruke, revizije, stabilni identiteti pokušaja i zaštite od tuđeg ili zastarelog rezultata. Proverom ostalih funkcija iz iste serverske migracije pronađeno je devet usklađenih ugovora, jedan već poznat blokirajući nesklad za „Moji zadaci” i jedan izostao opcioni podatak. Nije sve pokvareno i vraćanje celog starog paketa bi ugrozilo dobre novije delove. [E01] [E02] [E03] [E31]

Završno čitanje je dodalo četiri povezane grupe problema. Radnik može ispasti iz izbora pre provere sačuvanog područja ili raspoloživosti kasnije istog dana; područja izostaju iz nekih izvoznih i arhivskih projekcija; red za push i otvaranje odredišta nisu potpuno usklađeni. Posebno, sadašnja dozvola za čitanje cele tabele zadataka ponovo otvara tri ranije zaštićene kolone prijavljenom korisniku za tuđe javno vidljive zadatke u istom svetu naloga. To poslednje ima prioritet u prvom paketu. Nalazi su zasnovani na izvoru, aktuelnim definicijama i dozvolama, bez čitanja tuđih poslovnih podataka i bez tvrdnje o zabeleženom incidentu. [E41] [E45]

Glavni radovi sada su dovoljno precizno određeni za Codex: uskladiti klijent i server; sačuvati značenje i celovitost AI rezultata; povezati područje rada sa stvarnim izborom; zatvoriti cenu i neizvesne radnje; dovršiti razgovore, ekrane, obaveštenja i život podataka. Plan imenuje šta sačuvati, šta promeniti, šta prekodirati u postojećem vlasniku i šta kontrolisano povući. Kriterijum završetka je stvaran posao obe uloge na poznatoj verziji aplikacije, uključujući prekide, ispravke i proveru krajnjeg rezultata.

Nastavak provere povezao je 14 stvarnih korisničkih tokova sa svih 12 radnih zadataka. Za svaki su određeni postojeća dobra osnova, nedostajuća veza, vidljiv cilj i potrebna provera. Proveren je i stvarni izbor testova u CI-ju: neki postojeći zeleni testovi namerno reprodukuju kvar ili proveravaju samo tekst instrukcije. Zato plan sada izričito kaže šta sačuvati, šta popraviti u samom testu i koji dokaz nedostaje. Ovo je ciljana ponovna provera već pročitanog izvora, bez novih aplikacionih testova ili upisa. [E47]


Završna provera izvršivosti u reviziji 5 proverava sva tri dokumenta kao jedan plan. Svih 42 oznake nalaza (21 F, 15 SB i šest X) povezane su sa R01–R12; široki R11 dobija imenovane podzadatke. Čišćenje ima normalizovan indeks svih 3.434 putanje i konkretne pakete povlačenja sa uslovima. To nije bezuslovna lista za brisanje niti gotov vizuelni nacrt svakog ekrana. Dve uske poslovne granice izdvojene su od tehničkih odluka: značenje satnice i područje za poslove sa više lokacija. [E48]

**Završni Supabase pregled u reviziji 7 je stvarno izvršen.** Potvrđeni su važeći server ugovori, pročitani tekući izrazi i prava, preuzeti svi Edge paketi i povezani raspored, redovi, mediji, događaji i život podataka. Najvažniji novi nalaz za AI: ceo katalog trenutno postoji, ali tekst koji se pravi za klasifikator ne prikazuje verno roditeljske veze. Keš se proverava tek posle ponovnog punog preuzimanja. Plan zato prvo popravlja sadržaj i očuvanje odluke, zatim uklanja nepotreban rad i tek uz merenje uvodi provider cache. [E49] [E50] [E51] [E52]

Isti pregled razlikuje zdrave delove od otvorenih uslova: zakazani SQL poslovi rade, ali spremnost push-a ima zastareo zapis; export/closure kontrole i dalje pravilno odbijaju nespremnu aktivaciju; više starih tabela još služi sadašnjim lifecycle pravilima. Pronađen je i precizan mali duplikat indeksa za uslovno uklanjanje. Jedinstveni serverski manifest sada povezuje objekte, 14 konkretnih grupa promena, njihove zavisnosti i dokaz završetka. [E52] [E53] [E54]

### Jedinstveni plan revizije 10 i usaglašena završnica

Revizija 10 koristi pregledniju organizaciju naknadno priloženog plana i preciznije tehničke uslove našeg poslednjeg paketa. Svih 42 nalaza i 19 paketa čišćenja sa 180 tačnih putanja sačuvano je; svih 14 serverskih grupa sada je čitljivo razrađeno i u glavnom planu, uz pune izvorne registre u istom ZIP-u. Zapis objedinjavanja pokazuje šta je preuzeto i kako je provereno. [E57]

Ranija dostavljena dopuna pravilno razlikuje tehničku analizu od dovršenog proizvoda. Izvorni paket jeste obuhvatio čitanje, uzroke i pravce popravke; nije tvrdio da su već završeni konačni nacrti svih ekrana, ponašanje svake radnje, provera telefona ili objava u prodavnicama. Ova razlika je važna i sada je preciznije prevedena u izvršan posao. [E55]

Ponovo su semantički ukrštene sve 42 grupe nalaza, 19 paketa čišćenja i 14 grupa serverskih promena. Sve imaju zadatak i sačuvane uslove u punom paketu. Ipak, pronađena je stvarna neusaglašenost: jedan stariji izvršni zapis za ispravku cene preširoko je tražio novu EUR činjenicu. Glavni plan je već pravilno čuvao važeći RSD/OFFERS domen. Zapis je sada usklađen: ne sme ostati stara potvrđena cena, ali nepodržana valuta ne postaje nova funkcija bez odluke. Raniji zapis i reprodukcija ostaju istorijski dokaz. [E55]

Najveća dopuna odnosi se na završavanje proizvoda. Operativni plan sada traži jednu matricu stvarnih ekrana, opis svake radnje i četiri nezavisna statusa: definisano, vizuelno razrađeno, implementirano i dokazano na izdanju. Dvadeset oblasti u objedinjenom planu služi kontroli potpunosti; to nije 20 novih ekrana ni tvrdnja da je matrica već popunjena. Razlika prema ranijih 19 predstavlja izdvojeno grupisanje područja i raspoloživosti, a ne nov dokaz o dodatnom ekranu. Dokaz za završnu celinu skuplja se tokom svakog zadatka, a zatim potvrđuje na jednoj poznatoj verziji. [E55]

Provera izdanja donela je konkretnije uslove nego samo „pripremiti produkcioni backend”. Sadašnje kontrole namerno odbijaju production i dopuštaju samo tačan Android preview. Nedostaje iOS bundleIdentifier, a aktivni AI unos govorom koristi Android-only capture. Za iOS treba dovršiti i proveriti tu funkciju ili izričito odlučiti o užem opsegu; ne sme se prećutno proglasiti spremnom. Glasovni prilozi u Dogovoru imaju zaseban put. Broj verzije Android izdanja 36 nije dokaz da je njegov target API 36. [E56]

U R12 su zato razrađeni profili i zaštite izgradnje, zasebni Android/iOS artefakti, privatnost i brisanje, testiranje dve uloge, predaja, javna objava i operativna briga. Uslovi prodavnica imaju zvanične izvore i datum provere. Ovo nisu izvršeni build-ovi niti novo odobrenje objave. Novi pregled ekrana i konačan opis svih korisničkih koraka ostaju jasno označeni budući izlazi. [E55] [E56]

Pri prihvatanju dopune očuvane su važne tehničke granice. Razgovor ostaje bez parcijalnih kartica. Objavu ne dokazuje samo isti ID zadatka. Sadašnji Save+activate izvršioca je jedna atomska radnja, pa nije uvedeno izmišljeno odvojeno stanje uspešnog čuvanja i neuspešne aktivacije. Isti requester pregled može podržati nacrt i objavu, dok worker activate mora odgovarati potpisanom pregledu. Dve poslovne odluke, satnica i više radnih lokacija, ostaju korisnikove. [E55]

Napomena spoljnog pregleda o 120 nedostavljenih dokaznih fajlova odnosi se na priloge dostupne tom razgovoru. U našem polaznom ZIP-u svih 125 sadržajnih fajlova plus manifest jeste bilo prisutno. Revizija 10 čuva sve prethodne dokazne putanje, uključuje originalne slike i pune registre, te dodaje trag objedinjavanja. Za nastavak treba predati ceo ažurirani ZIP. Stare verzije planova čuvaju se samo kao označeni ulazi; važeći redosled i zahtevi su u jednom CODEX_PLAN_RADA.md. [E57] [E55]

**Ovo je analiza, ne izveštaj o već izvršenoj popravci.** Aplikacioni izvor je ostao nepromenjen. Potvrđeni su konkretni uzroci i granice; konačan prolaz stvarnog modela, servera i telefona tek treba dokazati nakon odobrene implementacije.

## 2. Šta je stvarno pregledano i šta dokazi znače

### Izvor, telefon i server

| Predmet | Provereno stanje | Granica dokaza |
|---|---|---|
| Trenutni GitHub izvor | `a9692e11942609bab9406215c3e407d79589dafa`, grana `feature/uskoci-cisto` | Zaključci o ovom kodu ne znače da ga telefon ili Edge trenutno izvršavaju. |
| Izvor prikazan u aplikaciji | `fcef803e719ba5663f6cfd8fbd5a601e08a3479b`, commit od 22.10.2026. u 12:51:46 UTC | About ekran je dokaz prikazane oznake aktivnog izvora; nije izvučen ceo APK. |
| Razlika izvora | Trenutni izvor je 69 commit-a ispred prikazanog, bez zaostajanja | To ne znači 69 popravki. API spisak izmenjenih fajlova je ograničen; nije tvrđeno da je ceo taj delta pročitan. |
| Aplikacija i OTA | 1.0.0; runtime `uskoci-v1-preview-r1`; kanal `preview`; OTA prefiks `01a163c4` | Nisu očitani ceo native build identitet, sve efektivne zastavice niti pojedinačni mrežni zahtev telefona. |
| Referentni DEV | `leqcwgzvjsxugfgzdmth`, aktivan projekat | Read-only definicije, metapodaci i agregati; bez čitanja sadržaja korisničkih zadataka. |
| Objavljeni Edge | Svih 15 paketa preuzeto i pregledano: 69 pojava fajlova, 48 jedinstvenih sadržaja; NEED 151, WORKER 104, post-save 5 | Devet pomoćnih paketa odgovara izvoru; tri glavna paketa imaju razlike, a tri DEV dijagnostička endpoint-a su HTTP 410 stubovi. Runtime tajne/flagovi nisu čitani. |

Dokazi: identitet sa treće slike, GitHub ref/commit/compare, sveže definicije i ranije poređenje Edge sadržaja. [E24] [E26] [E29]

### Obuhvat čitanja bez dvostrukog brojanja

**Pregledano je svih 3.434 fajla praćenih na analiziranom commitu: 3.335 tekstualnih fajlova sa 626.320 redova i 99 binarnih resursa.** Za tekst je dovršen semantički pregled celog sadržaja: neposredno čitanje, identičan sadržaj ranije potpuno pročitanog izvora ili kompletan diff nad takvim izvorom. Strukturisani veliki registri provereni su u celini, uz čitanje značenja svih tipova i svih odstupanja; ugrađeni izvršivi payload-i su dekodirani. Sama pretraga, broj redova, parsiranje ili hash bez ranijeg potpunog čitanja nisu korišćeni kao zamena. [E32] [E44]

| Obuhvat | Dovršeno | Šta ta tvrdnja znači |
|---|---|---|
| Ranije potpuno pokriven tekst | 1.207 fajlova / 188.167 redova | Raniji dokaz je prenet samo uz odgovarajući sadržajni identitet i zadržane beleške. |
| Preostali tekst završen u ovoj etapi | 2.128 fajlova / 438.153 reda | Testovi, SQL kandidati, proof skripte, registri, korpusi, designLab i pomoćni sadržaj sada imaju dovršen pregled. |
| Sav praćeni tekst | 3.335 fajlova / 626.320 redova | Nema tekstualne putanje koja ostaje samo inventarisana ili delimično pročitana. |
| Binarni resursi | 93 slike i šest fontova | Ponovo dekodirani i vizuelno pregledani; 18 tekstualnih SVG-ova dodatno je rasterizovano i pregledano. |
| Aktuelne funkcije servera | 680 public/private tela, plus dve potrebne `rls_private` funkcije | Prethodnih 680 ima potvrđen sadržaj/definiciju/ACL i pun trag čitanja; dve dodatne definicije pročitane su cele. Nisu dodatni source fajlovi. |
| Korisnikove slike | Tri originalna snimka | Dokazuju prikazana stanja i identitet sa About ekrana; ne zamenjuju obilazak svih ekrana. |

Prethodno su već bili pokriveni svi 711 aplikacionih runtime fajlova bez testova/designLab-a, 52 Edge source/shared fajla i 193 SQL migracije. Završna etapa je zatvorila preostali obuhvat, a sačuvala obrazloženja ranijih pregleda. Raspodela među pregledima i transferi fajlova spojeni su po jedinstvenoj putanji i SHA-256; fajl koji je preuzeo drugi pregled nije brojan dvaput. Registar sadrži i svrhu, stvarne potrošače, preporuku i granicu dokaza, ne samo oznaku FULL. [E32]

Za server je 418 od 680 tela neposredno povezano sa identičnim već potpuno pročitanim izvorom. Preostalih 262 su završena direktnim čitanjem celog tela, potpunom razlikom ili proverom identičnog pročitanog payload-a. Pročitani su i aktuelni tokovi koji čuvaju potpisanu saglasnost, upis, retry, vreme, javnu privatnost i obradu poruka. **Pregled svih definicija nije izvršavanje svih funkcija.** Sveže površine tabela, ograničenja i grantova imaju posebno označen obim; ne proglašavaju se novim replay-em cele baze. [E40] [E45]

GitHub izvor ostaje isti. Novi osnovni presek svih 680 function body/definition/ACL otisaka je 27.10. u 14:14:12 UTC; sva tela su jednaka prethodno pročitanim. Zatim su preuzeti tekući izrazi, prava i dve `rls_private` definicije, uz nove operativne i kataloške agregate. Završno osveženje identiteta i tačni vremenski preseci su u E49–E54; ne proširuju dokaz na neproveren telefon ili poslovne redove.

| Dodatni serverski obuhvat revizije 7 | Stvarno pregledano | Granica |
|---|---|---|
| Struktura i izrazi | 167 aplikacijskih tabela; `storage.objects` i `realtime.messages`; devet sekvenci; 1.652 kolone tabela; 446 default/generated veza, 1.103 ograničenja, 91 politika i 173 trigger deklaracije | Jedinstveni izrazi pročitani su sa svim vezama: 65 default/generated i 703 constraint definicije. Nema aplikacijskih view-a ili enum/domain tipova u pregledanim šemama. |
| Prava i identitet | Efektivni ACL 169 tabela i 680 public/private funkcija; dve dodatne RLS funkcije; schema/role/default prava i relevantan Auth/session kod | Data API closure hook je stvarno vezan. Potpuna Auth management konfiguracija nije dostupna kroz postojeći pristup. |
| Edge | Svih 15 objavljenih paketa: 48 jedinstvenih sadržaja | 36 identičnih prenosa iz punog čitanja, sedam punih semantičkih diffova, dve razlike samo u završecima redova i tri cela kratka stub-a. To nije njihovo poslovno izvršavanje. |
| Mediji i događaji | Tri privatna bucketa, 12 Storage politika, osam publication stavki i stvarni klijentski potrošači | Samo jedna publication tabela je aplikacijski agreement ID/revision hint; preostalih sedam su servisne Realtime particije. |
| Pozadinski tokovi | Tri minute cron posla, sedmodnevni agregati i šest lanaca od proizvođača do potvrde/čišćenja/potrošača | SQL uspeh, HTTP odgovor, provider potvrda i dostava na telefon imaju različito značenje. |
| Indeksi i zavisnosti | Strukturisan katalog 364 indeksa na 167 tabela; 6.168 kataloških dependency veza; funkcijski i source pozivni kandidati | Nije izmeren svaki indeks pod produkcionim opterećenjem niti je dobijen savršen graf dinamičkih poziva. Jedan tačan redundantni indeks ima poseban dokaz. |

Dokazi: E49–E54. Brojevi iz različitih slojeva se ne sabiraju kao novi jedinstveni fajlovi ili nezavisni testovi.

Ova tvrdnja o potpunosti odnosi se na praćeni sadržaj tačno navedenog commita. Ne obuhvata svaku istorijsku verziju svakog fajla, nedostupan originalni Downloads masterplan, neizvučen APK ili sve efektivne OTA vrednosti. Broj route fajlova takođe nije broj fizički pregledanih ekrana. To su odvojene granice dokaza.

### Izvršene provere iz prethodnih etapa i njihove granice

| Dokaz | Rezultat | Šta on potvrđuje |
|---|---|---|
| Ranija objedinjena etapa | 10 Jest suite-ova, 873 slučaja PASS; četiri server paketa 40 + 16 + 5 + 10 PASS | Aktivne rute i moduli sa kontrolisanim servisima. Currency 10 uključuje roditeljski test i devet podtestova. Ne sabira se sa drugim repo tvrdnjama o ukupnim testovima. |
| Prethodni Discovery regresioni podskup | 4 suite-a, 63 slučaja PASS | Postojeće ponašanje sa simuliranim serverom koji podržava MAP; ne dokazuje sposobnost živog servera. |
| Tri nove analitičke karakterizacije | PASS | Reprodukovana razlika početne greške i retry prikaza, kao i MAP greška uz očuvane PAGE redove. PASS ovde znači da je kvar potvrđen. |
| Dijagnostika legacy čitača | Pet vrsta greške daje isti tekst `true` | Izvršen stvarni focused-resource modul sa sintetičkim greškama; odnosi se na sadašnji legacy put. |
| Stari i novi P6 dekoder | Osam sintetičkih kombinacija | Stari decoder odbija HOURLY i mešovitu stranu sa takvim redom; novi ga prihvata. Nije dokaz da je takav red bio na telefonu. |
| AI semantičke probe | Gubitak važenja posle praznog patch-a i nepotpun BOTH reprodukovani; pozitivne kontrole prolaze | Pravi builder i sveža živa SQL tela u izolovanoj memorijskoj bazi, uz kontrolisane pomoćne funkcije. Ceo signed prepare, Save, binder i telefon nisu izvršeni. |
| Sinonim i jednočlani naziv | Registrovani alias prolazi; nepokriven semantički reuse odbijen; `Sisanje` i `Sisanje kose` imaju različit triage | Konkretno ponašanje validatora i prijema. Nije merenje koliko često stvarni model daje takav odgovor. |
| Katalog, ranija proba | 202 → 200 čvorova, naknadno pun snapshot i dalje 200; preskočena neuspešna grana | Stvarni loader uz sintetički transport. Ne tvrdi se da je aktuelni katalog oštećen. |
| Živi Discovery ugovor i greške | Samo PAGE/EXACT_PUBLIC; pet `P6_MODE_NOT_IMPLEMENTED` u prozoru 06:40–06:56 UTC, 27.10. | Potvrđena serverska nekompatibilnost. Poklapanje sa satom slike pretpostavlja isti datum i zonu Beograda; nema korelacije sa jednim telefonskim zahtevom. |
| Ostalih 11 baseline RPC-ja | 9 statički usklađenih; 1 F01 nesklad; 1 izostao opcioni podatak | Pročitan ugovor i potrošači, bez poslovnog izvršavanja tih funkcija. |
| GitHub CI | Run 40452826819, a969, SUCCESS | Provereni metapodaci; puna ponovna analiza logova nije izvršena. |

Dokazi i tačan nivo provere nalaze se u E07, E20 i E26–E34. Ove ranije izvršene analitičke probe ne predstavljaju popravku; završna revizija nije ih ponovo pokretala. Skupovi testova mogu se preklapati, pa ne navodimo zbir kao broj nezavisnih potvrđenih korisničkih scenarija.

**Šta je završno čitanje testova razjasnilo:** postoje jaki dokazi stvarnih transakcija, zaključavanja, RLS-a i ponovljenih istih zahteva. Postoje i testovi sa simuliranim serverom, fixture-ima, starim telima ili završnim PASS-om koji ne zahteva da svi opisani podscenariji budu provereni. Svakom je zadržan stvarni domet. Ova etapa je čitala i ukrštala te dokaze; nije ponovo izvršavala njihove potencijalno destruktivne skripte. [E42] [E43]

**Nije potvrđeno:** fizički obilazak svih ekrana, stvaran novi razgovor sa Gemini-jem, puna service→SQL→Save→readback integracija svih slučajeva, ponovna izgradnja baze od praznog stanja, novo izvršavanje svih istorijskih testova, merene sadašnje latencije/troškovi ili potpuna bezbednosna sertifikacija. Ranijih 322 advisory stavke ostaje istorijski presek. Novi pregled ima 325 security i 136 performance stavki; one nisu 461 potvrđen kvar. U ranije obuhvaćenim aplikacijskim granicama nema nevalidiranih ograničenja. Prošireni pogled nalazi jedno NOT VALID pravilo na servisnoj `realtime.messages` tabeli; to nije dokaz aplikacijskog kvara ili nalog da se menja Supabase interna tabela. Indeksni metapodaci nisu merenje buduće produkcione brzine. [E35] [E44] [E49] [E50] [E53]

## 3. Šta slike otkrivaju o mapi i ekranima

### Šta se stvarno vidi

Prva slika prikazuje samostalni ekran greške sa vidljivim velikim tasterom „Pokušaj ponovo”. Druga prikazuje filter „Na lokaciji”, praznu belu površinu umesto mape i pola otvorenog panela sa istom velikom porukom. Donja navigacija prekriva deo objašnjenja; veliki taster nije u celosti vidljiv i nastavlja se ispod donje granice prikaza. **Mala ikona osvežavanja u zaglavlju ostaje vidljiva.** Treća slika daje izvor i OTA podatke navedene u poglavlju 2. Ne zaključujemo veličinu ekrana u dp, podešeni font ili tačan niz dodira iz samih slika. [E26]

![Slika 1 — početni prikaz greške sa velikim tasterom.](dokazi/slike/01-zadaci-greska.jpg)
![Slika 2 — bela površina mape i velika greška u HALF panelu; navigacija prekriva donji sadržaj.](dokazi/slike/02-mapa-panel.jpg)
![Slika 3 — prikazani izvor, runtime, kanal i OTA identitet.](dokazi/slike/03-identitet-aplikacije.jpg)

### Konkretan uzrok čitanja

U `eas.json` commita prikazanog na telefonu, preview i production profili uključuju P6 reader. „Za mene” kontrola na slici odgovara tom putu. Ruta tog izvora počinje lokalnim prikazom, adapter traži map seed, session izvršava PAGE pa MAP, a oba zahteva šalju se u `rpc_discovery_v1`. Potreba za MAP postoji i kada je PAGE uspešno prazan. Pročitani stari route, adapter, session, owner i transport potvrđuju ceo lanac; efektivne zastavice OTA sadržaja nisu izvučene. [E27]

**Živa funkcija ima samo PAGE i EXACT_PUBLIC. MAP i PLACES završavaju kao `P6_MODE_NOT_IMPLEMENTED`.** Njen whitelist filtera takođe ne prihvata `forMe` ni `minBudgetRsd`. „Za mene” na dostavljenoj slici nije izabran, pa nije potrebno pripisivati mu prvobitni pad. [E27]

U prozoru 27.10.2026. od 06:40 do 06:56 UTC Discovery endpoint ima šest odgovora 200 i pet odgovora 400. PostgreSQL ima pet `P6_MODE_NOT_IMPLEMENTED`, SQLSTATE `22023`, iz `rpc_discovery_v1` na tačnoj grani `RAISE` za nepodržani režim. Na slikama se vidi 07:51, bez datuma/zone, a JPEG-ovi nemaju EXIF podatke. **Ako su snimci od 27.10. i telefon prikazuje vreme Beograda, 07:51 odgovara 06:51 UTC, unutar tog prozora.** Nekompatibilnost je potvrđena nezavisno od te pretpostavke; agregati ne identifikuju korisnikov pojedinačan zahtev niti otkrivaju mode svakog odgovora. [E26]

Telo funkcije je bajtno jednako telu u `20261025000000_baseline_core_client_rpcs.sql`; ta verzija je u istoriji migracija. To identifikuje smanjenu implementaciju koja je sada objavljena. Ne izmišljamo tačan trenutak ili osobu koja je zamenila ranije telo. [E27]

Ova putanja čita objavljene zadatke i prostorne podatke. **U njoj se ne poziva klasifikacioni AI.** Zato bolje prepoznavanje usluge ne može popuniti nedostajuću podršku serverskog čitača. Ponavljanje istog odbijenog zahteva takođe ne dodaje MAP implementaciju.

### Kako greška postaje i loš prikaz

| Korak u kodu | Vidljiva posledica | Potreban ishod buduće popravke |
|---|---|---|
| `mapShown` zahteva da nema `error` | Greška podataka uklanja celu mapu i ostavlja belu podlogu | Odvojiti dostupnost geografske podloge, PAGE liste i MAP pinova. |
| Ista promenljiva određuje `compact` poruke | Kad nastane greška, poruka u panelu postaje velika | Veličina poruke treba da odgovara prostoru panela. |
| Početni loading/error bez zapamćene visine bira HALF | U stanju sa slike velika poruka ne staje odmah; zapamćena visina ima prednost nad ovim default-om | Jasna poruka i dostupna akcija u stvarno raspoloživom prostoru. |
| Navigacija se crta preko panela | Na slici prekriva donji sadržaj | Proveriti vidljivost i interakciju, ne samo broj bottom-padding-a. |
| Dugme „Moja lokacija” ostaje aktivno | Može tražiti lokaciju i spustiti panel dok mapa ostaje uklonjena | Lokacija mora dati smislen vidljiv rezultat i sačuvati objašnjenje greške. |

Ovaj odlučujući lanac postoji i u prikazanom starom i u sadašnjem izvoru. Noviji kod uklanja narandžasti plus i menja neke visine/navigaciju, ali zadržava `error → mapShown=false → compact=false`. Sama nadogradnja na najnoviji commit zato nije dokaz da su ove slike već popravljene. [E28]

### Zašto postoje dva prikaza iste greške

Prvo neuspešno otvaranje postavi error bez objavljenog screen snapshot-a, pa ruta prikaže samostalnu grešku. Retry koristi izvršavanje koje objavljuje snapshot i u `finally`, čak i kada ponovo zakaže. Tada se pojave filteri i panel sa greškom. Izolovani testovi reprodukuju oba stanja. Ne tvrde da je poznat stvarni sled korisnikovih dodira između dve slike. [E33]

Još jedan test pokazuje da MAP failure može postaviti globalnu poruku „Zadaci nisu učitani” dok snapshot i dalje ima svih 50 ispravno učitanih PAGE zadataka. Zato zajednički boolean ne opisuje dovoljno precizno šta je zaista dostupno. [E33]

### Šta znači da ekran treba „očistiti”

Ovde nije dovoljno promeniti boju, smanjiti ikonu ili ukloniti dugme. Potrebno je prvo uskladiti stanja: koji podaci su učitani, šta je privremeno nedostupno, gde je bezbedna sledeća radnja i koliko prostora postoji. Tek zatim imaju smisla dosledna tipografija, razmaci i manje vizuelnog viška.

„Proveri internet vezu” trenutno nije izvedeno iz provere uzroka i u ovom potvrđenom serverskom neskladu navodi na pogrešan trag. U sadašnjem legacy putu pokušaj dodavanja dijagnostike završava tekstom `true`, zato što je stvarna greška prethodno svedena na boolean. Potrebni su sačuvan tehnički razlog za dijagnostiku i kratka ljudska poruka za ekran, bez SQL detalja koje korisnik treba da tumači. [E34]

Sadašnji `eas.json` predviđa isključen P6 i izbor starijeg čitača. To može zaobići ovu funkciju, ali menja mogućnosti i način čitanja: nestaje P6 „Za mene”, a legacy obilazi kolekciju u stranicama od 200, do 25 strana, pod zajedničkim rokom. **Prebacivanje zastavice nije funkcionalno dovršena zamena za usklađen Discovery ugovor.** [E27]

## 4. Cela aplikacija: šta već postoji

| Oblast | Stvarno postojeća osnova | Najvažniji preostali rad |
|---|---|---|
| Ulaz, prijava i nalog | Sesija, zaštićene rute, povratak iz linka i zaštite od kasnih rezultata drugog naloga. | Stvarni uređaj, obnova sesije i promena naloga kroz ceo tok. |
| Početna, prilike i mapa | Sažeci, javni detalj, lista, pretraga, filteri i alternativni reader-i. | Potvrđeni P6/server nesklad, nestajanje mape i HALF greška; Home odredište i ostale pretrage. |
| Sopstveni zadaci | Privatni nacrti, javni zadaci, liste, filteri, kandidati i životni ciklus. | Konkretan nesklad aktivnog paged client/server formata. |
| Naručilac i AI | Govor, tekst, fotografije, istorija, strukturisane činjenice, pregled i eksplicitna objava. | Cena, klasifikacija, završni uslovi i oporavak konkretnih radnji. |
| Radnik i AI | Predlog više usluga, oblasti rada, pregled, Save i izbor aktivacije. | Stabilna klasifikacija, celina BOTH, prirodan završetak i stvarna primena sačuvanih područja u povezivanju. |
| Prijava, izbor i Dogovor | Obe uloge, provereni uslovi, zastarelost, izmena, početak, završetak i otkazivanje. | Satnica kroz ceo lanac i sporedni profilni upis posle prijave. |
| Poruke i mediji | Privatni tekst/foto/glas, outbox, potvrde i grupni kontekst. | Medijski oporavak, vidljiva ručna provera i stvarna isporuka između dva naloga. |
| Ocene i podrška | Upis i agregati ocena, podrška, blokiranje i privatnost. | Osvežavanje ocena, očuvanje nacrta i dosledno obećanje o javnom komentaru. |
| Pravila i zatvaranje naloga | Verzije dokumenata, potvrde, izvoz i zatvaranje sa uslovima aktivacije. | Završetak neizvesne saglasnosti, potpuno očuvanje područja rada i dokazana aktuelna spremnost pre aktivacije izvoza/brisanja. |
| Razvoj i objavljivanje | Istorija migracija, CI, brojni dokazi, build zastavice. | Jedan proverljiv spoj tačnog source-a, Edge verzija, šeme i aplikacionog build-a. |

Ovo nije tabela „gotovo/nije gotovo” izvedena samo iz broja fajlova. Postojanje ekrana, postojanje zaštite i dokaz da ceo poslovni tok radi tri su različite tvrdnje. Širi raniji pregled i njegov provereni kontinuitet čuvaju ostatak aplikacije u obuhvatu; poglavlje 11 navodi i preostali sporedni backlog. Sadašnji STATUS od 26.10. nosi smer „Samo poruke za sad”; stariji server PHONE grantovi i stari klijenti još zahtevaju zasebno zatvaranje, pa uklonjena UI opcija nije dokaz da je cela mogućnost povučena. [E39]

## 5. Jedno značenje podataka kroz ceo sistem

Glavna arhitektonska potreba je da razgovor, klasifikacija, pregled, Save i povezivanje ljudi dele isti ugovor. To znači da se razumevanje jedne faze ne gubi ili tiho menja u sledećoj.

| Pojam | Značenje koje treba dosledno sačuvati |
|---|---|
| Korisnikova namera | Svaka jasna činjenica iz jedne poruke ulazi u predlog. Nejasan podatak ne poništava druge jasne podatke. |
| Usluga | Jedna stvarna usluga ima stabilan identitet i kada je čovek drugačije nazove. Naziv za prikaz i identitet nisu isto. |
| Nova usluga | Stvarno nova ponuda ide kroz postojeće pravilo predlaganja i potvrde kataloga. Sinonim ne postaje automatski nova kategorija. |
| ON_SITE | Rad zahteva dolazak na mesto naručioca ili mesto zadatka. |
| REMOTE | Rad se izvršava bez takvog dolaska; uključuje digitalni rad, radionicu ili rad kod radnika, uz moguću fizičku predaju. |
| BOTH | Ista usluga ponuđena na oba načina, sa istim canonical identitetom. Dva mode reda ne znače dve kategorije. |
| Predaja | Slanje ili lično preuzimanje rezultata/predmeta razlikuje se od terenskog rada. Nepoznato nije isto što i „predaja nije potrebna”. |
| Područje rada | Mesta/radijusi ili cela zemlja po eksplicitnoj nameri. Profilna tačka, radni teren i mesto fizičke predaje nisu automatski ista stvar. |
| Cena | Zajedno se tumače način dogovaranja, iznos, valuta, osnovica, broj ljudi i trajanje. Korekcija može učiniti raniju cenu nevažećom. |
| Termin | Jednokratan ili ponavljan posao i poznat/nepoznat kraj moraju ostati isti kroz razgovor, prijavu i Dogovor. |
| Pregled | Tačan, zamrznut predlog sa revizijom. Mogućnost da se prikaže ili prihvati nije isto što i već sačuvan rezultat. |
| Potvrda | Čovek odobrava prikazani sadržaj eksplicitnom radnjom. Modelov „gotovo” nije Save, aktivacija ili objava. |
| Povezivanje | Koristi serverom potvrđenu uslugu, reviziju, način rada, saglasnost i oblast. Sam naziv ili profilni ACTIVE status ne daju sva prava. |
| Nepoznat ishod | Proverava se prethodna ista radnja. Nedostatak odgovora ne znači ni uspeh ni dozvolu za slepo ponavljanje. |

Ovo je objedinjavanje značenja postojećih vlasnika, ne predlog novog sloja koji bi zamenio sve servise. Worker shared ugovor već dopušta inherentno jasan početni mode konkretne nove usluge. Nije potrebno postavljati posebno očigledno pitanje samo da čovek izgovori internu oznaku. Prethodno sačuvan izbor, međutim, ne sme se promeniti takvim nagađanjem. [E05] [E08]

Poslednje korisničke odluke koje ovaj izveštaj čuva jesu prirodan razgovor, bez parcijalnih kartica, najviše jedno stvarno potrebno pitanje po odgovoru, tihi klasifikator u pozadini i jedan razumljiv završni pregled. BOTH i REMOTE se tumače kako je gore opisano. Ne uvode se nove obavezne potvrde opreme, vozila, tima ili licence. Stara pravila o naknadama ili HITNO režimu ne vraćaju se iz istorijske memorije: aktuelni test setup izričito odvaja buduću kompatibilnost od prvog izdanja. [E09]


### Šta treba da radi mini i šta znači oporavak

Korisnikova zamisao je jasna: osoba kaže šta traži ili nudi; model razume uslugu, nalazi postojeći identitet ili predlaže smisleno proširenje stabla; baza validira i sačuva stvarni ID; sistem ga koristi za povezivanje. **Osoba potvrđuje svoj zadatak ili profil, bez upravljanja kategorijama.** Za postojeću uslugu koristi se postojeći ID. Za novu uslugu baza radi upis i vraća ID; model ne izmišlja identifikator koji se tretira kao već upisan zapis. [E37]

| Situacija | Ispravna reakcija sistema |
|---|---|
| Jasno opisan dozvoljen posao postoji pod drugim nazivom | Prepoznati isti smisao i sačuvati postojeći identitet uz validaciju. |
| Jasno opisan posao zaista nema odgovarajuću granu | Predložiti odgovarajuću novu strukturu i bezbedno dovršiti upis. Samo odsustvo grane ne stvara novo pitanje korisniku. |
| Opis je stvarno dvosmislen, npr. „klima” | Pitati da li je u pitanju ugradnja, servis, čišćenje ili nešto drugo. Pitanje je o poslu. |
| Model, mreža ili proces privremeno otkaže | Nastaviti zabeležen unutrašnji posao za važeći sadržaj, sa ograničenim pokušajima i proverom ishoda. |
| Korisnik kaže vreme ili „to je to”, a usluga ostane ista | Sačuvati semantički rezultat i bezbedno vezati ga za tekući pregled. |
| Korisnik stvarno promeni uslugu, mode ili predaju | Odbiti zastareli rezultat i obraditi novu nameru. |

„Oporavak” zato ne znači da korisnik treba da pronađe klasifikaciju umesto modela. Znači da aplikacija dovrši ili proveri sopstvenu prekinutu radnju. Kod trenutno ima i veštačke prepreke koje ponavljanje neće rešiti: nepotpun ugovor semantičkog reuse-a, jednočlani naziv tretiran kao nejasan i rezultat vezan za preširoku reviziju. Njih treba popraviti, uz očuvanje naloga, saglasnosti i zaštite od zastarelog sadržaja. [E30] [E37]

Postojeći `classificationGeminiShadow.mjs` već opisuje pun snapshot, semantičko ime, novu granu, višestepeni put, isti ID za oba moda i očuvanje rezultata kroz završnu poruku. Aktivni dual tok zaobilazi taj explorer/taxonomy prompt. To pokazuje da deo zamišljenog ugovora već postoji u projektu, ali nije povezan sa aktivnim putem. Treba objediniti ugovor u postojećim vlasnicima i dokazati koji ga put zaista izvršava. Slepo uključivanje starog režima ili dodavanje trećeg klasifikatora nije zaključak ove analize. [E30] [E38]

### Kako stablo ostaje dostupno bez nepotrebnog rada

**Cilj je da klasifikator dobije celo važeće stablo i da ne obilazi granu po granu pri svakom pitanju.** Baza ostaje vlasnik kategorija i ID-jeva. Edge čuva potpun, proveren snimak određene verzije. Ako se stablo nije promenilo, ponovo koristi taj snimak; ako jeste, zamenjuje ga tek kada je nova celina uspešno učitana i proverena. Nepotpun rezultat nikada ne dobija oznaku potpunog stabla. [E51]

Sveži snimak verzije 11 sadrži svih 153 ustanovljenih kategorija, 120 listova, jedan koren i 17 sinonima; devet čvorova podržava oba načina rada. Sadašnji JSON snimak ima 71.388 bajta, a izdvojeni tekst stabla za model 13.168 UTF-8 bajta. Bajtovi nisu tokeni i ne dokazuju isplativost provider cache-a. Pre optimizacije treba popraviti i prikaz odnosa u stablu opisan u F05. [E51]

Sadašnji kod već ima memorijski keš, ali proverava njegovu verziju tek **posle preuzimanja celog SQL snapshot-a**. Zato sam pogodak u kešu ne uklanja taj prenos iz baze. Plan postojeći poziv pretvara u uslovni: za već poznatu potpunu verziju vrati se mala potvrda, a celo stablo samo pri promeni ili hladnom startu. Potrebni su i jedan zajednički pokušaj učitavanja po instanci i provera tekućeg značenja pri upisu, da paralelni razgovori ne stvaraju različite kopije iste nove grane. [E51]

**Keš na Edge-u i kontekst koji vidi Gemini nisu isto.** Gemini ne može da čita memoriju našeg servera sam od sebe. Za podržani model, njegov eksplicitni context cache omogućava da se stabilno stablo pripremi kod provajdera i da sledeći zahtev navede tu pripremljenu verziju. Novi modelski zahtev i dalje je potreban kada treba nešto novo razumeti. Implicitni cache može pomoći ceni i obradi istog prefiksa, ali sam ne uklanja slanje tog prefiksa i ne garantuje pogodak. [E51]

Preporučen redosled je zato: ispravan kompletan snapshot na Edge-u; isti stabilan prefiks; očuvanje već razrešene usluge; zatim eksplicitni provider cache kada stvarna veličina konteksta, podrška izabranog modela, učestalost ponovne upotrebe i trošak čuvanja potvrde korist. Ne uvodi se dodatni vektorski servis ili stalno zagrevanje servera radi ovako malog stabla. Keširanje ne sme promeniti ID, saglasnost, oba izabrana načina rada ili konačnu korisnikovu potvrdu. [E51]

Zajednički cache sadrži samo katalog i zajedničke instrukcije. Korisnikove poruke i privatni profil ostaju van njega. Promena stabla, modela ili instrukcije pravi novi identitet keša. Istek ili nestanak keša ima ograničen rezervni put kroz potpun snimak; ne predstavlja razlog da se izmisli kategorija ili traži od čoveka da bira internu šifru. Ovo je konkretan plan optimizacije, bez tvrdnje da su već izmereni buduća brzina, cena ili uspešnost klasifikatora. [E51]

## 6. Naručilac: stvaran tok i željeni završetak

### Kako sada teče posao

| Korak | Šta sada radi aplikacija | Šta korisnik treba jasno da razume |
|---|---|---|
| Ulazak u novi razgovor | Prikazuje lokalni uvod. Sam ulazak ne pokreće model. | Može odmah opisati potrebu svojim rečima. |
| Slanje teksta/govora | Otvara ili nastavlja razgovor sa stabilnim ključem; identitet pokušaja se beleži pre dispatch-a. | Jedno slanje pripada jednoj radnji i ne šalje se ponovo zbog nestrpljivog klika. |
| Razumevanje | Predlaže strukturisane činjenice; prikazuje samo tekst koji je prošao prihvaćeni completion. | Jasne činjenice su prepoznate; sledeće pitanje traži ono što zaista nedostaje. |
| Fotografija i mesto | Fotografija i mapa imaju zasebne radnje i vlasnike. | Dodavanje slike nije potvrda objave. Predloženo mesto nije automatski potvrđen pin. |
| Završna kartica | Aktivna ruta je daje tek kada postoje potpun predlog i odgovarajuće tačke. | Kartica je pregledna celina predloga, bez tvrdnje da je već objavljeno. |
| Otvaranje pregleda | Meni može dozvoliti ulazak i pre završne kartice, kada postoje činjenice i nema nerešenog upisa. | Može pregledati i nedovršen sadržaj; to nije prečica za neispravnu objavu. |
| Ispravka | Obični podaci vraćaju u isti razgovor; mesto i fotografije imaju posebne radnje. | Ispravka ne zahteva ponovno diktiranje svega. |
| Sačuvaj nacrt | Prihvata konkretan review i pravi privatno prihvaćeno stanje. Može biti bez svih pinova ako ostali uslovi dozvoljavaju. | Nacrt je privatan. Čuvanje nacrta ne pokreće automatsku objavu. |
| Objavi | Prihvat, dozvoljena evaluacija i objava vezani su za isti sadržaj i komandu. | Objavljuje tačno ono što je pregledao. |
| Potvrda uspeha | Učitava isti objavljeni Need i reviziju pre završnog prikaza. | Uspeh je potvrđeno stanje, a ne zaključak iz nestalog spinner-a. |

Izvori: aktivne rute, review client, presentation i pročitani route testovi. [E01] [E02] [E10] [E11]

### Dve mape imaju različito značenje potvrde

Razgovorna mapa svaku izričito potvrđenu tačku odmah čuva na serveru uz očekivanu geografsku reviziju. Kod rute sa početkom i krajem jedna tačka može već biti sačuvana dok druga još nedostaje. Review mapa potvrđene tačke prvo drži lokalno; tek „Primeni potvrđene tačke” pravi novi review sa tim skupom. Izlazak pre primene zato nije ista radnja u ta dva slučaja. [E12] [E13]

To nije samo dupliranje izgleda i ne treba spojiti writere na brzinu. Budući dizajn treba da kaže kada čovek očekuje da pin preživi izlazak. Tačan redosled kartice, pregleda i mape ostaje predlog za odluku; ovaj audit ga ne pretvara u već potvrđenu korisničku naredbu.

### Željeni završetak

Čovek opiše posao, asistent zabeleži sve jasno, pita jednu preostalu bitnu stvar, pokaže smislen predlog i omogući ispravku. Posle eksplicitnog čuvanja ili objave korisnik vidi stvarni rezultat i eventualno jasno objašnjenje da automatsko povezivanje neke usluge još čeka. Korisnik ne treba da vidi interne nazive klasifikatora, potpisa ili revizija.

Važno je sačuvati razliku između „predlog je potpun”, „pregled može da se prihvati”, „nacrt je sačuvan”, „objava je potvrđena” i „automatsko povezivanje je spremno”. Pending klasifikacija nije univerzalna zabrana prihvata ili objave; određene neusaglašenosti, naročito REMOTE predaja, imaju sopstvene strože uslove. [E10] [E14]


### Tekst usluge, ID i završna kartica su različite stvari

Završna kartica zahteva tekstualnu činjenicu `need.category` među obaveznim podacima, ali tu stavku skriva iz korisničkog spiska onoga što nedostaje. Ako tekst nije upisan, kartica može izostati bez jasnog objašnjenja. To nije direktna provera da li postoji konačni category ID ili klasifikacija READY. Ne treba popravljati ovaj slučaj opštom zabranom objave svih pending klasifikacija. Posebni uslovi za mesto, safety i REMOTE predaju ostaju zasebni. [E37]

Naručilac ima i užu varijantu problema sa nastavkom: source otisak za predlog nove grane ili proširenja moda uključuje poruke i sve činjenice, dok novi BG posao pokreću samo promene usluge/scope-a/moda/predaje. Običan odgovor o budžetu ili vremenu može zato ostaviti predlog vezan za stari source. Ovo je statički praćen lanac; postojeća exact/alias kategorija i dalje može da se razreši neposredno iz činjenica. Ne generalizuje se da svaki zadatak naručioca gubi klasifikaciju. [E30]

## 7. Radnik: stvaran tok i željeni završetak

Radnik može navesti više usluga i više područja rada. Promena teme ne pokreće novu konverzaciju sama po sebi. Izmena iz pregleda vraća se u isti razgovor, a nezavisna nova izmena ne treba da izbriše ostale usluge, područja ili ranije načine rada. [E03] [E08]

| Korak ili status | Današnje značenje | Završni kvalitet koji treba postići |
|---|---|---|
| Razgovor ima neki sadržaj | `hasProfileContent` otvara tihi ulaz u pregled. | Ne predstavljati to kao dokaz da je intervju završen. |
| Svež pregled | Vezan je za nalog, profil, razgovor i reviziju. | Pokazati šta čovek radi, kako, gde i šta još stvarno nedostaje. |
| READY klasifikacija | Projekcija prihvata dostavljene parove; F08 pokazuje da očekivana celina BOTH još nije obavezno proverena. | Dokazati sve tražene parove, pa razlikovati spreman predlog od primenjenog prava na povezivanje. |
| Pending/review-required | Konkretna klasifikacija ili promena još čeka. | Objasniti konkretnu uslugu, uz očuvanje statusa nepogođenih starih usluga po server pravilima. |
| DRAFT bez aktivacije | Korisnik bira „Sačuvaj profil”. | Sačuvati privatnu pripremu bez neželjene aktivacije. |
| DRAFT sa aktivacijom | Isti pregled nudi „Sačuvaj i aktiviraj profil”. | Jedna završna radnja može sačuvati i aktivirati kada su ispunjeni uslovi. |
| Izmena ACTIVE profila | Nova verzija je predlog do Save-a. | Stari ACTIVE status ne znači da je nova usluga već spremna za povezivanje. |
| Potvrđen Save | Ruta čita merodavan receipt, pa nudi sačuvani profil. | Čovek vidi šta je sačuvano i šta konkretno čeka. |
| Sačuvani profil | Lista usluga i zbirni mode; nema svih detalja review-a. | Sačuvati razumljivost per-service mode/handoff/pending na postojećem prikazu. |

`activate=false` pri izmeni već ACTIVE profila nije naredba za deaktiviranje. Izbor nacrt/aktivacija prikazuje se za DRAFT. To je važno da kasniji Codex ne „popravi” ispravno ponašanje u neželjenu deaktivaciju. [E03] [E15]

Za završetak razgovora nedostaje autoritativan signal u worker snapshot-u. Sam modelov tekst „spremno je” nema to pravo. Treba povezati dovoljno prikupljen sadržaj, stvarni server review i jasan poziv korisniku na pregled; opciona biografija ili detaljan kalendar ne treba da produžavaju razgovor bez potrebe.

Područja rada imaju strukturisan ugovor: do pet CITY/RADIUS područja ili jedno COUNTRY. Radijus mora biti izričito naveden i vezan za razrešen centar; nije proizvoljan krug oko profilne tačke. Usklađivanje stare i nove lokacione putanje treba da čuva taj ugovor. [E16]

**Dublja provera je našla konkretnu posledicu neusklađenosti:** automatski izbor najpre može izbaciti radnika po staroj profilnoj tački, pre provere njegovog sačuvanog područja. Dodatno, novi proverivač područja trenutno podržava samo RS i STATIONARY, iako aktivni ugovor ima više fizičkih načina izvođenja. Radnik zato može jasno navesti gde radi i ipak ne ući u odgovarajuće preporuke. To je F18; ne znači automatsku zabranu njegove ručne prijave na zadatak. [E41]

## 8. Prioritetni nalazi, uz uzrok i kriterijum zatvaranja

Prioritet označava redosled dovršavanja proizvoda. Ne tvrdi da je svaki statički rizik već izazvao incident korisniku.

### F01 — Lista sopstvenih zadataka nema isti ugovor na obe strane

**Visok prioritet; source i živa definicija.** Klijent za prvu stranu zahteva pet brojača i scope-ove ALL/ACTIVE/DRAFTS/HISTORY/WAITING. Živi `rpc_list_my_needs_page` vraća `items`, `hasMore` i `asOf`, bez counts, prihvata tri scope-a i vraća camelCase stavke dok pravi mapper traži snake_case dokument zadatka. Praćeni EAS profili uključuju paged putanju. [E17] [E18]

Produbljena provera je utvrdila da baseline telo odgovara starom pkg045a telu koje EX04a kandidat izričito navodi kao prethodnika. **Čak i prazna prva strana pada zbog counts; dodavanje samo counts ne rešava neprazne strane.** Istovremeno postojeći `rpc_read_task` i `rpc_list_my_tasks` imaju kompatibilne ugovore koje treba sačuvati. [E31]

Ovo su **„Moji zadaci”**, odvojeni od fotografisanog taba „Zadaci” i njegovog Discovery RPC-a. Zatvaranje traži jedan usklađen ugovor, svih pet scope-ova, praznu i nepraznu prvu stranu, tačne brojeve i nastavak preko pravog dekodera. Nije utvrđen tačan istorijski trenutak kada je neko ranije telo eventualno prepisano.

### F02 — Satnica nije usaglašena kroz razgovor, prijavu i Dogovor

**Visok prioritet; različiti potvrđeni ugovori.** Validator činjenica dopušta HOURLY; Edge guard za PER_HOUR traži cenu celog posla i uklanja price predloge. Kasniji živi `assert_application_price_v5` za MY_PRICE priznaje null, PER_PERSON ili TOTAL, a drugu osnovicu odbija kao UNKNOWN_PRICE_BASIS. OFFERS ima drugačiju granu i ne sme se svesti na istu tvrdnju. [E04] [E18] [E19]

Treba odrediti jednu potpunu poslovnu politiku: kada se prikazuje satnica, šta znači trajanje, ko potvrđuje ukupan iznos i kako isti uslovi dolaze do prijave, izbora i Dogovora. Dok se ta odluka ne proveri u važećem izvoru pravila, nije opravdano tiho pretvoriti satnicu u ukupnu cenu ili proglasiti podržanom svaku valutu. Zatvaranje je isti iznos/jedinica/uslovi u svakoj fazi, sa pozitivnim i odbijenim slučajevima.

Stari instalirani Discovery decoder dodatno odbija HOURLY; jedan takav red može srušiti celu PAGE poruku. Novi decoder ga prihvata. Osam sintetičkih kombinacija potvrđuje ovu razliku, bez dokaza da je konkretan telefon dobio takav red. Usaglašavanje cene mora zato obuhvatiti i još aktivne stare klijente. [E34]

### F03 — Ispravka valute može ostaviti prethodnu potvrđenu cenu

**Visok prioritet; lokalno reprodukovano stvarnim guard-om i izdvojenim SQL telima.** Posle potvrđenih 5.000 RSD, korisnik kaže da je mislio u evrima. Guard ispravno ne izmišlja kurs i ne upisuje evre kao dinare, ali ne šalje komandu koja povlači staru RSD činjenicu. Ona ostaje CONFIRMED; osnovni review može prikazati stari iznos i `canSaveDraft=true`. Nezavisna naredna poruka može ukloniti warning, a ne ukloniti cenu. [E04] [E18]

Dokaz nije prošao signed accept, konačni Save ili publication, pa nije dokaz da je pogrešna cena zaista objavljena. Potrebno je atomsko pravilo korekcije: kada se menja značenje cene, stara cena prestaje da bude važeći potvrđeni dogovor dok se ne razjasni. To se može urediti u postojećem RSD ugovoru; automatska EUR podrška ili konverzija nisu podrazumevani zahtev.

Zaseban raniji nalaz odnosi se na tekst cene koji model šalje: ispravan broj 100 RSD može pratiti pogrešan `displayValue` „100 EUR”. Kontrolisana ranija proba pokazala je da takva kombinacija stiže do completion-a. Glavni pregled ponovo formatira cenu iz tipizovanog broja, pa pogrešan prikaz valute na tom ekranu nije potvrđen. Potrebno je sačuvati ispravan broj i uskladiti sve njegove prezentacione kopije; ovo je drugi slučaj od korisnikove ispravke valute. Precizni dokazi i vremenska granica su u tehničkoj referenci, F03.

### F04 — Nepotpun katalog može biti zapamćen kao potpun

**Visok prioritet; sintetički izvršivi dokaz.** Rezervni loader traži ROOTS/CHILDREN, ali ne prati `nextCursor` i može preskočiti nevažeću stranu. Rezultat zatim indeksira kao ceo katalog. Ako kasnije dobije potpun snapshot iste verzije i fingerprint-a, vraća prethodni parcijalni objekat. [E06] [E20]

Proba sa 202 čvora vratila je 200; potpun naknadni snapshot opet je dao 200. Druga proba sa samo dva čvora i NEED-shaped neuspehom jedne CHILDREN strane vratila je jedan čvor bez greške. WORKER HTTP helper u istom HTTP failure slučaju baca, pa nije tačno da oba handlera identično preskaču svaki failure. HTTP 200 nevažećeg oblika ostaje posebna slabost.

Trenutni DEV agregati imaju 153 established čvora, jedan koren, najviše 12 dece, 33 nonleaf čvora i dubinu pet. To ne pokazuje trenutno prekoračenje strukturnih granica. Ne tvrdi se da je živi katalog oštećen. Kriterijum zatvaranja je dokaz potpunosti svih strana ili jasno odbijanje parcijalnog rezultata, uz bezbedno zamenjivanje starog nepotpunog keša.

Dodatno, loader danas preuzima ceo snapshot pre provere toplog keša, a prefetch i builder mogu ponoviti isti prenos. Ograničenje `depthGuard < 6` broji šest grupa obrade, ne šest nivoa stabla. Plan spaja istovremena učitavanja, verifikuje sve strane i uvodi mali uslovni odgovor za nepromenjen kompletan sadržaj. Promena fingerprint-a mora obuhvatiti stvarni prikaz i relevantna pravila, ne samo broj verzije. [E51]

### F05 — Semantički identitet i nova grana nisu potpuno povezani sa aktivnim putem

**Visok prioritet; source, stvarni builder i izolovane SQL probe.** Exact naziv i registrovani alias imaju jasnu putanju. Glavni requester prompt već normalizuje prirodan opis u konkretan naziv usluge; nije tačno da semantičke obrade nema. Međutim, naziv koji posle toga ostane izvan canonical imena i registrovanih aliasa nema zatvoren background reuse prijem. Kontrolna proba razlikuje uspešan registrovani alias od `SEMANTIC_REUSE_ADMISSION_UNAVAILABLE` za nepokriven sinonim. [E06] [E30]

**Novi potvrđeni nedostatak ulaza:** snapshot ima svih 153 čvora i njihove roditeljske veze, ali klasifikatoru se pretvara u globalno abecedno sortiran spisak sa uvlačenjem, bez roditeljskog ID-ja i pune putanje. U stvarnom redosledu 73 deteta stoje pre roditelja, a 31 podstablo nije uzastopno. Model tako dobija nazive, ID-jeve i modove, ali ne i pouzdan prikaz iste hijerarhije. To nije dokaz da je ovde opažen pogrešan odgovor modela. Popravka je eksplicitna veza `id/parentId` ili dokazano pravilan prikaz stabla, uz alias i mode pravila; tek zatim taj sadržaj treba keširati. [E51]

Aktivni BG odgovor predlaže jedan novi child postojećeg parent-a. SQL već može `CREATE_NEW_BRANCH` i višestepeni put, ali aktivni izlaz to ne emituje. Zato „može da nastane novi list” nije isto što i mogućnost svakog smislenog proširenja stabla koje je proizvod zamislio. [E37]

Stvarna triage funkcija u izolovanom fixture-u daje `NEEDS_CLARIFICATION` za `Sisanje`, a `LOW_RISK_CANDIDATE` za `Sisanje kose`, bez aktivnih pravila rizičnog sadržaja. Jedna reč se tako tretira kao nejasnoća na osnovu oblika teksta. Ista prepreka postoji pri `EXTEND_MODE`, uključujući postojeći jednočlani naziv kategorije. Dve reči, s druge strane, same ne dokazuju ispravnost predloga. [E30]

Zatvaranje: očuvati postojeće ID-jeve i provere sadržaja, dovršiti validiran semantički reuse i stvarno potrebnu novu strukturu, proveriti potpun katalog, a korisniku postavljati pitanje samo o stvarnoj nejasnoći posla. Ne praviti novu kategoriju za svaki izraz i ne uklanjati identity/consent guard da bi test prošao.

Identitet treba sačuvati i kroz kasnije SQL upise. Need trigger ponovo izvodi ID iz prikaznog naziva, bez registrovanih sinonima i uz mogućnost da putanju svede na poslednji naziv. Worker sync može opozvati raniju podobnost posle neprepoznatog preimenovanja; dodavanje nepoznate usluge uz zadržanu staru ne ukida sve. Potpisani binder koji menja samo ID nije uzrok prvog ponašanja. Zato provera mora obuhvatiti preimenovanje, putanju, dodavanje i izričito povlačenje, uz očuvane dozvole i revizije. Tehnička referenca F05 povezuje ranija živa tela, ponovnu proveru njihovih hash-eva i ove ograničene zaključke.

### F06 — Običan nastavak može učiniti klasifikaciju nevažećom, a prvi plan nema potpun trajni nastavak

**Visok prioritet; lokalno reprodukovano svežim živim SQL telima uz kontrolisane pomoćne funkcije.** Worker hint se vezuje za ceo kandidat, revision i base_hash. Svaki uspešan odgovor povećava revision, čak i prazan patch pri „to je to”. Pregled traži hint te nove revizije; pozadinski trigger ne ponavlja rad ako se usluga/mod nisu promenili. [E30]

U kontrolisanoj probi novog radnog nacrta revizija 1 ima isti kandidat i dva odgovarajuća hint-a. Prazan patch pravi reviziju 2, kandidat ostaje identičan, broj odgovarajućih hintova postaje nula i exact projekcija daje `REVIEW_REQUIRED`. Hintovi nisu obrisani, već više ne pripadaju trenutnom otisku. Fallback netaknutog ranije sačuvanog profila na revision 0 ne zatvara ovaj tok novog nacrta. Ceo prepare/potpisivanje/Save/binder nije izvršen u probi. [E30]

Srodan requester rizik je uži: novi branch/mode predlog može zastareti na promeni budžeta, vremena ili poruka, dok se exact/alias usluga može ponovo razrešiti iz činjenica. Taj deo je statički dokaz, ne nova reprodukcija cele requester putanje.

**Novi lifecycle kod treba sačuvati.** a969 započinje devetosekundni rok pri startu klasifikatora, prekida ga kada glavni completion ne uspe i proverava store/capture potvrde. To popravlja život jednog pokušaja; nije trajni posao koji pouzdano nastavlja prvi propušten plan na drugoj instanci. [E04] [E06]

Post-save procesor obrađuje već formiran plan sa fingerprint-om i proverava receipt. Pending reconciler evidentira da sačuvani review nije završen; ne stvara nedostajući plan i ne poziva model. Save može ostati dozvoljen i kada klasifikacija nije READY, pa treba jasno razlikovati **sačuvan sadržaj** i **dovršen unutrašnji posao**. Ne uvoditi opštu zabranu čuvanja ili obavezan ručni izbor kategorije kao zamenu za nastavak.

Zatvaranje: vezati klasifikaciju za stvarno semantičko značenje i bezbedno ponovo vezati nepromenjen rezultat za važeći review; stvarnu promenu obraditi iznova. Zadržati nalog, svežinu, idempotency i odbijanje zakašnjelog rezultata. Trajan nastavak mora razlikovati tehnički neuspeh, stvarno pitanje, uspeh i nepoznat capture ishod, uz ograničen budžet. Produžavanje timeout-a samo po sebi ne rešava ovu grešku.

### F07 — Dodatni modelski poziv nema isti potpun put obračuna

**Srednje visok prioritet; statički potvrđen jaz.** Glavni model ima rezervaciju i settlement. Background direktno poziva provider, a njegov parser ne prenosi usage metadata u odgovarajući zaseban attempt/settlement tok. To nije dokaz da je nastao prekomeran račun niti da svaka poruka obavezno koristi dva modela: exact putanje i okidači mogu izbeći dodatni poziv. [E06]

Svaki stvarno plaćeni pokušaj treba da ima sopstveni identitet, dozvoljen budžet i poznat ili jasno nepoznat obračunski ishod. Naknadni retry mora poštovati isti ugovor. Zatvaranje se dokazuje praćenjem oba pokušaja pri uspehu, abort-u, gubitku odgovora i ponavljanju, bez prepisivanja potrošnje jednog drugim.

Pozadinski poziv ima i slabiji prijem odgovora: nema isto ograničenje veličine tela i može prihvatiti odgovor bez oznake završenog generisanja. Devetosekundni rok već postoji, pa nije problem odsustvo svakog timeout-a. Uskladiti veličinu, potvrdu završetka i obračun, uz očuvanje već dodatih zaštita. Odvojeno, govorni put oslobađa test rezervaciju kada nema transkripta, iako je audio možda već poslat. Prazan tekst sam ne dokazuje da obrada nije potrošena. Ovo su proverene razlike u kodu, bez dokaza o stvarno pogrešnom računu. Tehnička referenca F07 navodi tačne vlasnike i granice.

### F08 — Nepotpuna ponuda oba načina rada može postati READY

**Visok prioritet; pravi worker builder i stvarna exact SQL projekcija u izolovanoj probi.** Za izričito traženi ON_SITE + REMOTE sintetički provider vrati samo ON_SITE. Builder pravilno proizvede jedan proposal, failure za REMOTE i unresolved podatak. Edge prosledi rezultat jer postoji makar jedan proposal, bez očekivanog kompletnog skupa i neuspelog ostatka. Projekcija proverava da svaka usluga ima bar jedan mode i može vratiti **READY sa ON_SITE samo**. Kontrola sa dva provider item-a daje READY sa oba moda iste usluge. [E30]

To potvrđuje da deo namere može biti izgubljen između komponenti i proglašen kompletnim rezultatom. Nije dokaz zaobilaženja završnog Save-a, stvarno sačuvanog pogrešnog profila ili učestalosti takvog modelskog izlaza.

Dva prompta i dalje imaju različite formulacije početnog mode-a. Glavni shared ugovor dopušta inherentno jasan početni mode konkretne nove usluge, dok BG traži eksplicitnu ponudu ili sačuvan izbor. Treba jedno pravilo koje razdvaja novu jasnu nameru, raniji sačuvan izbor i izričitu promenu. REMOTE uključuje radionicu i fizičku predaju. BG handoff odgovor trenutno nije autoritet; builder koristi foreground/saved consent. Tu granicu treba sačuvati, a suvišan/neusklađen izlaz pojednostaviti. [E05] [E06] [E08]

Zatvaranje zahteva **nezavisno očuvan očekivani skup usluga–mode–handoff**, proveru da je svaki traženi deo razrešen i jasno stanje nedovršenog rada. Uspešan podskup ne sme sam definisati šta je bilo traženo. BOTH mora ostati isti canonical ID sa oba stvarno ponuđena načina kroz model, pregled, Save i povezivanje.

### F09 — Završetak worker intervjua nema autoritativan signal

**Srednji prioritet; potvrđeno u aktivnoj ruti.** `hasProfileContent` znači da postoji bar neki sadržaj. Snapshot nema intervju-complete signal, što source i navodi. Review `canAccept`, classification READY i sačuvan profil imaju druga značenja. [E03] [E15]

Korisniku treba prirodan završetak čim su potrebni podaci jasni; opciona biografija ili detaljan raspored ne treba da postanu prepreka. Zatvaranje zahteva pouzdan ugovor završetka u postojećim vlasnicima, pošten prikaz nedostajućeg podatka i jedan završni pregled. Nema potrebe za obaveznim dodatnim mode formularom ili posebnim obaveznim korakom aktivacije.

### F10 — Sačuvani profil ne prenosi sve važne detalje pregleda

**Srednji prioritet; potvrđena razlika u prikazu.** Review pokazuje način rada i predaju po konkretnoj usluzi, kao i pending objašnjenje. Ti detalji ostaju i odmah posle Save. Tek ekran sačuvanog profila koristi listu usluga i zbirni mode receipt bez per-service handoff-a i classificationState-a. [E03] [E21]

Nije dokaz gubitka podataka u bazi. Potrebno je da postojeći prikaz jasno pokaže šta je sačuvano za svaku uslugu i šta konkretno čeka. ACTIVE + pending nove usluge ne znači automatski da sve ranije potvrđene usluge gube povezivanje. Kriterijum je dosledna informacija posle prelaska sa pregleda na profil, bez novih obaveznih ekrana.

### F11 — Provera izgubljenog abandon odgovora ide pogrešnim putem

**Srednji prioritet; statički niz klijenta i sveže živo SQL telo.** U pregledu bez zasebnog Need-a korisnik potvrdi „Obriši nacrt”. Server može napustiti razgovor, a odgovor se izgubiti. „Proveri” zatim koristi opšti read, koji bez publication komande pokušava novi prepare. Obe žive prepare funkcije odbijaju razgovor koji više nije OPEN. Poruka potom može reći da je razgovor sačuvan i da treba učitati njegov zadatak, iako zaseban zadatak ne mora postojati. [E02] [E10] [E14]

To nije dokaz gubitka podataka ili blokade cele aplikacije; Back postoji. Uspešna grana proverava pravi ABANDONED receipt. Nedostaje pravilan readback nepoznatog ishoda iste radnje. Kriterijum: posle unknown odgovora provera utvrđuje ABANDONED ili i dalje OPEN, prikazuje tačan ishod i ne otvara automatski novu poslovnu operaciju.

### F12 — Jedan odgovor može tražiti dva razjašnjenja

**Srednji prioritet; prethodna izvršiva proba i sada pročitani postojeći test.** Kod naručioca kombinacija ponavljanih smena i satnice/dnevnice spaja više zaštitnih poruka. Test za ponavljanje + dnevnicu već očekuje oba sadržaja, bez uslova da odgovor traži samo jednu informaciju. [E22]

Potrebno je jedno mesto koje bira sledeću najvažniju nejasnoću, uz čuvanje ostalih za naredni korak. Samo brojanje znaka pitanja nije dovoljno: i rečenica bez upitnika može tražiti još tri stvari. Kriterijum je jedan konkretan zahtev korisniku, uz sačuvane sve jasne činjenice i bez preranog završetka.

### F13 — Uspešna prijava može pokrenuti zastareo dodatni profilni upis

**Visok prioritet za integritet profila; statički potvrđen rizik.** Posle uspešne prijave i čišćenja njenog journal-a izvršava se opcioni upis cele ranije uhvaćene liste veština u profil. Između await tačaka nema ponovljene provere izvornog naloga/revizije pre te druge radnje. Adapter uzima svoj aktuelni kontekst. [E23]

Postoji korisnikov izbor da doda veštinu; taj izbor sam ne rešava zastarelu celu listu ili promenu naloga. Potrebna je posebna jasno vezana namera koja dodaje tačno uslugu na aktuelnu dozvoljenu reviziju, ili kontrolisano odvojen tok. Nije izazvan incident na živom nalogu. Zatvaranje traži dokaz očuvanja paralelne promene i odbijanje starog callback-a posle A→B→A.

### F14 — Verzije izvora, servera i telefona još nisu potvrđene kao jedna celina

**Preduslov završne provere; deo ranije nepoznatog sada je zatvoren.** Treći snimak identifikuje prikazani izvor `fcef803…`, aplikaciju 1.0.0 i aktivni OTA prefiks `01a163c4`. GitHub potvrđuje 69 commit-a do analiziranog a969. Više se ne traže isti snimci niti se govori da izvor prikazan na telefonu nije poznat. [E26] [E29]

Raniji ciljani presek tri Edge paketa imao je 43 pojave fajlova i sedam jedinstvenih putanja sa razlikom u kodu. Revizija 7 proširuje stvarno preuzimanje na svih 15 paketa i 48 jedinstvenih sadržaja. NEED151/WORKER104 još nemaju sve a969 mode/lifecycle/receipt izmene. Post-save5 konkretno nema noviji catch koji neuspešno čitanje tela odgovora označava za retry istog pokušaja. Source popravka zato nije automatski DEV ponašanje. [E24] [E51] [E52]

Ostaje potreban potpun presek stvarno izvršavanog native/OTA klijenta, efektivnih zastavica, Edge sadržaja, SQL ugovora i odgovarajućeg servera. About nije izvlačenje svih ugrađenih vrednosti, a CI nije dokaz kompatibilnosti sa živim SQL-om. Trenutni README takođe odlaže production build/OTA do provere zasebnog produkcionog backenda. Analiza nije objavila ništa. [E36]

Završna provera porekla dodatno razdvaja stvarnu razliku od administrativne. Baza ima 314 zapisa o migracijama, a izvor 193 fajla; 219 serverskih zapisa nema sačuvane SQL statements. To zahteva dokaziv bootstrap i upgrade plan, a ne automatsku primenu svih različitih brojeva. Za tri najnovije migracije sa različitim timestamp ID-jevima pročitana je cela razlika: SQL sadržaj se razlikuje samo završnim praznim CRLF redom, a svih osam funkcijskih tela je isto. Te tri migracije ne treba ponavljati radi poravnanja naziva. Izolovana obnova prazne baze još nije izvršena. [E53]

### F15 — Instalirani Discovery traži režime koje objavljeni server ne podržava

**Najviši prioritet za prikazani kvar.** P6 onsite tok iz izvora prikazanog na telefonu traži PAGE pa MAP. Živi `rpc_discovery_v1` implementira samo PAGE i EXACT_PUBLIC; MAP/PLACES odbija. Telo odgovara baseline migraciji, a agregirani živi zapisi sadrže pet `P6_MODE_NOT_IMPLEMENTED` u pregledanom prozoru, uz ograničenje vremenskog povezivanja opisano u poglavlju 3. Filteri `forMe`/`minBudgetRsd` dodatno nisu prihvaćeni. [E26] [E27]

Zatvaranje: uskladiti sve aktivne režime i filtere, kroz stvaran objavljeni odgovor i pravi klijentski decoder, uz poznatu podršku starom instaliranom i ciljnom novom klijentu. Popravku izvesti kao proverenu novu promenu tačnih funkcija, uz očuvanje devet kompatibilnih baseline ugovora. Isključivanje P6 može biti izričito izabrana privremena mera sa poznatim gubitkom mogućnosti, ali nije završetak istog proizvoda. [E31]

### F16 — Jedna greška čitanja uklanja mapu i kvari veličinu poruke

**Visok prioritet; stvarne slike, izvor obe verzije i kontrolisana karakterizacija.** Zajednički error sklanja mapu i prebacuje poruku u veliki prikaz. Na slici je panel na HALF visini; to je default početne greške bez zapamćene pozicije, ne pravilo za svaku grešku. Slika pokazuje prekriveno objašnjenje i veliko dugme koje nije u celosti u prikazu; mala refresh ikona ostaje. Prvi failure bez snapshot-a i retry sa snapshot-om stvaraju dva različita ekrana iste greške. MAP failure može poruku proširiti na listu koja ima validne redove. [E28] [E33]

Zatvaranje: odvojena stanja mape/pinova/liste; dosledan prvi i ponovljeni neuspeh; čuvanje smisleno dostupnih podataka i filtera; vidljiva akcija; smisleno lociranje. Na telefonu proveriti HALF/FULL/PEEK, mali ekran, veći tekst, tastaturu gde je prisutna, neuspešno i prazno čitanje, povratak na tab i zasebnu grešku native mape. Ne prepisivati globalni StateView zato što ovaj jedan potrošač koristi pogrešan compact uslov.

### F17 — Stvarni razlog greške se gubi pre korisničke poruke

**Srednje visok prioritet; pet kontrolisanih slučajeva.** Sadašnji legacy focused resource čuva `error:boolean`. Ruta zatim pokušava `.message` ili `String(error)`, pa različiti auth, permission, invalid-response, network i timeout slučajevi završavaju istim tekstom `true`. Stari instalirani P6 put nema taj novi prop; ne pripisujemo mu to objašnjenje sa slike. [E34]

Zatvaranje: sačuvati strukturisan razlog i vezu sa pokušajem u dijagnostici; korisniku dati kratko objašnjenje i stvarno korisnu radnju. Ne prikazivati „internet” kao obavezno objašnjenje serverovog odbijanja i ne izlagati internu SQL poruku kao glavnu instrukciju čoveku.

### F18 — Područje rada i raspoloživost nisu potpuno povezani sa izborom prilika

**Visok prioritet; current source i živa tela, bez upita nad stvarnim profilima.** Početni izbor kandidata za zadatak sa koordinatama prvo traži stare profilne tačke u krugu od 300 km. Rezervni prolaz uzima samo profile bez takve tačke. Radnik sa postojećom udaljenom tačkom može zato ispasti pre nego što se proveri da je izričito sačuvao celu zemlju ili drugo odgovarajuće područje. Kasniji, ispravan matcher ne može vratiti kandidata kojeg nije ni dobio. [E41]

Druga granica je proverivač sačuvanih područja: za fizičke zadatke priznaje RS/STATIONARY, a POINT_TO_POINT, MULTI_STOP, AREA_BASED i druge zemlje odbija. To utiče na automatske prilike i „Za mene”. Ručna prijava i izbor imaju zasebne uslove; ovaj nalaz ne dokazuje da im isto pravilo zabranjuje svaku prijavu. REMOTE i predaja ostaju poseban ugovor.

Treći slučaj je sasvim običan: zadatak je „danas”, a radnik je slobodan kasnije danas. Kada zadatak nema fiksan početak i kraj, trenutna provera ne izvodi preostali deo tog dana i ne proverava radnikove kasnije slobodne termine. Radnik koji nije označen kao slobodan baš sada može zato ispasti iz automatskog izbora. To ne znači da svi zadaci „danas” padaju: oznaka „slobodan sada” i dalje ima svoj prolaz. [E41]

Zatvaranje: jeftin početni izbor mora obuhvatiti sve kandidate koje merodavna provera područja može prihvatiti. Jedan vlasnik treba da uskladi eksplicitna područja, stvarno podržane zemlje i fizičke načine izvođenja. Dokazati udaljenu staru tačku uz izabranu zemlju/grad/radijus, više područja, profil bez tačke, rutu sa više tačaka, REMOTE i „danas, slobodan kasnije”. Sačuvati potpisanu uslugu, saglasnost, vreme, ograničenja i slobodu ručne prijave. Stari SQL za mapu sa jednim krugom ne vraćati kao gotovo rešenje.

### F19 — Područja se sačuvaju u profilu, ali izostaju iz kasnijih izvoznih projekcija

**Visok prioritet pre aktivacije izvoza; potvrđen trag polja.** Aktuelni Save čuva `workAreas` u potvrđenom profilu/pregledu. Međutim, merodavni projektor za worker podatke u izvozu ima izričit spisak polja bez `workAreas`. Isti projektor koristi i deo taxonomy arhiviranja/reset kopija. Tako sačuvana namera ne prolazi ceo život podataka. [E41]

Živi uslovi spremnosti izvoza i brisanja ostaju zatvoreni. Zato ovo nije tvrdnja da je korisniku već isporučen nepotpun izvoz ili da je dokazano curenje pri brisanju. Potrebno je popraviti tačno polje i sve njegove kopije, proveriti vlasništvo, sadržaj i redosled, pa ponovo dokazati važeću celinu. Ne uključivati staru širu migraciju niti menjati certifikat samo da bi kontrola postala zelena.

Dodatna provera 27.10. u 14:43 UTC ponovo daje false za retention source, export binding i closure erasure binding. Povezani su privatni bucket-i, generation/lease, pozitivan readback i ovlašćenje pre vraćanja bajtova. Te ograde treba sačuvati; aktivaciju dobiti stvarnom ispravkom projektora i svih kopija, bez prepisivanja očekivanog hash-a. [E52]

Zatvaranje: sintetički profil sa COUNTRY/CITY/RADIUS područjima preživi razgovor, potpisani pregled, Save, arhivsku kopiju i autorizovani izvoz; tuđi profil ne ulazi u rezultat. Zahtev za izvoz pre spremnosti ostaje iskreno odbijen. Zatvaranje naloga ima svoj odvojen dokaz za sve kopije.

### F20 — Red za push, suzbijanje nepotrebnih poruka i otvaranje odredišta nisu usklađeni

**Visok prioritet za pouzdane obaveštajne tokove; povezani podslučajevi.** Objavljeni push worker v37 bajtno odgovara analiziranom izvoru. Jedan regularni invocation radi jedan SEND pokušaj i jednu zasebnu proveru potvrde. Minute cron poziva SQL tick, koji tek uz važeću konfiguraciju enqueue-uje HTTP; može uspešno završiti i kao NOT_CONFIGURED ili IDLE. Zato minutni SQL uspeh nije dokaz da se Edge stvarno pokrenuo ili da je poruka stigla. Kapacitet regularnog puta treba uskladiti sa stvarnim talasom prilika i izmeriti. [E41] [E52]

Sveži sedmodnevni agregat ima po 10.080 SQL uspeha za svaki od tri cron posla. Zadržanih 360 HTTP 200 zapisa pokriva približno šest sati i nije razdvojeno po endpoint-u. Poslednji push TICK_OK je od 23.10. u 22:23 UTC i više nije svež: sadašnji status je nepoznata spremnost, bez dokaza novog uspeha ili konačnog kvara. Plan prvo utvrđuje aktuelnu konfiguraciju i uzrok zastarelog opažanja, pa dokazuje claim, provider ishod i otvaranje odredišta. [E52]

Aktuelni prijem i kasnije provere takođe nemaju potpun uslov koji izbacuje osobu koja se već ručno prijavila na istu reviziju zadatka pre prve prilike. Postojanje deduplikacije već napravljenog događaja ne zatvara taj slučaj. Konačno, korisnik može imati PUSH uključen i obaveštenja u aplikaciji isključena, dok razrešavanje tačnog odredišta traži neugušeni IN_APP zapis. Dodir push-a tako može ostati bez dozvoljenog tačnog odredišta. To su statički potvrđene veze, ne opaženi incidenti sa uređaja.

Zatvaranje: ograničen rad reda uskladiti sa stvarnim talasima i obradom potvrda, bez duplog slanja posle nepoznatog odgovora; definisati suzbijanje iste već odgovorene prilike; omogućiti bezbedno odredište prema stvarnoj push potvrdi i korisničkim postavkama. Ne uključivati potajno IN_APP da bi link proradio. Testirati obe uloge, promenu revizije, povučenu prijavu, izgubljen odgovor, nevažeću sesiju i stvarni dodir na uređaju. Aktivacione/provider granice ostaju na snazi.

Za grupnu poruku je potvrđena i uža nedovršena veza: aktuelni upis čuva poruku i njenu vidljivost, ali ne stvara odgovarajući događaj za obaveštavanje; nema ni dodatnog trigera koji to nadoknađuje. Kandidat za tu vezu postoji, ali njegovo prisustvo u repozitorijumu ne znači da je primenjen. Slanje grupne poruke zato ne proglašavamo pokvarenim; potrebno je dovršiti obećani tok obaveštavanja i odredišta. [E41]

### F21 — Dozvola za celu tabelu ponovo otvara tri privatne kolone zadatka

**Visok prioritet u prvom paketu; potvrđene aktuelne dozvole.** Ranije je prijavljenom korisniku bio dozvoljen samo izričit spisak javnih kolona. Migracija od 23.10. ponovo je dala čitanje cele tabele `needs`. Sveža provera dozvola potvrđuje da prijavljena uloga sada može čitati i interni ID naloga naručioca, interni ID osobe koja je zatvorila preostalu pretragu i njen razlog zatvaranja. [E41] [E45]

Pravila za redove i dalje ograničavaju pristup. Konkretan problem je tuđ javno vidljiv zadatak u stanju PUBLISHED ili SELECTION u istom svetu naloga; anoniman ili drugi svet nije ovim nalazom otvoren. Kada zadatak ostane u SELECTION posle zatvaranja preostale pretrage, sačuvani razlog može ostati u istom dostupnom redu. Standardni ekran čita bezbednu projekciju bez tih polja, ali ta projekcija ne uklanja širu dozvolu direktnog API čitanja.

Nisu čitani tuđi redovi, nije dokazano da je neko ovo iskoristio i nije utvrđen broj pogođenih naloga. Potvrđen je propust u granici pristupa. Zatvaranje traži izričitu javnu projekciju ili odgovarajuće dozvole po kolonama, uz očuvanje čitanja sopstvenih zadataka, mape, RLS-a i sertifikacionih zavisnosti. Proveriti dva sintetička naloga, sve tri kolone, direktan upit, alias, filter, sortiranje i `*`, pa normalne dozvoljene ekrane. Stari PKG045b ne primenjivati bez prilagođavanja sadašnjem stanju.

Dodatni pregled prava potvrđuje i širi posao oko podrazumevanih dozvola: nove public tabele/funkcije dobijaju široke početne grantove, a deo postojećih tabela zadržava nepotrebna administrativna prava za klijentske uloge. To je konkretan posao sužavanja prava, bez dokazanog udaljenog puta za izvršavanje takvih SQL naredbi. Istovremeno je potvrđeno da anon/auth nemaju običan pristup private šemi, a closure pre-request zaštita je stvarno vezana za Data API. Upozorenja treba rešavati prema stvarnom pristupu i nameni. [E50]

## 9. Šta sačuvati, objediniti i povući

| Odluka | Konkretan deo | Razlog i uslov |
|---|---|---|
| Sačuvati | `useOwnedEditor`, request journal-i, account/focus/revision ograde | Aktivni vlasnici sprečavaju duplo pisanje, kasne rezultate i mešanje naloga. |
| Sačuvati | Potpisani review, digest, eksplicitni Save/publish i readback | AI predlog ne sme sam postati konačan poslovni rezultat. |
| Sačuvati | Novi lifecycle/ACK guard i post-save outbox | Imaju konkretne dokaze i rešavaju različite delove životnog ciklusa. |
| Sačuvati | SQL istorija i primenjeni ugovori | Stara migracija nije mrtva komponenta; brisanje istorije nije čišćenje UI-ja. |
| Objediniti značenje | Usluga, mode, handoff, cena, završetak i sledeće pitanje | Ista namera mora preživeti sve faze bez ponovnog nagađanja. |
| Izabrati ciljni režim | Dual background i explorer/direct/research putanje | Različite su u kontekstu, predlozima i obračunu; prvo dokazati jednakost potrebnih scenarija, zatim povlačiti višak. |
| Razdvojiti aktivno od starog | `aiNeedV2Ui` | Aktivni formatteri ostaju; manual editor helper-i bez običnih caller-a kandidati su za povlačenje. |
| Urediti preview granicu | `WorkerAiCard` | Pronađen mount je u designLab-u, aktivni worker chat ga ne montira. To nije razlog da se vrate parcijalne kartice. |
| Uslovno povući | `capturedParts`, `capturedSpeech`, dormant explicit-mode API | Pretraga običnog `src` nema aktivne spoljne caller-e za navedeni podskup. Proveriti kompatibilnost pre uklanjanja. |
| Uslovno povući | Stari term helper-i i označeni nekorišćeni izvozi adaptera | Brisati tačne funkcije, a ne mešovite fajlove sa živim name-adoption/recovery delovima. |
| Uslovno ukloniti | Potvrđeno nereferencirane početne Expo slike | Raniji vizuelni i caller dokaz postoji; izvorni bajtovi nisu obećanje iste uštede APK-a. |
| Urediti evidenciju | Stari operativni izveštaji, kandidati, proof manifesti | Jedan indeks i jasno CURRENT/HISTORICAL/REJECTED; stare komande nisu tekuće ovlašćenje. |
| Sačuvati provereno kompatibilno | Task reader-i, D12 review/comment ugovori, group-message izuzetak, ratingDue | Baseline sadrži mešavinu verzija. Popraviti imenovane nesklade bez vraćanja cele migracije. |
| Povezati postojeći ugovor | Full-snapshot semantika i aktivni dual put | Jedno značenje servisa/moda/grane; ne dodavati treći paralelni klasifikator. |
| Pojednostaviti stanje ekrana | Discovery error, compact, map/list status i lociranje | Rešiti uzročnu vezu i prostor panela pre opšteg restilizovanja. |
| Prekodirati tačnu vezu | Početni izbor kandidata i `worker_area_fit_v1` | Očuvati sačuvano područje kroz izbor i sve podržane fizičke načine; ne menjati ručnu prijavu usput. |
| Dopuniti postojeći projektor | Worker izvoz/arhivske kopije | `workAreas` mora ostati deo iste potvrđene namere kroz ceo život podataka. |
| Uskladiti postojeći red | Push worker, admission i resolver odredišta | Ograničen dovoljan rad, bez nepotrebnog slanja ili izgubljenog cilja pri validnim postavkama. |
| Uslovno povući | Nepovezani `SelectionRequestRegistry`, stari `workTrustModel.statsView` i temporal-conflict prototip | Sačuvati izbor naručioca sa memorijskim pending stanjem i proverom Dogovora, odvojeni trajni journal prijave radnika i publicTrustFacts; ne brisati celu oblast. |
| Kontrolisano povući | Legacy intake delete RPC sa odsutnim tabelama | Nema current caller-a i izvršni put je pokvaren; proveriti stare klijente i zavisnosti, bez izmišljene tvrdnje o dokazanom tuđem brisanju. |
| Izolovati kao istoriju | Dokazi koji brišu/reseed-uju, pauziraju cron ili menjaju zaštite | Korisni su samo uz tačno provereno izolovano okruženje, aktuelne pinove i vraćanje stanja. |

Ne treba označiti sve „V2”, „legacy”, „shadow” ili „proof” kao suvišno na osnovu imena. Jedan fajl može sadržati aktivan formatter, istorijski writer i testni adapter. Jedini pošten kriterijum je konkretna mapa potrošača, uloga u sadašnjem toku i potrebna kompatibilnost. `TEHNICKI_DOKAZI.md` daje izbor ključnih vlasnika i granica. Detaljne odluke po fajlu, obrazloženja i pronađeni pozivaoci sačuvani su u [jedinstvenom registru](dokazi/registar/consolidated_read_register.json). On sadrži i manje copy/helper i cleanup nalaze; nije samo brojač pročitanih fajlova. Pre čišćenja konkretnog dela treba pročitati njegov zapis i proveriti sadašnje pozivaoce. [E03] [E15] [E21] [E25]

Moja preporuka je ciljano konsolidovanje postojećeg sistema. Razgovor treba da ostane prirodan, a klasifikacija nevidljiva korisniku osim kada traži stvarno razjašnjenje ili pošteno objašnjava čekanje. Konačan izbor između postojećih AI režima treba da se zasniva na istom korpusu scenarija, kvalitetu, ceni i latenciji, a ne na tome koji naziv deluje novije.

### Koji testovi ostaju, koji se popravljaju, a koji se uslovno povlače

Test se vrednuje prema ponašanju koje korisnik zaista treba da dobije. Zelen rezultat ima tačno određenu granicu: može dokazati ispravnu zaštitu, uspešno ponavljanje postojećeg kvara ili samo prisustvo rečenice u promptu. Ta tri rezultata ne predstavljaju isto stanje proizvoda. [E47]

| Odluka | Konkretan kriterijum | Primer iz projekta |
|---|---|---|
| Sačuvati | Štiti važeću nameru, nalog, reviziju, potvrdu ili ishod ponovljenog pokušaja. | Pregled ne objavljuje sam; isti zahtev ne pravi drugi posao; kasni odgovor ne prelazi na drugi nalog. |
| Popraviti proveru | Proverava pogrešan poziv, dopušta odsutno obavezno polje ili preskočenu važnu granu. | Profilni test proverava pogrešni mock; provider smoke proverava klasifikaciono polje samo ako postoji. |
| Promeniti očekivanje i sačuvati regresioni slučaj | Današnji test čuva ponašanje koje treba ispraviti. | Test mape očekuje globalnu grešku posle MAP pada; test ocena ne čita ponovo kada su ID-jevi isti, iako se ocena može promeniti. |
| Dopuniti nedostajuću vezu | Dobar lokalni test ne prelazi granicu na kojoj se javlja stvarni kvar. | Pravi odgovor servera kroz pravi decoder; restart sa izgubljenim bajtovima; HALF panel na telefonu. |
| Uslovno zameniti ili arhivirati | Štiti povučeno pravilo ili napuštenu putanju, uz proverene potrošače i kompatibilnost. | Stari workflow pin, demo forma ili istorijsko pravilo ne postaju obavezni deo aplikacije zato što imaju test. |

**Konkretan nalaz o zelenim testovima:** test korekcije valute trenutno namerno potvrđuje da stara RSD cena ostaje; test background potvrde beleži da nepromenjen ulaz nema novi pokušaj posle neuspešnog čuvanja. Njihov PASS je dokaz ponovljenog problema. Pri popravci se reprodukcija čuva, a završno očekivanje postaje ispravno ponašanje. Test „jedno pitanje” proverava tekst instrukcije, pa još treba dokaz stvarnog odgovora i obrade. [E47]

Aktuelni `npm test` pokreće Jest testove. CI dodaje određene Node testove i provere izvora/tipova. Relevantni postojeći testovi post-save radnika i završetka oba načina rada nisu izabrani tim Node komandama. Plan sada navodi ciljanu selekciju za svaki R01–R12; ne predlaže pokretanje čitave istorije pri svakoj izmeni. Provera na telefonu ostaje zasebna tamo gde se odlučuje o mapi, rasporedu, glasu ili otvaranju obaveštenja. [E47]

**Granica čišćenja:** neizabran test nije automatski beskoristan. Istorijski dokaz može biti vredan nakon usklađivanja sa sadašnjim izvorom. Konačno povlačenje traži potvrdu da nije potreban aktivnom ili podržanom starom klijentu. Uklanjanje testa samo da bi rezultat bio zelen nije kriterijum dovršenog posla.


### Izvršivost čišćenja: šta sada tačno znamo

Broj od približno 14.000 testova ima osnovu u projektu. Kratki STATUS od 26.10. beleži 621 Jest paket i 14.131 test; noviji operativni status, ažuriran 27.10, beleži 622 paketa i 14.143 testa. To su rezultati prijavljeni u repozitorijumu, ne nova izvršenja ovog audita. Sadašnja deklarativna Jest selekcija obuhvata 622 testna fajla, dok šira registarska oznaka test/proof obuhvata 796 putanja. Broj fajlova, broj parametrizovanih slučajeva i broj korisnih provera nisu ista mera. Nijedan od tih brojeva ne znači da su svi ti testovi suvišni. [E48]

Isti STATUS navodi da je raniji ČISTO zahvat već uklonio više hiljada starih izveštaja, workflow-a i pomoćnih skripti iz aktivnog izvora, uz Git istoriju. Ovaj audit analizira preostali konkretan skup, bez ponovnog pripisivanja već uklonjenog viška današnjem checkout-u.

U preostalom sadržaju supabase/proofs i supabase/candidates imaju ukupno 1.507 putanja i približno 47,9% tekstualnih redova. To je značajan prostor za sređivanje istorije, duplikata i dokaznih alata, ali nije spisak 1.507 nepotrebnih fajlova. Pronađena je i 41 grupa bajtno identičnog sadržaja u 91 putanji; ponovljene kopije imaju 4.207.983 bajta. Među njima su aktivne slike i SQL kopije koje zahtevaju prevezivanje potrošača ili očuvanje porekla. Nije izmerena ušteda APK-a ili vremena rada. [E48]

Prethodni registar imao je 719 različito formulisanih preporuka. Nova operativna projekcija svodi ih na jasne vrste rada i za svaku putanju čuva izvornu odluku, dokaz i uslove; veze sa radnim zadacima navodi tamo gde je planirana konkretna promena. Devet zaostalih oznaka „čeka semantički pregled” usklađeno je u toj projekciji sa već završenim pregledom; to nisu novi nepročitani fajlovi. Za 912 putanja potrebno je ciljano razrešiti izvršnu zavisnost ako se odluči da se povlače, uglavnom razlikovanje istorijske kopije, potrebnog dokaza i aktuelnog potrošača. To nije 912 novih grešaka niti dozvola za masovno brisanje.

**Konkretan primer:** test starog owner-review builder-a je arhivski kandidat, ali je još eksplicitno naveden u CI-ju. Povlačenje mora obuhvatiti builder, njegov isključivi test i CI ulaz, uz prenos potrebnih provera na aktivni potpisani pregled. Drugi primer je tačno ponovljen test u prikazu Dogovora: uklanja se jedan identični testni blok, a ostali slučajevi istog fajla ostaju.

**Završen cleanup treba da ostavi proverljiv rezultat:**

1. Svako uklanjanje ima tačnu putanju ili simbol, razlog, aktivnu zamenu ili dokaz da zamena nije potrebna.
2. Pozivaoci, CI, build, generisanje i dokumentacija prevezani su u istoj promeni; nema zaostalih putanja.
3. Testovi proveravaju važeću nameru. Pozitivna očekivanja za povučenu ideju odlaze, a potrebne zaštite ostaju u tekućem toku.
4. Istorijski materijal koji ostaje ima konkretnu namenu i minimalan trag porekla. Samo premeštanje u folder „archive” ne isključuje fajl iz Jest ili TypeScript obuhvata.
5. Beleže se stvarni brojevi pre i posle: aktivne putanje, izabrani testovi, duplikati, trajanje provera i potreban build. Nema unapred obećanog procenta brisanja ili ubrzanja.

Plan razrađuje konkretne pakete, uključujući resurse, ručne editore, stare kartice, alternativne AI putanje, PHONE delove, istorijske testove, kandidate i generatore. Korisnik ne mora da odobrava svaki pomoćni fajl; implementator treba da dokaže da njegovo povlačenje čuva već određeni proizvod. [E48]

### Dodatno čišćenje stvarnog servera

Pronađen je jedan precizan kandidat za uklanjanje viška: indeks `work_taxonomy_service_scopes_lookup` pokriva iste dve kolone na isti način kao postojeći primarni indeks. Primarni ključ se čuva; uklanjanje pomoćnog indeksa ide kroz usku novu migraciju i proveru zavisnosti. Njegova zabeležena veličina je 8.192 bajta, pa ovo nije obećanje velikog ubrzanja. [E53] [E54]

Sa sedam DEV tabela bez primarnog ključa treba postupiti drugačije. Šest njih još je navedeno u aktuelnim inventarima zatvaranja naloga i redakcije podataka. Jedan `needs_snapshot` se stvarno čita u zaštitnoj funkciji i ulazi u dinamički obračun vlasništva. Prvo treba urediti te vlasnike, odrediti potreban dokaz i rok čuvanja, pa povući potvrđeni višak. Brisanje po nazivu „dev” ili „backup” moglo bi da pokvari sadašnji tok. [E52] [E53] [E54]

Slično važi za stare serverske ulaze: legacy intake delete ima zastarele reference, PHONE mora slediti odluku „Samo poruke” uz očuvan tačan lokacijski grant, a wrapper koji namerno odbija stari automatski upis kategorije možda još štiti kompatibilnost. Za njih plan daje tačan predmet, postojeće veze, zamenu, redosled i uslove povlačenja. Nema bezuslovne liste za veliko brisanje. [E50] [E54]

## 10. Redosled dovođenja do završenog stanja

Ovo je plan za kasnije odobreni implementacioni posao. **Nijedan paket u ovoj analizi nije implementiran.** Najnovija korisnička instrukcija ostaje analiza, bez kodiranja. Opis budućeg deploy-a nije samostalno ovlašćenje da se on izvrši.

| Paket | Konkretan posao | Kada je stvarno završen |
|---|---|---|
| 1. Uskladiti aplikaciju, server i privatnost čitanja | F21, F14/F15/F01, F16/F17: privatne kolone, verzije, Discovery, sopstveni zadaci i greške | Privatni podaci ostaju privatni; pravi odgovor prolazi pravi decoder oba podržana klijenta; mapa/lista i radnja imaju tačno stanje. |
| 2. Dovršiti značenje i povezivanje | F04–F08 i F18: katalog, ID, nova grana, kontinuitet, ceo BOTH, budžet, područje i raspoloživost | Nepromenjena usluga ostaje validna, promenjena se ponovo obradi, odgovarajuće područje i slobodno vreme ne ispadnu iz izbora. |
| 3. Zatvoriti cenu i neizvesne radnje | F02/F03/F11/F13: satnica/valuta, unknown abandon i dodatni profilni upis | Cena ima jedno značenje; ista radnja ima proverljiv ishod; paralelne promene i tuđi nalog su očuvani. |
| 4. Dovršiti razgovore i sačuvani prikaz | F09/F10/F12, requester tekst usluge, pregled/mapa i status svake usluge | Jedno potrebno pitanje, prirodan završetak, veran pregled i jasno sačuvan rezultat. |
| 5. Dovršiti ostatak i povući višak | F19/F20, SB01–SB15, X01–X06, kontakt smer, usko čišćenje i dokazni alati | Radne oblasti prolaze sve kopije, obaveštenja imaju dovoljan red i tačan cilj, preostali ekrani/nacrti imaju proverljive ishode. |
| 6. Dokazati stvarnu celinu | Tačan APK/OTA/server, dve uloge/nalozi, stvarni model i uređaji; uslovi izvoza/zatvaranja i release-a | Ceo posao i realni prekidi prođu; vreme/trošak se izmere; zatvorene funkcije se ne proglase spremnim na osnovu starog certifikata. |

Provera odgovarajuće granice ide uz svaki paket. Završni paket povezuje celu stvarnu upotrebu; nije razlog da se svi raniji problemi popravljaju bez lokalnog dokaza. Ne dodavati široke testove samo da poraste broj. Potrebne su pozitivna kontrola, reprodukcija imenovane greške i dokaz da popravka pokriva baš granicu koja je nedostajala.

Za server je potreban plan kompatibilnosti sa već instaliranom aplikacijom. Ne prepravljati primenjenu migraciju kao da time živi server postaje usklađen, niti slepo puštati ceo istorijski SQL kandidat. Treba pregledati novu konkretnu promenu funkcija, proveriti potpise i zavisnosti, pa potvrditi objavljeni sadržaj u odobrenom okruženju. Production ostaje zaseban presek prema važećem README-u. [E31] [E36]

Paket 2 može zahtevati izbor jednog ciljnog postojećeg AI puta. Odluka se zasniva na istom korpusu namera, tačnosti, trošku i latenciji. Ne uklanjati zaštitu revizije radi lakšeg prolaza; odvojiti semantičku stabilnost od revizije konačne korisničke potvrde.

## 11. Sporedni backlog koji ostaje deo cele slike

U posebnom kontinuitetnom pregledu proverena su 72 relevantna source fajla: 71 je bajtno isti između cb6 i a969. Intervju Edge je promenjen, ali tri relevantne image-only hash linije ostale su iste. To čuva raniji dokaz; ne pretvara staru reprodukciju u novo izvršavanje.

| Stavka | Konkretan preostali problem | Potreban ishod |
|---|---|---|
| SB01 — Početna | Kartica moje prijave vodi u vlasnički detalj tuđeg zadatka. | Otvoriti javnu priliku, uz postojeće serverske dozvole. |
| SB02 — Ocene | Novi podatak može ostati nevidljiv kada ID skup ostane isti ili nema obnove prve strane. | Osvežavanje posle ocene/povratka, uz očuvanje naloga. |
| SB03 — Pravila | Neizvestan stari pokušaj i novi hash dokumenata mogu ostati u READ_REQUIRED. | Završiti stari pokušaj i tražiti novu izričitu saglasnost. |
| SB04 — Glas | ABSENT može prerano ukloniti journal pre kasnog claim-a; postoje različiti read timeout-i. | Server cancel/reconcile i vidljiv oporavak, sa jednim budžetom čekanja. |
| SB05 — Avatar | Intent ostaje, izvorni bajtovi nestanu, a izbor nove slike ostaje blokiran. | Bezbedno otkazivanje/reconcile, zatim novi izbor. |
| SB06 — Podrška | Pozadina ili izlazak može obrisati neposlat formular/odgovor. | Nacrt istog naloga i jasna odluka pri izlasku. |
| SB07 — Dogovor | Neposlat predlog se resetuje; editor termina zahteva kraj koji izvorni ugovor možda nema. | Očuvanje nacrta i dosledan vremenski ugovor. |
| SB08 — Obaveštenja | Jedna postavka radi dva odvojena upisa; prvi može uspeti pre prekida drugog. | Pokazati oba ishoda i završiti samo preostali deo. |
| SB09 — Komentar | Obrazac obećava javni komentar, ali aktivni javni profil nema povezanu listu. | Usaglasiti javni prikaz i obećanje. |
| SB10 — Poruke | Ručna radnja osvežavanja postoji kao nevidljiva kontrola. | Dostupna radnja ili uredno povlačenje uz alternativu. |
| SB11 — Pretraga | Decode greška može zadržati busy; recent/fit keš ima uže ključeve od potrebnih. | Završiti neuspeh i obnoviti po stvarnim ulazima. |
| SB12 — Vremenska zona | Povezani ekrani mogu koristiti različita pravila prikaza istog vremena. | Jedna jasna politika uz očuvan stvarni instant. |
| SB13 — Mapa i animacije | Glavni Discovery kvar je izdvojen u F15/F16. Ostaju copy, lokalni draft drugih mapa i reduced-motion put. | Precizan prikaz, pristupačnost i predvidiv izlazak; bez dvostrukog brojanja istog nalaza. |
| SB14 — Proof/build | Build/CI nesklad, stari pinovi i fixture-i, mogući prazni/NULL prolazi, PASS uz neproveren podscenario i skripte za izolovanu bazu. | Proveriti i sam proverivač: aktuelni owner, nužan izlaz, sve grane, stvarna granica i bezbedno okruženje izvršenja. |
| SB15 — Image-only Edge | Claim i completion koriste različit tekst za isti sadržaj bez reči. Obični UI foto tok je zaseban. | Isti kanonski sadržaj i hash, uz zaštitu od izmene pod istim ključem. |

Posebno su vraćene tri konkretne granice testova: provider smoke može preskočiti proveru nedostajućeg klasifikacionog polja; source testovi staged SQL-a nisu izvršenje živog potpisa/transakcije; jedan profilni test proverava odsustvo poziva na pogrešnom mock-u. To su nedostaci dokazivanja, bez tvrdnje da je time dokazan korisnički incident. Tehnička referenca, odeljak 8, navodi tačne fajlove i uslov popravke.

Završno čitanje dodatno je proverilo **zašto prethodni test može proći pored stvarne greške**. Test ocena izričito čuva keš kada su ID-jevi isti, a nova ocena ne menja te ID-jeve. Testovi legal replay-a često zadržavaju iste hash-eve dokumenata. Test govora sa lažnom memorijom ne dokazuje oporavak posle gubitka procesa i bajtova. D12 runner ima pravi poslovni P5 tok, ali njegov završni PASS ne zahteva sve zasebno neproverene auto-complete/ratingDue/klijentske grane. To određuje konkretno šta treba dodati proveri, bez odbacivanja dobrih postojećih testova. [E42] [E43]

Manje stavke X01–X06 su u istoj tehničkoj referenci: oporavak oštećenog safety ključa, dva zapisa imena, stroži numerički/receipt decoder, zajednička konfiguraciona osnova, potpuni reset demo podataka i lifetime obaveštenja posle promene naloga. Svaka ima tačan source i ograničenje; nijedna se ovde ne predstavlja kao nova živa reprodukcija.

Ovi problemi ne nestaju zato što je poslednja etapa bila usmerena na AI. Istovremeno ih ne treba predstavljati kao sveže izazvane incidente na živom sistemu. `TEHNICKI_DOKAZI.md` čuva tačne vlasnike, kontinuitet hash-a i nivo ranijeg dokaza. Sveža smernica „Samo poruke za sad” dodatno zahteva da se kasnije proveri odnos sadašnjeg UI-ja, postojećih serverskih PHONE grantova i starijih klijenata; nije potvrđeno da je uklanjanje opcije sa ekrana zatvorilo sve starije mogućnosti. [E39]

## 12. Koji scenariji moraju da prođu

Korpus se koristi za prihvatanje budućeg rada, ne kao tvrdnja da je sve već prošlo. `CODEX_PLAN_RADA.md` vezuje ove scenarije za pakete, a `TEHNICKI_DOKAZI.md` za postojeće vlasnike i probe.

| Scenario | Šta se mora dokazati |
|---|---|
| Zadaci na lokaciji, sa i bez rezultata | PAGE i MAP odgovori prolaze stvarne dekodere; prazna lista ne uklanja geografsku podlogu; pinovi i lista imaju usklađen opseg. |
| PLACES, EXACT_PUBLIC, „Za mene”, minimalna cena i drugi ponuđeni filteri | Stari podržani i ciljni novi klijent imaju definisan serverski ugovor; uključiti HOURLY kompatibilnost i REMOTE bez fizičkog MAP zahteva. Odbijeni ili nepotpuni podaci ne izgledaju kao uspešna prazna lista. |
| MAP pad posle uspešnog PAGE | Validni zadaci ostaju smisleno dostupni; poruka tačno kaže šta nije učitano; retry ne ponavlja nepotreban ili nebezbedan rad. |
| Oba prikaza greške sa slika | Početni ulaz i retry čuvaju razumljiv tok; HALF/FULL/PEEK i navigacija ne zaklanjaju potrebnu radnju. |
| Moji zadaci | Pet scope-ova, svi counts, prazna/neprazna prva strana i nastavak prolaze pravi mapper. |
| Naručilac kaže više jasnih činjenica | Sve se sačuvaju; sledi samo jedno potrebno razjašnjenje; nema parcijalnih kartica. |
| Jasna usluga, drugi naziv i stvarno nova grana | Sinonim zadržava ID; nova usluga dobija potvrđen ID; nema ručnog administriranja kategorije. |
| Jednočlani jasan naziv | Sam nedostatak razmaka ne postaje dokaz nejasnoće; safety i stvarna semantika ostaju provereni. |
| „To je to”, vreme, budžet ili mapa posle klasifikacije | Nepromenjena usluga i izabrani modovi ostaju validni za tekući pregled; stvarna promena pokreće odgovarajuću novu obradu. |
| Izričito oba načina, provider vrati samo jedan | Nedostajući deo ostaje prepoznat kao nedovršen; uspešan podskup ne postaje cela READY ponuda. Pozitivna kontrola zadržava oba moda istog ID-ja. |
| Radionica, slanje i preuzimanje | REMOTE se ne pretvara u dolazak kod naručioca; handoff nije izmišljen niti tuđi predlog postaje korisnikova saglasnost. |
| Cena i valuta | Stari RSD iznos prestaje da bude potvrđen kada se promeni značenje; nema izmišljene konverzije; osnovica/uslovi isti kroz pregled, prijavu i Dogovor. |
| Novi tekst usluge i završna kartica | Sistem ne čeka skriveni `need.category` bez objašnjenja; ne meša nedostajući tekst sa konačnim category ID-jem. |
| Worker Save i Save+activate | Isti pregled dozvoljava odgovarajući izbor; stvarni decoder/SQL/readback čuvaju korisnikovu nameru. ACTIVE nije dokaz da je svaka nova klasifikacija spremna. |
| Promena bogatijeg profila | Menja se tačno tražena usluga/mod/područje; ostalo i nepogođena prava ostaju po server ugovoru. |
| Timeout, izgubljen odgovor, restart i A→B→A | Proverava se ista namera i važeći vlasnik/revizija; nema slepog dupliranja modela/upisa ili prelaska privatnog stanja drugom nalogu. |
| Nepotpuni katalog i nedostajući prvi plan | Parcijalni rezultat ne glumi kompletan katalog; zabeležen unutrašnji posao ima ograničen, proverljiv nastavak. |
| Odustajanje bez zasebnog zadatka | Unknown abandon readback utvrđuje stvarni OPEN/ABANDONED ishod, bez lažne poruke o sačuvanom zadatku. |
| Dostupnost od budućeg datuma i jedan izuzetak | Izričita promena ažurira stvarni kalendar i povezivanje samo u traženom periodu; ostala pravila ostaju. Lokalni datum, zona i stvarni trenutak ostaju dosledni, uključujući promenu sata. Kalendar nije zato obavezan deo svakog razgovora. |
| Privatnost, izvoz i zatvaranje naloga | Stvarni autorizovani izvoz, opoziv granta i završetak zatvaranja imaju tačan status/readback; kasni pokušaj ne vraća povučeni pristup. Ne izjednačavati zadržavanje podataka po važećem pravilu sa javnom dostupnošću. |
| Sačuvano područje, fizički način i vreme | Udaljena stara tačka ne izbacuje odgovarajuću zemlju/grad/radijus; podržani fizički načini i „danas, slobodan kasnije” imaju tačan zajednički ugovor. Ručna prijava ostaje po svojim pravilima. |
| Privatnost javnog zadatka | Tuđ javno vidljiv zadatak ne otkriva tri privatne kolone ni kroz direktan API; sopstveni i javni dozvoljeni prikaz i dalje rade. |
| Obaveštenje i njegova svrha | Već prijavljen korisnik ne dobija nepotrebnu istu priliku po dogovorenoj politici; PUSH on/IN_APP off ima validan tačan cilj; red i potvrde rade pod odabranim opterećenjem bez duplog slanja. |
| Područja kroz sve kopije | `workAreas` ostaje u potvrđenom profilu, živom i arhivskom izvozu; pristup je samo vlasniku, a erasure se dokazuje odvojeno. |
| Proverivač neuspeha | Izostao obavezan rezultat, NULL, preskočen podscenario ili lažni fixture ne mogu dati završni PASS za ceo imenovani scenario. |
| Dva čoveka završe posao | Prijava, izbor, poruke/foto/glas, promena, završetak i ocena ostaju u istom poslovnom kontekstu. |
| Pravi telefon i pristupačnost | Veći tekst, mali ekran, duga poruka, tastatura, screen reader, mapa i pozadina ostavljaju prohodan tok. Zabeleženi su source, OTA, backend i stanje scenarija. |

Dodatno je izričito uključena **zamena već objavljenog zadatka**: pregled izmene ne povlači staru objavu; uspešna nova objava i zatvaranje stare pripadaju jednoj transakciji; prijave se ne prenose na nove uslove. To je postojeći ugovor koji treba sačuvati, potvrđen čitanjem klijenta i aktuelnih serverskih tela, bez novog izvršavanja. „Samo poruke” se proverava i kroz stare klijente/server, uz očuvanu odvojenu dozvolu za tačnu lokaciju. [E47]

Plan sada prati 14 celih korisničkih situacija, od prvog opisa do ocene i života podataka. Jedna funkcija, isti ID ili lep ekran ne zatvaraju celu situaciju: završetak mora povezati vidljivu radnju, sačuvani rezultat i ono što druga uloga stvarno vidi.

Brzinu treba meriti od korisnikove radnje do prvog korisnog prikaza i potvrđenog ishoda. Trajanje jednog provider poziva nije celo čekanje čoveka. Trenutni source zadržava sirovi streaming tekst do potvrđenog completion-a; ubrzavanje mora sačuvati tu granicu ili imati jednako jasan novi ugovor. Nisu izmereni p50/p95, stvarna učestalost grešaka ili cena korpusa. [E01] [E03] [E06]

## 13. Šta još zahteva odluku ili stvaran dokaz


**Revizija 5 razdvaja četiri nivoa dovršenosti.** Sadržaj analiziranog izvora je pročitan; plan sada vezuje sve postojeće nalaze za kod i provere; pojedinačna brisanja i završni izgled imaju navedene izvršne uslove; stvarna popravljena aplikacija još nije dokazana. Nijedan niži nivo nije proglašen višim. [E48]

| Oblast | Šta je dovoljno određeno | Šta još treba dovršiti |
|---|---|---|
| Kod i uzroci | Sva 42 nalaza imaju odgovorne putanje/funkcije, radni zadatak i očekivani dokaz. | Osvežiti relevantan sadržaj pre izmene; napraviti i proveriti stvarnu popravku. |
| Čišćenje | Svaka praćena putanja ima normalizovanu preporuku, a konkretni paketi navode uklanjanje, očuvano i prevezivanje. | Zatvoriti uslove zavisnosti pre svakog povlačenja; nema bezuslovnog naloga za 3.434 fajla. |
| Ekrani | Poznati su tok, kvarovi, potrebna stanja i važeći podaci. | Izraditi konačnu specifikaciju i prikaz stanja po ekranu, pa proveriti uređaj. Nije nacrtan i potvrđen svaki piksel. |
| Poslovna pravila | Prirodan razgovor, tihi klasifikator, eksplicitna potvrda, oba načina rada i „Samo poruke” ostaju. | Precizirati uske granice satnice i područja pri poslovima sa više lokacija. |
| Gotov proizvod | Definisani su pozitivni i neuspešni tokovi obe uloge. | Pravi model, server, uređaji, prekidi, vreme i trošak još zahtevaju izvršni dokaz. |

### Završeni serverski pregled i preostale etape

**Revizija 7 je izvršila dodatni serverski pregled koji je revizija 6 samo planirala.** Tekuća struktura, izrazi, efektivna prava, Edge sadržaj, katalog/AI, Storage/Realtime i pozadinski/lifecycle lanci sada su povezani u istom paketu. Serverski manifest ima 14 konkretnih grupa promena sa identitetom, dokazom, svrhom, zavisnostima, zamenom, kompatibilnošću, redosledom, podacima/dozvolama, oporavkom i prihvatnim scenarijima. Nijedno destruktivno povlačenje nije označeno kao automatski spremno. [E49] [E54]

Ostale su precizne granice: kompletna Auth management konfiguracija nije dostupna kroz postojeći pristup; stvarne Edge secret/feature-flag vrednosti nisu čitane; stari klijenti i dinamički pozivi ne mogu se proglasiti odsutnim samo pretragom. Za 364 indeksa postoji strukturisan katalog i razvrstane preporuke, ali nema produkcionog workload dokaza za svaki. Izolovani bootstrap/upgrade, model, uređaj, dostava i merenje troška ostaju stvarni izvršni dokazi posle konkretnih izmena.

| Etapa | Rezultat ili sledeći izlaz | Status |
|---|---|---|
| Dodatna serverska analiza | Tekuća pravila i prava, svi Edge paketi, operativni lanci, plan klasifikatora/cache-a, migration poreklo i manifest promena. | Završena u navedenom obimu, sa izričito zapisanim ograničenjima. |
| Pregled novih ekrana | Ukršteni novi snimci, aktivni/povezani/nepovezani/nedostajući prikazi i stanja, nazivi i tekst. | Planiran u istom operativnom dokumentu, §3/§6/§10; novi vizuelni i uređajski rezultati tek se izrađuju u odgovarajućoj etapi. |
| Konačan opis USKOČI | Potpun opis naručioca, izvršioca i sistema, uključujući ispravke, prekide i završetak. | Povezane priče i J01–J14 već su u planu; konačna specifikacija svih radnji i stanja dopunjava iste dokumente tokom izvršavanja. |
| Implementacija i dokaz | Promene u R01–R12, usklađeno izdanje i provereni stvarni tokovi. | Još nisu izvršeni; ova isporuka ostaje analiza i plan. |

Četrnaest postojećih korisničkih tokova je osnova za kasniji konačan opis, ne već završena produktna specifikacija. Dve poslovne granice ispod nisu rešene umesto korisnika. Kontinuitet rada obezbeđuju isti važeći dokumenti, stabilne oznake, odluke, izvor, dokaz i preostali uslov; pre svake izmene proverava se tadašnji relevantan sadržaj. Nije potrebno oslanjati se na pretpostavku da svi redovi projekta stalno staju u razgovorni kontekst.

### Šta zaista može tražiti Miloševu odluku

**Satnica, R07b.** Treba odrediti šta znači, na primer, 1.200 RSD po satu kada rade dve osobe tri sata. Po osobi to bi bilo 7.200 RSD za taj poznati primer; za celu ekipu 3.600 RSD. To su ilustracije dve moguće osnovice, ne trenutni automatski obračun. Preporuka za najmanji jasan početni ugovor jeste satnica po osobi, izričito prikazana, uz procenu ukupnog iznosa kada je trajanje dogovoreno; kada trajanje nije poznato, prikazuje se dogovorena satnica bez izmišljene konačne sume. Druga osnovica mora biti zasebno jasna. Podrška obe osnovice može se izabrati ako to bolje odgovara proizvodu, ali se ne podrazumeva iz same reči HOURLY. Korekcija zastarele RSD cene, odustajanje i zaštita paralelne izmene ostaju nezavisni R07a/F11/F13 poslovi.

**Područje posla sa više lokacija, deo R05.** Za prevoz Novi Sad–Beograd treba jasno odrediti da li je za automatsku preporuku dovoljno da je preuzimanje u radnikovom području ili i ostale tačke moraju biti pokrivene. Trenutni workAreas dokaz ne zaključava jedno opšte pravilo za sve fizičke topologije. Preporuka za potvrdu jeste pokriće svih stvarnih radnih tačaka, a ne svake tranzitne tačke puta, uz vidljivu celu rutu. Alternativa samo sa polazištem daje šire preporuke prevoznicima. Nijedna od ovih opcija nije ovim auditom odobrena kao novo pravilo. Više odredišta ili posao na celoj oblasti zahtevaju odgovarajuću tipizovanu definiciju. Popravka stare profilne tačke, već definisanog STATIONARY područja i raspoloživosti „danas kasnije” ne čeka ovu odluku.

**Ne postaju nova obavezna pitanja:** izbor interne AI putanje, broj pomoćnih klasa, invalidacija keša, očuvanje podataka, raspored rada i imenovane popravke mape. Dodatne valute ostaju moguća promena proizvoda; trenutni RSD/OFFERS može se uredno dovršavati bez nje. REMOTE bez obaveznog fizičkog pina već je deo namere, dok potpuno uklanjanje administrativnog grada iz profila/aktivacije nije ista odluka i ne uvodi se usput. Povezivanje već obećanog javnog komentara ne zahteva ukidanje tog obećanja; promena njegove publike bila bi zaseban predlog. [E48]

### Kako će izgled i ponašanje postati konkretni

Za svaki primarni ekran R08/R11 treba da isporuče jedan kratak, pregledljiv opis: svrha i uloga, tačni podaci i vlasnik čitanja, glavna i sporedne radnje, stanja učitavanja/prazno/uspeh/greška/prekinut upis, povratak i nacrt, srpski tekst, tastatura, mali ekran, veći font i potrebna pristupačnost. Opis prati prikaz tih stanja u postojećem dizajnu. Tako se zajednička zamisao prevodi u proverljiv UI, bez novog paralelnog sistema ekrana.

Završni pregled mora pokazati istu sačuvanu nameru, a svaka poruka stvarni ishod. Za AI je persiranje već zapisano u zajedničkoj instrukciji; determinističke poruke istog razgovora treba uskladiti s njom. To ne dokazuje da je tekst svakog drugog ekrana već konačno odobren. Vizuelni raspored i kratke tekstove treba pripremiti kao celinu, uz očuvanje dogovorenog ponašanja. [E48]

**Nedostajući originalni dokument:** repo dokument `USKOCI_CISTO_STATUS_I_KONTINUIRANI_PLAN_26-10-2026.md` pominje `USKOCI_ULTRA_MASTER_PLAN_2026-10-26` i izvršnu komandu iz Downloads. Original nije bio dostupan ovom auditu; ciljano pretraživanje ga nije pronašlo. Nije proglašen pročitanim. Spornu poslovnu promenu kasnije treba vezati za stvarno pravilo ili izričitu novu odluku. To ne sprečava zaključke o sada potvrđenim tehničkim neskladima. [E48]

**Dokaz koji je sada dobijen:** dva stvarna stanja greške i About identitet, stari relevantni klijentski put, nekompatibilna živa Discovery funkcija i agregati istih unsupported-mode grešaka. Vremensko povezivanje sa fotografijama zavisi od pretpostavke o datumu/zoni telefona. Nema potrebe ponovo tražiti iste slike.

**Dokaz koji ostaje:** konkretan telefon/request nakon popravke, native/OTA/build presek, stvarni model i service→SQL→readback scenariji. Traženo potpuno čitanje praćenog sadržaja sada je završeno; sledeći korak je implementacija imenovanih veza i dokaz njihove stvarne upotrebe. Potpuno čitanje samo po sebi ne može dati garanciju da nema budućih grešaka. Daje proverljiv plan, poznate rizike i konkretne uslove završetka.

**Aktivacija zatvorenih funkcija:** aktuelni retention/export/erasure binding uslovi nisu ispunjeni. Trenutni server zato novi nespreman izvoz odbija pre stvaranja zahteva. Treba sačuvati iskren status i završiti celu proveru pre aktivacije. TEST izolacija vlasničkih/QA naloga namerna je u DEV-u; njen izlazak u stvarno izdanje mora biti izričit, uz proveren odvojen produkcioni backend. Stari certifikat ili dnevnik primene nije prečica. [E40] [E41] [E45]

**Sačuvane korekcije i uslovi obnove:** ranija sumnja da živa baza ignoriše samu promenu osnovice cene ostaje povučena — ranije preuzeto živo telo sadrži `priceBasis`, iako ga source prethodnik nema. Ostaje dokazivanje reproduktivne šeme. Tri istorijske proof migracije izričito očekuju pripremljene poslovne primere; bez celog izolovanog replay-a ne znamo da li prethodni koraci zadovoljavaju te uslove. Takođe treba proveriti stvarni opseg širokog granta privilegovanoj serverskoj ulozi; zapis da je migracija primenjena ne dokazuje njene izvorne bajtove ni današnje dozvole. Nije potvrđena nova ranjivost ili neuspeh svake prazne instalacije. Precizni izvori i granice su u tehničkoj referenci, F14 i odeljku 8.

**Granica čišćenja:** nema običnog caller-a nije automatska dozvola da se obriše endpoint starog klijenta, SQL istorija ili mešovit aktivni modul. Isto tako, dobar screenshot nije potvrda pozadinskog upisa, a zelen test sa mock serverom nije potvrda živog ugovora.

### Kako sada sprečavamo da završnica ostane samo opšta smernica

Operativni odeljci 3, 6 i 10 raspoređuju konkretne obaveze: matrica stvarnih ekrana u 20 oblasti, ugovor svake radnje u 16 polja, primer objave/profila/mape/izbora i deset podzadataka R12a–j. Odeljci 7 i 12 povezuju puni serverski posao sa priloženim dokazima. [E57] Svaka radnja povezuje korisnikov dodir, stvaran writer, potvrdu, ponovno čitanje i ono što vidi druga strana. Statusi specifikacije, dizajna, koda i uređajskog dokaza ostaju odvojeni. [E55]

Planirani pregled ima tri prolaza: sadašnje ponašanje, isti scenario posle popravke i konačno izdanje. Ne radi se o beskonačnom doterivanju. Prvo izdanje zatvara osnovni posao, pouzdanost, privatnost i obavezne uslove prodavnice; dodatni cache i svako istorijsko čišćenje ne postaju automatski razlog za odlaganje. Obećanu funkciju ipak ne uklanjamo bez jasne odluke. [E55]

Pre javnog izdanja treba dokazati novu dozvoljenu kombinaciju backend-a i build profila, potpis/identitet, native funkcije, SDK i dostavljeni paket. Posebno proveriti iOS AI govor, potrebna obaveštenja, stvarno brisanje naloga i saglasnost za spoljni AI. Aktuelne preview zaštite čuvaju se dok se ne uvede odgovarajući provereni ugovor; njihovim prostim gašenjem ne nastaje produkciona spremnost. [E56]

Objedinjavanjem u reviziji 10 nije ponovljen živi Supabase audit. Njegov poslednji potpuni dokaz ostaje vremenski označen revizijom 7. Revizija 9 ranije je potvrdila isti GitHub HEAD i ciljani izvor, uporedila planove i dokazne registre i proverila zvanične uslove prodavnica. Revizija 10 proverava oba ulazna plana, očuvanje svih priloga, usaglašenost dokumenata i PDF prikaze; ne preimenuje te ranije provere u nova izvršenja. [E57] Nema novog modelskog poziva, aplikacionog testa, build-a, migracije ili deploy-a. [E55] [E56]

**Konačna procena:** sada su povezani korisnikova zamisao, aktivni kod, konkretan prikaz sa telefona i objavljena serverska ograničenja. Najveća korist dolazi iz usklađivanja tih delova, očuvanja semantičkog rezultata i zatvaranja konkretnih tokova. Zadržati dobru osnovu i proverljive zaštite; svaku popravku završiti dokazom koji odgovara njenom stvarnom dometu.

## 14. Kako koristiti jedinstveni paket

Paket ima tri sadržajno različita dokumenta: **ovaj izveštaj** za celovitu sliku, **`CODEX_PLAN_RADA.md`** za redosled i kriterijume budućeg rada i **`TEHNICKI_DOKAZI.md`** za konkretne vlasnike, scenario i dokaz. Izveštaj i plan imaju po jedan PDF istog sadržaja. Kratki `PROCITAJ_PRVO.md` je indeks. Dve prethodne verzije plana sačuvane su pod `dokazi/objedinjavanje_rev10/ulazi/` isključivo kao dokaz porekla, a ne kao konkurentne verzije za rad.

Folder `dokazi/` sadrži registar čitanja **i detaljnih odluka po fajlu**, odabrane rezultate, analitičke probe, definicije, parity evidenciju i tri originalna snimka. To je proverljiva tehnička podloga; korisnik ne mora da čita desetine sirovih fajlova da bi razumeo zaključak. Manifest navodi putanje, veličine i SHA-256 sadržaja. Odeljak 12 jedinstvenog plana pokazuje koji zadatak koristi koji prilog: glavni dokumenti daju smisao i redosled, a tačan zahvat se oslanja na relevantne registre, definicije i rezultate. Nije potrebno ponovo čitati sve priloge pri svakom malom zadatku. [E57]

Registar čuva način punog pokrića svake tekstualne putanje: direktno čitanje, isti ranije pročitani sadržaj, ceo diff ili potpuni strukturisani pregled. Ranije parcijalne/pretražene beleške ostaju kao istorija, uz završni status. Binarni pregled, istorijski instalirani izvor, trenutna serverska tela i slike vode se odvojeno. Test receipt i dalje razlikuje izvršeni test, uspešnu reprodukciju kvara, read-only definiciju, čitanje istorijskog testa i neizvršenu celu korisničku putanju.

**Kontrola potpunosti prethodnog punog pregleda:** svih 17 ranijih F grupa, 15 SB i šest X grupa ostaje u istom paketu. Dodate su F18–F21, a novi detalji uklopljeni u odgovarajuće postojeće nalaze i plan. Sačuvani su izvorna obrazloženja i preporuke 611 ranijih UI/data zapisa, celovita nova čitanja i sve referentne veze. To nisu dodatni jedinstveni fajlovi za sabiranje. Završni registar proverava svih 3.434 putanje prema bajtovima analiziranog checkout-a, a 680 aktuelnih funkcija ima zaseban potpuni trag. Tehnička referenca objašnjava prenose i granice; nema drugog izveštaja koji poništava ove zaključke.

Originalni aplikacioni checkout ostaje čist. Napravljeni su samo analitički materijali izvan njega. Paket ne sadrži ceo checkout, zavisnosti, ključeve ili sadržaj korisničkih poslovnih redova. Pri sledećem radu treba proveriti da li su source i server promenjeni posle ovog preseka; postojeći zaključak se ne prenosi automatski na nove bajtove.

Najnovija korisnička instrukcija ima prednost nad starim dozvolama u repo dokumentima. Samo predavanje ovog paketa Codexu ne pretvara analizu u ovlašćenje za implementaciju, poslovni upis ili objavu. Ako korisnik zada konkretnu popravku, paket daje spremno polazište za taj rad.

Revizija 4 dodaje operativnu vezu 14 tokova i 12 zadataka, 45 tačnih izvornih putanja za testnu matricu, sedam preciziranih ciljnih odluka i proveru aktuelne CI selekcije. Prethodni broj pročitanih fajlova nije uvećan ponovnim pregledom. GitHub i svih 680 otisaka tela/definicija/dozvola ponovo su provereni i ostali su isti; proverene Edge verzije ostaju iste. Nema novih glavnih grupa kvara, izvršenih aplikacionih testova ili promene proizvoda. [E47]

Revizija 5 proverava izvršivost celog plana, dodaje 19 cleanup paketa i osam R11 podzadataka, normalizuje odluke za sve praćene putanje i precizira dve poslovne granice. Sve dopune su u istim dokumentima. GitHub i 680 function body/definition/ACL otisaka ponovo su nepromenjeni; 15 Edge deployment metapodataka je isto. Nema novog aplikacionog PASS-a ili izvršenog brisanja. [E48]

Revizija 6 je precizirala naredni serverski pregled. Revizija 7 ga je izvršila i usaglasila ova ista tri dokumenta sa novim nalazima. E49–E54 povezuju sadašnji katalog/prava, svih 15 Edge paketa, operativne agregate, migraciono poreklo i jedinstveni manifest. Osnovnih 42 F/SB/X oznaka ostaje stabilno; nove pojedinosti imaju eksplicitnu vezu sa postojećim R zadacima. Broj pročitanih source fajlova nije veštački uvećan ponavljanjem. Aplikacija i živa baza ostaju nepromenjene.

Revizija 9 integriše dostavljenu reviziju 8 u iste dokumente. Sve 42 grupe nalaza, 19 C paketa i 14 SV grupa ostaju, uz ispravljen trenutni F03 acceptance i preciziranu granicu logičkog događaja naspram fizičkog push-a. Novi R12a–j i ugovor ekrana/radnje dopunjuju postojeće detalje. Puni originalni dokazni sadržaj je sačuvan; novi pregled ne predstavlja novi live server ili uređajski PASS. [E55] [E56]

Revizija 10 objedinjuje obe rev9 verzije u jedan operativni dokument, sa punim SV zapisima i jasnom mapom korišćenja dokaza. Sve prethodne sadržajne putanje sačuvane su, a provereni aktivni dokumenti i njihove PDF verzije imaju isti važeći presek. Nova isporuka nije dodatni konkurentni plan i nije potvrda izvršenih popravki. [E57]

## 15. Izvori i dokazna evidencija

Oznake E01–E57 vode na primarni source tačnog commit-a ili spakovani dokaz. Za lokalni rad trenutni source je `/workspace/scratch/f356024cf009/audit/deep-review/source/`; relevantni istorijski izvor sa telefona je u audit radnoj kopiji `audit/consolidated-review/installed-source/`. GitHub izvor nije automatski dokaz sadržaja servera. U raspakovanom paketu relativni dokazni linkovi imaju isto značenje kao u ovom tekstu.

| Oznake | Sadržaj i domet |
|---|---|
| E01–E03 | Aktivne requester/worker rute, vlasništvo, pregled, Save i tok. |
| E04–E06 | Lifecycle/currency dokument, ugovor mode/handoff-a i aktivni background modul. |
| E07–E13 | CI metapodaci, worker Edge, test politika, review client i dva različita vlasnika mape. |
| E14–E20 | Živi review/cena ugovori, worker decoder, oblasti, own-tasks mapper i probe kataloga. |
| E21–E25 | Sačuvani profil, kombinovani guard, sporedni upis posle prijave, source/deploy razlike i mešovit UI modul. |
| E26 | Tri originalna snimka i agregirani serverski zapisi; nema pojedinačnog telefonskog request ID-ja. |
| E27 | Živa Discovery definicija, byte parity sa baseline telom i read ledger instaliranog/sadašnjeg puta. |
| E28 | Poređenje UI izvora, kompaktnost, mapa/panel i geometrija. |
| E29 | GitHub ref, installed commit i compare metapodaci; broj commit-a nije broj popravki. |
| E30 | AI semantičke lokalne probe, sveža SQL parity provera, izvršeni/izostavljeni delovi. |
| E31 | Svih 12 baseline ugovora: dva nesklada, devet kompatibilnih i jedan opcioni podatak. |
| E32 | Objedinjeni coverage registar, hash-evi i odvojeno novo čitanje. |
| E33–E34 | Discovery karakterizacija, postojeći test podskup, stari decoder i boolean greška. |
| E35 | Agregirani advisory metapodaci; nisu samostalna potvrda ranjivosti. |
| E36–E39 | Važeći README, semantički SQL/klijentski izvori, postojeći full-snapshot prompt i STATUS odluke. |
| E40 | Potpun trag 680 trenutnih funkcija i njihove celovite pročitane definicije. |
| E41 | SQL kandidati naspram trenutnog servera: područja, izvoz, dispatch, push, primenjene i neprimenjene promene. |
| E42 | Završni pregled svih dodeljenih klijentskih testova, pomoćnika, UI i referentnih prikaza. |
| E43 | Završni pregled proof skripti: stvarni nivo, stare pretpostavke, granice PASS-a i bezbednost izvršavanja. |
| E44 | Celoviti strukturisani registri, dependency/lock/corpus/payload pregled i root zaključci. |
| E45 | Aktuelni kataloški presek, konfiguracija, readiness, indeksi/ograničenja/trigger-i i poređenje istorije. |
| E46 | Ponovljeno dekodiranje i vizuelni pregled svih 99 binarnih resursa i 18 SVG-ova. |
| E47 | Namena → 14 tokova → R01–R12 → postojeći/potrebni testovi; ciljane odluke, CI selekcija i ponovljena svežina izvora. |
| E48 | Izvršivost: svih 42 nalaza, tačni vlasnici i provere, R11a–h, 19 cleanup paketa, svih 3.434 odluka, korisničke granice i sveža nepromenjena fizička istina. |
| E49 | Završni serverski obuhvat, nov potvrđeni nalaz i granice revizije 7. |
| E50 | Tekući schema/izrazi/ACL/Auth pregled i dva dodatna RLS helpera. |
| E51 | Svih 15 Edge paketa, potpuno stablo, dokaz redosleda i usklađen cache plan. |
| E52 | Šest operativnih lanaca, Storage/Realtime, cron/HTTP/readiness i lifecycle. |
| E53 | Migraciono poreklo, puna tri CRLF diff-a, performansne preporuke i zavisnosti. |
| E54 | Jedinstveni popis server objekata i 14 konkretnih grupa promena sa izvršnim uslovima. |
| E55 | Poređenje pune rev7 i primljene rev8, svih 42/19/14 jedinica, korekcije i očuvane granice; dokumentacioni pregled rev9. |
| E56 | Konkretni build/native/iOS/push vlasnici, R12a–j, uslovi artefakta i spoljne zavisnosti; bez izvršenog build-a. |
| E57 | Objedinjavanje obe rev9 verzije u rev10, očuvanje 42/19/14 jedinica i svih priloga, precizni ugovori i mapa korišćenja dokaza; bez novog aplikacionog ili živog serverskog izvršenja. |

`TEHNICKI_DOKAZI.md` daje precizne putanje i raspone po F/SB/X nalazima. `dokazi/VERIFIKACIJA.json` razdvaja nivoe provere i ograničenja. Primeri fixture-a su sintetički; SQL fajlovi sadrže definicije, a log evidencija agregate, bez privatnog sadržaja tuđih poslova.

[E01]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/app/%28app%29/nova.tsx
[E02]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/app/%28app%29/pregled-zadatka.tsx
[E03]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/app/%28app%29/profil/razgovor.tsx
[E04]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/docs/ai-stabilization/07_BACKGROUND_COMPLETION_AND_CURRENCY.md
[E05]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/supabase/functions/_shared/workerServiceModeContext.mjs
[E06]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/supabase/functions/_shared/backgroundTaxonomyArchitect.mjs
[E07]: https://github.com/uskocibusiness-boop/USKOCI-EAN/actions/runs/40452826819
[E08]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/supabase/functions/uskoci-worker-interview/index.ts
[E09]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/jest.urgent-env.cjs
[E10]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/data/aiTaskReviewClientService.ts
[E11]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/ui/v2/IntakePresentation.tsx
[E12]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/ui/location/ConversationPointAsk.tsx
[E13]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/ui/location/NeedLocationForm.tsx
[E14]: dokazi/prethodna_etapa/live_review_catalog_definitions.json
[E15]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/data/workerAiClientService.ts
[E16]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/contracts/workerAreas.ts
[E17]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/data/ownTasksPage.ts
[E18]: dokazi/prethodna_etapa/live_sql_definitions.json
[E19]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/supabase/proofs/ai/currency_correction_characterization.test.mjs
[E20]: dokazi/prethodna_etapa/server_catalog_probe_result.json
[E21]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/ui/workerProfile/WorkerProfileSaved.tsx
[E22]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/data/__tests__/ai-natural-server-guard.test.ts
[E23]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/app/%28app%29/prilike/%5Bid%5D/prijava.tsx
[E24]: dokazi/prethodna_etapa/live_source_parity.json
[E25]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/src/data/aiNeedV2Ui.ts
[E26]: dokazi/nova_etapa/discovery_log_evidence.json
[E27]: TEHNICKI_DOKAZI.md
[E28]: dokazi/layout/layout_read_ledger.json
[E29]: dokazi/nova_etapa/installed_to_current_compare.json
[E30]: dokazi/ai/semantic_completion_probe.json
[E31]: TEHNICKI_DOKAZI.md
[E32]: dokazi/registar/coverage_summary.json
[E33]: dokazi/discovery/characterization_results.json
[E34]: dokazi/discovery/validation_receipt.json
[E35]: dokazi/nova_etapa/advisory_summary.json
[E36]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/README.md
[E37]: TEHNICKI_DOKAZI.md
[E38]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/supabase/functions/_shared/classificationGeminiShadow.mjs
[E39]: https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/STATUS.md


[E40]: dokazi/zavrsni_pregled/function_body_review.json
[E41]: dokazi/zavrsni_pregled/candidate_review.json
[E42]: dokazi/zavrsni_pregled/client_review.json
[E43]: dokazi/zavrsni_pregled/proof_review.json
[E44]: dokazi/zavrsni_pregled/root_review.json
[E45]: dokazi/zavrsni_pregled/live_catalog_crosscheck.json
[E46]: dokazi/zavrsni_pregled/asset_review.json

[E47]: dokazi/namena_i_testovi/intent_review.json

[E48]: dokazi/izvrsivost/readiness_review.json

[E49]: dokazi/server_final/server_review.json

[E50]: dokazi/server_final/schema_review.json

[E51]: dokazi/server_final/edge_review.json

[E52]: dokazi/server_final/operations_review.json

[E53]: dokazi/server_final/migration_performance.json

[E54]: dokazi/server_final/change_manifest.json

[E55]: dokazi/provera_plana/comparison_review.json

[E56]: dokazi/provera_plana/release_review.json

[E57]: dokazi/objedinjavanje_rev10/merge_review.json
