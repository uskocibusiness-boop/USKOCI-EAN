# USKOČI — jedan plan, kompletni izvori i jedna predaja

**27.10.2026. · Revizija dokumentacije 10.** Paket spaja pregledniju organizaciju priloženog plana sa preciznijim uslovima i celom dokaznom podlogom našeg poslednjeg paketa. **Jedini važeći operativni plan je `CODEX_PLAN_RADA.md`; njegov PDF prikazuje isti sadržaj.**

Završeno je objedinjavanje dokumentacije. Aplikacija i baza nisu menjane, niti su ponovo pokretani aplikacioni testovi, stvarni model, build ili objavljivanje.

## 1. Šta da otvorite

| Fajl | Čemu služi |
|---|---|
| [USKOCI_IZVESTAJ.pdf](USKOCI_IZVESTAJ.pdf) | Izveštaj za čitanje, **37 strana**: stanje, uzroci, očuvana dobra osnova, obe uloge, čišćenje i preostali posao. |
| [USKOCI_IZVESTAJ.md](USKOCI_IZVESTAJ.md) | Isti izveštaj za pretragu i dalji rad. |
| [CODEX_PLAN_RADA.pdf](CODEX_PLAN_RADA.pdf) | **Ceo operativni plan, 114 strana**: redosled, zadaci, vlasnici, poznate putanje, testovi, čišćenje, server, ekrani i izdanje. |
| [CODEX_PLAN_RADA.md](CODEX_PLAN_RADA.md) | Jedini operativni dokument koji se dalje ažurira. Odeljak 12 povezuje zadatke sa tačnim dokaznim fajlovima i zapisima. |
| [TEHNICKI_DOKAZI.md](TEHNICKI_DOKAZI.md) | Tehnička referenca: vlasnici koda, obrazloženje nalaza, postojeće probe i granice dokaza. |
| `dokazi/` | Puni registri, serverske definicije i manifest, odluke po fajlovima, probe, rezultati, originalne tri slike i poreklo objedinjavanja. |
| [MANIFEST.json](MANIFEST.json) | Popis svakog sadržajnog fajla, veličina i SHA-256 za proveru potpunosti prenosa. |

Paket ima **138 sadržajnih fajlova i jedan manifest**: šest osnovnih fajlova iz korena i 132 priloga u `dokazi/`. Prethodni paket imao je 130 sadržajnih fajlova, od kojih 125 u `dokazi/`; nijedna prethodna putanja nije izgubljena. Napomena o „120 nedostavljenih dokaza” opisivala je raniji nepotpuni prilog u drugom razgovoru. U ovoj predaji izvori su uključeni.

## 2. Šta je spojeno i sačuvano

- **42 grupe nalaza** F01–F21, SB01–SB15 i X01–X06 povezane su sa 12 zadataka R01–R12 i uslovima završetka.
- Sačuvani su **14 tokova J01–J14**, 25 prihvatnih scenarija A01–A25, osam podzadataka R11 i deset podzadataka R12.
- **19 paketa čišćenja C01–C19** čuva svih 180 imenovanih putanja, razloge, potrošače, zamene i uslove povlačenja. Starost fajla ili broj testova nisu nalog za brisanje.
- **Svih 14 serverskih grupa SV01–SV14** ima puni opis u samom planu, ukupno 168 izvršnih polja. Manifest sa 3.037 zapisa o objektima ostaje priložen.
- UI/UX završnica obuhvata **20 oblasti** za popis ekrana i **16 polja** za opis važne radnje. Specifikacija, dizajn, implementacija i dokaz sa uređaja imaju odvojene statuse. Sva ta stanja još nisu nacrtana i dokazana.
- Usklađeni su AI kontinuitet, oba načina rada, potpisani pregled, objava i potvrda rezultata, Save/Save + aktivacija, RSD/OFFERS, privatnost i priprema Android/iOS izdanja.

Prethodni planovi su samo istorijski ulazi pod `dokazi/objedinjavanje_rev10/ulazi/`. Aktuelne dopune ugrađene su u odgovarajuće odeljke plana, izveštaja i tehničke reference.

## 3. Kako Codex koristi paket

Predajte **ceo ZIP** i omogućite pristup odgovarajućem repozitorijumu. Ovo je kompletan paket analize i plana; ceo aplikacioni checkout i instalirane zavisnosti ostaju u repozitorijumu.

1. Pročitati ovaj indeks i `CODEX_PLAN_RADA.md` radi važećih pravila, obima i redosleda.
2. Za izabrani R/C/SV zadatak otvoriti odgovarajući nalaz u `TEHNICKI_DOKAZI.md` i priloge iz **odeljka 12 plana**.
3. Pre izmene proveriti relevantni sadašnji kod, a za serverski zahvat i sadašnje stanje ciljnog okruženja. Stari dokaz se ne prenosi automatski na novi sadržaj.
4. Izvršavati korisnikov konkretno odobreni obim i ažurirati isti plan, nalaz i dokaz rezultata.

Tekst za predaju:

> Raspakuj ceo USKOČI REV10 paket i pročitaj PROCITAJ_PRVO.md i CODEX_PLAN_RADA.md. To je važeći plan. Za konkretan zadatak koristi tehničku referencu i priloge iz odeljka 12. Pre izmene uporedi relevantni kod i server sa dokumentovanim presekom. Čuvaj potvrđenu nameru proizvoda i postojeće zaštite; rezultate dopunjavaj u istim dokumentima. Samo predavanje paketa nije dozvola da započneš neodobrene izmene ili objavljivanje.

Nije potrebno svaki put ponovo čitati svih 132 priloga. Moraju biti dostupni, a za konkretan zahvat treba otvoriti odgovarajući puni zapis. Nekoliko sažetih dokumenata bez registra, serverskog manifesta i dokaza ne prenosi isti nivo detalja.

## 4. Šta još traži odluku ili izvršenje

Dve uske poslovne odluke ostaju otvorene: satnica po osobi ili za ekipu (**Z10/D06**) i pravilo pokrivanja više radnih lokacija (**Z10/D08**). Z09/D06 pripada starijem registru i znači „Samo poruke”; plan razdvaja ta imena. Nezavisne tehničke popravke ne čekaju te odluke.

Konačni opisi ekrana, vizuelni predlozi, provere na telefonu, stvarni AI tokovi, dostava obaveštenja, bootstrap/upgrade, trošak i produkciono izdanje dovršavaju se kroz R01–R12. Dokumentaciona provera nije potvrda da je aplikacija već popravljena.

## 5. Izvor i datum dokaza

Repozitorijum: `uskocibusiness-boop/USKOCI-EAN`; grana: `feature/uskoci-cisto`; commit: `a9692e11942609bab9406215c3e407d79589dafa`. Lokalni checkout ostao je na tom commitu i čist. **Revizija 10 nema novu udaljenu GitHub ili živu Supabase proveru.** Poslednji dodatni puni živi serverski pregled pripada reviziji 7; ciljane source/release provere i zvanični izvori politika pripadaju reviziji 9. Prilozi zadržavaju svoje datume i granice.

Kumulativni registri opisuju pregled 3.434 praćene putanje, uz odvojene metode čitanja i nivoe dokaza. Novi paket ih ne pribraja kao ponovo pročitane. Tri sačuvane slike telefona prikazuju stariji izvor `fcef803…` i OTA `01a163c4`; ne izjednačavaju se sa punim sadašnjim checkout-om.

Paket ne sadrži izdvojene ključeve, zavisnosti ili uzorke privatnih poslovnih redova. Istorijske probe i SQL definicije su dokaz; ne pokreću se na živom sistemu samo zato što su u arhivi.

## 6. Završna kontrola

- [Objedinjavanje, ulazi, očuvane jedinice i semantičke provere](dokazi/objedinjavanje_rev10/merge_review.json).
- [PDF i paket: završna provera](dokazi/PDF_I_PAKET_PROVERA.json).
- [Verifikacija i granice izvršenog](dokazi/VERIFIKACIJA.json).
- [Izvršna matrica i čišćenje](dokazi/izvrsivost/readiness_review.json).
- [Registar pregledanih putanja](dokazi/registar/consolidated_read_register.json) i [obuhvat](dokazi/registar/coverage_summary.json).
- [Serverski pregled revizije 7](dokazi/server_final/server_review.json) i [puni serverski manifest](dokazi/server_final/change_manifest.json).

Sirovi dokazi su sačuvani; metapodaci o aktuelnoj dokumentaciji ažurirani su uz istoriju. Manifest navodi konačne otiske ovog paketa. Interni otisci starih potvrda važe za njihove tadašnje verzije. Relativni linkovi istorijskih ulaza čitaju se u originalnom kontekstu; za aktuelnu navigaciju koriste se ovaj indeks i glavni plan.
