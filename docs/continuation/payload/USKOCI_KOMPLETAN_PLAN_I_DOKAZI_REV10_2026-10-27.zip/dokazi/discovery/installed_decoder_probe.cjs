/* Analysis only. Executes the two actual decoder files with synthetic public rows.
 * Imported market/geography helpers are unreachable because their fields are null;
 * a throwing stub prevents this probe from silently relying on their behavior.
 */
const fs = require('fs');
const vm = require('vm');
const crypto = require('crypto');
const ts = require('/workspace/scratch/f356024cf009/audit/repo/node_modules/typescript');
const root = '/workspace/scratch/f356024cf009/audit';
const sources = {
  installed: `${root}/consolidated-review/installed-source/src/data/discoveryV1Contract.ts`,
  current: `${root}/deep-review/source/src/data/discoveryV1Contract.ts`,
};
function decoder(path) {
  const source = fs.readFileSync(path, 'utf8');
  const exports = {};
  const unreachable = () => { throw new Error('UNEXPECTED_IMPORTED_HELPER'); };
  vm.runInNewContext(ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText, {
    exports,
    require: name => {
      if (name === '../lib/location') return { normalizeTaskGeography: unreachable };
      if (name === '../lib/market') return { countryCode: unreachable, timeZone: unreachable };
      throw new Error(`UNEXPECTED_IMPORT:${name}`);
    },
  }, { filename: path });
  return { exports, sha256: crypto.createHash('sha256').update(source).digest('hex') };
}
const AT = '2026-10-27T06:50:00.000000Z';
const FILTER = 'a'.repeat(32);
function item(priceBasis, index = 1) {
  return {
    id: `00000000-0000-4000-8000-${String(index).padStart(12, '0')}`, revision: 1,
    sortAt: AT, publishedAt: AT, title: 'Synthetic audit task', category: 'Audit', status: 'PUBLISHED', urgent: false,
    scheduleKind: 'FLEXIBLE', startsAt: null, endsAt: null, executionLocationMode: 'STATIONARY',
    taskCountryCode: null, taskTimezone: null, verifiedIdentityRequired: false, approximateCity: null,
    approximateArea: null, pin: null, requiredSlots: 1, coveredSlots: 0, requiredSkills: [], requiredTools: [],
    requiredVehicles: [], requiredLicenses: [], minimumExperienceYears: null, priceMode: 'MY_PRICE',
    requesterPriceRsd: 1000, priceBasis, requesterProfileId: '11111111-1111-4111-8111-111111111111',
    responseDeadline: null, acceptsApplications: true, publicTopology: null, criticalConditions: null,
  };
}
function page(items) {
  return {
    version: 'DISCOVERY_V1', mode: 'PAGE', asOf: AT, filterKey: FILTER,
    anchor: { version: 'DISCOVERY_V1', filterKey: FILTER, timeAt: AT, publishedThrough: AT, expiresAt: '2026-10-27T07:20:00.000000Z' },
    items, hasMore: false, nextCursor: null,
    counts: { kind: 'exact_live', observedAt: AT, mapped: items.length, listed: items.length, inArea: items.length, withoutPoint: 0, undated: 0 },
    availability: { hasKnownWorkMode: true, hasKnownSchedule: true, priceModes: ['MY_PRICE'] },
  };
}
const result = {
  scope: 'Actual installed/current decoder source; synthetic data only; no server calls; imported helpers unreachable by null fixture fields.',
  sources: {},
  cases: [],
};
for (const [version, path] of Object.entries(sources)) {
  const actual = decoder(path);
  result.sources[version] = { path, sha256: actual.sha256 };
  for (const priceBasis of ['TOTAL', 'PER_PERSON', 'HOURLY']) {
    const value = page([item(priceBasis)]);
    try {
      const decoded = actual.exports.decodeDiscoveryV1Page(value, 50);
      result.cases.push({ version, priceBasis, accepted: true, count: decoded.items.length });
    } catch (error) {
      result.cases.push({ version, priceBasis, accepted: false, error: error.message });
    }
  }
  try {
    const decoded = actual.exports.decodeDiscoveryV1Page(page([item('TOTAL'), item('HOURLY', 2)]), 50);
    result.cases.push({ version, priceBasis: 'mixed TOTAL + HOURLY', accepted: true, count: decoded.items.length });
  } catch (error) {
    result.cases.push({ version, priceBasis: 'mixed TOTAL + HOURLY', accepted: false, error: error.message });
  }
}
const oldHourly = result.cases.find(row => row.version === 'installed' && row.priceBasis === 'HOURLY');
const newHourly = result.cases.find(row => row.version === 'current' && row.priceBasis === 'HOURLY');
if (oldHourly.error !== 'DISCOVERY_V1_ITEM_PRICE_BASIS' || !newHourly.accepted) throw new Error('CHARACTERIZATION_NOT_CONFIRMED');
fs.writeFileSync(`${root}/consolidated-review/work/discovery/installed_decoder_probe_result.json`, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
