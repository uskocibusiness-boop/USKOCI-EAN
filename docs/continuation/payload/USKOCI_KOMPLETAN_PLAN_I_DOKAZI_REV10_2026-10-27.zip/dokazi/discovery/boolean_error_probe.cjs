// Analysis-only probe; runs actual pure focusedResource module and actual route expression.
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const crypto = require('crypto');
const ts = require('/workspace/scratch/f356024cf009/audit/repo/node_modules/typescript');
const source = '/workspace/scratch/f356024cf009/audit/deep-review/source';
const purePath = path.join(source, 'src/data/focusedResource.ts');
const routePath = path.join(source, 'src/app/(app)/zadaci.tsx');
const pure = fs.readFileSync(purePath, 'utf8'), route = fs.readFileSync(routePath, 'utf8');
const expr = route.match(/errorMessage=\{(.+)\}/)?.[1];
if (!expr) throw new Error('Route expression changed; review before running.');
function compile(text) {
  const exports = {};
  const code = ts.transpileModule(text, {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
  vm.runInNewContext(code, {exports, AbortController, Date, Promise, Set});
  return exports;
}
const {createFocusedResource} = compile(pure);
const {routeMessage} = compile(`export const routeMessage=(resource:any)=>(${expr});`);
(async()=>{
  const inputs = [new Error('AUTH_REQUIRED'),{message:'permission denied for table needs',code:'42501'},new Error('OPPORTUNITIES_RESPONSE_INVALID'),new Error('Network request failed'),new Error('MARKETPLACE_READ_TIMEOUT')];
  const cases=[];
  for(const error of inputs){
    const model=createFocusedResource(async()=>{throw error;},()=>true,{coalesce:true});
    model.start();
    for(let i=0;i<12;i++)await Promise.resolve();
    const snapshot=model.snapshot();
    cases.push({input:error.message,storedError:snapshot.error,storedErrorType:typeof snapshot.error,routeErrorMessage:routeMessage(snapshot),data:snapshot.data});
    model.stop();
  }
  if(!cases.every(c=>c.storedError===true&&c.routeErrorMessage==='true'))throw new Error('Characterization changed.');
  const out={scope:'Offline characterization of actual current source. No native/backend verification.',head:'a9692e11942609bab9406215c3e407d79589dafa',sources:[purePath,routePath].map(p=>({path:p,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')})),cases,passMeans:'Confirmed diagnostic collapse, not product correctness.'};
  fs.writeFileSync(path.join(__dirname,'boolean_error_probe_result.json'),JSON.stringify(out,null,2)+'\n');
  console.log(JSON.stringify({cases:cases.length,allStoredAsBoolean:true,allRouteMessages:'true',networkCalls:0},null,2));
})().catch(e=>{console.error(e.message);process.exitCode=1;});
