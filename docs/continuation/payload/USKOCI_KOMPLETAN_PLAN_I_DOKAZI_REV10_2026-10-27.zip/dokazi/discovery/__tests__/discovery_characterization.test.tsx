import { AppState } from 'react-native';
import React from 'react';
import { act, create, type ReactTestRenderer } from 'react-test-renderer';
import type { DiscoveryV1OwnerRequest } from '/workspace/scratch/f356024cf009/audit/deep-review/source/src/data/discoveryV1Owner';
import { taskRelationIndex } from '/workspace/scratch/f356024cf009/audit/deep-review/source/src/data/taskRelation';

// These tests drive the real route, screen and coordinator through whole visits; one of them takes about 3 s alone and passes Jest's 5 s on a loaded developer machine (Metro, other agents).
// What they pin is the order of the reads, not their speed, so the real-time limit is only a safety net and is widened (2026-10-08).
jest.setTimeout(30000);

// The P6 route unmounts its screen on blur and rebuilds it from the saved view on focus. This drives the REAL route, screen, coordinator and owners
// over a fake server through that whole cycle: the return must show the same list (read depth restored) and never the error state. The fake server
// answers the way the database does: it echoes a MAP request's bounds through double precision at 15 significant digits, while the map's own
// viewport (what the screen persists) carries 16-17 digits.
const ACCOUNT = '22222222-2222-4222-8222-222222222222';
const PROFILE = '33333333-3333-4333-8333-333333333333';
const AT = '2026-09-29T05:00:00.000000Z', EX = '2026-09-29T05:30:00.000000Z', A = 'a'.repeat(32), B = 'b'.repeat(32);
let mockFocused = true, mockRevision = 1;
let mockSource = { odnosiPremaZadacima: jest.fn(async (ids: readonly string[]) => taskRelationIndex([], ids)) };
const mockOriginalSource = mockSource;
const mockRouter = { navigate: jest.fn(), back: jest.fn(), canGoBack: jest.fn(() => false) };
const mockTransportCalls: DiscoveryV1OwnerRequest[] = [];
let mockTransport: (request: DiscoveryV1OwnerRequest) => Promise<unknown>;

jest.mock('/workspace/scratch/f356024cf009/audit/deep-review/source/src/data/supabaseClient', () => ({ supabaseKlijent: () => { throw new Error('Unexpected transport'); } }));
jest.mock('expo-router', () => ({
  router: { navigate: (...args: unknown[]) => mockRouter.navigate(...args), back: () => mockRouter.back(), canGoBack: () => mockRouter.canGoBack() },
  useLocalSearchParams: () => ({}),
  useFocusEffect: (callback: () => (() => void) | void) => {
    const React = require('react');
    React.useEffect(() => mockFocused ? callback() : undefined, [callback, mockFocused]);
  },
}));
jest.mock('expo-constants', () => ({ expoConfig: { android: { package: 'rs.uskoci.dev' } } }));
jest.mock('/workspace/scratch/f356024cf009/audit/deep-review/source/src/store/sesija', () => ({
  useSesija: () => ({ user: { id: ACCOUNT }, accountRevision: mockRevision }),
  sesijaSada: () => ({ user: { id: ACCOUNT }, accountRevision: mockRevision }),
}));
jest.mock('/workspace/scratch/f356024cf009/audit/deep-review/source/src/store/uloga', () => ({ useIzvor: () => mockSource, izvorSada: () => mockSource }));
jest.mock('/workspace/scratch/f356024cf009/audit/deep-review/source/src/hooks/useDiscoveryWorkArea', () => ({ useDiscoveryWorkArea: () => ({ target: null, handled: jest.fn(), retire: jest.fn() }) }));
jest.mock('/workspace/scratch/f356024cf009/audit/deep-review/source/src/data/discoveryV1ClientTransport', () => ({ createDiscoveryV1SupabaseTransport: () => (request: any) => mockTransport(request) }));
jest.mock('/workspace/scratch/f356024cf009/audit/deep-review/source/src/data/publicProfileClientService', () => ({ publicProfileClientService: { javniProfil: jest.fn(async () => null) } }));
jest.mock('/workspace/scratch/f356024cf009/audit/deep-review/source/src/data/needUrgencyClientService', () => ({ readNeedUrgencies: jest.fn(async () => new Map()) }));
jest.mock('/workspace/scratch/f356024cf009/audit/deep-review/source/src/data/discoveryV1PresentationBridge', () => ({ DiscoveryV1PresentationBridge: 'Bridge' }));

import { DiscoveryV1Route } from '/workspace/scratch/f356024cf009/audit/deep-review/source/src/ui/v2/discovery/DiscoveryV1Route';
import { DISCOVERY_V1_WARM_RETURN_MS } from '/workspace/scratch/f356024cf009/audit/deep-review/source/src/data/discoveryV1WarmReturn';

const rowId = (n: number) => `00000000-0000-4000-8000-${String(n + 1).padStart(12, '0')}`;
const anchor = () => ({ version: 'DISCOVERY_V1', filterKey: A, timeAt: AT, publishedThrough: AT, expiresAt: EX });
const item = (n: number): any => ({ id: rowId(n), revision: 1, sortAt: AT, publishedAt: AT, title: `Task ${n}`, category: 'Selidbe', status: 'PUBLISHED', urgent: false,
  scheduleKind: 'FLEXIBLE', startsAt: null, endsAt: null, executionLocationMode: 'STATIONARY', taskCountryCode: 'RS', taskTimezone: 'Europe/Belgrade',
  verifiedIdentityRequired: false, approximateCity: 'Novi Sad', approximateArea: 'Liman', pin: { lat: Number((45.25 + (n % 10) / 100).toFixed(2)), lng: 19.83, precision: 'COARSE_1KM' },
  requiredSlots: 1, coveredSlots: 0, requiredSkills: [], requiredTools: [], requiredVehicles: [], requiredLicenses: [], minimumExperienceYears: null,
  priceMode: 'OFFERS', requesterPriceRsd: null, priceBasis: null, requesterProfileId: PROFILE, responseDeadline: null, acceptsApplications: true,
  publicTopology: null, criticalConditions: null });

/** `select jsonb_build_array('19.371235347487277'::numeric::double precision)` answers 19.3712353474873 (extra_float_digits is 0). */
const databaseEcho = (bounds: readonly number[]) => bounds.map(value => Number(value.toPrecision(15)));
/** What the native map reports for its visible area: 16-17 significant digits, which no server echo reproduces. */
const NATIVE_BOUNDS = [19.371235347487277, 44.85134028015267, 21.899999999999999, 45.796000000000006];
const CANONICAL_BOUNDS = [19.371235, 44.85134, 21.9, 45.796];

/** A server of 100 tasks in pages of 50 with a whole-bounds hint, answering the way the SQL does (coverage echoes the request). */
function server(request: DiscoveryV1OwnerRequest): unknown {
  mockTransportCalls.push(request);
  if (request.mode === 'MAP') {
    return { version: 'DISCOVERY_V1', mode: 'MAP', asOf: AT, filterKey: A, anchor: anchor(), coverageBounds: databaseEcho(request.bounds), effectiveGrid: 8,
      wholeBounds: [19.5, 44.7, 21.9, 45.4], buckets: [{ kind: 'TASK', key: 'task:' + rowId(0), point: { lat: 45.25, lng: 19.83 }, taskId: rowId(0) }],
      counts: { kind: 'exact_live', observedAt: AT, mapped: 100, withoutPoint: 0 } };
  }
  if (request.mode === 'PAGE') {
    const start = request.after ? Number((request.after as any).id.slice(-12)) : 0;
    const size = Math.min(50, request.limit), rows = Array.from({ length: size }, (_, i) => item(start + i));
    const more = start + size < 100;
    return { version: 'DISCOVERY_V1', mode: 'PAGE', asOf: AT, filterKey: A, anchor: anchor(), items: rows, hasMore: more,
      nextCursor: more ? { scopeKey: B, section: 0, sortAt: AT, id: rowId(start + size - 1) } : null,
      counts: { kind: 'exact_live', observedAt: AT, mapped: 100, listed: 100, inArea: 100, withoutPoint: 0, undated: 0 },
      availability: { hasKnownWorkMode: true, hasKnownSchedule: true, priceModes: ['OFFERS'] } };
  }
  if (request.mode === 'PLACES') {
    return { version: 'DISCOVERY_V1', mode: 'PLACES', asOf: AT, filterKey: A, anchor: anchor(), items: [{ key: 'novi sad, liman', text: 'Novi Sad, Liman', count: 30 }],
      hasMore: false, nextCursor: null, counts: { kind: 'exact_live', observedAt: AT, everywhere: 100, inArea: null } };
  }
  if (request.mode === 'EXACT_PUBLIC') {
    return { version: 'DISCOVERY_V1', mode: 'EXACT_PUBLIC', asOf: AT, items: [item(Number(request.needId.slice(-12)) - 1)], hasMore: false, nextCursor: null };
  }
  throw new Error('UNEXPECTED_MODE');
}

let tree: ReactTestRenderer | undefined;
const bridge = () => tree!.root.findAllByType('Bridge' as unknown as React.ElementType)[0];
const errorState = () => tree!.root.findAllByProps({ title: 'Ne možemo da učitamo zadatke' });
const flush = async () => { for (let i = 0; i < 80; i++) await act(async () => { await Promise.resolve(); }); };
const modes = () => mockTransportCalls.map(request => request.mode);
const pendingRead = () => { let resolve!: () => void, reject!: (error: Error) => void;
  const promise = new Promise<void>((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; };
let info: jest.SpyInstance;
const traced = () => info.mock.calls.map(call => String(call[0])).filter(line => line.startsWith('[USKOCI_P6_TRACE]'));
beforeEach(() => {
  mockFocused = true; mockRevision = 1; mockSource = mockOriginalSource; mockTransportCalls.length = 0; mockTransport = async request => server(request); mockRouter.navigate.mockClear(); mockRouter.back.mockClear(); mockRouter.canGoBack.mockReturnValue(false);
  info = jest.spyOn(console, 'info').mockImplementation(() => {});
});


// ANALYTICAL CHARACTERIZATION. Expectations pin observed defective behavior;
// passing does not assert product acceptance or a native/device render.
afterEach(async () => { if (tree) await act(async () => tree!.unmount()); tree = undefined; info.mockRestore(); });

test.each(['PAGE', 'MAP'] as const)('initial %s failure shows standalone error, failed retry changes to the populated error shell', async stage => {
  mockTransport = async request => {
    if (request.mode === stage) throw new Error('DISCOVERY_V1_READ_FAILED');
    return server(request);
  };
  await act(async () => { tree = create(<DiscoveryV1Route />); }); await flush();
  expect(bridge()).toBeUndefined();
  const state = errorState().find(node => typeof node.props.primary?.onPress === 'function');
  expect(state).toBeDefined();
  await act(async () => { state!.props.primary.onPress(); }); await flush();
  expect(bridge()).toBeDefined();
  expect(bridge().props.error).toBe(true);
  expect(bridge().props.loading).toBe(false);
  expect(bridge().props.snapshot.view.where).toBe('onsite');
  expect(bridge().props.snapshot.items.length).toBe(stage === 'PAGE' ? 0 : 50);
});

test('a MAP-only refresh failure sets global task error while the valid page still has all 50 rows', async () => {
  await act(async () => { tree = create(<DiscoveryV1Route />); }); await flush();
  const beforeIds = bridge().props.snapshot.items.map((row: any) => row.id);
  const attempted: string[] = [];
  mockTransport = async request => { attempted.push(request.mode); throw new Error('DISCOVERY_V1_READ_FAILED'); };
  await act(async () => { bridge().props.actions.onViewportSettled(NATIVE_BOUNDS); }); await flush();
  expect(attempted).toEqual(['MAP']);
  expect(bridge().props.error).toBe(true);
  expect(bridge().props.snapshot.items.map((row: any) => row.id)).toEqual(beforeIds);
  expect(beforeIds).toHaveLength(50);
});
