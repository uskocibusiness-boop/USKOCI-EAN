// Offline characterization of real classifier and exact projection modules.
// Synthetic catalog/provider/schema only. No real model, app user or remote SQL.
import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const base=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../../deep-review');
const source=path.join(base,'source');
const out=path.dirname(fileURLToPath(import.meta.url));
const evidenceDir=path.resolve(out,'../../evidence');
const { PGlite }=await import(path.join(base,'runtime/node_modules/@electric-sql/pglite/dist/index.js'));
const {buildWorkerFullTreeTaxonomyProposals,buildFullTreeTaxonomyProposals}=await import(path.join(source,'supabase/functions/_shared/backgroundTaxonomyArchitect.mjs'));
const {workerModeRequests}=await import(path.join(source,'supabase/functions/_shared/workerServiceModeContext.mjs'));
const {normalizedClassificationIdentity}=await import(path.join(source,'supabase/functions/_shared/classificationEngine.mjs'));
const leaf='11111111-1111-4111-8111-111111111111';
const parent='22222222-2222-4222-8222-222222222222';
let version=905000;let transportCalls=0;let responseValue={};
globalThis.fetch=async (_url,init)=>{
  transportCalls++;
  assert.equal(JSON.parse(init.body).generationConfig.responseMimeType,'application/json');
  return new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(responseValue)}]}}]}));
};
const snapshot=(label='Casovi engleskog',aliases=[])=>({
  catalogVersion:++version,catalogFingerprint:'a'.repeat(32),categories:[
    {categoryId:parent,label:'Obrazovne usluge',aliases:[],modes:['ON_SITE','REMOTE'],path:['Obrazovne usluge']},
    {categoryId:leaf,label,aliases,modes:['ON_SITE','REMOTE'],path:['Obrazovne usluge',label]},
  ]
});
const args=(catalog)=>({rpc:async name=>{assert.equal(name,'rpc_taxonomy_fetch_snapshot_v1');return {ok:true,data:catalog};},geminiKey:'SYNTHETIC',geminiModel:'SYNTHETIC',conversationId:'SYNTHETIC',draftRevision:1});
const item=(mode,service='Casovi engleskog')=>({service,mode,action:'REUSE_EXISTING',parentId:'',handoffKind:'NONE',handoffCity:'',reason:'Ista postojeća usluga iz kontrolisanog kataloga.'});
const evidence='Casove engleskog nudim na lokaciji i na daljinu.';
const modes=['ON_SITE','REMOTE'];
const change=JSON.stringify([{service:'Casovi engleskog',modes,evidence,handoff:{required:false}}]);
const workerArgs={skills:['Casovi engleskog'],messages:[{role:'USER',body:evidence}],serviceModeChangesJson:change,serviceModeContext:{savedServices:[],draftServices:[]},hasWorkAreas:true};
responseValue={items:[item('ON_SITE')]};
const partial=await buildWorkerFullTreeTaxonomyProposals({...args(snapshot()),...workerArgs});
assert.equal(partial.proposals.length,1);assert.equal(partial.proposals[0].mode,'ON_SITE');
assert.ok(partial.failures.some(f=>f.mode==='REMOTE'&&f.code==='PROVIDER_INVALID_DECISION'));
responseValue={items:[item('ON_SITE'),item('REMOTE')]};
const complete=await buildWorkerFullTreeTaxonomyProposals({...args(snapshot()),...workerArgs});
assert.deepEqual(complete.proposals.map(p=>p.mode),modes);assert.equal(complete.failures.length,0);

// A valid historical declaration does not start a new background run when the
// current user turn is only about availability: use the real mode request parser.
const currentOnly={messages:[{role:'USER',body:'Radim subotom od 10 do 14.'}]};
const offered=new Map([['casovi engleskog','Casovi engleskog']]);
assert.equal(workerModeRequests(change,currentOnly,offered).size,0);
assert.equal(workerModeRequests(change,{messages:workerArgs.messages},offered).size,1);

// Exact/registered alias works; unsupported semantic reuse outside aliases fails.
responseValue={decisions:[{service:'Poducavanje engleskog',mode:'ON_SITE',action:'REUSE_EXISTING',categoryId:leaf,parentId:'',reason:'Isto značenje kao postojeći časovi engleskog.'}]};
const synonym=await buildFullTreeTaxonomyProposals({...args(snapshot()),items:[{service:'Poducavanje engleskog',mode:'ON_SITE'}]});
assert.equal(synonym.proposals.length,0);assert.ok(synonym.failures.some(x=>x.code==='SEMANTIC_REUSE_ADMISSION_UNAVAILABLE'));
const alias=await buildFullTreeTaxonomyProposals({...args(snapshot('Casovi engleskog',['Poducavanje engleskog'])),items:[{service:'Poducavanje engleskog',mode:'ON_SITE'}]});
assert.equal(alias.proposals[0].categoryId,leaf);assert.equal(alias.proposals[0].action,'REUSE_EXISTING');

// Exercise the real SQL exact projection in an isolated in-memory database.
// Its normalizer/fingerprint/catalog are controlled fixtures; no real consent,
// capture, review signature, save, binder, matching or deployment is executed.
const dependenciesPath='supabase/proofs/dynamic_taxonomy/parent-mode-admission/current-dependencies.sql';
const dependencyText=await readFile(path.join(source,dependenciesPath),'utf8');
function extract(text,name){
  const start=text.toLowerCase().indexOf('create or replace function '+name.toLowerCase()+'(');assert.ok(start>=0,name);
  const tail=text.slice(start);const tag=tail.match(/\bas\s+(\$[\w]*\$)/i)[1];
  const bodyStart=tail.indexOf(tag)+tag.length;const end=tail.indexOf(tag,bodyStart)+tag.length;
  return tail.slice(0,end)+';';
}
const functionBody=sql=>{const tag=sql.match(/\bas\s+(\$[\w]*\$)/i)[1];return sql.slice(sql.indexOf(tag)+tag.length,sql.lastIndexOf(tag));};
const checkedExactSql=extract(dependencyText,'private.taxonomy_review_exact_projection_v1');
const liveExactPath='live_private.taxonomy_review_exact_projection_v1.sql';
const exactSql=extract(await readFile(path.join(evidenceDir,liveExactPath),'utf8'),'private.taxonomy_review_exact_projection_v1');
assert.equal(functionBody(exactSql),functionBody(checkedExactSql));
const riskPath='supabase/migrations/20261019071732_taxonomy_natural_services_structural_paths.sql';
const riskSql=extract(await readFile(path.join(source,riskPath),'utf8'),'private.taxonomy_risk_triage_v1');
const db=new PGlite();
await db.exec(`CREATE SCHEMA private;
CREATE FUNCTION private.taxonomy_normalize_v1(p text) RETURNS text LANGUAGE sql IMMUTABLE AS $$SELECT lower(regexp_replace(btrim(p),'\\s+',' ','g'))$$;
CREATE FUNCTION private.taxonomy_admission_fingerprint_v1() RETURNS text LANGUAGE sql STABLE AS $$SELECT repeat('a',32)$$;
CREATE TABLE private.work_taxonomy_control(singleton boolean,catalog_version bigint);
INSERT INTO private.work_taxonomy_control VALUES(true,1);
CREATE TABLE private.work_taxonomy_categories(id uuid,canonical_key text,state text);
CREATE TABLE private.work_taxonomy_category_modes(category_id uuid,execution_scope text);
CREATE TABLE private.work_taxonomy_aliases(category_id uuid,normalized_key text);
CREATE TABLE private.work_taxonomy_risk_rules(enabled boolean,decision text,pattern text);
INSERT INTO private.work_taxonomy_categories VALUES('${leaf}','casovi engleskog','ESTABLISHED');
INSERT INTO private.work_taxonomy_category_modes VALUES('${leaf}','ON_SITE'),('${leaf}','REMOTE');`);
await db.exec(exactSql);await db.exec(riskSql);
const projection=async proposals=>(await db.query('SELECT private.taxonomy_review_exact_projection_v1($1,$2::jsonb,$3::jsonb) AS result',['WORKER_CAPABILITY',JSON.stringify(workerArgs.skills),JSON.stringify(proposals.map(p=>({service:p.service,mode:p.mode})))] )).rows[0].result;
const partialProjection=await projection(partial.proposals);
const completeProjection=await projection(complete.proposals);
assert.equal(partialProjection.status,'READY');assert.equal(partialProjection.reviewedServiceModes.length,1);
assert.equal(completeProjection.status,'READY');assert.equal(completeProjection.reviewedServiceModes.length,2);
const triage=(await db.query('SELECT label,private.taxonomy_risk_triage_v1(label) AS status FROM (VALUES ($1::text),($2::text)) t(label)',['Sisanje','Sisanje kose'])).rows;
assert.deepEqual(triage.map(x=>x.status),['NEEDS_CLARIFICATION','LOW_RISK_CANDIDATE']);

// Execute the real worker completion body under a synthetic owned session.
// Only ownership/context/patch/document/digest dependencies are fixture stubs;
// revision increment and the surrounding completion code are unmodified SQL.
const completionPath='supabase/migrations/20260913044510_clean_v5_unknown_ai_turn_exit.sql';
const checkedCompletionSql=extract(await readFile(path.join(source,completionPath),'utf8'),'public.rpc_complete_worker_ai_turn_service');
const liveCompletionPath='live_public.rpc_complete_worker_ai_turn_service.sql';
const completionSql=extract(await readFile(path.join(evidenceDir,liveCompletionPath),'utf8'),'public.rpc_complete_worker_ai_turn_service');
assert.equal(functionBody(completionSql),functionBody(checkedCompletionSql).replaceAll("errcode='40001'","errcode='PT409'"));
const preparePath='supabase/migrations/20261021103732_worker_equipment_retired_signed_policy.sql';
const checkedPrepareSql=extract(await readFile(path.join(source,preparePath),'utf8'),'public.rpc_prepare_worker_ai_review_taxonomy');
const livePreparePath='live_public.rpc_prepare_worker_ai_review_taxonomy.sql';
const prepareSql=extract(await readFile(path.join(evidenceDir,livePreparePath),'utf8'),'public.rpc_prepare_worker_ai_review_taxonomy');
assert.equal(functionBody(prepareSql),functionBody(checkedPrepareSql));
const account='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',conversation='bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
const profile='cccccccc-cccc-4ccc-8ccc-cccccccccccc',request='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
const attempt='eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee',turn='ffffffff-ffff-4fff-8fff-ffffffffffff';
await db.exec(`CREATE SCHEMA auth;CREATE SCHEMA extensions;
CREATE FUNCTION auth.role() RETURNS text LANGUAGE sql STABLE AS $$SELECT 'service_role'::text$$;
CREATE FUNCTION private.closure_assert_open(uuid) RETURNS void LANGUAGE plpgsql AS $$BEGIN RETURN;END$$;
CREATE FUNCTION extensions.digest(text,text) RETURNS bytea LANGUAGE sql IMMUTABLE AS $$SELECT decode(md5($1)||md5($1),'hex')$$;
CREATE FUNCTION extensions.digest(bytea,text) RETURNS bytea LANGUAGE sql IMMUTABLE AS $$SELECT extensions.digest(encode($1,'hex'),$2)$$;
CREATE TABLE private.worker_ai_sessions(account_id uuid,conversation_id uuid,candidate jsonb,revision integer,profile_id uuid,base_hash text,safety text);
CREATE TABLE private.worker_ai_turns(account_id uuid,conversation_id uuid,client_request_id uuid,attempt_id uuid,turn_id uuid,cancelled_at timestamptz,completion_hash text,state text,provider_dispatched boolean,lease_expires_at timestamptz,source_revision integer);
CREATE TABLE public.ai_conversations(id uuid,account_id uuid,purpose text);
CREATE TABLE public.ai_messages(account_id uuid,conversation_id uuid,role text,body text,safety text);
CREATE FUNCTION public.rpc_read_worker_ai_context_service(uuid,uuid) RETURNS jsonb LANGUAGE sql AS $$SELECT '{}'::jsonb$$;
CREATE FUNCTION private.worker_ai_patch(jsonb,jsonb,uuid,uuid,boolean) RETURNS jsonb LANGUAGE sql AS $$SELECT $1||$2$$;
CREATE FUNCTION private.worker_ai_turn_document(uuid) RETURNS jsonb LANGUAGE sql AS $$SELECT jsonb_build_object('state',state,'turnId',turn_id) FROM private.worker_ai_turns WHERE turn_id=$1$$;
CREATE TABLE private.work_taxonomy_gemini_turn_hints_v1(id integer,created_at timestamptz,purpose text,account_id uuid,conversation_id uuid,source_fingerprint text,catalog_version bigint,proposals jsonb);
INSERT INTO private.worker_ai_sessions VALUES('${account}','${conversation}','{"skills":["Casovi engleskog"],"bio":"Prvobitni opis"}',1,'${profile}','synthetic-base','ALLOW');
INSERT INTO public.ai_conversations VALUES('${conversation}','${account}','PROFILE');
INSERT INTO private.worker_ai_turns VALUES('${account}','${conversation}','${request}','${attempt}','${turn}',NULL,NULL,'PROCESSING',true,clock_timestamp()+interval '1 hour',1);`);
await db.exec(completionSql);
await db.query(`INSERT INTO private.work_taxonomy_gemini_turn_hints_v1
 SELECT 1,clock_timestamp(),'WORKER_CAPABILITY',account_id,conversation_id,
 encode(extensions.digest(convert_to(candidate::text||'|'||revision::text||'|'||base_hash,'UTF8'),'sha256'),'hex'),1,$1::jsonb FROM private.worker_ai_sessions`,[JSON.stringify(complete.proposals)]);
// Same equality fields as the real prepare query. The digest is a deterministic
// fixture hash, not a cryptography test; revision inclusion is the behavior.
const sourceHints=async()=> (await db.query(`SELECT h.proposals FROM private.worker_ai_sessions s
 JOIN private.work_taxonomy_gemini_turn_hints_v1 h ON h.purpose='WORKER_CAPABILITY' AND h.account_id=s.account_id
 AND h.conversation_id=s.conversation_id AND h.source_fingerprint=encode(extensions.digest(convert_to(s.candidate::text||'|'||s.revision::text||'|'||s.base_hash,'UTF8'),'sha256'),'hex')
 AND h.catalog_version=(SELECT catalog_version FROM private.work_taxonomy_control WHERE singleton=true)
 ORDER BY h.created_at DESC,h.id DESC LIMIT 1`)).rows[0]?.proposals??[];
const hintsBefore=await sourceHints();assert.equal(hintsBefore.length,2);
const candidateBefore=(await db.query('SELECT candidate FROM private.worker_ai_sessions')).rows[0].candidate;
await db.query('SELECT public.rpc_complete_worker_ai_turn_service($1,$2,$3,$4,$5::jsonb)',[account,conversation,request,attempt,JSON.stringify({assistantMessage:'Otvori pregled profila.',safety:'ALLOW',patch:{}})]);
const stateAfter=(await db.query('SELECT revision,candidate FROM private.worker_ai_sessions')).rows[0];
const hintsAfter=await sourceHints();assert.equal(stateAfter.revision,2);assert.equal(hintsAfter.length,0);
assert.deepEqual(stateAfter.candidate,candidateBefore);
const finishAfterProjection=await projection(hintsAfter);assert.equal(finishAfterProjection.status,'REVIEW_REQUIRED');
const normalTurn={input:'to je to',patch:{},revisionBefore:1,revisionAfter:stateAfter.revision,candidateUnchanged:true,currentHintsBefore:hintsBefore.length,currentHintsAfter:hintsAfter.length,exactStatusAfter:finishAfterProjection.status};
await db.close();
const hashes={};for(const rel of ['supabase/functions/_shared/backgroundTaxonomyArchitect.mjs','supabase/functions/_shared/workerServiceModeContext.mjs',dependenciesPath,riskPath,completionPath,preparePath])hashes[rel]=createHash('sha256').update(await readFile(path.join(source,rel))).digest('hex');
const liveHashes={};for(const rel of [liveExactPath,liveCompletionPath,livePreparePath])liveHashes[rel]=createHash('sha256').update(await readFile(path.join(evidenceDir,rel))).digest('hex');
const md5=text=>createHash('md5').update(text).digest('hex');
const parity={exactProjection:{bodyEqual:true,checkedBodyMd5:md5(functionBody(checkedExactSql)),liveBodyMd5:md5(functionBody(exactSql))},workerCompletion:{bodyEqual:false,checkedBodyMd5:md5(functionBody(checkedCompletionSql)),liveBodyMd5:md5(functionBody(completionSql)),onlyDifferences:'Two errcode literals on conflict branches: 40001 → PT409. Successful completion logic identical.',liveBodyExecuted:true},workerPrepareTaxonomy:{bodyEqual:true,checkedBodyMd5:md5(functionBody(checkedPrepareSql)),liveBodyMd5:md5(functionBody(prepareSql)),bodyExecuted:false}};
const result={scope:'OFFLINE CHARACTERIZATION; synthetic provider/catalog and isolated PGlite; not phone, real Gemini or live SQL',sourceCommit:'a9692e11942609bab9406215c3e407d79589dafa',transportCalls,
  cases:{both_partial_provider:{builder:partial,exactProjection:partialProjection},both_complete_provider:{builder:complete,exactProjection:completeProjection},unchanged_service_followup:{oldDeclarationValidInHistory:true,currentTurnStartsModeWork:false,completionAndProjection:normalTurn},unregistered_synonym:{builder:synonym},registered_alias:{builder:alias},single_word_triage:triage},sourceHashes:hashes,liveDefinitionHashes:liveHashes,definitionParity:parity,
  limitations:['Full worker review/capture/signature/save/binding not executed.','Exact projection and worker completion SQL use fresh live definitions executed only against isolated fixture schema; definition parity does not prove a live user flow.','Fixture normalizer uses lowercase/space normalization on ASCII labels; it does not test Cyrillic transliteration.','Provider outputs are synthetic controls; this does not measure how often Gemini returns one item for BOTH.','Worker completion body is real; auth/context/patch/digest/document helpers are controlled fixture stubs. The source-fingerprint selection is the prepare query relationship, not execution of full prepare RPC.']};
await writeFile(path.join(out,'semantic_completion_probe.json'),JSON.stringify(result,null,2)+'\n');
await writeFile(path.join(out,'semantic_completion_definition_parity.json'),JSON.stringify(parity,null,2)+'\n');
console.log(JSON.stringify({pass:true,partialBoth:{proposalModes:partial.proposals.map(x=>x.mode),failureModes:partial.failures.map(x=>x.mode),exactStatus:partialProjection.status,reviewedModes:partialProjection.reviewedServiceModes.map(x=>x.mode)},completeBoth:{proposalModes:complete.proposals.map(x=>x.mode),exactStatus:completeProjection.status},normalTurn,triage,transportCalls,remoteIO:false},null,2));
