# USKOČI plan dovršavanja aplikacije i objavljivanja

**Operativna revizija 8 | 27. oktobar 2026. | Dopuna posle pregleda dostavljenog paketa revizije 7**

## 1. Zaključak i svrha

Postojeća analiza je dovoljno konkretna da se započnu ciljane popravke. Za cilj da kompletna aplikacija bude logički dosledna, vizuelno završena, proverena na telefonu i spremna za prodavnicu potrebno je dopuniti završnu specifikaciju ekrana, radnji, povezanih tokova i objavljivanja. Ovaj plan daje tu dopunu, čuva nalaze F01-F21, SB01-SB15 i X01-X06, zadatke R01-R12 i tokove J01-J14.

Najveća korist dolazi iz dovršavanja postojećih veza i dokazivanja stvarnog rezultata. Ponovno neograničeno čitanje celog projekta, nova paralelna arhitektura ili veliki broj novih dokumenata nisu preduslov za prvi koristan korak.

**Status ovog dokumenta:** dovršen pregled i predlog operativnog plana. Ova revizija ne predstavlja izvršene popravke, nacrtane konačne ekrane, pokrenute testove ili odobreno izdanje. Korisnikov sadašnji zahtev uključuje razradu dosad odložene UI/UX i produktne završnice; ranija napomena „kasnije” zato više nije razlog da se ta završnica izostavi iz plana.

Kada se ova revizija koristi za implementaciju, njen sadržaj treba ugraditi kao novu važeću verziju postojećeg `CODEX_PLAN_RADA.md`. Glavni izveštaj i tehnička referenca ostaju izvori nalaza. PDF i Markdown ove revizije predstavljaju isti sadržaj, a ne dva nezavisna plana. Ne menjati istorijske dokaze da bi izgledali kao nov rezultat.

### 1.1. Šta je provereno u ovom pregledu

- Pročitani su glavni izveštaj, operativni plan, tehnička referenca i uvod. Manifest je parsiran; svih pet priloženih sadržajnih fajlova odgovara zabeleženoj veličini i SHA-256 otisku. Pregledani su stvarni prikazi telefona na strani 9 PDF-a. [D1-D6]
- Manifest navodi 125 sadržajnih fajlova. Priloženo je pet, uz sam manifest; 120 zasebnih dokaznih fajlova nije priloženo. Slike ugrađene u PDF jesu dostupne, ali izvorni slikovni fajlovi i ostali registri nisu. To ne sprečava ocenu plana, ali sprečava nezavisnu potvrdu celokupne ranije dokazne podloge.
- GitHub poređenje tokom ovog pregleda pokazalo je da je `feature/uskoci-cisto` identična commitu **`a9692e11942609bab9406215c3e407d79589dafa`**, bez novijih ili zaostalih commit-a u tom poređenju. Pre implementacije ponovo potvrditi tadašnji HEAD. [G1]
- Na tom potvrđenom izvoru pročitani su `README.md`, `STATUS.md`, `app.config.js` i `eas.json`. README potvrđuje Expo / React Native, DEV projekat `leqcwgzvjsxugfgzdmth` i namernu blokadu produkcionog build-a/OTA dok ne postoji provereni odvojeni produkcioni backend. STATUS potvrđuje pravilo „Samo poruke za sad” i otvorenu serversku granicu starih PHONE dozvola. [G2-G5]
- U ovom pregledu nisu ponovljeni Supabase audit, stvarni model, build, testovi, migracije, native instalacija ili proba na telefonu. Aktuelni serverski i uređajski nalazi u nastavku označavaju ono što dokumentuje revizija 7, do novog izvršnog dokaza.

**Važna granica:** provera otiska potvrđuje da je dokument isti kao u manifestu. Ne potvrđuje da je svaka njegova tvrdnja nezavisno reprodukovana. Tvrdnju prethodnog audita o 626.320 pročitanih redova treba pratiti njegovim stvarnim registrom, a ne ponavljati kao rezultat ovog pregleda.

### 1.2. Gde je paket jak i gde je otvoren

| Oblast | Ocena dostavljenog paketa | Potreban završetak |
|---|---|---|
| Tehnički uzroci i vlasnici | Jaki i konkretni; nalazi su povezani sa postojećim kodom i proverama. | Izvesti promene na svežem izvoru i potvrditi njihove efekte. |
| Čišćenje | Razumno uslovljeno potrošačima, kompatibilnošću i zamenom. | Ukloniti dokazani višak uz relevantnu izmenu; ne meriti uspeh brojem obrisanih fajlova. |
| Poslovni tokovi | J01-J14 pružaju dobru osnovu. | Popuniti sve radnje, ulaze, izlaze, prekide i posledice za drugu ulogu. |
| UI/UX | Postoje kriterijumi za stanja ekrana i konkretni kvarovi. | Popuniti inventar, usvojiti prikaze i proveriti stvarni native rezultat. |
| Stvarna aplikacija | Analiza razlikuje izvor, server i instalirani klijent. | Potvrditi jednu isporučenu kombinaciju i cele tokove na njoj. |
| Objavljivanje | Postoji tehnička release osnova. | Dovršiti zasebne Android/iOS uslove, dokumente, prijavu i operativnu podršku. |

Glavni izveštaj u odeljku 13 izričito ostavlja konačne ekrane i potpuni opis proizvoda otvorenim. Operativni plan u odeljku 8 već zahteva loading/empty/error/unknown-write, povratak, tastaturu i pristupačnost. Zato je tačna ocena: UX ima dobru polaznu specifikaciju završetka, ali još nije konačno razrađen i dokazan. [D2, odeljci 13 i 14; D3, odeljci 1, 8 i 9]

## 2. Važeće smernice proizvoda koje treba sačuvati

Ovo su smernice iz dostavljenog aktuelnog paketa i pročitanog STATUS-a. Novija izričita odluka vlasnika ima prednost. Starije sećanje, izdvojeni prototip ili naziv testa ne mogu sami promeniti ovu osnovu. [D2, odeljci 4-7; D3, odeljak 3; G3]

1. Jedan proizvod ima odvojena iskustva naručioca i izvršioca. Promena uloge ne prenosi tuđe stanje, nacrt ili dozvolu.
2. Čovek prirodno opisuje potrebu ili usluge. Sve jasne činjenice ostaju sačuvane u predlogu. Sledeće pitanje traži jednu stvarno potrebnu informaciju.
3. Klasifikator radi u pozadini. Čovek potvrđuje svoju potrebu ili ponudu; ne administrira kategorije i interne šifre.
4. Postojeća usluga zadržava postojeći ID. Nova kategorija dobija stvarni ID posle validacije i upisa u bazi. Sinonim nije automatski nova kategorija.
5. ON_SITE podrazumeva dolazak na mesto naručioca ili zadatka. REMOTE u ovom proizvodu može značiti digitalni rad, radionicu/rad kod izvršioca i odgovarajuću predaju. Nije sinonim isključivo za rad preko interneta.
6. BOTH su oba načina iste usluge. Oba očekivana dela i potvrđena namera moraju opstati kroz pregled, čuvanje i povezivanje.
7. Razgovor nema obavezne parcijalne kartice ili nove formulare za biografiju, opremu, tim, vozilo i licence. Završni pregled treba da bude jedna razumljiva celina.
8. Predlog, pregled, privatni nacrt, sačuvan profil, aktivacija, objava i spremnost za povezivanje imaju različita značenja. UI mora tačno pokazati koje stanje je postignuto.
9. Pending klasifikacija nije univerzalna zabrana čuvanja ili objave. Čuvaju se stvarni, uži serverski uslovi, uključujući posebna pravila za predaju kod REMOTE usluga.
10. DRAFT profil može imati čuvanje ili čuvanje sa aktivacijom. Čuvanje izmene već ACTIVE profila bez zahteva za aktivacijom ne predstavlja deaktivaciju.
11. Dogovor koristi poruke unutar aplikacije. Deljenje telefona kroz posebne PHONE dozvole treba zatvoriti i na serveru i za podržane stare klijente. Zasebna kontrola precizne lokacije ostaje.
12. Zabrana telefonskog broja u slobodnom tekstu nije automatski deo pravila „Samo poruke”; to bi bila posebna moderaciona odluka.
13. Stare naknade, HITNO režim, pretplate i nove valute ne vraćaju se u prvo izdanje iz istorijske memorije. Eventualna monetizacija dobija zasebnu odluku i proveru pravila prodavnice.
14. Signed review, granice naloga/revizije, journal pre slanja, stabilan identitet radnje, readback i proverene lifecycle zaštite ostaju.

## 3. Obim prvog izdanja i kriterijum završenosti

### 3.1. Jedna lista funkcija koje izdanje stvarno obećava

U početnom koraku iz aktuelnih ruta, konfiguracije, javnih tekstova i potvrđene namere napraviti listu funkcija prvog javnog izdanja. Svaka stavka dobija jednu oznaku:

- **Obavezno za ovo izdanje:** osnovni korisnički tok, privatnost, zaštita podataka, obaveza prodavnice ili već obećana aktivna funkcija.
- **Uslovno obavezno:** primenjuje se samo ako izdanje sadrži konkretnu mogućnost, platformu, dozvolu, SDK ili način naplate.
- **Kasnije:** dodatna optimizacija ili nova funkcija čije odsustvo ne krši postojeće obećanje.

Uz svaku blokadu navesti kratko obrazloženje. Ne premeštati teško rešivu, obećanu funkciju u „kasnije” bez odluke o promeni obima. Ne postavljati keš provajdera, svaki istorijski indeks ili arhiviranje svih starih dokaza kao automatski uslov objave.

### 3.2. Četiri odvojena statusa za svaki tok

| Status | Šta znači | Šta ga ne dokazuje |
|---|---|---|
| Definisano | Poznata su pravila, radnje, podaci, izuzeci i potvrde. | Postojanje route fajla. |
| Vizuelno razrađeno | Postoje prikazi bitnih stanja i dosledna pravila komponenti. | Jedan lep screenshot uspešnog stanja. |
| Implementirano | Aktuelni kod izvodi ta pravila kroz postojeće vlasnike. | Prototip, designLab ili mrtva grana. |
| Dokazano | Potrebna provera je izvršena nad imenovanim izdanjem. | Neizvršen test, stari PASS ili drugi APK. |

Za prvi javni release svi obavezni tokovi moraju imati sva četiri potrebna statusa. Nije potreban svaki mogući spoj uređaja, mreže i stanja. Pokriva se svaka ključna situacija, svaka kritična granica podataka i reprezentativni mobilni uslovi.

### 3.3. Razlozi koji zaustavljaju objavljivanje

- Potvrđeno neovlašćeno čitanje/upis, otkrivanje privatnih podataka ili prelazak između naloga.
- Gubitak potvrđenih podataka, duplo izvršavanje poslovne radnje ili lažan prikaz uspeha.
- Neprohodan osnovni tok objave, pronalaženja, prijave, izbora, dogovora ili komunikacije.
- Neispravna ili nepostojeća funkcija koju javno izdanje obećava i koja nema dogovorenu promenu obima.
- Nezavršen obavezan postupak brisanja naloga, potrebne saglasnosti ili prijave/blokiranja neprimerenog sadržaja.
- Neproveren produkcioni cilj, pogrešan potpis/paket/kanal ili nemogućnost bezbednog nastavka posle neispravnog izdanja.
- Neispunjen konkretan obavezan uslov ciljane prodavnice.

Sitne vizuelne nepravilnosti koje ne ometaju upotrebu mogu imati vlasnika i rok posle izdanja. Preklopljeno glavno dugme, nečitljiv tekst ili nedostupna radnja čitaču ekrana nisu takve sitnice.

## 4. Početni korak i jedinstvena isporučena verzija

Pre prve promene potvrditi repozitorijum, granu, HEAD, lokalni radni status, važeće instrukcije i deltu od revizije 7. Ne menjati tuđe novije izmene. Ako nedostaje neki dokaz iz originalnog ZIP-a, označiti konkretnu nedostajuću stavku; njen sadržaj ne rekonstruisati iz opisa kao da je original.

Za svaki razvojni kandidat i release voditi jedan tehnički zapis koji sadrži:

| Sloj | Obavezni podaci |
|---|---|
| Izvor | Repo, grana, commit, stanje radnog stabla, otisak dependency lock-a. |
| Baza | Projekat i okruženje, stvarni schema/ACL ugovor, primenjene migracije i relevantna odstupanja. |
| Edge | Aktivne verzije/sadržaj promenjenih funkcija i relevantne efektivne bezbedne zastavice; bez tajni u izveštaju. |
| Native | Platforma, application ID/bundle ID, verzija, build broj, artefakt i bezbedni potpisni metapodaci. |
| OTA | Runtime, kanal, tačan update identitet i učitani sadržaj gde ga je moguće potvrditi. |
| Uređaj | Model, OS, instalacija/nadogradnja, mrežni uslovi, uloga i početno test stanje. |
| Dokazi | Scenario, rezultat, vreme izvršenja, log bez privatnog sadržaja, screenshot/video po potrebi. |

U reviziji 7 telefon sa slike prikazuje `fcef803...`, a analizirani izvor `a9692e1...`. To je istorijski odnos iz paketa; ne tvrdi se da telefon i danas ima isti build. Novi snimak se ocenjuje prema identitetu tada instaliranog klijenta. [D3, odeljak 2]

Ne deinstalirati aplikaciju radi „čišćenja” pre provere lokalnih nacrta i komandi u toku. Preview i store paket mogu imati različit identitet i lokalni prostor. Ne obećavati automatski prenos lokalnih nacrta između njih bez dokaza.

## 5. Redosled rada kroz postojeće R zadatke

Rad se vodi po celim korisničkim rezultatima. R12 dokazi nastaju od prve popravljene celine; poslednja etapa proverava celinu ponovo, umesto da je prvi put spaja.

### Etapa A: privatnost, osnovna čitanja i vizuelna polazna tačka

R01 zatvara F21 i utvrđuje stvarne ugovore. Paralelno se popunjava inventar ekrana iz odeljka 7 i snima trenutno ponašanje. Posle usaglašenog ugovora R02 i R03 mogu teći paralelno. Priprema produkcije, podataka za pravne dokumente i store naloga može početi odmah, bez javne objave.

### Etapa B: dovršen AI razgovor do sačuvanog rezultata

R04, R06 i R08 završavaju semantičku celinu: isti smisao, ID, oba načina, pregled, potvrdu, ponovo otvoren rezultat i oporavak. R07a, F11 i F13 rešavaju se nezavisno od odluke o satnici. Prvo tačnost, zatim mereno smanjenje čekanja i troška.

### Etapa C: povezivanje ljudi i završen posao

R05 i relevantni R07 zatvaraju područje, vreme, cenu i uslove. R09 zatvara obaveštenja i poruke. Jedna stvarna situacija prolazi kroz obe uloge do dogovora, završetka i ocene. Rad na R10 i nepovezanim R11a-h popravkama teče prema zavisnostima, a ne čeka kraj svih AI radova.

### Etapa D: kompletan proizvod i izdanje

Zatvaraju se svi preostali obavezni ekrani, život podataka, podrška, moderacija, dokumenti i kontrolisano povlačenje viška. Sledi konkretan Android release kandidat i zaseban iOS kandidat kada se priprema Apple objava. Android dokaz i razvoj ne čekaju pristup Apple nalogu.

## 6. Izvršna matrica R01-R12

Putanje ispod su polazišta iz revizije 7. Pre izmene pročitati aktuelni sadržaj i stvarne potrošače. Dodatni vlasnici, testovi i svih 42 F/SB/X veze ostaju u tehničkoj referenci, odeljcima 8 i 9. [D3, odeljci 3-9; D4, odeljci 8-9]

### R01: privatnost čitanja i tačan ugovor

**Ulaz:** F21, F14; `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql` i svi stvarni čitači pogođeni promenom dozvola.

**Rad:** ukloniti preširoku dozvolu za tri privatne kolone uz očuvanje dozvoljenog javnog i sopstvenog čitanja. Proveriti efektivna i buduća prava, RLS pomoćnike i potrebnu kompatibilnost. Zatvaranje starih PHONE dozvola koordinisati sa R11/R12 i potvrđenim „Samo poruke” pravilom.

**Izlaz:** sintetički nalozi kroz stvarni Auth/API dokazuju dozvoljeno i zabranjeno čitanje, uključujući direktni zahtev i alternative kao alias/filter/order/wildcard gde su relevantne. RLS dokaz nije samo pogled u UI. Ako stari klijent zahteva preširoka prava, privatnost ima prvenstvo; definisati bezbedan minimum podržanih verzija.

### R02: lista, mapa, filteri i stvarna poruka greške

**Ulaz:** F15-F17, SB11; `src/app/(app)/zadaci.tsx`, `src/data/discoveryV1ClientTransport.ts`, `src/data/discoveryV1MarketplaceAdapter.ts`, `src/data/discoveryV1Owner.ts`, `src/data/discoveryV1ScreenSession.ts` i živi discovery RPC.

**Rad:** usaglasiti ponuđene PAGE/MAP/PLACES režime sa serverom; odvojiti stanje liste, podloge, pinova i prostornog rezultata; sačuvati pravi tip greške do UI-ja. Očuvati otkazivanje i pripadnost odgovora važećem upitu.

**Izlaz:** stvarni odgovor prolazi pravi decoder; uspešna lista opstaje uz kvar mape; prvi failure i retry su razumljivi; HALF/FULL/PEEK prikazuju dostupnu radnju iznad navigacije; REMOTE ne traži lažnu fizičku mapu. Izvesti isti scenario na ciljnom telefonu.

### R03: sopstveni zadaci i straničenje

**Ulaz:** F01; `src/data/needClientService.ts`, `src/data/ownTasksPage.ts`, `supabase/migrations/20261025000000_baseline_core_client_rpcs.sql`.

**Rad:** usaglasiti pet scope-ova, counts, format stavki i cursor. Ne vraćati ceo stari paket SQL funkcija preko novijeg pomoćnog vlasnika.

**Izlaz:** prazna i neprazna prva strana, nastavak, kraj liste, promena filtera, osveženje posle objave i tuđ nalog daju ispravno stanje bez duplih/preskočenih stavki. Ovo je zaseban kvar od javnog taba Zadaci.

### R04: jedinstven semantički rezultat AI-ja

**Ulaz:** F04-F06/F08; `backgroundTaxonomyArchitect.mjs`, `classificationGeminiShadow.mjs`, `serviceExecutionInstruction.mjs`, `workerServiceModeContext.mjs`, aktivni need/worker Edge handleri i signed-review vlasnici.

**Rad:** sačuvati pun katalog sa ispravnim roditeljskim vezama; stabilan identitet postojeće usluge; validiran upis nove grane; celinu očekivanih BOTH parova; razliku obične dopune vremena/cene i stvarne promene usluge.

**Izlaz:** mali reprezentativni semantički skup prolazi razgovor, pregled, Save, binder i readback. Pokriti sinonim, novu granu, dve usluge, BOTH, REMOTE predaju, „to je to”, promenu termina i stvarnu promenu posla. Stari pripremljen review i replay ne mogu proširiti prava ili prihvatiti nepotpunu novu nameru.

### R05: područje, vreme i dozvoljeni kandidat

**Ulaz:** F18; `src/contracts/workerAreas.ts` i postojeći SQL matching vlasnici.

**Rad:** sprečiti gubitak kandidata po staroj profilnoj tački pre stvarnih workAreas; pravilno tumačiti raspoloživost kasnije danas i poslovnu vremensku zonu. Sačuvati razliku automatske preporuke i dobrovoljne ručne prijave.

**Izlaz:** ista matrica dozvoljenih parova prolazi početni izbor, matcher, „Za mene” i dispatch. Već definisani STATIONARY slučajevi ne čekaju odluku o više lokacija. POINT_TO_POINT/MULTI_STOP/AREA_BASED proširenja čekaju konkretno razrešen poslovni ugovor iz odeljka 12.

### R06: trajan nastavak i ukupan AI trošak

**Ulaz:** F06/F07; postojeći taxonomy posao, `geminiTaskStream.ts`, `taxonomyPostSaveWorker.mjs`, `taxonomyProviderBudget.ts` i aktivni Edge handleri.

**Rad:** razdvojiti logički posao od konkretnog provider pokušaja. Sačuvati identitet, rok, ograničen broj pokušaja, budžet, stanje i readback. Urediti prvi plan pre čuvanja i nastavak posle čuvanja. Cache koristi potpun verzionisan katalog; jedan zajednički pokušaj učitavanja po instanci sprečava nepotrebne paralelne kopije.

**Izlaz:** restart, timeout, istekao lease, stari odgovor i paralelna promena imaju definisan završetak. Sigurno neposlat zahtev može imati dozvoljeni retry; nepoznat provider ishod ne dobija slepo novi pokušaj. Za dugotrajni UNKNOWN definisati vidljivo stanje, sledeću proveru, granicu automatskog rada i odgovornu intervenciju. Ne obećavati da je idempotentan poslovni rezultat dokaz tačno jednog naplaćenog modelskog poziva.

**Optimizacija:** najpre semantički reuse i uslovni snapshot; zatim mereni provider cache ako ga model i veličina konteksta opravdaju. Zajednički cache ne sadrži korisničke privatne poruke. Nepostojanje eksplicitnog Gemini cache-a samo po sebi nije prepreka objavi.

### R07: cena, neizvestan ishod i paralelne izmene

**Ulaz:** F02/F03/F11/F13; `pregled-zadatka.tsx`, `prilike/[id]/prijava.tsx`, `src/contracts/projections.ts`, `aiTaskReviewClientService.ts`, `applicationClientService.ts` i odgovarajući SQL vlasnici.

**Rad:** R07a odmah povlači zastarelu potvrđenu cenu pri ispravci unutar postojećeg domena. R07b usaglašava satnicu tek posle odluke o osnovici. Abandon dobija proveru iste radnje; dodatni profilni upis posle prijave ne prepisuje noviju izmenu profila.

**Izlaz:** isti iznos, valuta, osnovica, broj ljudi i relevantno trajanje ostaju kroz razgovor, pregled, prijavu i Dogovor. Izgubljen odgovor ne pretvara se u novu poslovnu radnju. Stari i paralelni odgovor ne mogu prepisati novo stanje.

**Zamena javne objave, A24:** proveriti uspeh, odbijanje, neizmenjen sadržaj i prekid. Prethodna objava ostaje važeća do uspeha transakcije zamene. Uspešna zamena zatvara staru objavu i odgovarajuće stare prijave u istoj transakciji; postojeće prijave ne prenose se na promenjene uslove.

### R08: prirodan završetak i veran sačuvani prikaz

**Ulaz:** F09/F10/F12; `src/app/(app)/profil/razgovor.tsx`, `workerAiClientService.ts`, `useWorkerExecutionModes.ts`, `WorkerAiPresentation.tsx`, `WorkerProfilePresentation.tsx` i need završni pregled.

**Rad:** autoritativan završetak, jedna potrebna informacija po sledećem pitanju, jedan smislen pregled, korekcija u istom razgovoru i prikaz sačuvanih podataka po usluzi. Uskladiti deterministički tekst sa važećim persiranjem.

**Izlaz:** DRAFT Save, Save+activate i izmena ACTIVE profila daju tačno različite ishode. Ponovo otvoren profil pokazuje iste potvrđene usluge/mode/predaju/pending detalje. Test „jedno pitanje” proverava značenje tražene informacije, ne samo broj upitnika.

### R09: poruke, obaveštenja i tačno odredište

**Ulaz:** F20, SB08/SB10; `profil/obavestenja.tsx`, `AgreementChat.tsx`, `PushPreferences.tsx`, `pushNotificationCopy.mjs`, `uskoci-push-transport/index.ts` i trenutni red/događaji.

**Rad:** izmeriti dolazak i obradu reda; ograničiti batch/rad po pozivu uz fairness i lease; rešiti semantički nepotrebne poruke već prijavljenom izvršiocu. PUSH i IN_APP preference su nezavisne. Grupna poruka emituje dozvoljen događaj samo za publiku koja sme da je vidi.

**Izlaz:** beleže se SQL wake, HTTP invocation, claim, provider rezultat i dokaz uređaja odvojeno. Proveriti PUSH on / IN_APP off, foreground/background/ugašenu aplikaciju, istu poruku, opozvanu sesiju, blokiranog korisnika i istekao cilj. Dodir otvara pravo autorizovano odredište. Provider retry/receipt ne smeju se pogrešno prikazati kao garantovana tačno jedna vidljiva isporuka.

### R10: saglasnosti, izvoz i zatvaranje naloga

**Ulaz:** F19, SB03; `profil/pravna.tsx`, `src/ui/legal/legalReview.ts`, current export/closure/retention vlasnici i sve relevantne kopije.

**Rad:** workAreas dodati u odgovarajuće izvozne i arhivske projekcije; potvrda pravila mora pripadati stvarnoj verziji dokumenta. Zasebno završiti izvoz, opoziv pristupa i postupak zatvaranja/brisanja kroz nalog, medije, voice, skladište i kopije.

**Izlaz:** autorizovan korisnik dobija ispravan sadržaj, drugi nalog ne može pristupiti izvozu, opozvan link ne važi, a brisanje ima potvrđen ishod i objašnjeno dozvoljeno zadržavanje. False readiness/binding ne pretvarati u true promenom očekivanog hash-a. Za objavu funkcija mora stvarno zadovoljiti zahtev; dugme koje je stalno blokirano nije dovršen tok.

### R11: ostali ekrani i usko čišćenje

Zadržati postojeću podelu: R11a početna/navigacija; R11b ocene/komentari; R11c mediji/safety/lifecycle; R11d nacrti i delimični upisi; R11e vreme/native layout/motion; R11f decoder/config; R11g proof/build; R11h demo izolacija. Time ostaju obuhvaćeni SB01, SB02, SB04-SB07, SB09, SB12-SB15 i X01-X06.

Svaki podzadatak dobija konkretan ekran/tok iz odeljka 7, posledicu za čoveka, vlasnika i dokaz. Obavezno dovršavanje ekrana odvojiti od uslovnog povlačenja istorije. Ne povlačiti obećani javni komentar samo zato što njegov čitač traži rad. Ne montirati nepovezan designLab prototip radi opravdavanja starog testa.

**Izlaz:** postojeće male, stvarne greške imaju potvrđenu popravku; korisnički tekst je dosledan; nacrti imaju ispravan vek; testni verifikatori zaista padaju kada se prekrši pravilo. C01-C19 ostaju vodič za ciljano čišćenje, uz konkretne potrošače i zamenu.

### R12: integracija, native kandidati i objavljivanje

**Ulaz:** F14 i rezultati svih obaveznih povezanih R zadataka; `app.config.js`, `eas.json`, build contract, migracije i deploy identiteti.

**Rad:** dokaz prikupljati tokom svake etape. Završno proveriti isti objavljivi kandidat, obe uloge, stvarni model, mrežne prekide, obnovu sesije, nadogradnju i povratak. Prazan bootstrap i upgrade postojeće baze su dve odvojene provere.

**Izlaz:** za odabranu platformu postoji instaliran kandidat, kompletan dokaz ključnih tokova, usaglašeni pravni tekstovi i deklaracije, sadržaj prijave, tačna konfiguracija produkcije i praktična procedura za neuspešno izdanje. „Spremno za prijavu”, „podneto”, „odobreno”, „objavljeno” i „provereno posle objave” su odvojeni statusi.

## 7. Inventar ekrana i povezanih tokova

Ovo je obavezni popis oblasti za proveru, a ne tvrdnja da se svaka oblast sastoji od jednog novog ekrana. Svaki pronađeni ekran/modal/sheet dobija svoju postojeću rutu i jednu oznaku: aktivan i povezan; kodiran ali nepovezan; istorijski/prototip; potreban a nedostaje; aktivan sa nedostajućim stanjem.

| Oblast za popis | Ishod koji mora biti razrađen | Veza sa radom |
|---|---|---|
| Početni ulaz i sesija | Prijava/registracija, potvrda, oporavak, istekao/nevažeći link, odjava i promena naloga. | R01/R11/R12; ulazi u J01-J14 |
| Izbor i promena uloge | Jasno razlikovanje naručioca i izvršioca; povratak i čuvanje dozvoljenog stanja. | R11/R12 |
| Početna i donja navigacija | Svaka kartica i prečica vode pravom sadržaju; bez pogrešne uloge ili prazne slepe ulice. | R11a; J09-J11 |
| Naručilac AI | Uvod, tekst, glas, fotografija, jedno pitanje, nastavak, prekid, nedovršen razgovor. | R04/R06/R08; J01/J02 |
| Naručilac pregled i mesto | Konačna celina, ispravka, foto, pin/predaja, nacrt, objava i potvrđen rezultat. | R02/R07/R08; J03/J04 |
| Moje potrebe i detalj | Statusi, counts, strane, izmena/zamena, prijave i dostupne radnje po statusu. | R03/R07/R11; J04/J10 |
| Izvršilac AI | Više usluga, načini rada, oblasti i raspoloživost bez nepotrebnih obaveznih formi. | R04/R06/R08; J05/J07/J08 |
| Pregled i sačuvan profil | Save, Save+activate, izmena aktivnog profila, pending po usluzi i ponovno otvaranje. | R04/R08/R10; J06 |
| Prilike, lista, mapa, filteri | Relevantni rezultati, ručna pretraga, bez lokacijske dozvole, bez rezultata, delimična greška. | R01/R02/R05; J08/J09 |
| Javni detalj i prijava | Dozvoljena javna polja, uslovi, slanje/izmena/povlačenje prijave gde ugovor to dozvoljava. | R01/R07/R11; J10 |
| Kandidati i izbor | Prava osoba, važeći uslovi/revizija, tačan kapacitet i potvrđen Dogovor. | R07/R11/R12; J10/J11 |
| Dogovor i tok posla | Obe uloge, promena uslova, početak, završetak, otkazivanje i dozvoljene informacije. | R07/R09/R11; J11 |
| Poruke i prilozi | Slanje, red, potvrde, greške, nacrti, foto/glas, grupna vidljivost i oporavak. | R09/R11c/R11d; J11/J13 |
| Obaveštenja | Preference, lista gde postoji, stvarni push i dozvoljeno odredište pri dodiru. | R09; J12 |
| Ocene i javni prikazi | Ko sme oceniti, šta je javno, promena/reload i istinit agregat. | R11b; J11 |
| Podrška i zaštita | Prijava problema/sadržaja/korisnika, blokiranje, potvrda, nacrt i obrada prijave. | R01/R10/R11 |
| Pravila, privatnost i podaci | Važeći dokument, saglasnost, izvoz, brisanje, bezbedan povratak i status zahteva. | R10; J14 |
| Podešavanja i dozvole | Lokacija, mikrofon, fotografije, obaveštenja; odbijanje i naknadna promena u sistemu. | R09/R11/R12 |
| O aplikaciji i pomoć | Razumljiv identitet izdanja, podrška i ispravni javni linkovi. | R11/R12 |

Za svaki red postoji najmanje jedna cela priča iz tri ugla: šta naručilac radi i vidi, šta izvršilac radi i vidi, šta sistem proverava/čuva/potvrđuje. Svaki J01-J14 mora imati vezu do konkretnih ekrana i radnji; pomoćni ulazni tokovi ne nestaju zato što nisu zaseban J broj.

## 8. Obrazac specifikacije ekrana i svake radnje

Popuniti ovaj obrazac za stvarni ekran. Podaci o poslovnoj logici upućuju na postojeći domen; dokument ili UI ne postaju novi vlasnik istog pravila.

1. **Identitet:** postojeća ruta, uloga, svrha, vezani J/R/F/SB/X i status aktivan/prototip/nedostaje.
2. **Ulazi:** odakle se dolazi, dozvoljen deep link/push, potrebna sesija, preduslovi i ponašanje zabranjenog pristupa.
3. **Podaci:** polja koja čovek vidi, privatnost svakog polja, postojeći reader i trenutak osvežavanja.
4. **Radnje:** za svako dugme navesti preduslov, značenje, postojeću komandu/writer, payload granicu, potvrdu i razlog disabled stanja.
5. **Stvarno sačuvano:** šta se menja na serveru, šta ostaje samo lokalni nacrt i kada je radnja završena.
6. **Potvrda:** autoritativni rezultat/readback; vidljiva posledica na drugim ekranima i kod druge uloge.
7. **Stanja:** početno, loading, empty, success, partial, greška, offline, zabranjeno/isteklo i nepoznat ishod upisa, gde su primenljiva.
8. **Prekidi:** Back, gest nazad, zatvaranje sheet-a, promena taba, background, restart, odjava i promena naloga.
9. **Konkurentnost:** dupli dodir, odgovori obrnutim redom, zastareo pregled, paralelna izmena i ponovljeno otvaranje.
10. **Nastavak:** šta može bezbedno da se ponovi, šta samo da se proveri i gde završava automatski retry.
11. **Tekst:** konačni nazivi, objašnjenja, greške i potvrde na srpskom; bez internih oznaka i lažnih obećanja.
12. **Prikaz:** hijerarhija, glavna radnja, sekundarne radnje, kartice, razmaci i postojeće zajedničke komponente.
13. **Telefon:** tastatura, safe area, donja navigacija, mali ekran, uvećan tekst i dugački realni sadržaji.
14. **Pristupačnost:** labels, redosled fokusa, status teksta umesto same boje, dovoljne dodirne površine i smanjene animacije.
15. **Dokaz:** prikaz bitnih stanja, relevantni test i fizička proba konkretnog kandidata kada je potrebna.
16. **Granica:** poznato ograničenje, vlasnik, razlog da li blokira baš ovo izdanje i sledeća radnja.

## 9. Četiri konkretna ugovora ponašanja

Predlozi korisničkog teksta u ovom odeljku služe za razradu. Nisu dokaz da su prikazi već nacrtani ili prihvaćeni. Očuvati postojeće pravilo formalnog obraćanja tamo gde je potvrđeno, a nazive dugmadi uskladiti kroz ceo proizvod.

### 9.1. Pregled potrebe i Objavi

Pregled prikazuje stvarne činjenice, cenu sa osnovicom, vreme, ljude i relevantno mesto/predaju. „Izmenite”, „Sačuvajte nacrt” i „Objavite” imaju različite efekte. Pending klasifikacija sama ne uvodi novu opštu zabranu.

| Stanje | Vidljivo ponašanje | Poslovni efekat |
|---|---|---|
| Spremno | Dostupna radnja za tačan prikazani pregled. | Još nema objave. |
| Slanje | „Objavljivanje je u toku.” Dugme ne šalje drugi pokušaj. | Isti pregled i stabilan identitet radnje. |
| Izgubljen odgovor | „Proveravamo da li je Vaša potreba objavljena.” | Provera iste radnje, bez nove objave ili novog modelskog poziva. |
| Potvrđen uspeh | „Vaša potreba je objavljena.” Otvara se stvarni detalj. | Readback potvrđuje isti Need i reviziju. |
| Potvrđeno odbijanje | Konkretan razlog i put za ispravku. | Nacrt/sadržaj ostaje prema važećem vlasniku. |
| Neizvesnost traje | Dostupna provera i iskreno objašnjenje. | Nema lažnog uspeha ili automatskog novog identiteta. |

Back tokom provere nije dokaz otkazivanja. Glavna radnja ostaje dostupna iznad tastature. Čitač ekrana dobija razumljivu najavu statusa bez neprekidnog ponavljanja.

### 9.2. Sačuvaj profil i Sačuvaj sa aktivacijom

Svaka usluga prikazuje svoj način rada, potrebnu predaju i status. DRAFT nudi odgovarajuća dva izbora na istom pregledu. ACTIVE izmena čuva izmene bez neželjene deaktivacije. Posle potvrde prikazuje se merodavan sačuvan profil, ne stara lokalna kartica.

Ako nova usluga čeka, poruka se vezuje za nju. Ne proglašavati sve stare usluge neaktivnim. Ako je tražen BOTH, uspeh jednog moda nije uspeh cele nove ponude. Izgubljen odgovor proverava isti Save; zastareo pregled traži obnovu i potrebnu potvrdu bez prepisivanja paralelne promene.

### 9.3. Discovery i delimična greška mape

Lista, podloga, pinovi i prostorni rezultat imaju odvojeno stanje. Ako lista radi a mapa ne radi, lista ostaje upotrebljiva. Ako podloga radi a zadaci na mapi ne rade, poruka precizira taj problem. Pri osvežavanju se može sačuvati još važeći prikaz, uz jasnu oznaku; rezultati starog filtera ne predstavljaju se kao novi.

Prvi failure bez podataka ima kratko objašnjenje i dostupno ponovno pokušavanje. Prazan rezultat kaže da nema zadataka za izabrane uslove. HALF/FULL/PEEK ne skrivaju radnju iza donje navigacije. REMOTE ne pokreće besmislen fizički MAP zahtev.

### 9.4. Izbor izvršioca i potvrđen Dogovor

Izbor se vezuje za važeću prijavu i uslove. Koristiti postojeći requester mehanizam, zamrznutu komandu, isti ključ i `readSelectedAgreement`; ne uvoditi drugi trajni journal samo da bi ličio na worker tok. Tokom upisa prikazuje se potvrđivanje. Tek autoritativni rezultat omogućava prikaz stvarnog Dogovora.

Brojač poput „Izabrano 1 od 2” treba koristiti samo kada je potvrđeno šta aktuelni domen broji: osobe, mesta ili timski kapacitet. Ne povećavati broj lokalnim brojanjem dodira. Zastarela prijava ili promenjeni uslovi daju objašnjenje i osvežen prikaz.

## 10. Vizuelno dovršavanje i snimci sa telefona

### 10.1. Snimanje u tri prolaza

**Prvi prolaz: polazno stanje.** Pre završnog dizajna uzeti nedostajuće prikaze trenutnog APK-a. Sačuvati poznati identitet verzije. Ne tražiti ponovo ista tri snimka koja su već u PDF-u; novi About dokaz ima smisla kada je izdanje promenjeno ili nedostaje podatak koji na starom prikazu nije postojao.

**Drugi prolaz: popravljeni tok.** Posle svake važne celine ponoviti isti scenario na ciljnom buildu. Upariti pre/posle za isti korak, ulogu i stanje. Kratak video je korisniji od izolovane slike za tastaturu, povratak, sheet, čekanje i dupli dodir.

**Treći prolaz: konačno izdanje.** Snimke za prodavnicu praviti iz proverenog release kandidata sa reprezentativnim probnim sadržajem i bez privatnih korisničkih podataka. Marketinški snimak mora odgovarati stvarnoj funkciji.

### 10.2. Redosled grupa koje korisnik može da pošalje

1. Početna, izbor/promena uloge, donja navigacija i povratak.
2. Naručilac: novi razgovor, završni pregled, mapa/predaja, objava i Moje potrebe.
3. Izvršilac: razgovor o uslugama, pregled, sačuvan profil, aktivacija i raspoloživost.
4. Prilike: lista, mapa, filteri, detalj, prijava i Moje prijave.
5. Kandidati, izbor, Dogovor, poruke, završetak i ocena.
6. Podešavanja, podrška, pravila, izvoz i brisanje.

Za prvi koristan pregled dovoljno je poslati jednu celu grupu. Korisnik ne treba sam da traži skrivene API greške ili da pravi stotine snimaka; izvršni tim reproducira tehničke neuspešne slučajeve u test okruženju.

### 10.3. Dizajn kao jedna dosledna celina

Iz aktuelnih komponenti i stvarnih prikaza utvrditi postojeći vizuelni pravac. Potom razraditi reprezentativne prikaze: početna, lista/kartica prilike, AI razgovor, završni pregled i Dogovor/poruke. Na njima zaključiti tipografiju, razmake, boje, ikone, dugmad, kartice, sheet/modal, prazna i neuspešna stanja.

Zajednička pravila ugraditi u postojeće komponente/tokene. Nema potrebe za drugim dizajn sistemom ili paralelnom aplikacijom. Veći vizuelni izbor prikazati korisniku kao konkretnu povezanu celinu; tehničke sitnice rešavati samostalno u okviru tog pravca.

Za svaku glavnu površinu proveriti: čitljivost, jednu jasnu primarnu radnju, potrebnu količinu informacija, dostupnost palcem, sadržaj uz tastaturu, dugačke naslove, veći font, fokus i smanjene animacije. „Premium” kvalitet ovde znači dosledan, razumljiv i stabilan proizvod u stvarnoj upotrebi.

## 11. Dokazi, provere i merenje

### 11.1. Minimalna jaka provera po promeni

Provera treba da bude dovoljno jaka za stvarni rizik. Ispravka RPC formata zahteva pravi odgovor i pravi decoder. Promena prava zahteva pozitivne i negativne autorizovane zahteve. Native geometrija zahteva uređajski prikaz. Sama promena teksta ne zahteva novi veliki testni sistem.

Sačuvati postojeće korisne provere. Dodavati samo nedostajući dokaz konkretnog rizika; ne praviti hiljade testova koji preslikavaju implementaciju. Proverivač mora pasti kad rezultat izostane, bude pogrešan ili se izabere pogrešna grana. Istorijskih 14.143 testa nisu novi dokaz ovog kandidata. [D4, odeljak 8]

### 11.2. Obavezne cele situacije

- Naručilac opiše potrebu, ispravi jednu činjenicu, potvrdi mesto gde treba, sačuva nacrt, ponovo ga otvori i objavi tačan sadržaj.
- Izvršilac doda dve usluge i odgovarajuće načine, potvrdi profil, aktivira kada je potrebno i ponovo vidi istu sačuvanu ponudu.
- Potreba dobija relevantnog izvršioca po usluzi, području i vremenu; ručna pretraga ostaje dostupna.
- Izvršilac se prijavi, naručilac izabere, obe uloge vide iste uslove Dogovora, razmene poruku/prilog, završe posao i vide ispravnu ocenu.
- Ista situacija uključuje realan prekid: izgubljen odgovor, restart, ponovljen dodir ili zastareo pregled, bez duplog efekta ili gubitka.
- Drugi nalog ne može pročitati privatno; blokiranje, prijava sadržaja, izvoz i brisanje rade kroz odgovarajuću autorizaciju.
- Push se proverava od događaja do uređaja i dodira, sa nezavisnim preferencama i dozvoljenim odredištem.
- Nadogradnja sa minimalne podržane instalacije čuva dozvoljene podatke i bezbedno rešava zastarele komande.

Za dvostranu interakciju koristiti dva odvojena naloga i najmanje dve nezavisne klijentske sesije. Za završni mobilni dokaz koristiti fizičke uređaje u potrebnim kombinacijama. Android prolaz ne dokazuje iOS.

### 11.3. AI provere

Odvojiti determinističke ugovorne testove od ograničenog živog modelskog korpusa. Ocena živog odgovora prati sačuvano značenje, potrebne činjenice, bezbednost i dozvoljen završetak; ne zahteva istu formulaciju pri svakom pozivu.

Pre živog pokretanja odrediti broj primera i maksimalni budžet. Beležiti sve pokušaje, uspeh, timeout, retry, broj poziva i ukupni trošak. Jasna korisnička usluga ne sme zbog unutrašnjeg kvara postati zahtev da korisnik izabere tehničku kategoriju.

### 11.4. Merenja koja imaju smisla za korisnika

Meriti dodir do vidljivog odziva, prvog korisnog sadržaja i potvrđenog ishoda; hladno/toplo učitavanje; sačuvani rezultat posle restarta; čekanje reda; provider rezultat i uočenu isporuku na telefonu. Uz p50/p95 prikazati broj uzoraka, uređaj, mrežu i verziju; mali uzorak ne predstavlja produkcionu statistiku.

**Početni predlog budžeta za planiranje, koji nije izmereni rezultat:** lokalni odziv na dodir do približno 250 ms; tipičan mrežni read do 3 s na dogovorenim referentnim uslovima; prvi koristan AI odgovor do 8 s u 95. percentilu reprezentativnog uzorka. Ovi ciljevi se pre release-a potvrđuju ili menjaju uz stvarna merenja i obrazloženje, bez tihog pomeranja granice radi prolaza. Za sporije grane UI objašnjava čekanje i nudi bezbedan nastavak. Postojeći discovery rok od 15 s nije cilj normalne brzine. [D3, odeljak 8]

Kapacitet push reda dokazati testom očekivanog talasa i konkurentnih događaja, sa veličinom zaostatka i starošću najstarijeg posla. SQL cron uspeh ili provider acceptance nisu dokaz koliko brzo čovek dobije obaveštenje. Broj sintetičkih profila nije broj istovremenih korisnika.

## 12. Poslovne odluke i pitanja koja stvarno ostaju

### 12.1. Satnica i više ljudi

Potrebno je odlučiti da li satnica znači cenu po osobi ili za celu ekipu, odnosno da li proizvod eksplicitno podržava obe osnovice. Dve osobe, tri sata i 1.200 RSD daju ukupno 7.200 RSD kada je 1.200 RSD satnica po osobi, odnosno ukupno 3.600 RSD kada je 1.200 RSD satnica za celu ekipu. To je ilustracija značenja, a ne tvrdnja da aplikacija već obračunava konačan račun.

**Predlog za jednostavno prvo izdanje:** izričita satnica po osobi, jasno naznačena kroz ceo tok. Ako trajanje nije poznato, prikazati ugovorenu satnicu bez izmišljene ukupne cene. Ovo ostaje predlog do vlasnikove odluke. R07a/F11/F13 ne čekaju taj izbor. [D2, odeljak 13; D3, R07b]

### 12.2. Posao sa više lokacija

Za Novi Sad-Beograd treba razlikovati područje gde osoba dolazi da radi, polazište preuzimanja i domet dostave. Uslov da izvršilac radi na obe radne tačke može biti opravdan za višelokacijski rad, ali može nepotrebno ukloniti prevoznika koji polazi iz Novog Sada i dobrovoljno vozi u Beograd.

Pre odluke uporediti najmanje prevoz između dva grada, dostavu sa više stanica i rad na dve odvojene lokacije. Revizija 7 predlaže pokriće stvarnih radnih tačaka; alternativa je polazište uz jasno prikazanu rutu. Nijedna opcija nije već zaključana. Ne zahtevati pokriće svakog tranzitnog kilometra niti prećutno menjati ručnu prijavu. [D2, odeljak 13; D3, R05]

### 12.3. Vizuelne i operativne odluke

Preostali izbori obuhvataju potvrdu vizuelnog pravca, eventualnu promenu redosleda pregleda/mape i redosled objavljivanja platformi. To nisu razlozi da se zaustave nepovezane popravke. Predlog plana je da se Android kandidat vodi prema postojećem APK iskustvu, a iOS dobije svoju paralelnu listu spremnosti i kasniji ili istovremeni termin prema stvarnom stanju.

Ne uvoditi nove valute, uklanjanje administrativnog grada, naplatu, HITNO ili novu moderaciju slobodnog teksta kao usputnu optimizaciju. Takva promena ima svoj razlog, konkretan prikaz posledica i odluku.

## 13. Produkcija i pouzdana isporuka

Pročitani README zahteva odvojen produkcioni backend; `eas.json` još sadrži DEV cilj u produkcionom profilu, dok build contract namerno sprečava takvu objavu. To je otvoren release posao, ne razlog da se zaštita isključi. [G2, G5]

Pre release-a završiti:

1. **Reprodukciju:** iz praznog izolovanog okruženja podići šemu uz jasno odvojene potrebne seed/fixture ulaze. Proveriti stvarne funkcije i prava.
2. **Nadogradnju:** unaprediti postojeće okruženje uz očuvanje podataka i minimalnih podržanih klijenata. Broj ledger zapisa i broj source migracija ne moraju sami po sebi biti jednaki.
3. **Kompatibilnost:** nove ugovore prvo dodati/proveriti, zatim pustiti kompatibilnog klijenta, pa tek povući stari put kada prestane da bude potreban. Kritična privatnost se ne odlaže radi stare verzije.
4. **Konfiguraciju:** Auth redirect, mejl, dozvole, skladište, Realtime, Edge, push, rate limits i bezbedni feature flag-ovi pripadaju pravom okruženju. Ne kopirati testne naloge i privatne razvojne podatke u produkciju.
5. **Identitet aplikacije:** store paket, native potpis, runtime/OTA kanal i produkcione dozvole moraju biti usklađeni. U izvoru je Android store paket `rs.uskoci`; njegovo stvarno stanje u Play Console tek treba proveriti. [G4]
6. **Oporavak:** probati vraćanje aplikacije i odgovarajući povratni ili kompenzacioni postupak za bazu. OTA rollback ne vraća automatski šemu ili već nastale podatke.
7. **Pristup za proveru:** namenski nalozi i reprezentativni podaci daju pristup svim važnim funkcijama bez privilegija nad stvarnim tuđim podacima. Backend ostaje dostupan tokom pregleda prodavnice.

Native promene, uključujući potrebne SDK/permission izmene, ne smatrati rešenim samo OTA izmenom JavaScript-a. Izvršiti odgovarajući native build i potvrditi stvarno ponašanje.

## 14. Google Play i Apple App Store

Zahtevi u ovom odeljku provereni su na zvaničnim izvorima 27.10.2026. Pred predaju ponovo proveriti primenljive uslove i konkretne konzole. APK je Android paket za instalaciju; Apple izdanje zahteva sopstveni iOS build. Isti proizvod može koristiti zajednički izvor, ali platforme imaju odvojene dokaze i prijave.

### 14.1. Zajednički sadržaj i stvarno ponašanje

- Potvrđen izdavač, odgovorni kontakt i podrška koja stvarno prima zahteve.
- Javno dostupna politika privatnosti i uslovi koji odgovaraju podacima, korisnicima i funkcijama stvarnog izdanja.
- Popis podataka i SDK obrada: nalog, profil, mesto, poruke, fotografije/glas, AI obrada, push identifikatori, dijagnostika i rokovi zadržavanja prema stvarnom proizvodu. Deklaracije nisu prepisane iz generičkog obrasca. Google izričito obuhvata i podatke koje obrađuju ugrađeni SDK-ovi. [W3]
- Prijava neprimerenog sadržaja/korisnika, blokiranje i osoba/proces koji obrađuje prijave. Postojanje dugmeta bez funkcionalne obrade nije završen operativni tok. Google UGC pravila traže odgovarajuću stalnu moderaciju. [W4]
- Potrebne OS dozvole traže se u razumljivom trenutku; odbijanje vodi alternativi gde je moguća, a ne pogrešnoj tvrdnji o mrežnom kvaru.
- Stvarni tok brisanja, potrebne potvrde, rok i izuzeci zadržavanja. Blokirano brisanje zbog nezavršenog binding-a nije prihvatljiv konačan korisnički ishod.
- Naziv, ikona, opis, odgovarajući upitnici o uzrastu/sadržaju, screenshotovi konačnog kandidata i uputstvo za proveru obe uloge.
- Ako prvo izdanje nema naplatu platforme, ne uključivati stare naknade radi popunjavanja dokumentacije. Buduća naplata dobija zasebnu proveru primenljivih pravila.

### 14.2. Android prijava

| Stavka | Konkretan izlaz |
|---|---|
| Play nalog i identitet | Potvrđen vlasnik/tip naloga, potrebna verifikacija, paket i pristup aplikaciji u konzoli. |
| Paket za predaju | Potpisan AAB i proverene instalacije koje Play generiše. Google za nove aplikacije zahteva Android App Bundle. [W1] |
| Platformski nivo | Za novu telefonsku aplikaciju ili update sada je cilj Android 16 / API 36 ili viši; ne oslanjati se na stari API 35 zahtev. [W2] |
| Native kompatibilnost | Proveriti 64-bitne native biblioteke, 16 KB kompatibilnost stvarnog paketa i primenljiv rok/obaveštenje konzole. Sam uspeh lokalnog APK-a nije dovoljan. [W6] |
| Privatnost | Tačan Data safety obrazac, politika, dozvole i SDK obrada. [W3] |
| Brisanje | Put u aplikaciji i javna veb mogućnost za zahtev brisanja naloga i pripadajućih podataka. [W5] |
| Testiranje | Internal/closed proba odgovarajućeg kandidata; za lični nalog otvoren posle 13.11.2023. primenjuje se najmanje 12 prijavljenih testera neprekidno 14 dana pre zahteva za production pristup. Proveriti da li se uslov odnosi na ovaj nalog. [W7] |
| Pregled i objava | Pristup recenzentu, ispravni listinzi, prihvatljiva provera pre objave, zatim izričito odobrena predaja/puštanje. |

Nije potvrđeno da su nalog, testeri ili deklaracije već završeni. Ispunjenih 14 dana samo po sebi nije garancija odobrenja produkcionog pristupa.

### 14.3. iOS prijava

| Stavka | Konkretan izlaz |
|---|---|
| Apple nalog i aplikacija | Potvrđen Apple Developer/App Store Connect pristup, izdavač, bundle ID, potpis i potrebne mogućnosti aplikacije. |
| Build | Sopstveni iOS kandidat iz podržanog okruženja. Aktuelni minimum za predaju uključuje Xcode 26 ili noviji i iOS 26 SDK ili noviji. To ne znači da minimalni podržani telefon mora da ima iOS 26. [W8] |
| Uređaj i TestFlight | Proverene dozvole, tastatura, navigacija, mediji, linkovi i push na iOS-u; odgovarajuća TestFlight proba pre javnog izdanja. |
| Brisanje naloga | Korisnik pokreće brisanje iz aplikacije; samo deaktivacija ili obavezan običan mejl podršci nisu dovoljan opšti tok za ovu vrstu aplikacije. [W9] |
| Privatnost i SDK-ovi | App Privacy odgovori, potrebni privacy manifests i razlozi za obuhvaćene API-je prema stvarnom build-u i zavisnostima. [W11, W12] |
| AI, prijava i sadržaj | Pre deljenja ličnih podataka sa spoljnim AI-jem jasno objašnjenje i izričita dozvola. Ako postoje obuhvaćene društvene prijave, proveriti odgovarajuću alternativu prema 4.8; email/password ne znači automatski obavezan Sign in with Apple. Za sadržaj korisnika proveriti zaštite iz 1.2. [W10] |
| Predaja | Precizan opis, screenshotovi, upitnici, support/privacy linkovi, nalozi i napomene za pregled obe uloge. |

Funkcionalni Android APK nije dokaz iOS spremnosti. Nedostatak iOS dokaza označava se kao otvorena iOS stavka, bez zaustavljanja nezavisnog Android dovršavanja.

## 15. Podrška posle objave i kontrola izdanja

Pre javnog puštanja odrediti odgovornu osobu i postupak za kvar osnovnog toka, privatnost, zastarele pozadinske poslove, porast troška, neuspešno brisanje i prijavu neprimerenog sadržaja. Koristiti postojeće instrumente i vlasnike; novi administrativni sistem nije automatski potreban.

Pratiti verziju uz crash/grešku, prolaz ključnih radnji, vreme do potvrđenog ishoda, starost reda, nepoznate provider ishode, stvarne neuspehe dostave i backlog podrške. Logovi ne sadrže sirove privatne poruke, tajne ili nepotrebne lične podatke.

Pre svake nove verzije sačuvati šta je promenjeno, koje granice su pogođene, šta je provereno i kako se zaustavlja ili popravlja loše izdanje. Prvi release nema svuda iste opcije postepenog puštanja kao update; način ograničavanja publike odabrati prema stvarnim opcijama prodavnice.

Rok za objavu dati tek nakon početnog preseka, platformskih uslova i procene konkretnih zadataka. Ne obećavati „za nekoliko dana” na osnovu broja testova ili dužine analize. Svaki sledeći korak završava se pregledljivim rezultatom, pa se plan osvežava prema novom dokazu.

## 16. Dokumentacija i kontinuitet bez novih slojeva

Zadržati tri sadržajno različite celine i jedan indeks dokaza:

1. **USKOCI_IZVESTAJ:** razumljiv opis trenutnog stanja, cilja i preostalih poslovnih odluka. U njega uključiti konačnu priču naručioca, izvršioca i sistema.
2. **CODEX_PLAN_RADA:** važeći redosled, obim prvog izdanja, ekran/radnja matrica, R/J/F veze i izlazni uslovi. Ovu reviziju ugraditi u postojeći operativni plan uz očuvanje njegovih konkretnih zadataka, veza, testnih komandi i cleanup uslova; ne zamenjivati ih skraćenim opisima iz ove dopune.
3. **TEHNICKI_DOKAZI:** precizni izvori, ugovori, izvršene provere, verzije i tehnička ograničenja. Originalni istorijski dokaz ostaje sa svojim datumom.
4. **Indeks dokaza:** veze do stvarnih test rezultata, prikaza, izlaznih artefakata i identiteta izdanja.

Matrice mogu biti tabele u postojećim dokumentima ili postojeći strukturisani registar. Ne praviti novi servis, validator ili kontrolni sistem samo da bi postojao još jedan „source of truth”. Za svaku promenu ažurirati povezano trenutno stanje; ne ponavljati isti dugi izveštaj posle svakog malog koraka.

Za tehnički prenos preporučen je originalni kompletan ZIP revizije 7 uz ovaj plan. U ovom razgovoru nedostaje 120 dokaznih priloga, pa se ne isporučuje prepakovani „potpuni” ZIP sa izmišljenim ili prećutno izostavljenim dokazima.

## 17. Konkretan zadatak za nastavak u Codex-u

Sledeći tekst je operativni predlog za sesiju kojoj vlasnik zada implementaciju. Samo postojanje ovog teksta u dokumentu nije naredba da se sada menjaju udaljeni sistemi.

> Nastavi USKOČI prema važećem CODEX_PLAN_RADA, dopunjenom operativnom revizijom 8 od 27.10.2026. Sačuvaj nalaze F/SB/X, zadatke R01-R12 i tokove J01-J14. Prvo fizički potvrdi repo, granu, HEAD, radno stablo, aktuelne instrukcije, backend i razlike u odnosu na analizirani presek. Ne vraćaj starije naknade, HITNO ili PHONE ponašanje iz memorije.
>
> Cilj je završena, dosledna aplikacija: definisani ekrani i stanja, logika svake radnje, stvarni upisi/readback, izgled na telefonu i kompletna spremnost izabrane platforme za prodavnicu. Počni R01 zaštitom podataka i potvrdom ugovora, uz paralelan popis ekrana i pripremu release uslova. R02 i R03 mogu teći paralelno nakon usaglašenog R01. Zatim dovršavaj cele korisničke situacije kroz R04-R11, prikupljajući R12 dokaz od početka.
>
> Za svaki ekran i važnu radnju popuni obrazac iz plana. Razlikuj definisano, vizuelno razrađeno, implementirano i dokazano. Ne proglašavaj screenshot dokazom servera, zeleni mock telefonskim prolazom, niti istorijski test novim rezultatom.
>
> Radi nad postojećim vlasnicima. Čuvaj granice naloga/revizije, signed review, journal, idempotentan poslovni efekat i autoritativni readback. Neizvestan ishod proveravaj kao istu radnju. Čuvaj razliku nacrta, objave, aktivacije i spremnosti za povezivanje. Usko povlači dokazani višak uz zamenu i kompatibilnost.
>
> Koristi paralelne stručne agente kada mogu nezavisno pregledati domen, UI, backend ili dokaze. Jedan integrator vodi redosled promena zajedničkih vlasnika. Agenti ne menjaju iste review/matching/export ugovore nezavisno jedan od drugog. Osveži HEAD pre integracije i posle značajnog koraka.
>
> Posle svakog završenog dozvoljenog koraka nastavi sledeći relevantni zadatak u odobrenom obimu. Daj kratak status: problem, izmena, dokaz, ograničenje i sledeći korak. Ne otvaraj novi neograničen audit bez novog razloga. Za odluku o satnici i višelokacijskom povezivanju pripremi konkretne opcije; nezavisan rad nastavi.
>
> Razdvoji Android/AAB i iOS/TestFlight izlaze. Pripremi sve pregledljivo pre završne odluke o objavljivanju. Ne uklanjaj produkcione zaštite, ne koristi DEV kao produkciju i ne izvodi destruktivne promene, troškovne ili javne release radnje bez potrebnog važećeg ovlašćenja. Ne tvrdi da rad traje u pozadini nakon završetka aktivne sesije.

### Prvi pregledljiv rezultat ove naredne sesije

- Svež identitet izvora i isporuke, uz tačno razdvojene poznate i nepoznate podatke.
- Potvrđen minimalni obim prvog izdanja i konkretne release prepreke.
- Popunjen početni inventar stvarnih ekrana/ruta i prva cela korisnička priča.
- R01 promena ili precizna konkretna blokada sa završenim nezavisnim bezbednim radom.
- Pripremljen prvi R02/R03 scenario i vizuelni pre/posle dokaz koji će se tražiti na ciljanom telefonu.

## 18. Izvori i granice

### Dostavljeni paket

- **D1:** [PROCITAJ_PRVO, revizija 7](https://chatgpt.com/library?file_id=libfile_af1d195761c08191810beabec28d7b54&account_id=personal), posebno opseg i odložene etape.
- **D2:** [USKOCI_IZVESTAJ, Markdown](https://chatgpt.com/library?file_id=libfile_16847a3164048191a1928eac6741b2b7&account_id=personal), posebno odeljci 4-8 i 13-14.
- **D3:** [CODEX_PLAN_RADA, revizija 7](https://chatgpt.com/library?file_id=libfile_0698d8f07f0481918eb6673cba090560&account_id=personal), odeljci 1-10.
- **D4:** [TEHNICKI_DOKAZI](https://chatgpt.com/library?file_id=libfile_fcb6db7fab888191b17c186afdd3716b&account_id=personal), posebno F01-F21, provere R01-R12 i granice detaljnosti.
- **D5:** [MANIFEST revizije 7](https://chatgpt.com/library?file_id=libfile_20ebab9074048191903ef0c2f90d8507&account_id=personal), integritet pet prisutnih sadržajnih fajlova i popis ostalih priloga.
- **D6:** [USKOCI_IZVESTAJ, PDF](https://chatgpt.com/library?file_id=libfile_c607057cfa38819197ddb1afa3268fa9&account_id=personal), 40 strana; stvarne slike na strani 9.

### Pročitani trenutni izvor

- **G1:** [Provereni commit](https://github.com/uskocibusiness-boop/USKOCI-EAN/commit/a9692e11942609bab9406215c3e407d79589dafa). Connector poređenje sa `feature/uskoci-cisto` vratilo je identical, ahead 0, behind 0 tokom pregleda.
- **G2:** [README](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/README.md).
- **G3:** [STATUS](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/STATUS.md).
- **G4:** [app.config.js](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/app.config.js).
- **G5:** [eas.json](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/eas.json).

### Zvanični zahtevi prodavnica

- **W1:** [Google Play - Android App Bundle](https://support.google.com/googleplay/android-developer/answer/9844279).
- **W2:** [Google Play - target API nivo](https://support.google.com/googleplay/android-developer/answer/11926878?hl=en).
- **W3:** [Google Play - Data safety](https://support.google.com/googleplay/android-developer/answer/10787469?hl=en).
- **W4:** [Google Play - User-generated content](https://support.google.com/googleplay/android-developer/answer/9876937?hl=en-GB).
- **W5:** [Google Play - brisanje naloga](https://support.google.com/googleplay/android-developer/answer/13327111?hl=en).
- **W6:** [Android Developers - 16 KB kompatibilnost](https://developer.android.com/guide/practices/page-sizes).
- **W7:** [Google Play - testiranje novih ličnih naloga](https://support.google.com/googleplay/android-developer/answer/14151465?hl=en).
- **W8:** [Apple - aktuelni zahtevi za predaju](https://developer.apple.com/news/upcoming-requirements/).
- **W9:** [Apple - brisanje naloga u aplikaciji](https://developer.apple.com/support/offering-account-deletion-in-your-app/).
- **W10:** [Apple App Review Guidelines](https://developer.apple.com/app-store/review/guidelines/), posebno 1.2, 4.8 i 5.1.2(i).
- **W11:** [Apple - privacy manifests i SDK obaveze](https://developer.apple.com/news/?id=3d8a9yyh).
- **W12:** [Apple - App Privacy Details](https://developer.apple.com/app-store/app-privacy-details/).

Ovaj pregled ocenjuje dostavljeni plan i dodaje operativnu završnicu. Ne predstavlja novu bezbednosnu sertifikaciju, pravno odobrenje, potvrdu izvršenih popravki ili garanciju prihvatanja od strane prodavnica.
