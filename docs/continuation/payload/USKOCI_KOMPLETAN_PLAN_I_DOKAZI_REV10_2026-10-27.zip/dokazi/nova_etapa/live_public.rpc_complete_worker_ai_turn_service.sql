CREATE OR REPLACE FUNCTION public.rpc_complete_worker_ai_turn_service(p_account_id uuid, p_conversation_id uuid, p_client_request_id uuid, p_attempt_id uuid, p_output jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
declare s private.worker_ai_sessions; t private.worker_ai_turns; hash text; next_candidate jsonb;
begin
 if auth.role() is distinct from 'service_role' then raise exception 'SERVICE_ROLE_REQUIRED' using errcode='42501'; end if;
 perform private.closure_assert_open(p_account_id);
 perform pg_advisory_xact_lock(hashtextextended('worker-ai-turn:'||p_account_id::text||p_client_request_id::text,0));
 select * into s from private.worker_ai_sessions where conversation_id=p_conversation_id and account_id=p_account_id for update;
 if not found then raise exception 'WORKER_AI_DENIED' using errcode='42501'; end if;
 perform 1 from public.ai_conversations where id=p_conversation_id and account_id=p_account_id and purpose='PROFILE' for update;
 if not found then raise exception 'WORKER_AI_DENIED' using errcode='42501';end if;
 select * into t from private.worker_ai_turns where account_id=p_account_id and client_request_id=p_client_request_id for update;
 if not found or t.conversation_id is distinct from p_conversation_id or t.attempt_id is distinct from p_attempt_id then raise exception 'WORKER_AI_DENIED' using errcode='42501'; end if;
 if t.cancelled_at is not null then return private.worker_ai_turn_document(t.turn_id);end if;
 hash:=encode(extensions.digest(p_output::text,'sha256'),'hex');
 if t.state='SUCCEEDED' then
  if t.completion_hash is distinct from hash then raise exception 'WORKER_AI_REQUEST_CONFLICT' using errcode='PT409'; end if;
  return private.worker_ai_turn_document(t.turn_id);
 end if;
 if t.state<>'PROCESSING' or not t.provider_dispatched or t.cancelled_at is not null or t.lease_expires_at<clock_timestamp() or t.source_revision<>s.revision
 then raise exception 'WORKER_AI_TURN_STALE' using errcode='PT409'; end if;
 perform public.rpc_read_worker_ai_context_service(p_account_id,p_conversation_id);
 if jsonb_typeof(p_output) is distinct from 'object' or p_output-array['assistantMessage','safety','patch']<>'{}'::jsonb
  or not(p_output?&array['assistantMessage','safety','patch'])
  or jsonb_typeof(p_output->'assistantMessage') is distinct from 'string'
  or length(btrim(p_output->>'assistantMessage')) not between 1 and 1200
  or coalesce(p_output->>'safety','') not in ('ALLOW','CLARIFY','REVIEW','BLOCK')
 then raise exception 'WORKER_AI_OUTPUT_INVALID' using errcode='22023'; end if;
 next_candidate:=private.worker_ai_patch(s.candidate,p_output->'patch',s.profile_id,s.account_id,false);
 if p_output->>'safety' in ('BLOCK','REVIEW') then next_candidate:=s.candidate; end if;
 update private.worker_ai_sessions set candidate=next_candidate,revision=revision+1,safety=p_output->>'safety' where conversation_id=p_conversation_id;
 insert into public.ai_messages(account_id,conversation_id,role,body,safety)
 values(p_account_id,p_conversation_id,'ASSISTANT',p_output->>'assistantMessage',p_output->>'safety');
 update private.worker_ai_turns set state='SUCCEEDED',completion_hash=hash where turn_id=t.turn_id;
 return private.worker_ai_turn_document(t.turn_id);
end $function$
