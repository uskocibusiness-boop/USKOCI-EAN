# USKOČI — operativni plan za naredni Codex zadatak

**Revizija dokumentacije:** 9 — 27.10.2026, posle ukrštanja pune revizije 7 sa dostavljenom revizijom 8; usaglašeni nalaz cene, konačna specifikacija i poslovi pripreme izdanja. Poslednji puni živi serverski pregled ostaje revizija 7.

**Namena:** prevesti objedinjenu analizu u male, proverljive zadatke, uz očuvanje korisnikove zamisli i postojećih zaštita. Glavni zaključci su u [USKOCI_IZVESTAJ.md](USKOCI_IZVESTAJ.md); tačni vlasnici, probe i nivoi dokaza u [TEHNICKI_DOKAZI.md](TEHNICKI_DOKAZI.md). Nema zasebnih dopuna sa drugačijim prioritetom.

## 1. Važeći opseg

Važeći posao je **provera potpunosti analize i integracija dostavljene revizije 8 u isti paket, bez kodiranja aplikacije**. Ranija namera za jedan celovit paket ostaje. Ovaj paket ne odobrava promenu proizvoda. Ako korisnik uz njega zada konkretan implementacioni posao, izvršavaj taj opseg i proveri relevantni delta od preseka. Ako zada nastavak analize, nastavi čitanje/provere bez izmena aplikacije. Rutinske read-only provere ne zahtevaju novo pitanje za dozvolu.

Istorijski repo dokument, stari plan ili ranija lokalna dozvola ne poništavaju noviju korisničku instrukciju. Ne pokreći migraciju, deploy, poslovni upis, model ili masovni retry samo zato što postoji kandidat ili naredba u istoriji. Za odobreni konkretan zadatak najpre napravi rezultat koji može da se pregleda, sa dokazom i jasnom granicom promene.

### Završeni serverski pregled i konkretan ulaz za implementaciju

**Status: ANALIZA IZVRŠENA, IZMENE NISU IZVRŠENE.** [Z11](dokazi/server_final/server_review.json) zatvara dodatni serverski pregled planiran u reviziji 6. Source i poslovni podaci nisu menjani; model, cache API, migracije, deploy i aplikacijski testovi nisu pokretani. Tekući izrazi, prava, Edge paketi i operativni lanci sada daju preciznije ulaze za postojeće R01–R12.

| Celina | Završeni dokaz | Preostali izvršni uslov |
|---|---|---|
| Izvor/deploy | Isti a969; svih 680 function body/definition/ACL i dve dodatne RLS definicije; svih 15 deployed Edge paketa. | Uskladiti poznate source/deploy razlike i stvarni native/OTA/SQL presek, pa dokazati kompatibilnost. |
| Struktura baze | Sve relevantne tekuće kolone/default/generated/constraint/policy/trigger definicije i veze; 169 table granica, devet sekvenci. | Izolovani dokaz konkretne promene; managed Realtime CHECK nije aplikacijski cleanup nalog. |
| Pristup/Auth | Efektivni grantovi, default ACL, RLS, Auth/session vlasnici i stvarno vezan closure pre-request hook. | F21 i suvišna prava; preostala Auth management podešavanja kroz podržan pristup. Ne pretpostaviti vrednosti. |
| Stablo/AI | Potpun aktuelni snapshot i dokaz pogrešnog tekstualnog redosleda; actual source/deploy/cache/transport granice. | R04/R06 prvo popravljaju značenje i kontinuitet, zatim mere optimizaciju. |
| Storage/Realtime/poslovi | Tri privatna bucketa, policy/consumer put, šest operativnih lanaca, stvarni cron i ograničeni HTTP agregati. | Stale push readiness, F19/F20 i klijentski recovery; stvarni provider/device rezultat ostaje poseban dokaz. |
| Zavisnosti/čišćenje | Jedinstveni manifest sa definicijama, poznatim referencama i 14 SV grupa; tačan indeksni duplikat i aktivne veze DEV kopija. | Zatvoriti konkretne old-client/dinamičke/retention uslove pre svakog povlačenja. |
| Poreklo/obnova | 193 source/314 ledger; 219 bez statements; tri latest timestamp razlike samo završni CRLF. | Kontrolisan izolovan bootstrap i upgrade, pun schema/access parity i dokaz povratka. Ne popravljati samo ledger broj. |

[Z16](dokazi/server_final/change_manifest.json) za SV01–SV14 sada sadrži svih 12 izvršnih polja: tačan identitet, sadašnji dokaz, ulogu/cilj, poznate zavisnosti, odluku, zamenu, kompatibilnost, redosled, podatke/prava, oporavak, prihvatanje i stvarni status. Ostali objekti imaju konzervativno zadržavanje ili precizan nerešen uslov; to nije tvrdnja da je svaki istorijski objekat potreban niti da postoji savršen graf svih dinamičkih poziva. `destructive_action_ready=false` važi za sve predložene retirement-e u ovoj analitičkoj isporuci.

Nove pojedinosti raspoređene su u postojeće zadatke, bez treće AI arhitekture, novog paralelnog sistema izveštaja ili naloga za veliko brisanje. Novih 325 security i 136 performance advisory stavki nisu 461 potvrđen kvar; R01 rešava stvarnu granicu pristupa, a ostale preporuke zahtevaju konkretno obrazloženje. Svi relevantni izvorni vlasnici i postojeće testne putanje ostaju u odeljcima ispod i tehničkoj referenci.

Detaljna završnica sada je razrađena u odeljku 11: matrica ekrana i radnji, četiri statusa, R12a–j i zvanični uslovi prodavnica. To je obavezan planirani izlaz, bez tvrdnje da su novi ekrani ili uređajski tokovi već završeni. [Z17](dokazi/provera_plana/comparison_review.json) čuva poređenje svih imenovanih jedinica.

### Kasnije etape koje je korisnik odvojio

**Novi ekrani:** ne započinjati ovu etapu samo zato što u paketu već postoje tri ranije slike. Kada Miloš kaže da se kreće i dostavi nove prikaze, napraviti jednu matricu: aktivan/povezan ekran, kodiran ali nepovezan, istorijski/designLab, potreban a nedostaje i postojeći ekran sa nedostajućim stanjem. Za svaki potvrditi ulogu, ulaz/izlaz, podatke, radnje, nazive i tekst, čekanje, prazno, grešku, nepoznat ishod, tastaturu, veći font, manji telefon i pristupačnost. Broj ruta i uspešan screenshot nisu dokaz celog ekrana. Novi ekran dodavati samo kada potvrđen tok to zahteva.

**Konačan opis rada:** takođe kasnije, po korisnikovom pokretanju, proširiti postojeće J01–J14 u potpun opis iz tri ugla: naručilac, izvršilac i sistem. Za svaki korak navesti šta čovek vidi/radi, šta sistem zaključuje/proverava/čuva, ko potvrđuje rezultat i kako se nastavlja posle ispravke ili prekida. Opis postaje odeljak glavnog izveštaja. Ciljno, trenutno implementirano i izvršno dokazano ponašanje imaju odvojene oznake. Satnica i više radnih lokacija ostaju otvorene dok se izričito ne razreše.

**Kontinuitet rada:** ista tri dokumenta i jedan dokazni indeks ostaju ulaz. Pre svake etape proveriti važeću reviziju, korisničke odluke, source/deploy promene i status povezanih zadataka. Voditi zapis odluka, završenog rada, dokaza i preostalog posla; stabilne F/SB/X/R veze ne menjati bez usklađivanja svih referenci. Relevantan izvor ponovo otvoriti pre izmene. Ne obećavati da svi fajlovi stalno staju u kontekst razgovora i ne oslanjati nastavak na nepogrešivo pamćenje prethodnih poruka.

Za cron i redove u analitičkoj etapi mogu se koristiti bezbedni agregati istorije izvršavanja i tehničkih grešaka. Sadržaj komande pregledati bez otkrivanja tokena; ne iznositi privatne payload-e iz reda. Stvarno pokretanje posla i probni poslovni efekti ostaju odvojeni izvršni korak.

## 2. Fizičko polazište koje treba ponovo potvrditi

| Predmet | Zabeleženo 27.10.2026. |
|---|---|
| Kanonski repozitorijum | `uskocibusiness-boop/USKOCI-EAN` |
| Grana / analizirani HEAD | `feature/uskoci-cisto` / `a9692e11942609bab9406215c3e407d79589dafa` |
| Audit checkout | `/workspace/scratch/f356024cf009/audit/deep-review/source` — čist, sa lokalnim audit origin-om; nije novi kanonski repo |
| Telefon, prikazani izvor | `fcef803e719ba5663f6cfd8fbd5a601e08a3479b` |
| Prikazano izdanje | 1.0.0; runtime `uskoci-v1-preview-r1`; kanal `preview`; OTA prefiks `01a163c4` |
| Razlika GitHub izvora | HEAD je 69 commit-a ispred izvora sa About ekrana; ne znači 69 popravki |
| Referentni DEV | `leqcwgzvjsxugfgzdmth` |
| Edge verzije | Svi 15 paketa preuzeti; NEED 151, WORKER 104, post-save 5 i dalje imaju kodne razlike od a969; 48 jedinstvenih sadržaja u Z13 |
| Push Edge | v37 byte-equal; jedan SEND po regularnom invocation-u; SQL cron ne dokazuje invocation, a poslednji TICK_OK od 23.10. je stale |
| Aktuelni serverski pregled | 680 public/private funkcija i dve dodatne RLS; 169 table granica, devet sekvenci; 314 ledger prema 193 source migracije; puni izrazi/ACL u Z12 |
| Spremnost izvoza/brisanja | Aktuelni retention/source/export/erasure binding uslovi ostaju zatvoreni; ne menjati certifikat radi prolaza |
| CI | Run `40452826819`, isti a969, SUCCESS; provereni metapodaci |
| Production | README zahteva poseban proveren produkcioni backend pre production build/OTA |

Tri stvarne slike su već u `dokazi/slike/`. **Ne traži iste slike ili About podatke ponovo.** Nisu očitani puni native build identitet, sve efektivne zastavice ili pojedinačni mrežni zahtev telefona. Takav nedostajući dokaz je drugačiji od nedostajuće fotografije.

Prvo pročitaj aktuelni README, STATUS, eventualne važeće instructions i promene od a969. Ne obnavljaj obsolete repo/backend iz memorije. STATUS sadrži „Samo poruke za sad”; stari server PHONE grantovi/stariji klijenti nisu time automatski zatvoreni. Originalni `USKOCI_ULTRA_MASTER_PLAN_2026-10-26` iz Downloads nije bio dostupan auditu; nije proglašen pročitanim.

## 3. Korisnikova namera koju implementacija mora da sačuva

- Čovek prirodno opisuje posao ili usluge. Sve jasne činjenice ulaze u predlog; sledi najviše jedno stvarno potrebno pitanje.
- Mini vidi proveren katalog i u pozadini razrešava postojeći identitet ili predlaže novu smislenu granu. Korisnik ne administrira kategorije i ne bira interne šifre.
- Postojeća usluga zadržava postojeći ID. Za novu uslugu baza posle validacije pravi zapis i vraća ID. Sinonim nije nova kategorija po automatizmu.
- ON_SITE znači dolazak na mesto naručioca/zadatka. REMOTE znači bez takvog dolaska i može uključiti radionicu, slanje ili lično preuzimanje. BOTH su oba moda iste usluge sa istim identitetom.
- Predlog, sačuvani izbor, saglasnost za mode/handoff i pravo na povezivanje imaju različite uloge. AI predlog sam ne proširuje potvrđenu ponudu.
- Razgovor nema parcijalne kartice ni obavezne dodatne formulare za mode, opremu, tim, vozilo, licence ili biografiju. Jedan smislen završni pregled treba da bude dovoljan za odgovarajuću potvrdu.
- Naručilac bira privatni nacrt ili objavu. Worker DRAFT bira Save ili Save+activate sa istog pregleda; `activate=false` nije deaktivacija postojećeg ACTIVE profila.
- Pending klasifikacija nije univerzalna zabrana svakog Save-a/objave. Posebne strože granice, npr. REMOTE predaja, ostaju po stvarnom ugovoru.
- Tehnički nastavak je unutrašnja obaveza sistema. Jasna usluga se ne pretvara u korisnikovo pitanje o kategoriji zato što je proces prekinut ili schema odbila validan zaključak.
- Čuvaj account/focus/revision ograde, journal pre dispatch-a, stabilan request ID, potpisan review/digest, eksplicitnu korisničku potvrdu i autoritativni readback.

Ova pravila su ugrađena u glavni izveštaj, poglavlja 5–7. Stare naknade ili HITNO pravila ne vraćati iz istorijske memorije.

### Četrnaest korisničkih tokova kao merilo završetka

Ovo je sažetak konkretnog ponašanja kojem izmene služe. Postojanje ekrana ili zelen lokalni test nije oznaka da je ceo red završen. Za svaki tok [Z09](dokazi/namena_i_testovi/intent_review.json) čuva već ispravnu osnovu, tačne vlasnike, nedostajuću vezu, pozitivan slučaj i realan neuspeh. Ni jedan red nije nov native PASS.

| Tok | Vidljiv ishod koji treba postići i sačuvati | Radni zadaci |
|---|---|---|
| **J01 — Naručilac opisuje potrebu** | Sve jasne činjenice ostaju; jedno potrebno pitanje; prazan ulaz nema model/upis. | R04/R06/R08 |
| **J02 — Ispravka i nastavak** | Termin ili završna poruka ne obezvređuju istu uslugu; stvarna promena odbacuje samo zastareli rezultat. | R04/R07/R08 |
| **J03 — Jedan pregled i mapa** | Čovek vidi celinu; potvrda pina, lokalna izmena i objava imaju tačan ishod; REMOTE nema lažnu radnu mapu. | R02/R08/R11 |
| **J04 — Nacrt, objava i zamena** | Nacrt ostaje privatan; objava ima readback; zamena čuva staru do uspeha i ne prenosi stare prijave. | R07/R08/R12 |
| **J05 — Radnik opisuje i dopunjava ponudu** | Isti razgovor čuva ostale usluge i područja; nema obavezne opcione biografije ili parcijalnih kartica. | R04/R06/R08 |
| **J06 — Čuvanje i aktivacija profila** | Isti pregled nudi odgovarajući Save/Save+activate; ponovo otvoreni profil verno pokazuje potvrđenu ponudu. | R04/R08/R10/R12 |
| **J07 — ID, oba načina i predaja** | Sinonim koristi isti ID; nova grana ima stvaran DB ID; ceo BOTH i stvarni REMOTE/handoff ostaju. | R04/R06 |
| **J08 — Područje i vreme** | Odgovarajući kandidat prolazi od početnog izbora do prilike; stara tačka ne poništava sačuvano područje. | R05 |
| **J09 — Lista, mapa i filteri** | Ponuđeni režimi rade sa pravim serverom; korisna lista opstaje uz odvojenu grešku mape; ručna pretraga dostupna. | R01/R02/R12 |
| **J10 — Moji zadaci, prijava i izbor** | Pet scope-ova i counts odgovaraju podacima; prijava/izbor čuvaju reviziju i uslove; dodatak veštine ne pregazi profil. | R03/R07/R11/R12 |
| **J11 — Dogovor, poruke i ocene** | Obe uloge vide iste uslove, poruke i potvrđen završetak; ocena se osveži; PHONE ugovor zatvoren i na serveru. | R07/R09/R11/R12 |
| **J12 — Obaveštenje i odredište** | Poštuju se obe preference; nema nepotrebnog dupliranja; dodir vodi tačnom dozvoljenom sadržaju. | R09/R12 |
| **J13 — Povratak, restart i nepoznat ishod** | Proverava se ista radnja; sačuvani posao ne ponavlja model; gubitak medijskih bajtova ima bezbedan izlaz. | R06/R07/R11/R12 |
| **J14 — Privatnost i život podataka** | Tri privatne kolone ostaju privatne; saglasnost je za pravi dokument; izvoz/kopije čuvaju potvrđena područja. | R01/R10/R12 |

Za ceo tok izvesti jednu razumljivu priču iz perspektive korisnika, a iza nje sačuvati tačnu reviziju, nalog, potvrdu, stanje i readback. Za razliku „radi deo” / „povezan tok” / „dokazano na telefonu” koristiti stvarno dostignuti nivo. Dobar mehanizam se čuva dok se popravlja preostala veza.

### Kako se ovaj plan pretvara u izvršan rad

Za odobrenu implementaciju koristi sledeći redosled. Svaki red je konkretan radni zadatak nad postojećim vlasnikom, sa zasebnim rezultatom i potrebnim dokazom. Posle potvrđenog uspeha sledeći dozvoljeni zadatak koristi osveženu istinu; istorijski hash ovog paketa nije dozvola da se prepišu novije promene.

| Zadatak | Zavisnost i predmet | Pregledljiv rezultat / uslov izlaza |
|---|---|---|
| R01 — privatnost čitanja, verzije i ugovori | Početak: F21 i aktuelni repo/Edge/SQL/klijenti | Obnovljena javna kolonska granica sa pozitivnim/negativnim dokazom; tabela stvarnih ugovora i tačnih vlasnika; očuvani kompatibilni čitači. |
| R02 — Discovery i poruka greške | R01; F15/F16/F17 | PAGE/MAP/PLACES/filteri i odvojeno stanje liste/podloge/pinova; reprodukovana oba screenshot stanja zatvorena stvarnim decoder-om i uređajem. |
| R03 — sopstveni zadaci | R01; F01 | Pet scope-ova, svi counts i pravi item format; prazna i neprazna prva strana, nastavak i dozvole. |
| R04 — identitet i kompletan rezultat AI-ja | R01; F04/F05/F06/F08 | Pun katalog, reuse/nova grana, stabilna semantika i kompletan očekivani BOTH; prava revizija/signed review/Save/binder, uključujući ranije pripremljen review i replay. |
| R05 — područje, vreme i izbor | R04 signed ugovor očuvan; F18 | Zajednički area/topology/TODAY ugovor i početni izbor bez izgubljenog kandidata; Za mene/dispatch parity i nepromenjena ručna prijava. |
| R06 — tehnički nastavak i obračun | R04; F06/F07 | Postojeći posao ima durable identitet, bounded pokušaje, receipt/readback i zaseban provider usage; prekid ne traži ponovno objašnjavanje iste usluge. |
| R07 — cena i neizvesni dodatni upisi | R01; R07a postojeći domen, R07b širi cenovni ugovor; F02/F03/F11/F13 | Korekcija ne čeka novu valutu; stvarna jedinica ostaje, isti abandon ima pravi readback, dodatni upis čuva paralelnu izmenu. |
| R08 — završetak razgovora i prikaz | R04 i relevantni deo R07; F09/F10/F12 | Jedno potrebno pitanje, autoritativan završetak, jedan pregled, veran sačuvan rezultat po usluzi; bez obaveznih suvišnih formi. |
| R09 — obaveštenja i poruke | R01/R05; F20, SB08/SB10 | Dovoljan ograničen rad reda, isti-key bez duplog slanja, suppression već prijavljene osobe, validan tačan cilj pri oba nezavisna preference izbora. |
| R10 — život podataka i privatnost | R04; F19, SB03, current export/closure vlasnici | workAreas u svim projekcijama, važeći consent replay, proverene sve kopije i autorizacija; gates ostaju zatvoreni dok ceo dokaz nije validan. |
| R11 — ostatak ekrana i usko povlačenje | Po odgovarajućim owner zavisnostima; SB/X | Svi pojedinačni backlog problemi imaju proveru; aktivne module sa istorijskim delovima ne brisati u celini. |
| R12 — stvarna celina i release presek | Prethodni relevantni zadaci | Dve uloge/nalozi, realan model i telefon, prekidi i pristupačnost, poznat deploy/OTA, merene latencije/trošak i izričiti DEV/production izlaz. |

R02 i R03 mogu se raditi paralelno nakon usklađenog R01 ugovora; nezavisni klijentski nacrti/ocene mogu napredovati paralelno sa AI radom. Promene istog review/matching/export vlasnika usklađivati sekvencijalno da jedna grana ne izgubi tuđu zaštitu. Veći cleanup ide posle popravljene aktivne veze, uz caller/kompatibilnost dokaz. SB14, provera samog proverivača, prati svaki zadatak od početka.


### Izvršivost na nivou vlasnika i fajla

Revizija 5 dodaje jedinstvenu mapu svih 42 nalaza prema R01–R12. [Z10](dokazi/izvrsivost/readiness_review.json) čuva primarnog vlasnika, tačne izvorne putanje i SHA, vrstu izmene, šta ostaje, zavisnost, postojeću proveru i pozitivan/negativan uslov završetka. Donja tabela je radni indeks; detaljni F/SB/X izvori i testovi ostaju u tehničkoj referenci. Izbor novog izdanja mora proveriti source/Edge/SQL/old-APK kompatibilnost pre menjanja zajedničkog ugovora.

Potpuno čitanje ne zatvara automatski sve istorijske F0 runtime/provenance ciljeve iz repo operativnog statusa. Prava baza, nedostupni originalni Downloads masterplan, nepregledani efektivni APK/OTA parametri i živ model zadržavaju svoje navedene granice. Ova revizija nije novo pokretanje 14.143 testa niti implementacija.

| Zadatak | Primarni source ulazi za pripremu promene | Primarni nalazi |
|---|---|---|
| R01 — Privatnost čitanja i tačan isporučeni ugovor | `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql` | F21 |
| R02 — Discovery, mapa i istinita greška | `src/app/(app)/zadaci.tsx`; `src/data/discoveryV1ClientTransport.ts`; `src/data/discoveryV1MarketplaceAdapter.ts`; `src/data/discoveryV1Owner.ts`; `src/data/discoveryV1ScreenSession.ts`; još 8 putanja u Z10 | F15, F16, F17, SB11 |
| R03 — Moji zadaci i straničenje | `src/data/needClientService.ts`; `src/data/ownTasksPage.ts`; `supabase/migrations/20261025000000_baseline_core_client_rpcs.sql` | F01 |
| R04 — Identitet usluge i celovit semantički rezultat | `supabase/functions/_shared/backgroundTaxonomyArchitect.mjs`; `supabase/functions/_shared/classificationGeminiShadow.mjs`; `supabase/functions/_shared/serviceExecutionInstruction.mjs`; `supabase/functions/_shared/workerServiceModeContext.mjs`; `supabase/functions/uskoci-worker-interview/index.ts`; još 3 putanja u Z10 | F04, F05, F08 |
| R05 — Područje, vreme i pravi izbor kandidata | `src/contracts/workerAreas.ts`; `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql` | F18 |
| R06 — Trajan nastavak i trošak pokušaja | `supabase/functions/_shared/backgroundTaxonomyArchitect.mjs`; `supabase/functions/_shared/geminiTaskStream.ts`; `supabase/functions/_shared/taxonomyPostSaveWorker.mjs`; `supabase/functions/_shared/taxonomyProviderBudget.ts`; `supabase/functions/uskoci-ai-interview/index.ts`; još 4 putanja u Z10 | F06, F07 |
| R07 — Cena, odustajanje i dodatni profilni upis | `src/app/(app)/pregled-zadatka.tsx`; `src/app/(app)/prilike/[id]/prijava.tsx`; `src/contracts/projections.ts`; `src/data/aiTaskReviewClientService.ts`; `src/data/applicationClientService.ts`; još 4 putanja u Z10 | F02, F03, F11, F13 |
| R08 — Prirodan završetak i veran sačuvani rezultat | `src/app/(app)/profil/razgovor.tsx`; `src/data/workerAiClientService.ts`; `src/hooks/useWorkerExecutionModes.ts`; `src/ui/workerProfile/WorkerAiPresentation.tsx`; `src/ui/workerProfile/WorkerProfilePresentation.tsx`; još 3 putanja u Z10 | F09, F10, F12 |
| R09 — Obaveštenja, poruke i tačno odredište | `src/app/(app)/profil/obavestenja.tsx`; `src/ui/AgreementChat.tsx`; `src/ui/notifications/PushPreferences.tsx`; `supabase/functions/_shared/pushNotificationCopy.mjs`; `supabase/functions/uskoci-push-transport/index.ts` | F20, SB08, SB10 |
| R10 — Život podataka i pravne saglasnosti | `src/app/(app)/profil/pravna.tsx`; `src/ui/legal/legalReview.ts`; `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql` | F19, SB03 |
| R11 — Preostali ekrani i usko povlačenje | `.github/workflows/ci-clean.yml`; `app.config.js`; `scripts/check-eas-preview.cjs`; `scripts/verify-native-patches.cjs`; `src/app/(app)/index.tsx`; još 43 putanja u Z10 | SB01, SB02, SB04, SB05, SB06, SB07, SB09, SB12, SB13, SB14, SB15, X01, X02, X03, X04, X05, X06 |
| R12 — Stvarna celina i izdanje | `app.config.js`; `eas.json`; `supabase/migrations/20261021101527_staged_task_replacement_noop_guard.sql`; `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql` | F14 |


### Odluke i obavezna priprema bez ponovnog odlučivanja o već određenom

R07a povlači zastarelu potvrdu cene unutar postojećeg RSD/OFFERS domena. R07b pre promene ugovora mora konkretno razrešiti HOURLY kroz broj ljudi i trajanje. Primer: 2 osobe × 3 sata × 1.200 RSD daje 7.200 RSD samo ako je osnovica po osobi; sat ekipe daje 3.600 RSD. Predlog najmanjeg početnog ugovora je jasno označena satnica po osobi. Korisnik može odabrati širi ugovor, ali implementator ne sme da ga izmisli iz enum-a. F11 i F13 ne zavise od te odluke.

R05 čuva već definisano STATIONARY područje, popravlja prefilter i TODAY, a pre proširenja POINT_TO_POINT/MULTI_STOP/AREA_BASED mora oblikovati smisao područja. Za NS→BG pripremi predlog „sve stvarne radne tačke u sačuvanim područjima + vidljiva ruta + dobrovoljna prijava”, uz alternativu samo sa preuzimanjem i uporedi sa važećim kanonom. Ako taj predlog menja korisničko obećanje i kanon nema odgovor, traži ciljanu potvrdu; ne pretvori ga prećutno u novu obavezu da radnik pokriva svaki kilometar ili sve tačke.

R04 bira tehnički put na istom semantičkom korpusu i merenju; korisnik ne bira interne klase ili zastavice. R08 verno prikazuje sačuvanu ponudu i usklađuje AI guard poruke sa zajedničkom instrukcijom persiranja. Novi valutni domen, cityless REMOTE aktivacija, povlačenje već obećanog javnog komentara ili zabrana telefonskog broja u slobodnoj poruci nisu automatski odobreni cleanup. Ostatak poznate namere može se dovršavati nezavisno.


## 4. Paket 1 — uskladiti aktivni klijent, server i stanje ekrana

**Nalazi:** F15, F01, F14, F16, F17. Najpre rešava konkretno prikazani problem.

### Discovery server ugovor

P6 put iz izvora prikazanog na telefonu radi onsite PAGE pa MAP. Njegovi EAS profili uključuju P6 i slika ima odgovarajuću „Za mene” kontrolu; efektivne OTA zastavice nisu izvučene. Živi `rpc_discovery_v1` ima samo PAGE i EXACT_PUBLIC, odbija MAP i PLACES i nema `forMe`/`minBudgetRsd` u filter whitelist-u. Telo odgovara `20261025000000_baseline_core_client_rpcs.sql`. Pet agregiranih `P6_MODE_NOT_IMPLEMENTED` grešaka potvrđuje aktuelni unsupported-mode problem; ne mapirati ih proizvoljno na pet MAP zahteva jednog telefona. Fotografije daju 07:51 bez datuma/zone; povezivanje sa prozorom 06:40–06:56 UTC pretpostavlja 27.10. i vreme Beograda. [Dokaz](dokazi/nova_etapa/discovery_log_evidence.json)

Vlasnici: `src/data/discoveryV1Contract.ts`, `discoveryV1MarketplaceAdapter.ts`, `discoveryV1ScreenSession.ts`, `discoveryV1Owner.ts`, `discoveryV1ClientTransport.ts`, `src/ui/v2/discovery/DiscoveryV1Screen.tsx` i konkretna SQL funkcija. Prati ceo request/response ugovor, filtere, cursor, map seed/viewport i vezu sa korisničkim nalogom.

**Dokaz završetka:** svi režimi koje ciljni klijent stvarno nudi prolaze pravi objavljeni odgovor i pravi decoder; testiraj prazno/neprazno, nastavak, filtere, mapiranje i validne odbijene slučajeve. Test double koji već podržava MAP ne dokazuje live podršku.

| Grana kompatibilnosti | Stari podržani native/OTA klijent | Ciljni novi klijent |
|---|---|---|
| PAGE/MAP/PLACES/EXACT_PUBLIC | Pravi request/response i decoder za svaku ponuđenu mogućnost | Ista funkcionalna namera, uz važeću novu verziju ugovora |
| `forMe`, `minBudgetRsd` i ostali filteri | Prihvaćen definisani oblik; nema tihog izbacivanja filtera | Usklađen UI, adapter i server |
| HOURLY stavka ili mešovita strana | Izričito rešena kompatibilnost; jedan red ne sme neobjašnjeno oboriti sve | Tačno značenje cene i podržan decoder |
| REMOTE prikaz | Nema fizičkog MAP zahteva kada prikaz to ne traži | Ista semantika rada bez dolaska; predaja je zaseban podatak |

Plan mora pokriti još aktivni stari klijent. Njegov decoder odbija HOURLY; sadašnji prihvata. Jedan HOURLY red ruši celu staru PAGE poruku. Izaberi eksplicitnu kompatibilnu strategiju, bez skrivanja podataka ili tihog menjanja značenja cene. Trenutni flag0 za P6 prelazi na drugačiji legacy ugovor i gubi mogućnosti; nije dovoljan dokaz završenog Discovery proizvoda.

### Moji zadaci

`rpc_list_my_needs_page` nije Discovery endpoint. Treba uskladiti pet scope-ova, sve counts na prvoj strani i oblik stavke koji prolazi `ownTasksPage.ts`, `needClientService.ts`, `mapNeed` i `readPublicNeedDetail`. Counts sami nisu dovoljni: stari camelCase i dalje ne odgovara pravom task dokumentu. Prazna prva strana je obavezna negativna/pozitivna kontrola.

Baseline migracija ima **dva utvrđena nesklada ukupno**, devet drugih statički kompatibilnih ugovora i jedan izostao opcioni displayName. Sačuvati posebno D12 review/comment ugovore, `ratingDue` i group-message izuzetak u `rpc_mark_agreement_messages_read`. Ne vraćati ceo istorijski SQL paket niti prepravljati primenjenu migraciju kao zamenu za novu proverenu promenu. [Poređenje tela](dokazi/layout/baseline_candidate_body_comparison.json)

### Ekran i razlog greške

`DiscoveryPresentation` koristi isti `error` da ukloni mapu i da `compact=false` pošalje velikoj grešci. HALF je početni loading/error default bez zapamćene pozicije; sačuvana visina ima prednost. Na slici navigacija prekriva opis, a veliki taster nije ceo vidljiv i nastavlja se ispod kadra; mala refresh ikona ostaje. Prvi failure nema snapshot, a retry ga objavi i u neuspehu. MAP failure može preglasiti 50 validnih PAGE redova.

Odvojiti šta je dostupno: geografska podloga, lista, pinovi i prostorni rezultat. Sačuvati smisleno dostupne podatke i filtere. Obezbediti kratku poruku i dostupnu radnju u stvarnom viewport-u; lociranje ne sme samo skloniti objašnjenje dok mape nema. Ne menjati globalni StateView za sve potrošače bez potrebe.

`focusedResource.error` je boolean; novi legacy `String(error)` daje `true`. Sačuvati strukturisan razlog i identitet pokušaja za dijagnostiku, uz razumljiv korisnički tekst. Posebno razlikovati mrežu, serverovo odbijanje, nevažeći odgovor i sesiju tamo gde ta razlika menja korisnu radnju.

**Uređaj:** posle odobrene izmene proveriti oba stanja sa slika, HALF/FULL/PEEK, veći tekst, mali ekran, povratak na tab, prazno/uspešno/neuspešno čitanje i zasebnu native map grešku. Zabeležiti izvor, OTA, backend i scenario. Ne proglasiti ispravnim na osnovu samog padding assertion-a.

### F21 — vratiti granicu privatnih kolona uz očuvanje sadašnjih čitača

U prvom paketu mapiraj efektivne table/column grantove, sve current `needs` politike, invoker čitače i vlasničke helpere. `20261023210000…:6` vraća authenticated table SELECT, pa privatne `requester_account_id`, `remaining_search_closed_by_account_id` i `remaining_search_close_reason` postaju čitljive na redovima koje RLS već dopušta. Safe `rpc_read_task` nije dovoljan ako direktan table API zadržava taj grant.

Pripremi preciznu javnu kolonsku/projekcionu granicu i kompatibilan put za potrebne sopstvene podatke. Proveri closure schema/certificate efekat; ne prepisuj certifikat samo radi prolaza i ne primenjuj stari PKG045b napamet. Zaseban sintetički isti-svet ne-vlasnik mora dobiti zabranu svih tri kolone kroz direct/alias/filter/order/wildcard, dok normalni task/public/owner/Discovery čitači prolaze. Dodaj drugi svet, zatvoren nalog, PUBLISHED/SELECTION i privatni razlog zatvorene preostale pretrage. ACTIVE/historijske redove tretiraj po njihovim stvarnim politikama. Sveži catalog dokaz je Z06; nije potrebno čitati stvarne tuđe redove da bi se ovaj rad pripremio i proverio.

## 5. Paket 2 — dovršiti klasifikaciju, povezivanje i kontinuitet

**Nalazi:** F04–F08 i F18. Ovo je glavni posao da zamisao „mini razume i dobije ID” stvarno preživi ceo tok i dovede do odgovarajućeg povezivanja.

**Izbor AI implementacije je inženjerski posao.** Potrebno ponašanje je već određeno. Uporedi postojeće putanje na istom korpusu značenja, sa istim uslovima potvrde, merama kvaliteta, ukupnog čekanja i troška. Korisnik ne treba da odlučuje o internim imenima režima. Ne proglašavaj pobednika bez merenja i ne uvodi treći paralelni klasifikator.

### Sačuvati već razrešenu uslugu kroz normalan razgovor

Za novi worker nacrt, hint je vezan za ceo kandidat/revision/base_hash. Prazan uspešan patch podigne reviziju, a BG trigger ne radi jer se usluga nije promenila. Stvarne completion/exact funkcije u izolovanoj probi pokazuju isti kandidat, revision1→2, odgovarajući hintovi2→0, `REVIEW_REQUIRED`. Auth/context/patch/digest pomoćne funkcije su kontrolisane; ceo signed prepare/Save nije izvršen. [Proba](dokazi/ai/semantic_completion_probe.json)

Rešenje treba da odvoji stabilnost semantičkog ulaza od revizije korisničkog pregleda. Validan nepromenjeni rezultat može se bezbedno revalidirati/vezati za novi pregled; stvarna promena usluge/moda/predaje zahteva novu obradu. Odbijanje zastarelog rezultata, vlasnik naloga i potpis sadržaja ostaju. Produženje timeout-a ili prihvatanje starog rezultata bez provere ne zatvara nalaz.

Requester proveriti odvojeno: ceo source obuhvata poruke/sve činjenice, BG trigger uži skup; novi branch/mode predlog može zastareti posle budžeta/vremena. Exact/alias kategorija ima i direktno razrešavanje. Ne primeniti worker generalizaciju na svaki requester slučaj.

### Proveriti celinu BOTH namere

Očekivani skup usluga–mode–handoff mora postojati nezavisno od uspešnih provider item-a. `proposals.length>0` nije provera završetka. Sačuvati failure/unresolved ostatak do odluke o kompletnosti. Za tražena oba moda, jedan uspešan item ne daje kompletan READY. Pozitivna kontrola mora vratiti oba moda istog ID-ja.

Ne pretvarati provider handoff u korisničku saglasnost: sadašnji builder koristi foreground/saved consent. Uskladiti izlaz i ukloniti suvišan zahtev tamo gde nema potrošača, bez slabljenja vlasništva.

### Pun katalog i postojeći/nova identitet

Loader mora završiti sve strane i dokazati potpunost. Neuspešna CHILDREN strana ne sme dati „kompletan” parcijalni indeks; puni snapshot iste verzije mora moći zameniti raniji nepotpuni keš.

Zatvoriti put za normalizovanu uslugu koja ostane izvan canonical imena i registrovanih aliasa: validiran semantic reuse, ne izmišljeni novi ID ili uklonjen guard. Omogućiti stvarno potrebnu novu granu/višestepeni put kroz isti aktivni ugovor. Jednočlani naziv nije sam po sebi semantička nejasnoća; safety/duplikati/ID provere ostaju.

`classificationGeminiShadow.mjs` već ima širi full-snapshot ugovor, ali ga dual put zaobilazi. Prvo odredi aktivnog vlasnika i uskladi ugovor; ne uvoditi treću arhitekturu niti slepo vratiti stari režim. Poredi postojeće mogućnosti na istom korpusu.

U obuhvat F05 uključiti i upis posle klasifikatora: Need text-trigger i worker skills sync. Proveriti canonical naziv, registrovan i neregistrovan sinonim/preimenovanje, putanju sa pogrešnim roditeljem i postojećim listom, ID-only signed binder, dodavanje nepoznate uz očuvanu staru uslugu i izričito povlačenje. Ne ukloniti zaštitu povlačenja usluge da bi rename prošao. Tehnička referenca F05 navodi proverena tela i source/live razliku.

### R04/R06 — konkretna optimizacija dostupnosti stabla

1. Baza ostaje autoritet kategorija i ID-jeva. Koristiti jedan potpun verzionisan snapshot, sa fingerprint-om svih polja koja utiču na klasifikaciju. Modelu predati eksplicitne parent/path veze ili dokazano ispravan preorder; sadašnji alfabetno sortiran, samo uvučen spisak nije veran prikaz hijerarhije. Alias i mode pravila moraju ostati dostupna. Ne uvoditi novi katalog ili vektorsku kopiju kao konkurentski izvor.
2. U postojećem snapshot RPC-u omogućiti uslovni odgovor prema potpunom stamp-u: mali NOT_MODIFIED za identičan kompletan sadržaj, pun snapshot pri promeni ili hladnom startu. Ukloniti bezuslovni prefetch po poruci i duplo učitavanje prefetch/builder; dodati single-flight, odvojeno otkazivanje waitera, ograničen cache i atomsku zamenu. Pun snapshot mora zameniti raniji parcijalni objekat iste oznake. ROOTS/CHILDREN fallback završava svaku stranu ili jasno odbija rezultat. O(1) unapred izračunati stamp/payload uvoditi tek uz obuhvat svih pisaca i opravdanje merenjem; sadašnji META nije O(1).
3. Ujednačiti stabilan prompt prefiks i koristiti postojeći exact/registrovani alias i ranije proverenu odluku kada je i dalje važeća. Novi semantički REUSE sa canonical ID-jem dovršiti kroz F05/R04; nije već dokazana puna mogućnost. Ne ponavljati klasifikaciju zbog promene budžeta ili običnog „to je to”. Stvarno izmenjena usluga/mode/handoff dobija novi proverljiv pokušaj.
4. Za aktivni Gemini model i generateContent proveriti prag, tačan broj tokena i očekivani reuse/TTL trošak. Ako potvrđuju korist, dodati explicit `cachedContent` za zajednički katalog/instrukcije, sa verzionisanim registry-jem i ograničenim kreiranjem. Ako ne, ostaje ispravan kompletan prefiks i meren implicitni cache. Edge memorija sama ne čini stablo vidljivim modelu.
5. Cache ključ vezati za projekat, katalog version/fingerprint, model i prompt/response ugovor. Ne deliti privatne razgovore/profil kroz zajednički cache. Istek ili provider mismatch imaju jedan ograničen rezervni put; tekuća DB verzija proverava se pri capture/Save/binder-u, bez duplih grana i bez gubitka korisničke potvrde.
6. Obračun svakog stvarno poslatog pokušaja i cache operacije odvojiti od foreground pokušaja; uključiti nepoznat ishod. Za generateContent cached tokeni su deo `promptTokenCount`, ne dodatak preko njega. Ne prenositi usage polja drugog API-ja.
7. Dokazati hladan/topao cache, isti sadržaj/nova verzija, paralelni miss, nepotpun snapshot, provider expiry, alias/mode promenu i restart trajnog posla. Potom meriti stvarnu latenciju, cenu i tačnost na istom korpusu. Ne tvrditi uštedu na osnovu same veličine JSON-a ili naziva cache-a.

Primarni vlasnici ostaju postojeći `backgroundTaxonomyArchitect.mjs`, shared Gemini transport/obračun, oba interview handler-a, aktuelni snapshot/version RPC i postojeći potpisani review/capture/binder. Predlog ne uvodi treću AI arhitekturu. [Z13](dokazi/server_final/edge_review.json), [Z16](dokazi/server_final/change_manifest.json).

### Trajan nastavak i trošak

Sačuvati a969 lifecycle: rok od starta, abort na neuspešan foreground completion, store/capture ACK provere. Dopuniti trajno zabeležen posao za prvi nedostajući plan, vezan za sadržaj, nalog, reviziju i ograničene pokušaje. Razlikovati tehnički failure, stvarno razjašnjenje i nepoznat upisni ishod.

Post-save outbox već obrađuje odobren plan; pending ledger ne kreira prvi plan. Ne predstavljati ih kao dokaz da se svaki klasifikacioni zastoj automatski rešava. Svaki stvarno plaćeni BG pokušaj treba zaseban attempt/budget/usage ishod; ne prepisivati potrošnju foreground-a i ne pokretati neograničen retry.

F07 obuhvata i ograničenje veličine provider odgovora, obavezan dokaz završetka i usklađen prijem izlaza; postojeći devetosekundni rok, spajanje tekstualnih delova i bezbedne tipizovane greške ostaju. Za STT proveriti slučaj poslatog audio sadržaja bez transkripta: odluka o oslobađanju test rezervacije mora imati dispatch/usage dokaz. Nije utvrđen stvarno pogrešan račun.

**Obavezni scenariji:** nepromenjena usluga + „to je to”; vreme/budžet/pin; stvarna promena usluge; sinonim/alias; nova grana; jednočlani jasan naziv; BOTH sa jednim i dva item-a; REMOTE radionica/handoff; nepotpun katalog; prekid pre capture-a; kasni rezultat, restart, promena naloga i ograničen trošak.

**Dodatno iz server pregleda:** objavljeni post-save5 nema current četiri-redni catch za stream/UTF-8 read grešku. Uskladiti tačan retryable ugovor i proveriti isti request key, lease i pet-pokušaja granicu pre deploy-a; to ne stvara prvi izostali plan. Sadašnji snapshot fingerprint nije digest svih prikaznih bajtova. Pre uslovnog NOT_MODIFIED ili provider cache-a obuhvatiti relevantne label/alias/scope promene. Verziju RPC ugovora urediti bez dvosmislenih overload-a i uz podršku starom Edge caller-u koji još traži ceo snapshot.

### F18 — sačuvano područje i raspoloživost moraju da važe pri izboru

Vlasnici su `candidate_profile_ids`/`candidate_profile_ids_v1b`, `worker_area_fit_v1`, `worker_need_fit_v1`, `worker_need_match_v1`, `discovery_for_me_v1`, dispatch admission i existing workerAreas ugovor. Current signed scope gate je uključen i ispravno traži Need reviziju/category i stvarnu sačuvanu Worker/service/mode saglasnost. To zadrži.

Prvo karakteriši radnika sa starom tačkom>300km i izričitom COUNTRY ili udaljenom CITY/RADIUS oblašću. Current prefilter ga može izbaciti pre autoritativne provere. Potom karakteriši saved-area radnika na POINT_TO_POINT/MULTI_STOP/AREA_BASED: evaluator trenutno prihvata samo RS/STATIONARY. Izaberi i dokumentuj tačno značenje područja za svaku stvarno podržanu fizičku topologiju. Ako tržište ostaje RS, validator/prikaz to jasno čuvaju; ne uvoditi međunarodnu podršku kao sporedni efekat.

Popravi jedan zajednički ugovor: početni izbor mora obuhvatiti sve koje konačna provera može odobriti, uz bounded čitanje, stabilan red/fairness, caps, dedupe i remote rotaciju. Ne dodavati lažnu fizičku tačku REMOTE profilu. `workerDailyCap=1000` je current sentinel za NULL/off, a ne stvaran limit1000; čitaj normalizovanu konfiguraciju. Sačuvaj current dispatch ALL i remote300/1000 talase,30min,stop5 kao zatečeni ugovor dok nema namerne odluke da se menja.

U istom paketu popravi current `worker_need_time_tier_v1`: TODAY_FLEXIBLE nema posebno izveden dan, pa worker sa `available_now=false` i stvarnim kasnijim terminom može biti izgubljen. Neka jedan vlasnik izvodi dan objave i preostali dozvoljeni interval. Sačuvaj nameran empty-calendar fallback i stvarne hard calendar gates. Proveri null/null i već započet ograničen TODAY, sada/kasnije, weekly/AVAILABLE/UNAVAILABLE, kraj dana i poslovnu zonu, istek i obične TOMORROW/WEEK/FIXED scenarije. Ne vrati ceo stari exact-pin kandidat da bi se obnovila jedna grana.

Provera mora proći retrieval→fit→Za mene→dispatch nad istim parovima, plus ručni submit/select pozitivnu kontrolu. Njihov responseAllowed nije isto što i dispatch preference gate. Nemoj proširiti zabrane ručne prijave da bi se podudarale sa preporukama. Izvori: tehnički F18 i Z01/Z02/Z06.

### F05/F06/F08 — granica već pripremljenog pregleda i sačuvanog pokušaja

Cross-mode kandidat iz21.10 i njegovi scenariji imaju korisnu nameru, ali current batch/consent preflight pinovi su promenjeni. Ne primenjuj ceo kandidat. Dokaži pravilo tamo gde se rezultat stvarno potpisuje/čuva: već READY review, ponovljen isti Save receipt, Save→batch→binder i obrnuti red završavanja, payload sa istim ID-jem oba moda i nameran konflikt identiteta. Uspeh novog čistog fixture-a ne zatvara stari pripremljeni pokušaj.

Current `ai_turn_sweep` posle grace perioda postavlja FAILED/CANCELLED; nije automatski provider retry. Zadrži razlikovanje PROCESSING/unknown/terminal i postojeći post-save outbox. Troškovni prikaz ima istorijske koeficijente i izričito realSpendUsd:null; ne predstavljaj ga kao trenutni račun providera ili hard cap. Novi pokušaj mora imati stvarni budžetski i obračunski dokaz.

## 6. Paket 3 — cena, neizvestan ishod i dodatni upisi

**R07a — ne čeka novu poslovnu politiku:** izričita korekcija povlači zastarelu potvrdu kroz writer, review, Save i objavu. Očuvaj RSD/OFFERS domen i ostale jasne činjenice. **R07b — precizan širi ugovor:** satnica kroz broj ljudi i trajanje i eventualna podrška novoj valuti zahtevaju jasno određeno značenje; samo postojanje HOURLY enum-a ne rešava Dogovor. Oba dela ostaju pod istim R07; ne blokiraju F11/F13.

**F02/F03:** zatvoriti HOURLY/PER_HOUR/MY_PRICE/OFFERS ugovor kroz razgovor, pregled, prijavu i Dogovor. Kod ispravke 5.000RSD→„mislio sam evra”, stari RSD ne sme ostati CONFIRMED. Ne izmišljati kurs ili podrazumevanu novu podršku valute. Ranija proba dokazala je osnovni review/canSaveDraft, ne objavu pogrešne cene. Signed accept/publish provera je zaseban potreban dokaz.

Zaseban F03 podslučaj je numeric RSD sa protivurečnim modelskim `displayValue`. Glavni review već koristi tipizovani formatter; ne kvariti ga i ne proglašavati pogrešan glavni prikaz dokazanim. Uskladiti prezentacionu kopiju tamo gde se zaista čuva/koristi. Ranija sumnja o ignorisanju price-basis-only izmene na živom serveru ostaje povučena; source/live razliku i prihvatnu proveru voditi kroz F14.

**F11:** unknown odgovor posle abandon-a bez posebnog Need-a proverava status iste radnje. Ne pokušavati novi prepare nad napuštenim razgovorom i potom tvrditi da postoji sačuvan zadatak. Pozitivni ishodi su tačan OPEN/ABANDONED rezultat sa dostupnim sledećim korakom.

**F13:** dodatno upisivanje cele uhvaćene skills liste posle uspešne prijave mora biti zasebno vezana korisnička namera sa aktuelnim nalogom i revizijom. Sačuvati paralelno dodate veštine; odbiti stari callback posle A→B→A. U analizi nije izazvan incident na živom nalogu.

## 7. Paket 4 — završetak razgovora i veran sačuvani rezultat

**F09:** `hasProfileContent` je ulaz u pregled, nije dokaz da je intervju završen. Potreban je jasan ugovor završetka bez obavezne opcione biografije ili još jednog ekrana aktivacije.

**F10:** pregled ima detalje po usluzi; odmah posle Save-a ostaju. Sačuvani profil kasnije pokazuje zbirni mode bez svih per-service handoff/pending detalja. Popraviti kontinuitet prikaza; ne tvrditi da su podaci dokazano obrisani ili da pending nove usluge automatski ukida sva stara prava.

**Minimalna vernost saved prikaza je obavezan izlaz R08.** Čitaj merodavan sačuvan model iste revizije i pokaži način rada, relevantnu predaju i status po usluzi. Kratke oznake uz uslugu i sklopljeni duži detalji su preporučen prikaz, bez nove obavezne forme. Ne crtati izgubljene podatke iz starog lokalnog review-a.

**F12:** postojeći guard test za ponavljanje+dnevnicu očekuje oba sadržaja. Treba promeniti semantičko pravilo izbora jednog pitanja, uz sačuvane jasne činjenice. Broj upitnika nije dovoljan kriterijum.

**Requester završetak:** `need.category` tekst je obavezan za karticu, a skriven u listi nedostajućih podataka. Sistem ne sme bez objašnjenja čekati ono što čovek ne zna da nedostaje. To nije direktni READY/category-ID gate. Očuvati razliku između teksta, identiteta, prihvata, nacrta, objave i povezivanja.

**Mape:** ConversationPointAsk odmah čuva potvrđenu tačku sa geografskom revizijom. NeedLocationForm drži lokalne tačke do „Primeni”. Ne objedinjavati writere samo zbog sličnog izgleda; odrediti jasno očekivanje pri izlasku i potvrdi.

**Regresija zamene javne objave (A24):** provera izmene ne povlači staru objavu; uspešna nova objava i zatvaranje stare deo su iste transakcije; prijave se ne prenose. Proveri uspeh, odbijenu/neizmenjenu izmenu, gubitak ACK-a i kasniji rollback. Postojeći klijent i aktuelna SQL tela nose taj ugovor; ova analiza ga nije ponovo izvršila.

## 8. Paket 5 — preostala aplikacija i usko čišćenje

Obavezni nastavak istog backloga: Home odredište prijave; refresh ocena; pravila i promenjeni dokumenti; voice/avatar oporavak; nacrti podrške i Dogovora; delimičan upis notification postavki; javni komentari; vidljiva ručna provera poruka; search busy/cache ključevi; vremenska zona; preostale mape/reduced motion; proof/build; image-only Edge hash. Svi SB01–SB15 i X01–X06 imaju izvor i granicu u tehničkoj referenci.

Sačuvati `useOwnedEditor`, journal-e, signed review, readback, nove lifecycle zaštite i primenjenu SQL istoriju. `aiNeedV2Ui` ima aktivne formattere; `WorkerAiCard` je potvrđen u designLab-u, ne u aktivnom razgovoru. Povlačiti tačne nekorišćene izvoze tek nakon caller/kompatibilnost provere. Ime „legacy”, „V2” ili „shadow” nije dokaz da je ceo fajl suvišan.

Pre pojedinačnog čišćenja pročitaj i zapis u [jedinstvenom registru](dokazi/registar/consolidated_read_register.json): purpose, disposition, rationale/evidence, caller-i i sačuvani detalji ranijih test analiza. SB/X tabele nisu potpuni spisak svakog manjeg helper/copy nalaza. Preporuka za povlačenje nije dozvola da se ukloni ceo mešovit fajl.

SB14 uključuje konkretne popravke samih dokaza iz tehničkog odeljka 8: obavezno vraćeno shadow polje u provider smoke-u; aktuelni SQL owner umesto tvrdnje o runtime dokazu iz staged stringa; negativna RPC tvrdnja na `mockRpc`, ne nepovezanom `mockFrom`. Ne pokretati pravi model da bi se proverila statička greška harness-a.

F14/proof obuhvata reproduktivan bootstrap sa jasno pripremljenim fixture-ima, proveru stvarnih ACL-ova širokog service_role granta i očuvanje izvorno/živih korekcija. Zapis primene migracije, neizmenjen source i uspešan izolovani test imaju različit domet.


### Obavezni izlaz za svaki primarni ekran

Pre zatvaranja UI podzadatka upisati: ruta/uloga; cilj čoveka; autoritativna polja i reader/writer; prikaz loading/empty/success/error/unknown-write; dozvoljene radnje i disabled razlog; povratak/nacrt/focus; tačan copy; mali ekran/uvećan tekst/tastatura/reduced motion i relevantna accessibility provera. Priložiti pregledljiv prikaz potrebnih stanja u postojećem dizajnu i povezati ga sa stvarnim upisom/readback-om. Nije dovoljan samo spisak komponenti.

AI rute obuhvataju uvod, tekst/glas/foto, jedno pitanje, završetak, pregled, ispravku i potvrđeni rezultat. Discovery obuhvata samostalni početni failure, retry snapshot, HALF/FULL/PEEK, uspešnu listu uz MAP grešku, REMOTE i lokacijsku dozvolu. Dogovor/poruke obuhvataju obe uloge, nacrt, medijski prekid, izmenu uslova, završetak i ocenu. Nalog/podrška/pravila obuhvataju povratak, promenjeni dokument, neizvestan upis i privatnost. Za svaku grupu koristiti postojeće vlasnike iz radne matrice; nema novog paralelnog dizajn sistema.


### R11a–h — imenovane radne jedinice ostatka aplikacije

| Podzadatak | Nalazi koji se zatvaraju | Konkretni ulazi; pun lanac je u Z10 |
|---|---|---|
| R11a — Početna i navigacija; search regresija | SB01 | `src/ui/home/HomePresentation.tsx`; `src/app/(app)/index.tsx` |
| R11b — Ocene i javni komentari | SB02, SB09 | `src/ui/reviews/useGivenRatings.ts`; `src/ui/reviews/useReceivedReviews.ts`; `src/app/(app)/profil/ocene.tsx`; `src/ui/reviews/ReviewCommentField.tsx`; ostalo u Z10/R11b |
| R11c — Media/safety oporavak i account lifecycle | SB04, SB05, SB15, X01, X06 | `src/features/voiceMessages/voiceMessageComposer.ts`; `src/data/agreementVoiceClientService.ts`; `src/data/serverReceipt.ts`; `supabase/functions/uskoci-media/index.ts`; ostalo u Z10/R11c |
| R11d — Neposlati nacrti i delimični profilni upisi | SB06, SB07, X02 | `src/ui/support/useSupportController.ts`; `src/ui/support/SupportDetailScreen.tsx`; `src/ui/support/SupportNewScreen.tsx`; `src/ui/agreements/AgreementActionsScreen.tsx`; ostalo u Z10/R11d |
| R11e — Vreme, native layout, mapa i motion | SB12, SB13 | `src/ui/v2/ApplicationComposerPresentation.tsx`; `src/ui/v2/MyApplicationsPresentation.tsx`; `src/ui/agreements/agreementListModel.ts`; `src/ui/agreements/AgreementActionsPresentation.tsx`; ostalo u Z10/R11e |
| R11f — Dekoderi i zajednička konfiguracija | X03, X04 | `src/data/applicationClientService.ts`; `src/data/ru4Production.ts`; `src/app/(app)/moje-prijave.tsx`; `src/data/supabaseClient.ts`; ostalo u Z10/R11f |
| R11g — Namenski proof build i verifikatori | SB14 | `app.config.js`; `scripts/check-eas-preview.cjs`; `scripts/verify-native-patches.cjs`; `.github/workflows/ci-clean.yml` |
| R11h — Demo izolacija i dokazivo povlačenje | X05 | `src/data/lazniIzvor.ts` |


### R11 — merljivo čišćenje aktivnog projekta

Normalizovani indeks u Z10 obuhvata svih 3.434 putanje uz izvornu odluku i dokaz. To je operativna projekcija prethodnog punog pregleda, ne nova caller provera svake putanje. Devet zaostalih pending oznaka razrešeno je prema završenom čitanju. Za 912 putanja treba ciljana izvršna adjudikacija ako se povlače; takve stavke imaju NEEDS_TARGETED_ADJUDICATION i destructive_action_ready=false. Brojevi 24/68/58 iz nekoliko starih oznaka nisu ukupan obim čišćenja.

Za svaku promenu popuni tačnu putanju/simbol, trenutno korišćenje, važeće pravilo, odluku KEEP/REPAIR/MERGE/RETIRE/HISTORICAL, aktivnu zamenu, potrošače za prevezivanje, kompatibilnost, potrebnu proveru i rezultat. Za mrtav podskup ne brisati mešovit aktivni fajl; za nepovezan prototip ne uvoditi novu funkciju samo da bi se opravdao stari test.

Prvo se uklanjaju jasno razjašnjeni duplikati i mrtvi lokalni podskupovi. Istorijska očekivanja prevode se na važeći proizvod zajedno sa njihovim pravim popravkama. Alternativne AI putanje povlače se posle R04/R06 izbora i dokaza. PHONE ugovor povlači se i na serveru/podržanim starim klijentima. Kandidati/proof generatori, SQL istorija i produkcioni rebuild imaju posebnu zavisnost: minimalan dovoljan dokaz/poreklo ostaje, a nepotrebne kopije izlaze iz aktivne grane.

Sama archive putanja nije granica izvršavanja: Jest bira __tests__ i testMatch, TypeScript ima široke include, CI ima eksplicitne Node ulaze, a postinstall generiše iz sačuvanih resursa. Svako premeštanje prati tačne ulaze i ažurira ih sa važećom zamenom; ne dodavati globalni ignore da bi obavezne provere nestale.

**Merenje pre/posle:** broj tracked fajlova/redova po ulozi, runner izbor i stvaran broj slučajeva, tačni duplikati, trajanje relevantnog i obaveznog skupa u istom okruženju, install/type/build i uređaj kada su promenjeni resursi ili nativni ulazi. Veći broj obrisanih fajlova nije samostalni cilj. Dokaz je manji i razumljiv aktivni izvor uz očuvano današnje ponašanje i potrebne zaštite.

### F19 — dopuniti vlasnika izvoza i svih kopija workAreas

U `data_export_worker_candidate_v5` dodati potpuno validiranu projekciju workAreas kroz isti postojeći whitelist ugovor. Prati sve pozive iz `data_export_snapshot` i `closure_taxonomy_project_v1`; workerAiSaves reviewId sam ne sadrži profil. Primer polja u WAR01 nije odobrenje celog starog paketa12funkcija. Rebase tačan current owner i njegovo sertifikaciono/policy vezivanje.

U izolovanom canary-ju uporedi korisnikov originalni COUNTRY/CITY/RADIUS izbor, signed review, Save i svaku arhivsku/reset projekciju. Proveri strukturni tip/red, strani nalog, revoke/download grant i ponovljen zahtev. Novi zahtev bez važećeg binding-a i dalje mora da se odbije pre upisa, sa poštenim UI stanjem. Erasure ima zaseban dokaz svih kopija, media/voice i Auth/storage koraka; staru potvrdu ne prepisivati da bi se uklonio blocker.

Fresh Z14 ponovo potvrđuje false za retention source, export i closure erasure binding. Zatvaranje R10 zahteva semantičku korekciju i potpun dokaz sadašnjih kopija i policy/source/projection ugovora, ne ažuriranje očekivanog hash-a radi zelenog statusa. Tri private bucketa, generation/lease i nezavisni readback ostaju. Grupa šest DEV no-PK tabela ima sadašnje closure veze; povlačenje obavezno uskladiti sa SV10.

### F20 — uskladiti red, suppression i tačan push cilj

Za kapacitet prvo definiši opterećenje iz stvarnih dozvoljenih dispatch talasa. Current v37 worker ima jedan SEND i jedan RECEIPT po invocation-u; minute SQL cron samo uslovno enqueue-uje wake i može vratiti NOT_CONFIGURED/IDLE. Poslednji runtime readiness zapis je stale, pa najpre proveriti stvarne dozvoljene gates i dobiti svež dokaz. Izaberi bounded obradu ili batch lease u postojećem owner-u; proveri ukupni rok, fairness između send/receipt, claim lease, token/session, unknown provider ishod, restart i zabranu duplog slanja. Šest leases/60claims po sekundi nije trenutno implementiran batch sender.

Za admission proveri ručnu aktivnu prijavu iste Need revizije pre prve opportunity delivery. Historical F5 nije primenjen i njegovi pinovi su stari. Definiši suzbijanje na zajedničkom current owner-u; pokrij prethodnu reviziju, withdrawn/rejected, selected coverage, concurrency response/dispatch i običnu prvu poruku. Idempotent event dedupe sam ne rešava semantički nepotrebnu prvu poruku.

Za navigaciju sačuvaj nezavisnu korisnikovu odluku IN_APP off/PUSH on. Message i opportunity exact resolver ne smeju zavisiti od vidljivog IN_APP zapisa ako legitimna PUSH potvrda daje potreban autorizacioni trag. Ne otvaraj tuđu/staru priliku ni poruku radi popravljanja linka. Testiraj stvarni dodir, obe uloge, expiry, opozvanu sesiju, odsutno odredište i pošten generic fallback. Ovaj analitički paket nije uključio push/send/native gates.

Za grupne poruke poveži sadašnji sender/immutable visibility sa događajem i tačnim autorizovanim target-om. U aktuelnom telu nema emit-a ni kompenzujućeg trigera; stari GRP02 je predlog. Testiraj najviše jedan logički autorizovani događaj/target za isti message receipt i idempotentnu ponovljenu obradu, vidljivost u trenutku slanja, kasniji izlazak/blokiranje, nezavisni PUSH/IN_APP i stvarni tap. To nije garancija tačno jedne fizičke push isporuke; nepoznat provider ishod razrešava se bez slepog ponovnog slanja. Zadrži ispravan osnovni upis poruke i baseline kompatibilnost; nemoj objaviti događaj svim članovima koji nisu imali dozvolu da vide poruku.

### SB/X — konkretno dovršavanje ostatka umesto opšteg „poliranja”

| Vezani poslovi | Precizan rad | Dokaz |
|---|---|---|
| SB01/SB02/SB09 | Home prijava otvara javni detalj; ocene imaju review revision/invalidation; javni komentar ima stvarnog čitača ili usklađeno obećanje | Nova ocena uz isti IDs, refocus, own/public privatnost i prava destinacija, bez oslanjanja samo na formatter/copy test. |
| SB03/SB08/X02 | Legal replay, dual preference i dva name upisa razdvojiti po tačnom potvrđenom/unknown ishodu | Nova hash verzija posle izgubljenog stare potvrde; prvi role upis uspe, drugi prekine; uspešno displayName uz nerešen secondary upis. |
| SB04/SB05/SB06/SB07 | Oporavak medija i život nacrta po stvarnom owner-u | Proces/restart/ABSENT/izgubljeni bajtovi/late claim, blur/background/back; group draft uspeh ne preneti na support/agreement bez dokaza. |
| SB10/SB11/X01/X06 | Vidljivo osvežavanje, decode/busy/cancel ownership, bezbedan safety recovery i lifetime toast-a | Ista generacija sa odgovorima obrnutim redom, decode failure, oštećen journal, A→B→A i stvaran focus lifecycle. |
| SB12/SB13 | Dosledan datum/zona/instant i stvarna geometrija/reduced motion | Poznata poslovna zona, promene sata, mali ekran/uvećan tekst/tastatura/mapa; fiksna aritmetika testa ne zamenjuje Yoga/native render. |
| SB14/SB15/X03–X05 | Aktuelni proof/build, isti image-only kanonski hash, strogi decode i konfiguracija/demo ownership | Obavezan stvarni izlaz; current SQL; prazna/NULL/skip grana odbijena; pravi mock/caller; istovetan sadržaj claim/completion. |

Potvrđene nekorišćene pomoćnike povlači po izvozu/pozivaocu, uz aktivne zamene i kompatibilnost. Ne montirati designLab ručni kalendar/profil u proizvod zato što postoji test. Sačuvaj publicTrustFacts i stvarni requester izbor (`session.pending` u memoriji, zamrznuta komanda, isti ključ, `readSelectedAgreement`), odvojeno od trajnog worker `applicationCommandJournal`, dok povlačiš nepovezane stats/registry alternative. Legacy delete API sa odsutnim tabelama i temporal-conflict prototip zahtevaju poseban retirement zapis, bez brisanja cele istorije.

Za Discovery merenje koristi aktuelnog čitača i rok klijenta od 15 sekundi, uz F21 javne kolone i F18 područja. Stari prozor posmatranja od 90 sekundi nije prihvatljivo korisničko čekanje. Broj sintetičkih zadataka, broj istovremenih zahteva i broj korisnika moraju biti odvojeni; sačuvaj proveru celog odgovora, otkaza, hladnih/toplih i ponavljanih/različitih upita.

**Samo poruke (A25):** R11/R12 obuhvataju server i podržane stare klijente, uz odvojeno očuvanu dozvolu za tačnu lokaciju. Uklonjena UI opcija nije dokaz zatvorene PHONE mogućnosti. Ne dodavati novu moderacionu zabranu slobodnog teksta bez posebnog poslovnog pravila.

### C01–C19 — konkretni paketi čišćenja

Svaki red je uslovan posao u okviru postojećih R zadataka. Z10 navodi svih 180 ciljnih i kontrolnih putanja, njihove SHA-ove, prevezivanje, aktivnu zamenu i prihvatni dokaz. Broj 180 nije broj fajlova za brisanje.

| Paket čišćenja | Veza sa radom | Tačna jedinica promene | Šta ostaje |
|---|---|---|---|
| C01 — Nereferencirani template resursi | R11 | Ukloniti 21 označeni template/placeholder resurs iz aktivnog stabla zajedno sa eventualnim suvišnim asset unosima. | Aktivne app-icon/premium-entry/reference-entry resurse, fontove, njihove manifeste i install generisanje. |
| C02 — Stari ručni izbor veština | R08, R11 | Povući foldTerm, hasTerm i toggleTerm i test koji postoji samo radi tog quick-pick editora. | workerDraft, workerCommand, workerReadbackMatches, nameForSave i aktivni recovery/name-adoption; AI izmena profila. |
| C03 — Ručni editor činjenica pored aktivnih AI formattera | R08, R11 | Povući factEditorKind, factChoices, editorCorrection, correctionFromText, amountDigits i njihove isključivo interne manual helper-e kada se testovi prevežu. | factLabel, priceAmountRowValue, factReviewValue, slotLabel i safetyMessage sa svim aktivnim pregled/support potrošačima. |
| C04 — Stari card i layout podskupovi | R11 | Povući nekorišćene CardHead/CardDecision/CardFoot/CardBriefFoot/CardRequirement/CardPerson/CardPlaces/CardNext/CardNote/CardWaitingLine/CardFootLine; uz njih stari headBeside/wrapTitle/titleColumn i test-only requesterPrijava podskup. | Aktivne task/status/capacity/rating/spoken helper-e, CardStatus/CardStatusLine/CardTitle/WaitingDot, textWidth/font tabelu/TITLE_SIZE i stvarno odvojene requester/worker kompozicije. |
| C05 — Nepovezani selection registry i privatna stats alternativa | R11 | Povući SelectionRequestRegistry sa isključivo njegovim testom, te statsView/reliabilityNeeds podskup gde je bez običnih potrošača. | Stvarni requester izbor u kandidati ruti: memorijski session.pending, frozen command, isti ključ i readSelectedAgreement; odvojeni trajni applicationCommandJournal radnika; publicTrustFacts/memberSincePhrase. |
| C06 — Duplikat identičnog testa | R11 | Ukloniti jednu od dve identične provere prvog dolaska redova (588–604 i 606–622 na analiziranom izvoru). | Jednu kompletnu proveru: najviše šest prvih animiranih redova; topla lista i promena filtera bez ponovljene animacije. |
| C07 — Stari ulazni motion i design-only reference | R11 | Iz aktivnog izvora i default suite-a povući isključivo napuštenu BrandScene/V49/useEntryIntro referencu sa njenim testovima i starim token allowance-om; design scenu ukloniti ili prevezati u jednom zahvatu. | Aktivni EntryWelcome, premium PNG, BrandAssets/BrandRaster, potrebni brandParts/BRAND_PARTS i postinstall generisani font/reference-entry ulazi dok ih potrošači koriste. |
| C08 — V1 AI portovi i fake AI | R04, R08, R11 | Povući legacy V1 intake/confirm/publish port i njegove override-e kao zajedničku celinu; izdvojiti fixture-e koje još trebaju tekućim testovima. | Aktivni V2 razgovor, signed review/Save/publish, aktivne ne-AI komande/readere centralnog Izvor porta i smislen reset demo stanja. |
| C09 — Nepovezani owner-review builder i eksplicitni CI ulaz | R04, R11 | Premestiti ili povući source-only Gate A builder i isključivo njegov synthetic test zajedno sa eksplicitnim CI pozivom, posle prenosa važećih scenarija. | Aktivni potpisani review/prepare/Save/binder, revalidaciju identiteta i kompletan BOTH; ne smanjiti potrebnu zaštitu samo uklanjanjem CI reda. |
| C10 — Aktivne i alternativne AI strategije | R04, R06, R11 | Posle odabira i dokaza ciljnog postojećeg toka povući nepodržane alternativne flag grane, njihove izvozove i retired-only testove. | Puni semantički ugovor, nove grane, isti ID, oba moda, stvarnu saglasnost i postojeće granice potrošnje/timeout-a; foreground razgovor i pozadinski posao mogu imati različite potrebne uloge. |
| C11 — Messages-only povlačenje PHONE delova | R11, R12 | Povući PHONE metode/portove i positive-feature testove koje važeći proizvod više ne podržava; povezati sa posebnom kompatibilnom serverskom migracijom. | Poruke, važeći tačan lokacijski grant i njegove privatnosne provere; istorijski negativni test da stari klijent ne može vratiti povučenu PHONE mogućnost. |
| C12 — Nepovezane buduće GPS i permission putanje | R09, R11 | Iz aktivnog opsega povući controller/prototip i testove koji samo dokazuju nezakačenu buduću mogućnost; potrebno generičko GPS/permission ponašanje zadržati kod aktivnog vlasnika. | Aktivni exact-location grant, native location helpers i postojeći push enrollment/permission tok. |
| C13 — Javni komentari: ugovor pre povlačenja čitača | R11 | Odluku o starom prikazu doneti zajedno sa SB09: povezati potvrđen javni komentar ili uskladiti obećanje i izdvojiti neaktivni public-list podskup. | Aktivni context/submit servis, ocene i stvarna privatnost publikovanja; ne izbrisati ceo reviewComments servis. |
| C14 — Testovi povučenih pravila i istorijski oracle | R04, R07, R08, R11 | Razdvojiti stare 11-stem/fee/HITNO/equipment/license i kopirane oracle pretpostavke; povući retired-only pozitivna očekivanja iz default acceptance-a. | Važeće privacy/ownership/canonical identity/budget granice i korisne sintetičke slučajeve prevezane na sadašnji ugovor. |
| C15 — Aktuelni kvar kao zelena karakterizacija | R02, R06, R07, R11 | Posle konkretne popravke promeniti završno očekivanje sa ponavljanja kvara na ispravan rezultat; zadržati precizan ulaz/prekid koji je kvar reprodukovao. | Reprodukciju stare RSD potvrde, neuspešnog capture-a, MAP failure posle uspešne liste i nove ocene uz iste ID-jeve. |
| C16 — Dokazi, kandidati i zamrznuti generatori | R01, R11, R12 | Za svaku historical/candidate grupu zadržati minimalan manifest sa commitom, hash-em, namenom i zamenom, a nepotrebne kopije izbaciti iz aktivne grane kada nisu input tekućeg build/test/replay-a. Ne održavati drugu arhitekturu u kandidatima. | Primenu i poreklo stvarno korišćenog SQL-a, nužne fixtures i dokazive rollback preimage reference, te aktuelne minimalne canary/replay alatke. |
| C17 — Test i build katalog posle čišćenja | R11, R12 | Uskladiti package scripts, eksplicitne CI putanje, Jest selekciju, TypeScript includes i generisanje sa odlukama o aktivnom/istorijskom sadržaju. Premeštanje u archive samo po sebi ne isključuje __tests__ glob ni **/*.ts include. | Obavezne tekuće safety/regression/integrity provere i pouzdan install/build iz zaključanih zavisnosti. |
| C18 — Potpuno identične premium slike i njihove kopije | R11 | Konsolidovati tri potvrđena byte-identical para na aktivni premium-entry vlasnički put i prevezati ostale potrošače/provenance; zatim ukloniti višak kopija iz aktivnog stabla. | Isti pikseli/izgled i sve stvarne upotrebe; canonical premium-entry put se predlaže zato što je aktivni ulazni vlasnik. |
| C19 — Identični SQL i proof blizanci | R11, R12 | Kod byte-identical candidate/migration i ponovljenih proof kopija izabrati primenjenu migraciju ili jasno određen evidencioni vlasnički zapis; prevezati aktuelne testove i manifest linkove, pa ukloniti suvišnu aktivnu kopiju kada nema nezavisnu funkciju. | Primenjene migracije i njihov originalni hash; tačan istorijski run/commit identitet i sadržaj potreban za audit/replay/rollback. |

### R01/R10/R11/R12 — server cleanup posle provere stvarnih veza

[Z16](dokazi/server_final/change_manifest.json) čuva tačne serverske predmete, namenu, poznate zavisnosti, odluku i 12 izvršnih polja. Njegov status nije dozvola za automatski DROP. Odluka po grupama:

| Predmet | Redosled i očuvana granica | Završni dokaz |
|---|---|---|
| F21 i podrazumevane/efektivne dozvole | Urediti stvarni table/column grant i buduće default ACL; čuvati RLS svet/vlasnik i namerno javni legal bundle. PUBLIC EXECUTE razmotriti zasebno od anon/auth grantova. | Dozvoljene projekcije rade; direktni zabranjeni pristup i nove testne funkcije ne dobijaju neželjena prava. |
| Legacy intake delete | Proveriti podržane stare klijente; povezati active abandon/retention, pa kompatibilno zatvoriti zastareli RPC i njegove PUBLIC/role grantove. | Nema poziva na odsutne stare tabele, tuđeg pristupa ili promene značenja abandon-a. |
| PHONE | Povlačiti zajedno server/API/klijentski ugovor u skladu sa „Samo poruke”. | Stari klijent ne vraća PHONE; zaseban EXACT_LOCATION i njegove privatnosne provere rade. |
| Odbijajući taxonomy wrapper | Zadržati zatvoreno odbijanje dok kompatibilnost i dinamički/istorijski potrošači ne dozvole uklanjanje. | Nijedan caller ne može tiho vratiti stari automatski upis kategorije. |
| Sedam DEV snapshot/backup tabela | Šest ima sadašnje closure/redaction veze; needs snapshot i aktivan guard/dinamički scope. Odrediti retention i minimalan dokaz, prevezati te vlasnike pa uklanjati potvrđeni višak. | Export, redakcija, zatvaranje i vlasništvo pokrivaju sadašnji sadržaj bez odsutne relacije; potreban dokaz ostaje dostupan. |
| Dupli scope lookup indeks | Sačuvati primarni indeks; novom uskom migracijom povući samo potvrđeno redundantni `work_taxonomy_service_scopes_lookup`, nakon provere eksplicitnih zavisnosti. | Ista unikatnost i lookup; nema tvrdnje da je time dobijena velika merena ušteda. |
| Ostalih 136 performance preporuka | Raditi prema konkretnom query/trigger/lifecycle trošku, ne masovno dodavanje 93 indeksa ili brisanje 13 nula-scan indeksa. | Jednaka semantika i mereno opravdanje svake promene; policy OR publike ostaju ispravne. |
| Migration poreklo | Sačuvati primenjenu istoriju. Tri najnovija preimenovanja su samo završni CRLF; ne primenjivati ponovo. Zasebno pripremiti clean bootstrap i upgrade sa tačnim reference/fixture ulazima. | Izolovan replay i puni schema/ACL/RLS/trigger/index parity, zatim podržani stari/novi klijent; nema ledger repair-a radi broja. |

### SB14 — obavezna provera da dokaz ne može lažno proći

Pre izvršavanja svakog starog harness-a pročitaj njegove prve mutacije, environment guard, data scope i finally/rollback. SELECT koji poziva mutirajuću funkciju nije read-only; odsustvo reči INSERT/UPDATE/DELETE nije dovoljan kriterijum. Nikad ne upotrebi DB_URL koji nije potvrđeno sopstvena izolovana baza za DROP/replica/cron/backend-kill helper. Source-only parser ili mocked provider ostaju source/mock nivo.

Finalni PASS mora zahtevati stvarno proverene obavezne grane: NULL-safe polja i kardinalnost, nonempty fixture/oracle, tačan stage, aktuelno telo, stvarni decoder, bez neoznačenog fallback-a. D12 ima validan stvarni P5, ali final status ne zatvara sve dodatne gap/notVerified grane; EX06 PARTIAL/SMOKE_ONLY nije readiness; stari hardcoded equipment/fee/phone/11stem test nije izvor današnje poslovne politike. Zadrži jake stvarne lock/RLS/receipt dokaze i dopuni konkretno odsutni deo.

### Izbor postojećih testova po zadatku

Tehnička referenca, odeljak 8, sada sadrži svih 12 konkretnih selekcija sa tačnim putanjama; [Z09](dokazi/namena_i_testovi/intent_review.json) čuva i opsege, SHA-256, pozivne preduslove i predložene lokalne komande. Ne izvodi ih iz naziva fajla niti primenjuj sve istorijske skripte. Nijedna predložena komanda nije izvršena u ovoj etapi.

| Zadaci | Obavezna razlika koju provera mora da uhvati |
|---|---|
| R01–R03 | Stvaran trenutni SQL/Auth/API odgovor kroz pravi decoder; privatne kolone, prazna/neprazna strana, pet scope-ova i nezavisna greška mape. |
| R04–R06 | Ceo očekivani semantički skup, nepromenjena usluga kroz novu reviziju, stvaran prepare/Save/binder i trajni nastavak sa obračunom. |
| R07–R08 | Stara potvrda cene povučena, pravi abandon readback, paralelni profil sačuvan, jedno potrebno pitanje i isti smisao posle Save-a. |
| R09–R10 | Nezavisne push preference, događaj i odredište, sve workAreas kopije, nova pravna verzija posle nepoznatog starog ishoda. |
| R11–R12 | Konkretni SB/X propust, očuvani aktivni potrošači i konačan poznat native/server/model tok za obe uloge. |

CI trenutno pokreće Jest, Node AI glob i 13 imenovanih taxonomy testova. Post-save worker i finish-mode-completeness nisu u tom Node izboru. Deno check nije izvršenje modela ili servera. Characterization test za valutu ili odsustvo retry-ja može proći uz postojeći kvar: pri popravci zadrži scenario i promeni cilj u ispravno ponašanje. Test jednog pitanja proverava prompt tekst, pa ne zatvara stvarni razgovor. Test globalnog error-a posle MAP neuspeha treba prevesti na očuvanu validnu listu i zasebnu grešku mape; test ocena mora obuhvatiti novu ocenu uz iste ID-jeve.

Posle popravke pokreni samo relevantne lokalne provere i neophodnu integracionu granicu, zatim odgovarajući obavezni CI. Širi prolaz ponovi kada promenjeni zajednički vlasnik to zahteva. Native ili model dokaz radi samo u odgovarajuće odobrenom implementacionom opsegu; ni širok broj PASS-ova ne zamenjuje njegov konkretan rezultat.

## 9. Završna provera stvarne celine i izveštavanje

Po odobrenom opsegu proveriti tačan klijent/server, oba naloga, stvarni model i ceo posao: opis → pregled → objava → pronalaženje → prijava → izbor → Dogovor → poruke/izmena/završetak → ocena. Obuhvatiti sačuvan profil, nerešen novi deo, prekid i promenu naloga. Meriti vreme do korisnog prikaza i potvrđenog ishoda, kao i ukupnu potrošnju pokušaja.

Sačuvati i ranije prihvatne scenarije: dostupnost od budućeg datuma i pojedinačni kalendarski izuzetak menjaju samo željeni opseg; zona, datum i instant ostaju dosledni. Zasebno proveriti autorizovani izvoz, opoziv granta, javnu privatnost i završetak zatvaranja naloga. To su uslovi završne provere, ne novi dokaz kvara niti obavezna pitanja svakog AI razgovora.

PROVIDER vreme i SQL COMPLETE vreme nisu vreme do prvog korisnog prikaza. Merenje mora obuhvatiti stvarni prikaz/readback i ukupno čekanje, uz isti korpus i poznatu verziju. Precizni timer owner-i su u tehničkom odeljku 8.

Za svaki zadatak izvesti: problem i korisničku posledicu; promenjene postojeće vlasnike; rezultat pozitivnih i negativnih kontrola; stvarni nivo provere; ono što još nije dokazano. Koristi jednostavan srpski. PASS karakterizacije kvara znači da je kvar reprodukovan, ne da je popravljen. UI mock, izolovani SQL i telefon nisu zamenljivi dokazi.

Završeni registar pokriva svih 3.335 tekstualnih fajlova / 626.320 redova i odvojeno 99 binarnih resursa, ukupno 3.434 praćene putanje. Svih 680 aktuelnih public/private tela funkcija ima potpun trag čitanja. To je kumulativno direktno/hash/diff/strukturisano semantičko pokriće, ne tvrdnja o jednom ponovnom neposrednom čitanju svakog bajta. Neizvučen APK, nedostupan Downloads masterplan, svi istorijski commit-i i fizički prolaz svih ekrana nisu obuhvaćeni.

Za release potvrdi i readiness izvoza/zatvaranja, pravilnu produkcionu bazu i izričit izlaz OWNER_PERSONAL/OWNER_BUSINESS iz namernog DEV TEST sveta kada to postane cilj. Ne nasleđuj stare current oznake, pinove, grantove ili certifikate bez ponovnog sadržajnog poređenja. Analiza je dovršena na svom preciznom preseku; aplikacija nije proglašena već popravljenom.

Revizija 4 dodaje J01–J14, testnu selekciju R01–R12 i D01–D07 u iste dokumente. GitHub ref i svih 680 function body/definition/ACL otisaka ponovo su potvrđeni nepromenjenim; Edge verzije su iste. To osveženje nije novi full read ili korisnički runtime prolaz. Pre buduće izmene ponovo proveriti tadašnje stanje.

### Izlaz R12 mora obuhvatiti i očišćen aktivni izvor

Završni paket sadrži jednu važeću mapu komponenti/pravila, stvarni manifest izmena i povlačenja, relevantne rezultate provera, poznatu kombinaciju source/SQL/Edge/APK/OTA, finalna stanja primarnih ekrana i preostale ograničene rizike. Stari PASS ili veliki broj testova ne zamenjuje dokaz ove kombinacije. Konačan izgled, vremenski ciljevi i trošak moraju biti konkretni i izmereni, bez proizvoljne garancije da buduća greška nije moguća.


R12 obavezno preuzima izvršni manifest svih stvarno sprovedenih serverskih promena i povlačenja iz završne serverske dopune: objekti, zavisnosti, zamene, kompatibilnost, redosled, provere i preostala ograničenja. Analitički plan manifesta i potpuno pročitano telo funkcije nisu potvrda da je objekat već povučen. Priložiti stvarni dokaz obnove i usklađene isporuke tamo gde je potreban za odobreni zahvat.

### Revizija 7 — šta završna potvrda dodatno mora pokazati

R01 obuhvata stvarna current/default prava i potrebne RLS helpere. R04 mora pokazati vernu hijerarhiju u ulazu modela, kompletan rezultat i canonical ID kroz oba moda. R06 mora pokazati uslovni snapshot bez nepotrebnog prenosa, trajan prvi plan, ograničen cache i stvaran obračun. R09 razlikuje SQL/HTTP/claim/provider/device faze i dokazuje svežu readiness; R10 zatvara sve kopije i source/policy binding. R11 uklanja samo dokazani višak sa prevezanim potrošačima, a R12 potvrđuje izgradnju/upgrade i stvarni isporučeni presek.

Za novi cache/hijerarhijski dokaz prvo dopuniti postojeće real-builder/handler testove. `classification-full-catalog-edge.test.mjs` sa db.invalid fixture-om ne uključuje exact-DEV dual granu; njegov zeleni shadow/direct tok sam nije dokaz BG loadera. Koristiti potpuno presretnut sintetički transport uz pravi odgovarajući handler i relevantne postojeće failure/consent slučajeve. Ne pokretati mrežu/model radi ove analize i ne dodavati hiljade novih karakterizacija koje samo ponavljaju implementaciju.

Svi zaključci su preneti u isti glavni izveštaj, tehničku referencu i ovaj plan. Z11–Z16 su dokazna podloga, ne dodatni konkurentski izveštaji. Svaka kasnija izmena osvežava relevantni source/deploy/katalog i ove povezane statuse; stare činjenice ne ostaju označene kao sadašnje kada ih novi dokaz menja.

## 10. Obrazac jednog konkretnog radnog zadatka

Kada korisnik odobri izabrani paket, zadatak konkretizovati ovako:

1. **Problem:** navedi F/SB oznaku, opaženo ponašanje i tačan dokaz.
2. **Presek:** potvrdi HEAD, backend i pogođeni klijent; sažmi novi relevantni delta.
3. **Obim:** imenuj postojeće vlasnike i najmanju povezanu promenu.
4. **Rezultat:** opiši šta korisnik može da uradi posle promene i koji ugovor ostaje očuvan.
5. **Dokaz:** navedi reprodukciju, pozitivnu kontrolu, stvaran decoder/readback i potreban uređajski scenario.
6. **Isporuka:** promena koju je moguće pregledati, jasni nalazi provere i status preostalog posla; bez neodobrene objave.

Posle R01 (privatne kolone i potvrđen aktuelni ugovor), primer narednog zadatka R02 je usklađivanje Discovery ugovora sa aktivnim P6 klijentom uz očuvanje kompatibilnih baseline funkcija, pa dokaz PAGE/MAP/PLACES/filtera i dva konkretna prikaza greške. To je predlog za naredno korisničko zaduženje; u ovoj analitičkoj isporuci nije izvršen.

## 11. Konačna specifikacija, dokaz rada i objavljivanje

Ovaj odeljak ugrađuje korisne dopune dostavljene operativne revizije 8 u postojeći detaljni plan. Ne zamenjuje R01–R12, tačne testne komande, C01–C19, SV01–SV14 niti izuzetke iz prethodnih odeljaka. [Z17](dokazi/provera_plana/comparison_review.json) prati semantičko ukrštanje, a [Z18](dokazi/provera_plana/release_review.json) precizira izvorna ograničenja izdanja. Nove slike, završni nacrti i runtime provere ovim dokumentom nisu izvršeni.

### 11.1. Četiri odvojena statusa i granica prvog izdanja

Za svaki tok/ekran voditi četiri nezavisne kolone. Svaka ima datum, verziju, vlasnika i link do konkretnog rezultata; status se ne nasleđuje iz druge kolone.

| Kolona | Uslov za potvrdu |
|---|---|
| Definisan | Popunjen smisao, ulazi/izlazi, podaci, radnje, prava, greške i potvrda rezultata; otvorena poslovna odluka vidljiva. |
| Vizuelno razrađen | Prikazana potrebna stanja u postojećem dizajnu, sa konačnim tekstovima i proverljivim rasporedom. |
| Implementiran | Aktuelni pozivaoci, decoder-i, writer-i, readback i druga uloga zaista izvode ugovor. |
| Dokazan na izdanju | Poznat source/server/native/OTA presek, uređaj i scenario; pozitivan i relevantan neuspešan slučaj imaju rezultat. |

Postojanje rute, lepe kartice ili PASS-a nad mock-om ne zatvara preostale kolone. Dok se matrica ne popuni po stvarnim ekranima, popis oblasti ispod je obaveza rada, a ne završena specifikacija svih ekrana.

Prvo izdanje mora imati prohodan osnovni posao obe uloge, istu potvrđenu nameru kroz pregled/upis/ponovno otvaranje, privatnost, razuman oporavak i obavezne uslove ciljane prodavnice. Neovlašćen pristup, gubitak potvrđenog sadržaja, dupli poslovni upis, neprohodan osnovni tok ili obavezan neispunjen uslov izdanja blokiraju objavu. Dodatni provider cache, uklanjanje svakog istorijskog pomoćnog fajla i nemerena indeksna optimizacija nisu sami po sebi blokatori. Funkcija koju proizvod obećava ne izlazi iz obima tihim skrivanjem: potreban je jasan razlog i korisnikova odluka o promeni obima.

### 11.2. Jedna matrica stvarnih ekrana i stanja

Koristiti postojeće J/R/F/SB/X oznake. Jedan ekran može zatvarati više nalaza, a jedan tok može obuhvatati više ekrana. Za svaku stvarnu rutu proveriti da li je aktivna i povezana, kodirana a nepovezana, istorijska/designLab, potrebna a nedostaje ili joj nedostaje stanje. Ove oblasti su kontrola potpunosti, ne nalog da se napravi 19 novih ekrana.

| Oblast | Tok i radni vlasnici | Obavezna veza koju treba opisati |
|---|---|---|
| Prijava, sesija, povratak | J13/J14; R01/R10/R11 | Pravi nalog, promena naloga, odjava, odbijen pristup i očuvanje dozvoljenog nacrta. |
| Uloga i promena uloge | J01/J05/J13; R08/R11 | Jasno odredište, odgovarajući podaci i nezavisnost naloga/uloga. |
| Početna i donja navigacija | J09/J10; R11a/R11e | Glavna radnja, ispravno odredište kartice, osvežavanje i sadržaj iznad navigacije. |
| Razgovor naručioca | J01/J02; R04/R06/R08 | Tekst/glas/foto, jedno potrebno pitanje, nastavak i spreman pregled. |
| Pregled potrebe i radne tačke | J03/J04; R02/R07/R08 | Šta pin odmah čuva, šta ostaje lokalno, nacrt naspram objave. |
| Sopstveni zadaci | J04/J10; R03 | Pet scope-ova, counts, status, privatni nacrt, izmena i ponovno otvaranje. |
| Razgovor izvršioca | J05/J07; R04/R06/R08 | Više usluga, oba moda, isti ID, područja i završetak bez parcijalnih kartica. |
| Sačuvani profil i aktivacija | J06/J08; R05/R08/R10 | Ista potvrđena ponuda posle čuvanja; aktivacija i spremnost pojedine usluge nisu isto. |
| Prilike: lista, mapa i filteri | J08/J09; R01/R02/R05 | Nezavisne greške, postojeći rezultat, dozvola lokacije, ručna pretraga i rok. |
| Javni detalj i prijava | J10; R05/R07/R11 | Trenutna revizija, vidljivi uslovi, dozvoljena prijava i potvrđen rezultat. |
| Kandidati i izbor | J10/J11; R07/R11 | Ista zamrznuta komanda, dostupni kapacitet i potvrđeni Dogovor obe strane. |
| Dogovor i promena uslova | J11/J13; R07/R11d | Cena, tim, vreme, tačke, potvrde, nacrt i posledica izmene. |
| Poruke i mediji | J11/J13; R09/R11c | Tekst/glas/slika, vlasništvo, prekid prenosa, čitanje i vidljivost drugoj strani. |
| Obaveštenja | J12; R09 | PUSH/IN_APP nezavisno, prva legitimna poruka, tačno dozvoljeno odredište. |
| Završetak, ocene i komentari | J11; R11b | Prava obe uloge, potvrđen završetak, nova ocena uz iste ID-jeve i javna vidljivost. |
| Podrška, prijava i blokiranje | J13/J14; R10/R11c/R11d | Nacrt, receipt, izveštaj korisniku, blokada i stvarna obrada prijave. |
| Pravila, AI saglasnost i podaci | J14; R01/R10 | Prava verzija dokumenta, tačan obim slanja, izvoz i završeno brisanje. |
| Podešavanja i dozvole | J12/J13/J14; R09/R10/R11 | Odvojene preference, delimičan upis, odbijena dozvola i promena u sistemu. |
| O aplikaciji i pomoć | J13; R11/R12 | Razumljiv proizvodni tekst; tehnički identitet dostupan za dijagnostiku bez zatrpavanja glavnog toka. |

Za svaku konkretnu radnju popuniti sledeći ugovor, u istom registru ekrana:

1. Ruta, uloga, cilj čoveka i J/R/F/SB/X veze.
2. Ulaz, izlaz, povratak i eventualni link iz obaveštenja.
3. Polja koja se prikazuju, njihov autoritativni reader, privatnost i verzija.
4. Svako dugme/gest: smisao, preduslov, disabled razlog i nadležni writer.
5. Payload, očekivana revizija i identitet pokušaja; šta korisnik tačno potvrđuje.
6. Šta se čuva odmah, šta tek potvrdom i šta je samo lokalno.
7. Merodavna potvrda i readback; šta vidi druga uloga i kada.
8. Loading, prazno, uspeh, odbijanje, parcijalna greška i nepoznat ishod.
9. Povratak, promena taba, background, restart, odjava i promena naloga.
10. Dupli dodir, odgovori obrnutim redom, nova revizija i konkurentna promena.
11. Dozvoljeni nastavak/retry, rok i izlaz; bez nove komande dok stara nije razrešena.
12. Kratak tačan srpski tekst; dosledan ton, uključujući postojeće persiranje AI-ja.
13. Postojeće komponente, raspored, razmaci i vidljivost glavne radnje.
14. Mali ekran, uvećan tekst, tastatura, safe area, pristupačnost i reduced motion.
15. Pozitivan i potreban negativan test, prikaz/snimak i identitet proverene verzije.
16. Preostala odluka/blokada, odgovorni radni zadatak i stvarno dostignuta četiri statusa.

### 11.3. Četiri radnje koje ne smeju izgubiti postojeće značenje

**Nacrt i objava potrebe — R07/R08/R12.** Postojeći requester review namerno može podržati SaveDraft i Publish: oba koriste isti pripremljeni accept/digest, a Publish nastavlja kroz evaluate/publish. Ne uvoditi drugi suvišan prepare samo zato što postoje dva dugmeta. Nastavak prihvaćenog nacrta koristi već potvrđenu komandu i njen ključ. Promena sadržaja ili revizije, međutim, traži odgovarajući novi pregled. Tačan ugovor čuvaju postojeći `aiTaskReviewClientService` i ruta pregleda. Zasebno proveriti prvu direktnu objavu, SaveDraft/ponovno otvaranje/objavu i A24 zamenu javne objave; nacrt nije obavezan korak pre svake objave. Pri zameni prethodna objava ostaje do atomskog uspeha nove, a stare prijave ne prenose se na nove uslove.

| Situacija | Prikaz i dozvoljena radnja | Merodavni ishod |
|---|---|---|
| Pregled je spreman | Jasno „Sačuvajte nacrt” ili „Objavite”, prema stvarnim preduslovima. | Nema tvrdnje o objavi pre izvršenja. |
| Slanje traje / ponovljen dodir | Jedan status rada; bez novog identiteta komande. | Isti pokušaj i ista revizija. |
| Odgovor nije stigao | Provera prethodne radnje uz očuvan sadržaj. | ACCEPTED, EVALUATING, EVALUATED i UNKNOWN nisu PUBLISHED. |
| Server potvrđuje objavu | Uspeh tek posle provere postojećeg ugovora. | Komanda PUBLISHED, published.status=PUBLISHED, ocena ALLOW, tačan Need/revizija i odgovarajući javni readback. Samo podudaranje ID-ja nije dovoljno. |
| Odbijanje ili stvarna promena | Tačan razlog i najmanja potrebna ispravka. | Nema lažnog uspeha niti automatskog ponavljanja nove objave. |

**Čuvanje i aktivacija izvršioca — R04/R08.** `activate` je deo pripremljenog potpisanog pregleda. Izbor Save+activate mora odgovarati tom pregledu; ako je vrednost drugačija, pripremiti odgovarajući novi signed review pre slanja. Sadašnji `rpc_save_worker_ai_review` obavlja upis i traženu aktivaciju u jednoj transakciji; ne projektovati izmišljeno stanje „profil uspešno sačuvan, aktivacija odvojeno nije uspela” niti dodavati drugi activation writer. Za activate=true potvrda mora dokazati ACTIVE. Nepoznat mrežni ishod rešava se čitanjem iste komande. Za već ACTIVE profil activate=false ne znači deaktivaciju. Podobnost za povezivanje po usluzi/modu/području ima sopstvene uslove i ne sledi automatski iz opšte aktivacije. Posle uspeha ponovo otvoriti profil i uporediti ceo potvrđeni sadržaj.

**Mapa i lista — R02.** Uspešna lista uz neuspeh MAP čitanja ostaje korisna. Greška mape, neuspešno učitavanje liste i legitimno prazan rezultat imaju različita stanja. Ne pripisivati svaki kvar internetu. HALF/PEEK/FULL i donja navigacija moraju zadržati čitljiv tekst i dostupnu radnju; retry ne sme bez potrebe uništiti prethodni valjan prikaz. REMOTE, ugašena dozvola lokacije i ručno izabrano područje imaju izričito ponašanje.

**Izbor izvršioca — R07/R11.** Sačuvati sadašnji requester `session.pending`, zamrznutu komandu, isti ključ i `readSelectedAgreement`. Ne uvoditi drugi journal kao navodnu popravku već postojeće zaštite; trajni worker `applicationCommandJournal` služi drugom toku. Obe strane moraju videti isti Dogovor i potvrđene uslove. Kapacitet, tim i konkurentni izbor proveriti prema važećem domenskom pravilu; broj kandidata nije sam po sebi broj popunjenih mesta. Izgubljen odgovor ne sme postati druga prijava/izbor.

### 11.4. Pregled ekrana i provere tokom rada

Kada korisnik pokrene vizuelnu etapu, povezane grupe ekrana prolaze tri puta: trenutni APK, isti scenario posle popravke, završni kandidat za izdanje. Tri stare dostavljene slike ostaju dokaz; ne tražiti ih ponovo. Novi snimci ne znače da je ceo tok izvršen. Kratak video posebno koristi za tastaturu, povratak, panel i čekanje. Raditi po toku: ulaz/uloga; naručilac do objave; izvršilac do sačuvane ponude; pronalaženje/prijava/izbor; Dogovor/poruke/završetak; nalog/podaci/podrška.

Na reprezentativnoj početnoj, prilici, AI razgovoru, završnom pregledu i Dogovoru usaglasiti tipografiju, razmake, dugmad, kartice, panele i poruke, zatim primeniti iste postojeće komponente. Vizuelno pojednostavljivanje ne uklanja smisao radnje ili recovery zaštitu. Razgovor ostaje bez parcijalnih kartica; blaži izraz iz revizije 8 „bez obaveznih parcijalnih kartica” nije usvojen.

R12 prikuplja dokaz od prvog odobrenog zahvata. Posle izmene razgovora proveriti pregled, Save i ponovno otvaranje; posle prijave proveriti kandidata kod naručioca; posle poruke proveriti drugu ulogu i potrebno obaveštenje. Konačni prolaz objedinjuje ove dokaze na istom izdanju. Sačuvati minimalne smislene provere iz odeljka 8; ne množiti testove koji samo preslikavaju implementaciju. Prekid mreže, izgubljen ACK, dupli dodir, zastarela revizija i promena naloga proveravaju se tamo gde stvarno ugrožavaju radnju.

Predložene vrednosti iz revizije 8 (250 ms lokalni odziv, 3 s čitanje, 8 s p95 AI) ostaju neodobreni i neizmereni predlozi. Prvo odrediti radnju, uzorak, uređaj, mrežu, p50/p95, hladan/topao slučaj i ukupno čekanje/trošak. Postojeći rok Discovery klijenta od 15 sekundi ne znači cilj kvaliteta od 15 sekundi. Ne proglašavati proizvoljne brojke postojećim SLA-om.

### 11.5. R12a–j — konkretno dovršavanje izdanja

Ovo su podzadaci postojeće R12. Android i iOS imaju nezavisne dokaze; uspeh jedne platforme ne zatvara drugu. Trenutne namerne preview/production zabrane ostaju dok odgovarajući novi ugovor nije pripremljen i proveren.

| Podzadatak | Konkretan rezultat i zavisnost | Uslov zatvaranja |
|---|---|---|
| R12a — Presek i opseg | Zabeležiti source SHA, stvarnu bazu/migracije, Edge verzije, javnu konfiguraciju, native build/potpis, OTA runtime/kanal/update i podržane platforme. Bez tajni u paketu. | Svaki dokaz pripada poznatoj kombinaciji; DEV TEST i production jasno odvojeni. |
| R12b — Produkcioni backend i obnova | Poseban potvrđen projekat, kontrolisan bootstrap i upgrade, Auth/session/email, Storage/Realtime/cron, lifecycle bindings i kompatibilnost. Veza R01/R09/R10/SV. | Izolovan replay/parity i oporavak; stvarni prod gates, bez prenosa nevažećih certifikata ili širokih DEV prava. |
| R12c — Profili, identitet i zaštite izgradnje | Uskladiti `app.config.js`, `app.json`, `eas.json`, `scripts/build-contract.cjs`, `scripts/check-eas-preview.cjs` i `package.json` preinstall. Odrediti proverene profile po platformi, tačne backend/package/runtime/channel vrednosti i Firebase/APNs konfiguraciju gde je potrebna. | Pozitivna matrica dozvoljenih profila i negativna pogrešnih projekata/platformi/kanala. Ne ukloniti guard globalno i ne pretvoriti DEV URL u production. |
| R12d — Android artefakt | Provereni potpisani AAB, stvarni target/compile SDK i native biblioteke, primenljiva 16 KB kompatibilnost, dozvole, update i paket koji Play stvarno isporučuje. | Artefakt i ciljna konzola daju dokaz; android.versionCode=36 nije targetSdk=36. Sadašnji APK ostaje preview dokaz. |
| R12e — iOS artefakt i funkcije | Odrediti ios.bundleIdentifier/signing, dozvoljen build profil, capabilities/privacy purpose strings, runtime/OTA i stvarne native funkcije. AI govor sada koristi Android-only capture; implementirati i dokazati iOS tok za puni obećani opseg. | Poseban iOS build/uređajski prolaz i glas/tekst fallback. Uži iOS opseg zahteva izričitu poslovnu odluku; ne sakriti funkciju bez nje. Dogovor voice prilozi proveravaju se zasebno. |
| R12f — Privatnost, brisanje i sadržaj | AI saglasnost za stvarnu obradu, tačni obrasci o podacima/SDK, brisanje u aplikaciji i potreban web put, prijava/blokiranje i obrada korisničkog sadržaja. | Celovit izvršen tok u ciljnom okruženju, sa potvrđenim ishodom, rokovima i dopuštenim retention izuzecima. Stalna poruka „nije spremno” ne zatvara obavezu. |
| R12g — Cela aplikacija i nadogradnja | Dva stvarna naloga/obe uloge, svi primarni tokovi i potrebni prekidi; instalacija/nadogradnja, restart, dozvole i četiri statusa svakog bitnog ekrana. | Povezan rezultat i poznate verzije; nema gubitka potvrđenih podataka, duplog upisa ili nedozvoljenog čitanja. |
| R12h — Materijal za pregled prodavnice | Nalozi/identitet, opis, ikona, stvarni snimci, kategorija/uzrast, kontakt/podrška/privacy URL, review pristup i uputstva, primereni test nalozi. | Reviewer može proći ponuđeni proizvod na dostupnom backend-u; tvrdnje i snimci odgovaraju artefaktu. |
| R12i — Predaja i javno izdanje | Odvojiti spreman paket, predato, odobreno i javno dostupno; platforma/track, vlasnik predaje, plan rollout-a i povratka. | Stvaran status konzole i javnog izdanja, uz odgovarajuće odobrenje predaje/objave. Ovaj plan nije takvo odobrenje. |
| R12j — Operativni rad posle objave | Imenovati odgovornog za probleme/podršku, pravila i brisanje, queue/provider greške, potrošnju, kompatibilnost i postupak incidenta. | Korisna tehnička dijagnostika bez nepotrebnog privatnog sadržaja, pragovi i put reakcije; prva objava i kasniji rollout nisu isti dokaz. |

**Zašto nova baza nije dovoljna:** sadašnji `build-contract.cjs` bezuslovno odbija production profil/OTA cilj. EAS preinstall ide kroz `check-eas-preview.cjs`, koji dopušta samo tačan Android preview. iOS bundleIdentifier nije konfigurisan, a aktivni AI hold-to-talk capture odbija iOS. To su potvrđene granice izvora; nema tvrdnje da je pokrenut ili neuspeo neki novi build. Ispravno rešenje je eksplicitan odobreni ugovor za svaku novu platformu/profil sa negativnim proverama, ne zaobilaženje postojećih zaštita. Tačne putanje i postojeći testovi su u Z18 i tehničkom odeljku 11.

Običan preview zadržava svoje namerno inertno push ponašanje. Namenski push proof ima zaseban SB14/R11g posao usklađivanja plugin-a i validatora; njegova konfiguracija ne prelazi u store izdanje. Sadašnji `googleServicesFile` dodaje se samo paketu `rs.uskoci.preview`, dok je predviđeni store paket `rs.uskoci`; to zahteva pravi odobreni Firebase/FCM identitet, ne preimenovanje starog fajla. Nije provereno stanje udaljenih Firebase/Apple naloga.

Minimalna konfiguraciona matrica u Z18 obuhvata običan Android preview, namenski push proof, odobreni Android production, iOS interni kandidat, iOS production, pogrešan OTA/backend/runtime/kanal, odbijenu dozvolu/opozvanu sesiju/odsutnog provajdera i neispravan SDK/native artefakt. Prvo proveriti izvršnu validaciju konfiguracije, a zatim konkretan paket/uređaj. Sama pretraga stringa u kodu nije dovoljna.

R12g/R12i odvojeno dokazuju povratak klijenta/OTA i oporavak baze: OTA rollback ne poništava migraciju ili već potvrđen poslovni upis. Pre probne nadogradnje zabeležiti postojeće lokalne nacrte i nerešene komande; ne deinstalirati aplikaciju napamet da bi se dobio čist prolaz. Oporavak mora sačuvati njihov dozvoljeni nastavak.

**Spoljne zavisnosti u istom registru izdanja:** za svaki red upisati odgovornu osobu/ulogu, relevantan kod, okruženje/platformu, datum, POTVRĐENO/NEPOZNATO/BLOKIRANO, dokaz i uslov za dogovoreno prvo izdanje. Sledeća tabela ne tvrdi da su nalozi ili konfiguracija već provereni.

| Zavisnost | Radni zadatak i konkretan izlaz |
|---|---|
| Supabase produkcija | R12b: vlasništvo projekta, kompatibilan source/SQL/Edge, Auth/Storage/Realtime/cron, potrebne zastavice i stvarni lifecycle binding. |
| Expo/EAS i prodavnice | R12c/d/e/h: projekat, izdavački nalog, package/bundle ID i signing/provisioning metapodaci; privatne ključeve ne unositi u izveštaj. |
| Obaveštenja | R09/R12c: odgovarajući Firebase/FCM, APNs/EAS i saglasnost; posebno dokazati registraciju, događaj/red, provider, uređaj i tačno odredište. |
| Model i govor | R04/R06/R12e/j: odgovarajući provider/model, potrebna konfiguracija, kvote, troškovni limit, dozvola i stvarni input/output. DEV pristup ne dokazuje production spremnost. |
| Mapa i pretraga mesta | R02/R12g/j: postojeći OpenFreeMap style i LocationIQ put preko sopstvenog Edge-a; proveriti dostupnost, ograničenja, dozvolu upotrebe i attribution. Uspeh Supabase-a ne dokazuje tiles/geocoder. |
| Auth email i javni linkovi | R12b/h: isporuka email-a, recovery/redirect i native scheme, koegzistencija preview/production, funkcionalni policy/deletion/support URL-ovi i domen. |
| Podrška i moderacija | R10/R11/R12f/j: stvaran prijem, odgovorna osoba, obrada, status i završetak slučaja; postojanje forme nije dokaz operativne usluge. |

Predloženi budući dokazi ostaju u istom paketu: `dokazi/ekrani/screen_action_matrix.json` za stvarne rute/host-ove, radnje i stanja; `dokazi/izdanje/release_readiness.json` za kandidat, platformne uslove, spoljne zavisnosti i operativni status. Ove dve matrice još nisu popunjene niti je njihovo postojanje izmišljeno u manifestu ove analize.

### 11.6. Uslovi prodavnica — proveriti ponovo pri predaji

Sledeći zahtevi provereni su na zvaničnim izvorima 27.10.2026. To je vremenski označen planski presek. Tip/datum izdavačkog naloga i stanje konzola nisu pregledani; uslovni zahtevi ne postaju automatski potvrđena obaveza konkretnog naloga. [Spisak izvora i granica](dokazi/provera_plana/release_policy_sources.json).

| Predmet | Planski uslov | Zvanični izvor |
|---|---|---|
| Play paket i API | Za novu telefonsku aplikaciju AAB i aktuelni target API 36 ili viši; proveriti stvaran artefakt i eventualnu primenljivu konzolnu iznimku. | [AAB](https://support.google.com/googleplay/android-developer/answer/9844279), [target API](https://support.google.com/googleplay/android-developer/answer/11926878?hl=en) |
| Android native biblioteke | Proveriti 16 KB podršku kroz stvaran paket i native zavisnosti, uključujući posredne. | [Page sizes](https://developer.android.com/guide/practices/page-sizes) |
| Play pristup produkciji | Za lični nalog otvoren posle 13.11.2023. proveriti uslov najmanje 12 opt-in testera neprekidno 14 dana i zatim zahtev za pristup; to nije automatsko odobrenje. | [Testiranje novih ličnih naloga](https://support.google.com/googleplay/android-developer/answer/14151465?hl=en) |
| Podaci i brisanje na Play-u | Data safety uključuje relevantnu obradu kroz SDK; funkcionalan put zahteva brisanja u aplikaciji i izvan nje. | [Podaci](https://support.google.com/googleplay/android-developer/answer/10787469?hl=en), [brisanje](https://support.google.com/googleplay/android-developer/answer/13327111?hl=en) |
| Apple SDK i kompatibilnost | Xcode 26 i iOS 26 SDK ili noviji za predaju; SDK za izgradnju nije minimalna OS verzija uređaja. Proveriti i tekuću Apple granicu deployment target-a i native zavisnosti. | [Aktuelni zahtevi](https://developer.apple.com/news/upcoming-requirements/) |
| Apple privatnost i AI | Jasno objašnjenje obrade i izričita dozvola pre deljenja ličnih podataka sa spoljnim AI; tačni App Privacy/SDK manifesti i required-reason API deklaracije gde se primenjuju. | [Review Guidelines](https://developer.apple.com/app-store/review/guidelines/), [App Privacy](https://developer.apple.com/app-store/app-privacy-details/), [SDK privacy](https://developer.apple.com/news/?id=3d8a9yyh) |
| Apple brisanje | Pokretanje brisanja u aplikaciji; privremena deaktivacija nije zamena. Prikazati tok i stvarni završetak, uz dopuštene retention granice. | [Account deletion](https://developer.apple.com/help/app-review/guideline-reference/5-1-1-account-deletion) |
| Korisničke objave i poruke | Funkcionalna prijava, blokiranje i moderacija prema stvarnoj vrsti sadržaja. Za social login posebno proveriti primenljiv Apple uslov; ne uvoditi ga napamet za svaki email/password tok. | [Google UGC](https://support.google.com/googleplay/android-developer/answer/9876937?hl=en-GB), [Apple Guidelines](https://developer.apple.com/app-store/review/guidelines/) |

### 11.7. Odluke, kontinuitet i izlaz ovog plana

D06 — osnovica satnice — i D08 — pravilo više radnih lokacija — ostaju otvorene. Za dve osobe po tri sata uz 1.200 RSD/h, satnica po osobi daje 7.200 RSD, a za celu ekipu 3.600 RSD; ne pretpostavljati osnovicu niti trajanje. Za prevoz Novi Sad–Beograd razlikovati područje polaska/preuzimanja od spremnosti za odredište; proveriti i posao koji stvarno zahteva rad na dve tačke. Ne usvojiti automatski ni pravilo „samo početak” ni „uvek obe tačke”. Te odluke ne zaustavljaju nezavisne F21/R02/R03 popravke.

F03/R07a ispravlja zastarelu potvrdu cene u važećem RSD/OFFERS domenu. Korisnikova ispravka sa nepodržanom valutom mora povući staru potvrdu i dobiti jasan dozvoljeni nastavak; sama reprodukcija RSD→EUR nije odobrenje da se uvede EUR. Izvršni zapis Z10 sada je usaglašen sa ovim pravilom, uz sačuvan raniji tekst kao istoriju.

R09 „jedan događaj” odnosi se na stabilan identitet i idempotentnu obradu potvrđene poruke, ne na nemoguću garanciju jednog fizičkog push prikaza uprkos izgubljenom provider odgovoru. Provider acceptance, receipt i stvaran uređajski prikaz ostaju odvojeni. Očuvati vidljivost u trenutku slanja, podržane stare klijente i nezavisne preference.

Pri sledećem radu otvoriti PROCITAJ_PRVO, ovaj plan, glavni izveštaj i tačne povezane dokaze. Proveriti novi relevantni source/server delta, izvesti samo odobreni obim i dopuniti iste dokumente: promena, dokaz, preostalo. Ako stari dokaz sadrži hash dokumenta revizije 7, to je istorijski identitet tog pregleda; važeći dokumenti imaju hash u najnovijem MANIFEST-u. Ceo ZIP prenosi podlogu, a ne samo pet sadržajnih fajlova. Završni plan je sada precizniji; završni proizvod se dokazuje implementacijom i stvarnim prolazima.
