# USKOČI — jedinstveni plan dovršavanja proizvoda i objavljivanja

**Datoteka za nastavak rada:** `CODEX_PLAN_RADA.md`  
**Revizija:** 9 — objedinjena revizija, 27.10.2026.  
**Status ove isporuke:** ažuriran i objedinjen plan; aplikacija, baza i deployment nisu menjani. Novi završni UI nacrti, izvršeni testovi i prolaz na telefonu nisu predstavljeni kao već završeni.

Ovo je **jedan važeći operativni plan**. U njega su uključeni radni zahtevi izvornog plana revizije 7, dostupni tehnički nalazi, konkretni vlasnici i testovi, server i cleanup ograničenja, korisnički tokovi, UI/UX, provera na telefonu i priprema za Google Play i Apple App Store. Prethodna zasebna dopuna revizije 8 više nije dodatni obavezni dokument za izvršavanje. Izvorni izveštaji ostaju istorijska dokazna podloga; čitalac ne treba ručno da spaja više planova da bi znao šta je sledeće.

**Konačan cilj:** sve postojeće aktivne funkcije i potvrđena obećanja USKOČI povezani su u razumljiv, vizuelno dosledan i tehnički pouzdan proizvod. Tokovi su logički određeni, potrebna stanja stvarno nacrtana, radnje povezane sa merodavnim kodom i podacima, provere izvršene nad poznatim izdanjem, a dokumentacija i operativa dovoljne za slanje u prodavnice i podršku posle objave. Plan je put do tog rezultata, a ne potvrda da je on već postignut.

## Sadržaj

| Odeljak | Namena |
|---|---|
| [1. Polazište i važenje](#1-polazište-važenje-i-stvarni-nivo-dokaza) | Šta je stvarno provereno, šta je preneti dokaz i koji izvor se nastavlja. |
| [2. Važeća pravila proizvoda](#2-važeća-pravila-proizvoda) | Korisnikova namera i zaštite koje svaka izmena mora sačuvati. |
| [3. Proizvod, tokovi, ekrani i UI/UX](#3-proizvod-korisnički-tokovi-ekrani-i-završni-uiux) | J01–J14, inventar ekrana, ponašanja, vizuelna razrada i snimci sa telefona. |
| [4. Nalazi i redosled rada](#4-svih-42-nalaza-i-redosled-rada) | Svih 42 F/SB/X nalaza, njihov R vlasnik, zavisnosti i sledeći korak. |
| [5. Vlasništvo nad stanjem](#5-vlasništvo-nad-stanjem-i-očuvani-ugovori) | Postojeći autoriteti za razgovor, review, Save, mapu, sesiju i život podataka. |
| [6. Izvršni zadaci R01–R12](#6-izvršni-zadaci-r01r12) | Konkretne promene, pune poznate putanje, postojeće provere i uslovi završetka. |
| [7. Čišćenje i server](#7-čišćenje-aktivnog-izvora-i-servera) | C01–C19, očuvani potrošači, konkretne putanje i uslovi povlačenja. |
| [8. Prihvatanje, testovi i merenja](#8-prihvatanje-testovi-i-merenja) | A01–A25, provereni CI ulazi, bootstrap/upgrade i granice stvarnog dokaza. |
| [9. Otvorene odluke](#9-otvorene-odluke-i-šta-može-napredovati-odmah) | Uske poslovne i vizuelne odluke koje se rešavaju na konkretnom predlogu. |
| [10. Produkcija, prodavnice i podrška](#10-produkcija-dokaz-izdanja-prodavnice-i-podrška) | Jedno poznato izdanje, obaveze platformi, sadržaj prijave i rad posle objave. |
| [11. Kontinuitet i izvršni zadatak](#11-kontinuitet-ažurira-se-ovaj-isti-plan) | Kako se ažurira ovaj isti plan i kako sledeća sesija nastavlja bez novog paralelnog plana. |
| [12. Izvori i granice](#12-izvori-nedostajući-dokaz-i-obuhvat-objedinjavanja) | Poreklo informacija, nedostajući dokazi i obuhvat objedinjavanja. |

## 1. Polazište, važenje i stvarni nivo dokaza

### 1.1. Šta ova revizija menja

Prethodno je napravljen odvojen dokument za proširenje plana. Ova revizija tu grešku ispravlja: dopune su raspoređene uz postojeće radne zadatke, a zajednički proizvodni, vizuelni i release zahtevi imaju svoja mesta u istom dokumentu. Oznake F01–F21, SB01–SB15, X01–X06, R01–R12, J01–J14, A01–A25 i C01–C19 ostaju stabilne.

Ranija formulacija da se UI/UX i celovit opis proizvoda tek naknadno dodaju u druge dokumente više nije aktuelan način rada. Njihova razrada sada je sastavni deo ovog plana. Stvarni prikazi i uređajski dokaz nastaju u odgovarajućim izvršnim koracima; tri ranije slike nisu dovoljne da se svi ekrani proglase pregledanim.

Ovaj korisnički zahtev ovlašćuje objedinjavanje i ažuriranje plana. Ne beleži neizvršenu implementaciju kao završenu. Kada korisnik zada nastavak implementacije, izvršava se taj već odobreni opseg autonomno kroz postojeće zadatke; ne traži se novo odobrenje za svako čitanje, rutinsku tehničku odluku ili lokalnu proveru. Produkciona objava i promene korisničkog obećanja imaju svoje konkretne izlaze i postojeće granice ovlašćenja.

### 1.2. Potvrđeno u ovom pregledu i preneto iz analize

| Predmet | Poznato stanje | Granica |
|---|---|---|
| Kanonski repozitorijum | `uskocibusiness-boop/USKOCI-EAN` | Ne obnavljati stariji repo ili backend iz memorije. |
| Grana i izvor | `feature/uskoci-cisto`, `a9692e11942609bab9406215c3e407d79589dafa` | GitHub poređenje u ovoj reviziji daje identično, ahead 0 / behind 0. To ne potvrđuje ceo runtime. |
| Pročitani trenutni repo ulazi | `README.md`, `STATUS.md`, `app.config.js`, `eas.json`, `package.json`, `.github/workflows/ci-clean.yml` | Sve pročitano na navedenom SHA; nije ponovljen audit svih fajlova. |
| Dodatna uska potvrda putanje | `supabase/proofs/ai/background_taxonomy_failures.test.mjs` | Potvrđeni putanja i početni sintetički setup; test nije izvršen. |
| Referentni DEV | `leqcwgzvjsxugfgzdmth` | Preuzeto iz aktuelnog README/config i ranijeg paketa; nema novog live audita baze u ovoj reviziji. |
| Telefonski prikaz iz priloga | Izvor `fcef803e719ba5663f6cfd8fbd5a601e08a3479b`, verzija 1.0.0, runtime `uskoci-v1-preview-r1`, kanal `preview`, OTA prefiks `01a163c4` | Raniji About screenshot; puni native identitet i sve efektivne zastavice nisu očitani. |
| Razlika telefona i izvora | U dostavljenoj analizi zabeleženo 69 commit-a | Broj commit-a nije broj popravki niti dokaz instalirane novije verzije. |
| Server iz analize rev7 | 680 public/private funkcija i dve dodatne RLS definicije, 169 table granica, devet sekvenci, 15 Edge paketa | Preneti opis tadašnjeg pregleda. Ova revizija nije ponovila njihove live definicije ni izvršenja. |
| Edge iz analize rev7 | NEED 151, WORKER 104 i post-save 5 sa poznatim razlikama od a969; push v37 byte-equal | Ne koristiti kao neograničeno važeću oznaku „sada deployed”; proveriti relevantnu deltu pre isporuke. |
| Istorijski CI | Run `40452826819`, a969, SUCCESS prema prilozima | Nije nov CI run ove revizije i nije native/server/model potvrda. |
| Izvoz i zatvaranje | Poslednji opisani retention/source/export/erasure binding uslovi ostaju zatvoreni | Ne menjati očekivani digest ili certifikat samo da bi funkcija postala dostupna. |
| Produkcija | README traži poseban proveren backend; production build/OTA ima namernu blokadu | `eas.json` još pokazuje DEV cilj u production profilu; blokada se čuva do ispravnog povezivanja. |
| Dostavljeni paket | Šest priloga; pet payload fajlova po veličini i SHA-256 odgovara manifestu rev7 | Manifest navodi 125 payload fajlova, a 120 pratećih dokaznih fajlova nije dostavljeno. |

Tri ranija screenshot-a vide se u PDF-u, uključujući stranu 9; nisu dostavljeni kao tri zasebna originalna fajla. Nema potrebe tražiti iste slike ponovo. Novi screenshot/video potreban je kada pokazuje nedostajuće stanje ili novi kandidat.

Raniji audit checkout `/workspace/scratch/f356024cf009/audit/deep-review/source` jeste istorijska lokacija iz analize, a ne potvrđena sadašnja radna kopija. Originalni `USKOCI_ULTRA_MASTER_PLAN_2026-10-26` iz Downloads nije bio dostupan i nije proglašen pročitanim. Tri governance putanje pomenute u projektnom postupku nisu pronađene na ovoj grani; ne pripisivati im nepročitana pravila. Pred implementaciju pročitati stvarno dostupna aktuelna repo uputstva.

### 1.3. Kako se koristi dokaz

| Nivo | Šta zaista potvrđuje | Šta ostaje posebno |
|---|---|---|
| Pročitan izvor | Konkretan uslov, caller, decoder ili SQL telo. | Da je ta verzija izvršena na telefonu ili serveru. |
| Izolovana proba | Pravi modul/handler/SQL uz kontrolisan I/O. | Pravi model, cela baza, native renderer i završni poslovni tok. |
| Živa definicija/metapodaci | Objavljen sadržaj, verzija ili agregat u vreme čitanja. | Poslovno izvršenje RPC-a i korisnički rezultat. |
| Živi log | Zabeležen serverski događaj ili ishod. | Veza sa konkretnim telefonom bez request/trace identiteta. |
| Snimak uređaja | Ono što je stvarno vidljivo u tom stanju. | Svi prethodni koraci, pozadinski upis i druga platforma. |
| Preneti dokaz sa istim hash-em | Ranija proba i nepromenjen konkretan sadržaj. | Novo izvršavanje ili potvrda sadašnjeg deployment-a. |
| Celovit uređajski tok | Stvaran korisnički rezultat za imenovani kandidat i server. | Univerzalna garancija za svaki uređaj, mrežu i buduću izmenu. |

U narednim odeljcima „postojeće”, „aktuelno telo” i linijski brojevi iz tehničke analize označavaju opisani a969/rev7 presek, osim gde je izričito naveden nov provereni repo ulaz. Pre izmene osvežiti relevantni deo. Zeleni karakterizacioni test može dokazivati reprodukciju postojećeg kvara; tek promenjeni uslov prihvatanja i pravi rezultat dokazuju popravku.

## 2. Važeća pravila proizvoda

Ova pravila proizlaze iz dostavljenog aktuelnog paketa i pročitanog STATUS-a. Novija izričita odluka korisnika ima prednost. Naziv starog testa, izdvojeni prototip ili istorijska memorija ne menjaju kanon.

1. **Dve uloge u jednom proizvodu.** Naručilac i izvršilac imaju odvojene zadatke, prikaze i ovlašćenja. Promena uloge ili naloga ne prenosi nedozvoljene podatke i komande.
2. **Prirodan razgovor.** Sve jasne činjenice ulaze u predlog. Sledeći odgovor traži najviše jednu stvarno potrebnu informaciju. Prazan ulaz ne pokreće model ili poslovni upis.
3. **Klasifikacija je unutrašnji posao.** Čovek potvrđuje svoju potrebu ili ponudu; ne bira tehničku kategoriju da bi popravio interni kvar. Jasna usluga dobija bezbedan tehnički nastavak kada prvi pokušaj nije završen.
4. **Stabilan identitet.** Postojeća usluga zadržava pravi ID. Semantički sinonim nije automatski nova kategorija. Za opravdanu novu granu baza validira i stvara zapis, pa vraća stvarni ID; model ne izmišlja trajni UUID.
5. **Tačan način rada.** ON_SITE znači dolazak na mesto naručioca/zadatka. REMOTE može biti digitalni rad, radionica/rad kod izvršioca i odgovarajuća predaja. Ne izmišljati radni pin, domet ili dolazak za REMOTE. Administrativni grad profila je odvojeno pitanje.
6. **Potpun BOTH.** Oba očekivana načina iste usluge čuvaju isti identitet, smisao i korisničku saglasnost. Uspeh jednog dela nije dokaz celog očekivanog skupa.
7. **Jedan razumljiv završni pregled.** Nema novih obaveznih parcijalnih kartica ili dodatnih formulara za mode, biografiju, opremu, tim, vozilo i licence. Stvarno potrebna činjenica prikuplja se u odgovarajućem postojećem toku.
8. **Različita poslovna stanja.** Predlog, review, privatni nacrt, Save, aktivacija, objava, admission/binding i matching READY imaju različito značenje. UI prikazuje stvarno postignuti rezultat.
9. **Pending nije opšta zabrana.** Pending klasifikacija sama ne zabranjuje svaki Save/objavu. Stvarni uži uslovi, uključujući posebne REMOTE handoff granice, ostaju.
10. **Čuvanje i aktivacija.** DRAFT sa istog pregleda bira Save ili Save+activate. `activate=false` pri čuvanju ACTIVE profila nije deaktivacija.
11. **Samo poruke za sada.** Dogovor koristi poruke. PHONE saglasnost/reveal treba zatvoriti kroz server i podržane stare klijente. EXACT_LOCATION ostaje zasebno autorizovan. Phone OTP prijava i slobodan tekst poruke nisu ta ista funkcija.
12. **Nema prećutnih novih pravila.** Ne uvoditi zabranu broja telefona u slobodnoj poruci, nove valute, pretplate, naknade, HITNO ili obavezna polja kao usputno čišćenje.
13. **Čuvaju se dokazane zaštite.** Account/focus/revision ograde, journal pre dispatch-a, stabilan request identitet, signed review/digest, eksplicitna potvrda, idempotentni upis i autoritativni readback ostaju kod svojih postojećih vlasnika.
14. **Govori se stvarni ishod.** „Poslato”, „sačuvano”, „objavljeno”, „izabrano”, „izvezeno” ili „obrisano” prikazuje se tek na odgovarajućoj potvrdi. UNKNOWN se proverava kao ista radnja; ne skriva se novim slanjem ili lažnim uspehom.
15. **Jedan dosledan jezik.** AI instrukcija već propisuje persiranje. Determinističke poruke razgovora uskladiti s njom; ostali konačni tekstovi i nazivi razrađuju se kao povezana celina, bez mešanja tehničkih detalja u korisnički tok.

### Obim završetka

Obavezne su sve postojeće aktivne funkcije i potvrđena obećanja, privatnost i konkretni zahtevi ciljne prodavnice. Uslovne obaveze važe kada izdanje sadrži određenu platformu, dozvolu, SDK, prijavu ili način naplate. Dodatna optimizacija ili nova neobećana funkcija može ostati kasniji posao, ali se potvrđen kvar aktivne funkcije ne skriva smanjivanjem obima.

Za svaki obavezni tok moraju postojati **definicija, vizuelna razrada relevantnih stanja, aktuelna implementacija i izvršen odgovarajući dokaz**. Završetak ne znači sve moguće kombinacije svakog uređaja, već sve ključne korisničke situacije i kritične granice uz reprezentativne mobilne uslove. Prekrivena glavna radnja, nečitljiv tekst ili nepristupačan ključni korak jesu blokade. Preostalo manje ograničenje može se prihvatiti samo konkretno, sa razlogom i vlasnikom; ne nestaje iz plana.

## 3. Proizvod, korisnički tokovi, ekrani i završni UI/UX

### 3.1. Obavezni rezultat i granica sadašnjeg dokaza

USKOČI treba da omogući čoveku da prirodno opiše potrebu ili svoju ponudu, potvrdi tačno shvaćene podatke, pronađe odgovarajuću drugu stranu i završi dogovor kroz razumljive, povezane ekrane. Jedan nalog može koristiti odvojena iskustva naručioca i izvršioca. Promena uloge ne prenosi nedozvoljeno stanje, tuđe podatke ili radnje iz prethodnog konteksta.

Cilj obuhvata **sve postojeće aktivne funkcije i potvrđena korisnička obećanja**, uz njihovo logičko, kodno i vizuelno dovršavanje. Teška ili nezavršena aktivna funkcija ne premešta se samovoljno u „kasnije”, ne skriva se i ne proglašava suvišnom radi lakšeg objavljivanja. Promena obima zahteva konkretnu odluku vlasnika proizvoda; istorijski/prototipski sadržaj ostaje odvojen od stvarno aktivnog proizvoda. Redosled platformskih izdanja može biti različit bez tihog smanjivanja funkcionalnog cilja.

Ovaj odeljak određuje završni proizvodni i vizuelni ugovor unutar jedinstvenog plana. **Specifikacija nije dokaz da su svi prikazi već nacrtani, povezani ili provereni na telefonu. U ovoj etapi nisu izrađeni novi konačni nacrti ekrana; plan određuje obavezu njihovog stvarnog dovršavanja.** Poznata ponašanja u nastavku potiču iz analiziranog preseka. Njihovu primenu proveriti na aktuelnom izvoru i konkretnoj isporučenoj kombinaciji aplikacije, servera i konfiguracije.

Za svaki tok i njegov ekran voditi četiri odvojena statusa: **definisano**, **vizuelno razrađeno**, **implementirano** i **dokazano**. Uz poslednji status navesti stvarni nivo: izvor, izvršen test, integracija, native uređaj ili ceo tok. Nedostupna provera ostaje BLOCKED sa razlogom; odsustvo dokaza ostaje UNPROVEN. Postojanje rute, prototipa, starog PASS-a ili jednog screenshot-a ne popunjava ostale statuse.

Čovek vidi smisao svog posla. Interne kategorije, potpisi, revizije i nazivi klasifikatora ostaju unutrašnji detalji. Jasne činjenice se čuvaju, a jedno naredno pitanje rešava jednu stvarno potrebnu nejasnoću. Predlog, pregled, privatni nacrt, objava, sačuvan profil, aktivacija i spremnost za povezivanje ostaju različita stanja.

Razgovor ne dobija obavezne parcijalne kartice niti dodatne formulare za mode, opremu, tim, vozilo, licence ili biografiju. Potrebna stvarna činjenica prikuplja se prirodno i potvrđuje u razumljivom pregledu; postojanje starog polja ili testa nije razlog da se uvede nova korisnička obaveza.

### 3.2. Sačuvani kanonski tokovi J01–J14

Oznake i ishodi ostaju stabilni. Svaki red povezati sa konkretnim ekranima, radnjama i dokazom; pomoćni ulazni tokovi iz inventara ispod dopunjuju njihovu celinu.

| Tok | Vidljiv ishod koji treba postići i sačuvati | Radni zadaci |
|---|---|---|
| **J01 — Naručilac opisuje potrebu** | Sve jasne činjenice ostaju; jedno potrebno pitanje; prazan ulaz nema model/upis. | R04/R06/R08 |
| **J02 — Ispravka i nastavak** | Termin ili završna poruka ne obezvređuju istu uslugu; stvarna promena odbacuje samo zastareli rezultat. | R04/R07/R08 |
| **J03 — Jedan pregled i mapa** | Čovek vidi celinu; potvrda pina, lokalna izmena i objava imaju tačan ishod; REMOTE nema lažnu radnu mapu. | R02/R08/R11 |
| **J04 — Nacrt, objava i zamena** | Nacrt ostaje privatan; objava ima readback; zamena čuva staru do uspeha i ne prenosi stare prijave. | R07/R08/R12 |
| **J05 — Radnik opisuje i dopunjava ponudu** | Isti razgovor čuva ostale usluge i područja; nema obavezne opcione biografije ili parcijalnih kartica. | R04/R06/R08 |
| **J06 — Čuvanje i aktivacija profila** | Isti pregled nudi odgovarajući Save/Save+activate; ponovo otvoreni profil verno pokazuje potvrđenu ponudu. | R04/R08/R10/R12 |
| **J07 — ID, oba načina i predaja** | Sinonim koristi isti ID; nova grana ima stvaran DB ID; ceo BOTH i stvarni REMOTE/handoff ostaju. | R04/R06 |
| **J08 — Područje i vreme** | Odgovarajući kandidat prolazi od početnog izbora do prilike; stara tačka ne poništava sačuvano područje. | R05 |
| **J09 — Lista, mapa i filteri** | Ponuđeni režimi rade sa pravim serverom; korisna lista opstaje uz odvojenu grešku mape; ručna pretraga dostupna. | R01/R02/R12 |
| **J10 — Moji zadaci, prijava i izbor** | Pet scope-ova i counts odgovaraju podacima; prijava/izbor čuvaju reviziju i uslove; dodatak veštine ne pregazi profil. | R03/R07/R11/R12 |
| **J11 — Dogovor, poruke i ocene** | Obe uloge vide iste uslove, poruke i potvrđen završetak; ocena se osveži; PHONE ugovor zatvoren i na serveru. | R07/R09/R11/R12 |
| **J12 — Obaveštenje i odredište** | Poštuju se obe preference; nema nepotrebnog dupliranja; dodir vodi tačnom dozvoljenom sadržaju. | R09/R12 |
| **J13 — Povratak, restart i nepoznat ishod** | Proverava se ista radnja; sačuvani posao ne ponavlja model; gubitak medijskih bajtova ima bezbedan izlaz. | R06/R07/R11/R12 |
| **J14 — Privatnost i život podataka** | Tri privatne kolone ostaju privatne; saglasnost je za pravi dokument; izvoz/kopije čuvaju potvrđena područja. | R01/R10/R12 |

### 3.3. Potpun radni inventar grupa ekrana

Ovo je obavezan inventar oblasti, **ne tvrdnja da je izvršen nov popis svih ruta niti nalog da se napravi dvadeset novih ekrana**. Jedna grupa može imati više postojećih ruta, modalnih prikaza i stanja. Svaki pronađeni prikaz dobija tačnu putanju i oznaku: aktivan/povezan; kodiran/nepovezan; istorijski/prototip; potreban/nedostaje; aktivan sa nedostajućim stanjem. Nepovezani designLab se ne uključuje samo zato što postoji.

| Br. | Grupa i obuhvat | Obavezni izlaz i veza |
|---|---|---|
| **01** | Početni ulaz i Auth: prijava, registracija, potvrda kontakta prema podržanom načinu, oporavak, nevažeći/istekao link, odjava. | Čovek pouzdano ulazi u pravi nalog; nema prazne slepe ulice ili tuđeg nastavka. R01/R11/R12. |
| **02** | Izbor i promena uloge, povratak u prethodno radno okruženje. | Jasno „Treba mi neko” / „Želim da uskočim”; dozvoljeni nacrti ostaju kod svog vlasnika. R11/R12. |
| **03** | Početna, donja navigacija, prečice, povratak i zabranjeno odredište. | Svaka aktivna radnja otvara odgovarajući sadržaj u pravoj ulozi. R11a; ulazi u J01–J14. |
| **04** | Naručilac AI: uvod, tekst, glas, fotografija, dopuna, prekid i nastavak. | Jasne činjenice opstaju; jedno potrebno pitanje; tehnički problem ne postaje pitanje o kategoriji. J01/J02/J13. |
| **05** | Pregled potrebe, izmena, fotografije, razgovorna i pregledna mapa, predaja. | Jedna razumljiva celina; vidljivo je šta je predlog, lokalna izmena i sačuvani podatak. J03/J04. |
| **06** | Moje potrebe, statusi, brojači, strane, privatni nacrt, detalj, izmena/zamena. | Pet postojećih scope-ova i counts odgovaraju podacima; status određuje dozvoljene radnje. J04/J10. |
| **07** | Izvršilac AI: više usluga, izmene, načini izvođenja, predaja i područja. | Nepogođene usluge ostaju; nema obaveznih suvišnih formi za biografiju/opremu/licence. J05/J07/J13. |
| **08** | Pregled i sačuvan profil, Save/Save+activate, izmena ACTIVE profila. | Ponovo otvoren profil verno pokazuje mode/handoff/pending po usluzi. J06/J07. |
| **09** | Područja i raspoloživost, sačuvani izbor i postojeći dozvoljeni način izmene. | Radni prostor i vreme imaju isti smisao u profilu i povezivanju; nema novog obaveznog formulara. J08. |
| **10** | Prilike: lista, mapa, filteri, ručna pretraga i „Za mene”. | Prazno, parcijalno i neuspešno čitanje su različita stanja; korisna lista ostaje dostupna. J08/J09. |
| **11** | Javni detalj, slanje prijave, Moje prijave i izmena/povlačenje gde ugovor dozvoljava. | Prikazani uslovi odgovaraju poslatoj radnji; privatna polja ostaju zaštićena. J10. |
| **12** | Kandidati, izbor, potvrda i kapacitet. | Izabrana je prava prijava za važeće uslove; brojač potiče iz autoritativnog modela. J10/J11. |
| **13** | Dogovor: pregled, dozvoljene izmene, tok, završetak i otkazivanje prema stanju. | Obe uloge vide iste potvrđene uslove i sledeću dozvoljenu radnju. J11. |
| **14** | Poruke, foto/glas, grupna vidljivost, nacrti, neuspešno slanje i oporavak. | Nema dupliranja, tuđe poruke ili izgubljenog nacrta prikrivenog uspehom. J11/J13. |
| **15** | Obaveštenja i preference, dozvola, push i tačno odredište. | IN_APP i PUSH ostaju nezavisni; dodir ima autorizovan cilj ili pošten rezervni prikaz. J12. |
| **16** | Ocene, javni prikazi i komentari prema važećem ugovoru. | Pravo ocenjivanja, vidljivost, agregat i osvežavanje ostaju dosledni. J11; R11b. |
| **17** | Podrška, prijava problema/sadržaja/korisnika, blokiranje i potvrda prijema. | Razraditi postojeće i za izdanje potrebne mogućnosti; odrediti stvarnog vlasnika obrade. R01/R10/R11. |
| **18** | Pravila, privatnost, saglasnosti, izvoz, zatvaranje naloga i status zahteva. | Važeći dokument, prava potvrda, sve potrebne kopije podataka i proverljiv završetak. J14. |
| **19** | Podešavanja i OS dozvole: lokacija, mikrofon, fotografije i obaveštenja. | Objašnjena svrha, odbijanje i naknadna promena imaju upotrebljiv nastavak. R09/R11/R12. |
| **20** | O aplikaciji, pomoć, kontakt podrške i javni linkovi. | Razumljiv identitet izdanja, funkcionalni linkovi i jasan put do pomoći. R11/R12. |

Loading, greška, offline, uvećan tekst i tastatura nisu novi ekrani po automatizmu: pripadaju svakoj relevantnoj grupi. Skrivena nedozvoljena ruta mora ostati zaštićena i pri direktnom linku, nezavisno od vidljivosti dugmeta.

### 3.4. Cele priče naručioca, izvršioca i sistema

**Naručilac.** Posle prijave i izbora uloge dolazi u svoje radno okruženje. Otvara razgovor; lokalni uvod sam ne pokreće model. Opisuje potrebu tekstom ili podržanim medijem. Asistent čuva jasno izrečene činjenice i pita jednu preostalu bitnu stvar. Čovek ispravlja podatak u istom razgovoru, bez ponovnog diktiranja cele potrebe. Pregled pokazuje posao, uslove, vreme, broj potrebnih ljudi i relevantno mesto/predaju. Nacrt ostaje privatan; objava nastaje tek eksplicitnom radnjom i potvrđuje se čitanjem stvarnog rezultata. U Mojim potrebama vidi status i prijave, bira po važećim uslovima, ulazi u potvrđen Dogovor, razmenjuje poruke i koristi dozvoljene korake do završetka i ocene. Ako menja objavljenu potrebu, priprema ne gasi staru objavu; uspešna zamena zatvara staru u propisanoj transakciji i ne prenosi prijave na nove uslove.

**Izvršilac.** U svom prostoru opisuje jednu ili više usluga, načine rada i područja. Dopuna jedne usluge ne briše ostale. Ista usluga sa oba načina zadržava isti ID i oba potvrđena smisla. REMOTE može obuhvatiti digitalni rad ili radionicu sa predajom; zato ne dobija izmišljenu fizičku radnu tačku. DRAFT sa istog pregleda bira čuvanje ili čuvanje sa aktivacijom. Izmena ACTIVE profila ne deaktivira ga slučajno i ne daje novoj nepotvrđenoj usluzi prava starih potvrđenih usluga. Ponovo otvoren profil verno pokazuje sačuvano. Izvršilac pronalazi prilike ručno ili preko odgovarajućeg obaveštenja, proverava uslove, šalje prijavu i vidi potvrđen ishod. Posle izbora koristi isti Dogovor i poruke kao naručilac, uz prava svoje uloge, pa završetak i ocenu.

**Sistem.** Za svaki korak proverava nalog, ulogu, svet, reviziju i stvarno dozvoljene podatke. Model predlaže činjenice; baza potvrđuje identitet i čuva poslovni rezultat. Izmena budžeta/vremena ne ruši nepromenjenu semantiku usluge; stvarna promena odbacuje zastareli rezultat. Nedovršena tehnička klasifikacija dobija ograničen nastavak i obračun kroz postojeći vlasnički tok. Izbor kandidata koristi sačuvanu ponudu, područje i vreme; ručna prijava ne dobija automatski dodatne zabrane iz dispatch preference pravila. Poslovna komanda koristi postojeći stabilan identitet i zaštite. Nejasan odgovor zahteva proveru iste radnje, a potvrđen uspeh osvežava povezane ekrane. Poruke, obaveštenja i tačna lokacija imaju zasebne granice vidljivosti. Izvoz i zatvaranje naloga obuhvataju potrebne žive i arhivske kopije.

Sve tri priče proveriti sa dva odvojena naloga i nezavisnim klijentskim sesijama. Uključiti izgubljen odgovor, zastareo pregled, dupli dodir, restart i promenu naloga. Android dokaz ne predstavlja iOS dokaz.

### 3.5. Specifikacija ekrana i svake komande

Za svaki stvarni ekran popuniti sledeća polja u istom operativnom registru plana. UI ne postaje novi vlasnik pravila koje već poseduje domen.

1. **Identitet:** ruta, uloga, svrha, grupa 01–20, J/R/F/SB/X veze i četiri statusa.
2. **Ulazi i izlazi:** navigacija, dozvoljeni push/deep link, sesija, preduslovi, zabranjeno odredište i povratak.
3. **Podaci:** vidljiva polja, njihova privatnost, merodavan reader i pravilo osvežavanja.
4. **Svaka radnja:** naziv, preduslov, postojeća komanda/writer, obuhvat izmene, potvrda i razlog nedostupnosti.
5. **Trajnost:** šta je lokalni nacrt, šta je poslato i kada je server potvrdio rezultat.
6. **Posledice:** readback, povezani ekran, druga uloga, obaveštenje ili nastavak procesa.
7. **Stanja:** početno, loading, empty, success, partial, greška, offline, zabranjeno/isteklo i nepoznat upis, gde su primenljiva.
8. **Prekidi:** Back/gest, zatvaranje sheet-a, tab, background, restart, odjava i promena naloga.
9. **Konkurentnost:** dupli dodir, obrnut red odgovora, paralelna izmena, zastareo pregled i kasni callback.
10. **Oporavak:** bezbedno ponavljanje ili provera iste radnje, ograničenje retry-ja i izlaz iz neuspeha.
11. **Tekst i izgled:** konačan srpski copy, formalno obraćanje, hijerarhija, glavna radnja i postojeće komponente.
12. **Telefon i pristupačnost:** safe area, tastatura, mali ekran, veliki font, dugačak sadržaj, čitač ekrana, fokus, dodirne površine i smanjene animacije.
13. **Dokaz i granica:** relevantan test, prikaz bitnih stanja, native proba kada je potrebna, preostalo ograničenje i vlasnik.

Obavezna sledljivost je **tok → ekran → radnja → postojeći vlasnik → test → dokaz na telefonu**. Jedan red operativne matrice sadrži:

| Tok i problem | Ekran i stanje | Radnja i efekat | Postojeći vlasnik | Test i rezultat | Dokaz na telefonu |
|---|---|---|---|---|---|
| J oznaka, vezani R/F/SB/X i konkretan scenario | Tačna aktuelna ruta/komponenta, uloga i početno stanje | Naziv komande, uslov, sačuvani rezultat i readback | Reader/writer, ugovor i source putanja | Stvarna testna putanja/komanda, datum, rezultat i granica dokaza | Kandidat/source/OTA/backend, model uređaja/OS, scenario, screenshot/video i rezultat |

Na primer, J03/J04 objava mora povezati pregled potrebe, postojeći review/publish vlasnički tok, proveru izgubljene potvrde i uređajski prikaz iste potvrđene objave. Naziv budućeg testa ili zamišljeni snimak ne popunjavaju polje dokaza. Relevantna provera unosi se iz stvarnog izvršenja; gde uređajski dokaz nedostaje ostaje UNPROVEN.

Ne primenjivati jedan identičan mehanizam trajnosti na sve radnje. Requester izbor već koristi memorijski `session.pending`, zamrznutu komandu i `readSelectedAgreement`; worker prijava ima zaseban postojeći journal. Proveriti potrebnu granicu oporavka, bez uvođenja drugog vlasnika samo radi simetrije.

### 3.6. Četiri obavezna konkretna ugovora ponašanja

#### 3.6.1. Pregled potrebe i objava

Predloženi nazivi su „Izmenite”, „Sačuvajte nacrt” i „Objavite”; uskladiti ih kroz proizvod. Pregled pokazuje stvarni sadržaj, cenu sa osnovicom, vreme, ljude i relevantno mesto/predaju. Pending klasifikacija sama ne uvodi opštu zabranu čuvanja ili objave; posebni stvarni uslovi ostaju.

| Stanje | Korisnički prikaz | Obavezan efekat |
|---|---|---|
| Spremno | Dostupna radnja za prikazani pregled. | Još nema objave. |
| Slanje | „Objavljivanje je u toku.” | Isti pregled i identitet radnje; dupli dodir ne pravi novu objavu. |
| Izgubljen odgovor | „Proveravamo da li je Vaša potreba objavljena.” | Provera iste komande, bez novog modela ili izmišljene potvrde. |
| Potvrđen uspeh | „Vaša potreba je objavljena.” | Readback potvrđuje isti Need i reviziju; otvara stvarni detalj. |
| Potvrđeno odbijanje | Konkretan razlog i put za ispravku. | Sadržaj ostaje prema postojećem vlasniku; nema lažnog uspeha. |
| Neizvesnost traje | Iskreno objašnjenje i dostupna provera. | Ne pokretati automatski drugi identitet radnje. |

Back tokom provere nije dokaz otkazivanja. Tastatura ne prekriva glavnu radnju; status se čitaču ekrana saopštava jasno, bez neprekidnog ponavljanja.

#### 3.6.2. Čuvanje i aktivacija profila

Svaka usluga pokazuje svoj mode, relevantnu predaju i status. DRAFT sa istog pregleda nudi „Sačuvajte profil” i „Sačuvajte i aktivirajte profil” kada su uslovi ispunjeni. ACTIVE izmena čuva izmene bez neželjene deaktivacije. Tokom upisa nema drugog slanja; nepoznat odgovor proverava isti Save. Posle uspeha prikazuje se merodavan sačuvan profil, ne stara lokalna kartica.

Ako nova usluga čeka, objašnjenje stoji uz nju. Nepogođene stare usluge ne gube prava bez odgovarajućeg serverskog pravila. Traženi BOTH zahteva oba očekivana dela istog ID-ja. Zastareo pregled obnavlja se uz potrebnu korisničku potvrdu i očuvanje paralelnih izmena. Status ima tekst, ne samo boju; detalji rade i bez animacije. Opciono polje ne odlaže završetak razgovora.

#### 3.6.3. Discovery: lista i mapa

Lista, podloga, pinovi i prostorni rezultat imaju odvojeno stanje. Uspešna lista ostaje upotrebljiva kada mapa ne radi. Ako podloga radi a pinovi ne rade, poruka precizira prikaz zadataka na mapi. Prvi neuspeh bez rezultata i kasniji neuspeh imaju jednako razumljivo objašnjenje i dostupnu radnju. Prazan rezultat jasno kaže da nema zadataka za izabrane uslove.

Tokom osvežavanja sačuvati još važeći sadržaj uz oznaku; stari filter ne sme se predstavljati kao novi. HALF/FULL/PEEK ne skrivaju poruku i dugme iza navigacije. REMOTE ne pokreće besmislen fizički MAP zahtev. Povratak na tab čuva dozvoljeni kontekst, a čitač ekrana ne gubi fokus pri svakom retry-ju. Razlog greške određuje korisnu radnju: serverovo odbijanje se ne objašnjava automatski „lošim internetom”.

#### 3.6.4. Izbor izvršioca i Dogovor

Izbor se vezuje za važeću prijavu, reviziju i prikazane uslove. „Izaberite” šalje postojeću zamrznutu komandu; tokom upisa prikazuje se „Potvrđivanje izbora”. Nepoznat ishod proverava istu radnju. Tek autoritativni `readSelectedAgreement` opravdava prikaz potvrđenog Dogovora. Zastarela prijava ili promenjeni uslovi daju konkretno objašnjenje i osvežen prikaz.

Brojač „Izabrano 0 od 2 → 1 od 2 → 2 od 2” ostaje **predlog prikaza do potvrde šta aktuelni model broji**: osobe, popunjena mesta ili timski kapacitet. Ne povećavati ga brojanjem klikova ili pretpostavkom da jedna prijava uvek popunjava jedno mesto. Dogovor koristi poruke; zasebna kontrola tačne lokacije ostaje. Posebnu PHONE mogućnost zatvoriti i na serveru i za podržane stare klijente. To samo po sebi ne uvodi novu zabranu da čovek otkuca broj u slobodnoj poruci.

### 3.7. Dve mape: postojeće značenje i otvoren vizuelni izbor

Poznati ugovor razlikuje dve radnje. **`ConversationPointAsk`** svaku izričito potvrđenu tačku odmah čuva na serveru uz geografsku reviziju; START može biti sačuvan dok END nedostaje. **`NeedLocationForm`** u pregledu čuva tačke lokalno; „Primeni potvrđene tačke” priprema novi review. Izlazak bez primene ne znači sačuvan novi skup.

UI mora objasniti tu razliku i ponašanje pri izlasku. Sačuvano se ne sme predstaviti kao izgubljeno, niti lokalno kao potvrđeno na serveru. Ne objedinjavati writere zbog sličnog izgleda. Promena redosleda kartice/pregleda/mape ili načina potvrđivanja ostaje konkretan dizajnerski predlog za odluku; jasno označavanje sadašnje trajnosti je obavezna ispravnost.

### 3.8. Vizuelni rad od sadašnjeg APK-a do konačnog izdanja

Rad počinje od nedostajućih prikaza trenutne aplikacije. Ne tražiti ponovo iste tri već dostavljene slike. Uz novi obilazak zabeležiti stvarni identitet tada instaliranog izdanja. Trenutni prikaz nije automatski dokaz ponašanja novijeg izvora.

Snimanje ide u tri prolaza: **polazno stanje**, **isti scenario posle popravke** i **konačan release kandidat**. Korisnik može prvo poslati jednu celu grupu: ulaz/navigacija; naručilac od razgovora do objave; izvršilac od razgovora do sačuvanog profila; prilike/prijava; izbor/Dogovor/poruke/završetak; podešavanja/podrška/privatnost. Kratak video bolje pokazuje tastaturu, čekanje, gest i povratak. Tehničke greške reprodukuje izvršni tim; korisnik ne mora praviti stotine snimaka.

Na postojećim komponentama razraditi reprezentativne površine: početnu, karticu/listu prilike, AI razgovor, završni pregled i Dogovor/poruke. Zaključiti tipografiju, razmake, kontrast, ikone, dugmad, kartice, sheet/modal, prazno i neuspešno stanje. Potom isti jezik primeniti kroz inventar. Veći vizuelni izbor prikazati kao povezanu celinu; rutinske detalje rešavati u tom pravcu. Ne praviti paralelan dizajn sistem.

Za svaku glavnu površinu proveriti jednu jasnu primarnu radnju, stvarnu količinu informacija, dugačke nazive, mali ekran, veliki font, tastaturu, safe areas, fokus i smanjene animacije. Snimke za prodavnicu praviti iz proverenog kandidata sa reprezentativnim probnim sadržajem bez privatnih podataka; prikazana funkcija mora stvarno raditi.

### 3.9. Izlazni kriterijum UI/UX i povezanog proizvoda

Ova celina je završena kada svi obavezni tokovi imaju definisana pravila, vizuelno razrađena relevantna stanja, aktuelnu implementaciju i izvršen odgovarajući dokaz. Povezani scenario uključuje opis, ispravku, pregled, čuvanje/objavu, pronalaženje, prijavu, izbor, Dogovor, poruke, završetak i ocenu; ponovno otvaranje pokazuje iste potvrđene podatke. Ulaz u nalog, uloge, podrška, privatnost i potrebne dozvole nemaju slepe ulice.

Nema nerešenog blokirajućeg gubitka podataka, neovlašćenog pristupa, lažnog uspeha, duplog poslovnog efekta ili neprohodne glavne radnje. Pozitivni tok ima relevantan negativni slučaj. Proverivač mora zaista pasti kada njegov očekivani rezultat izostane. Meriti odziv, korisni prikaz, potvrđen ishod, ukupan AI trošak i push čekanje u imenovanim uslovima; ne proglašavati cilj izmerenim rezultatom.

Konačan izgled mora biti proverljiv na stvarnom Android kandidatu i zasebno na iOS kandidatu ako je iOS u izdanju. UI/UX završetak ulazi u R12 zajedno sa ispravnim produkcionim presecima, pravnim sadržajem, zahtevima prodavnica i operativnom podrškom; sam ne znači da je izdanje već odobreno ili objavljeno. Manje prihvaćeno ograničenje dobija vlasnika, razlog i rok; prekriveno glavno dugme ili nepristupačan ključni korak ostaju blokada.

## 4. Svih 42 nalaza i redosled rada

### 4.1. Stabilan registar nalaza

Svaki red zadržava primarnog R vlasnika iz izvornog tehničkog mapiranja. R11a–h su podzadaci R11. Prateći R ne predstavlja drugi nezavisan vlasnički sistem: označava granicu koja mora ostati usklađena. U ovoj reviziji nijedan nalaz nije označen kao novopopravljen ili novoizvršeni incident. Detaljan posao, tačne poznate putanje i testovi stoje u odeljku 6.

| Nalaz | Konkretan problem | Primarni R | Povezano | Obavezna promena / granica |
|---|---|---|---|---|
| F01 | Lista sopstvenih zadataka ima neusaglašen wire ugovor | R03 | — | Uskladiti pet scope-ova, counts, cursor i tačan wire oblik javnog reader-a i decoder-a. Napraviti usku novu migraciju prema sadašnjem reader-u; ne vraćati ceo istorijski EX04a kandidat. |
| F02 | Satnica nema isto značenje kroz sve faze | R07 | R12 | Nakon zaključivanja podrške za satnicu uskladiti HOURLY/PER_HOUR kroz fact validator, writer, review, objavu, prijavu, izbor, Dogovor i dekodere. Ne uklanjati samo TOTAL guard. |
| F03 | Korekcija valute može ostaviti staru potvrđenu cenu | R07 | — | Svesti eksplicitnu korekciju valute na kanonski supersession stare činjenice i novu vrednost; zameniti očekivanje koje danas potvrđuje zadržavanje RSD. |
| F04 | Parcijalan katalog može postati „potpun” keš | R04 | — | Iterirati nextCursor do potvrđenog završetka uz kontrolu ponovljenih kursora, grešaka, verzije/fingerprint-a i kompletne cache jedinice. Delimično stablo ne dobija status celog. |
| F05 | Semantički identitet, nova grana i sintaksička prepreka nisu spojeni u jedan aktivan ugovor | R04 | R08 | Izabrati jednog aktivnog semantičkog vlasnika prema istom korpusu i merama; dozvoliti semantički reuse postojeće grane i smislen predlog nove hijerarhije. Uskladiti bind ID-a i kategorijski tekst, worker rename/sync i sve čitaoce; tek posle parity dokaza povući suvišan put. |
| F06 | Klasifikacija može ostati nedovršena i posle uspešnog modelskog odgovora | R06 | R04, R12 | Pre implementacije definisati tačan minimalan trajni zapis rada: account/conversation, draft revision, ulaz/fingerprint, scope, očekivani mode parovi, pokušaj/budget, stanje i rezultat. Omogućiti ograničen nastavak i kada prvi plan nije nastao. Existing post-save outbox povezati gde je primenljiv, ne nazivati ga rešenjem za nepostojeći plan. |
| F07 | Dodatni model poziv nema zatvoren zaseban obračun | R06 | — | Uskladiti jednog timeout/abort vlasnika i budžet logičkog pokušaja; BG čitanje mora proveriti potpunost/STOP/body limit i beležiti usage ili UNKNOWN. STT rezervaciju ne oslobađati samo zato što nema transkripta, već po dokazu dispatch/usage. |
| F08 | Worker mode ugovor nije jedinstven; nepotpun BOTH može postati READY | R04 | R08 | Iz ulazne namere izvesti ceo očekivani skup service×mode pre provider odgovora; validirati potpunost skupa nezavisno od uspešnog podskupa. BOTH ne sme postati dva nepovezana service ID-a. |
| F09 | Završetak worker razgovora nema autoritativan signal | R08 | — | Izvesti finish/readiness iz obaveznih potvrđenih poslovnih činjenica i statusa semantike, pa povezati isti kriterijum u Edge, decoder i ekran. |
| F10 | Sačuvani profil prikazuje manje značenja nego review | R08 | — | Povezati trajni per-service/per-mode read model sa sačuvanim profilom; prikazati ono što je upravo potvrđeno, uključujući smislen scope. Ne oživljavati stari lokalni manual draft kao drugi vlasnik. |
| F11 | Izgubljeni abandon ACK u pregledu nema odgovarajući readback | R07 | — | Posle unknown abandon čitati isti review/request i razlikovati OPEN/ABANDONED/UNKNOWN; omogućiti proveru i tačan nastavak bez novog prepare-a. |
| F12 | Više guard-ova može tražiti više razjašnjenja odjednom | R08 | — | Birati sledeću relevantnu nejasnoću i ograničiti sastavljeni odgovor na jedno pitanje; proveriti rezultat poruke, ne samo string instrukcije. |
| F13 | Posle uspešne prijave sledi moguć zastareo profilni upis | R07 | — | Ukloniti slepi upis starog celog skills niza; koristiti autoritativno ograničen merge/CAS sa account revision ili vezati postojeći vlasnik koji to već garantuje. |
| F14 | Source, Edge, SQL i instalirani klijent su različiti potvrđeni preseci | R12 | R01 | Za svaku isporuku snimiti source SHA, dependency lock, migration ledger/function bodies/ACL, Edge bundle versions+hashes, flags, build/OTA/runtime i dokaz uređaja. Razlike rebase-ovati po vlasniku; proveriti clean isolated schema bootstrap, jer istorijske proof migracije očekuju fixture stanje. |
| F15 | Instalirani P6 klijent traži MAP koji živi discovery RPC ne podržava | R02 | — | Uskladiti PAGE/MAP/PLACES i exact/filter/paging ugovor između aktivnog transporta, decoder-a i javne funkcije, uz eksplicitnu politiku kompatibilnosti podržanog starog klijenta. |
| F16 | Jedna read greška uklanja mapu; retry menja oblik greške, HALF zaklanja veliku poruku | R02 | R11, R11e native regression | Odvojiti dostupnu listu od MAP/PLACES/native-style greške i specificirati prvi read, retry bez snapshot-a i parcialni uspeh. Za HALF/FULL/PEEK panel nacrtati/stilizovati error i CTA unutar dostupne visine i navigacionih insets. |
| F17 | Trenutna legacy dijagnostika prikazuje boolean „true” | R02 | — | Sačuvati bezbedan tip razloga greške od data vlasnika do UI-ja i mapirati ga na razumljivu radnju; interne detalje ostaviti u dijagnostici. |
| F18 | Prefilter, saved-area i TODAY vreme mogu izgubiti dozvoljenog kandidata | R05 | R11, R12 | Uskladiti candidate_profile_ids/v1b, dispatch konfiguraciju, area-fit i time-tier. Retrieval mora biti nadskup stvarno podobnih radnika; koristiti potpisano područje, ne stari jedan profilni pin. Za STATIONARY/POINT_TO_POINT/MULTI_STOP/AREA_BASED eksplicitno zaključati koji postojeći topološki predicate važi. |
| F19 | `workAreas` nedostaje current export i arhivskom projektoru | R10 | — | Pratiti workAreas i izvedene/private/archive kopije kroz oba export sloja, consent revocation i closure projection. Dodati minimalne postojeće adaptere/kolone, ne vraćati ceo stari WAR01 kandidat. |
| F20 | Kapacitet push reda, suppression i exact-target ugovor | R09 | R12 | Usaglasiti push-only target resolver bez IN_APP zavisnosti, emit/writer za stvarne event tipove i isključivanje već prijavljenog radnika iste revizije iz prve opportunity ponude. Kapacitet meriti stvarnim scheduler claim/send/receipt ciklusom, ne batch deklaracijom. |
| F21 | Authenticated table SELECT poništava granicu tri privatne Need kolone | R01 | — | Novom uskom migracijom ukloniti konflikt širokog table SELECT i eksplicitnih public projekcija/privatnih kolona. Pre toga popisati invoker/owner read korisnike i closure binding; ne menjati ACL naslepo. |
| SB01 | Početna | R11a | — | Uvesti/vezati razlikovan public opportunity target za karticu moje prijave; povezati ga na postojeću /prilike/[id] rutu. |
| SB02 | Ocene | R11b | — | Invalidirati datu ocenu posle potvrđenog upisa i obnoviti prvu stranu primljenih ocena na definisan povratak, uz scope/revision ključeve. |
| SB03 | Pravila | R10 | — | Autoritativno završiti/otkazati staru consent operaciju pre prihvatanja novog TERMS/PRIVACY hash-a; obezbediti izlaz iz READ_REQUIRED stanja i eksplicitan nov pristanak. |
| SB04 | Glasovne poruke | R11c | — | ABSENT posle pokušaja ne zaboraviti pre server cancel/reconcile; izložiti PROCESSING/STAGED oporavak i uskladiti jedan deadline/abort owner. |
| SB05 | Avatar | R11c | — | Definisati avatar-specifičan reconcile/cancel starog upload-a i osloboditi novu selekciju tek posle tačnog završetka; ne kopirati conversation-only task photo API. |
| SB06 | Podrška | R11d | — | Razdvojiti neposlat nacrt od poslate durable komande; očuvati nacrt istog account/context/revision pri običnom background/povratku i upozoriti pri namernom izlasku. |
| SB07 | Izmena Dogovora | R11d | — | Vezati neposlat razlog/predlog za account, agreement i version; očuvati i ponovo proveriti review. Start-only podršku zaključiti i provesti kroz model/writer/read/UI, ne samo oslabiti validProposal. |
| SB08 | Obaveštenja | R09 | — | Ili vezati postojeći atomski autoritet za oba role scope-a ili trajno pročitati oba ishoda i nastaviti samo nedostajući; Back mora uzeti writing/unknown u obzir. |
| SB09 | Javni komentar | R11b | — | Odrediti podržan javni put do komentara, vezati postojeći read/service/UI ili uskladiti obećanje sa stvarnim proizvodnim pravilom. Test sopstvenog profila koji ne šalje comments props ne dokazuje ceo javni tok. |
| SB10 | Osvežavanje poruka | R09 | — | Prikazati refresh kao stvarnu dostupnu radnju ili ukloniti montiranu fokusabilnu kontrolu uz očuvanu dostupnu alternativu. |
| SB11 | Discovery recovery/keš | R02 | R11, R11a regression | Finalize placePaging/controller i kod decode izuzetka; loaded recent account označiti tek nakon prihvaćenog read-a ili dati ponovljiv fallback; fit ključ mora uključiti sva relevantna revision/mode/pin/end polja. |
| SB12 | Vremenska zona | R11e | R05 | Povezati jedan eksplicitan policy prikaza/izmene ugovorenog vremena; označiti relevantnu zonu i čuvati UTC instant. Testirati drugim TZ okruženjem, jer sadašnji Jest setup UTC prikriva razliku. |
| SB13 | Map/motion detalji | R11e | R02, R08, R12 | Razdvojiti style/raster readiness od funkcionalnog SVG pin/drag gde vlasnik to dozvoljava; uskladiti Nearby copy/camera, panel insets, blur draft i reduced-motion lifecycle. Odluku o uklanjanju rastera doneti tek nakon native drag dokaza. |
| SB14 | Proof build/validator | R11g | R12 | Uskladiti namenski proof build sa plugin/patch zahtevom i current repo/workflow; svako dokazno izvršenje vezati za runId/source/input/checks. Osvežiti samo pogođene istorijske harness-e i stroge završne uslove. |
| SB15 | Fotografija bez teksta | R11c | R06 | Definisati jedan kanonski payload za claim i complete uključujući photo-only tekst i attachment identity; primeniti ga na obe strane bez isključivanja hash provere. |
| X01 | Safety ključ | R11c | — | Za nevalidan lokalni identitet obezbediti konkretnu kontrolisanu obnovu sa proverom/objašnjenjem i čišćenjem samo korumpiranog lokalnog zapisa; za validan unknown zadržati server reconciliation. |
| X02 | Dva imena | R11d | — | Naći jedan postojeći autoritet ili uvesti usku trajnu/revision-aware koordinaciju dve stvarne promene, tako da se posle mount-a prepozna i razreši delimičan ishod. |
| X03 | Decoder/receipt | R11f | — | Na servisnoj granici validirati finite vrednosti i sva polja potvrđenog receipt-a; klijentskim potrošačima garantovati jedinstven tačan tip. |
| X04 | Konfiguracija | R11f | — | Povezati sve read/stream/resolver potrošače na jedan eksplicitni config owner sa istim permitted fallback/required-env pravilom i proverom build-a. |
| X05 | Demo reset | R11h | — | Izolovati početni fixture i pri reset-u obnoviti sve mutable kandidate i povezane kolekcije. |
| X06 | Stari toast | R11c | — | Proveriti account+revision neposredno pre objave potvrđenog toast-a, u postojećem lifecycle owner-u. |

**Sačuvane korekcije nalaza:** F14 ne vraća povučenu sumnju o samostalnoj promeni `priceBasis`; ostaje poreklo source/live i reproduktivnost. SB/X opisi su preuzeti sa svojim ranijim dokaznim ograničenjima, a ne ponovljeni runtime nalazi. F21 zahteva proveru stvarne kolonske granice bez tvrdnje da je dokazana eksfiltracija. F16 uređajski problem zahteva isti scenario na novom kandidatu, a ne pretpostavku iz novijeg source-a.

### 4.2. Izvršni redosled i zavisnosti

R12 počinje da prikuplja integracione i uređajske dokaze od prve završene vertikale. Njegov konačni release presek dolazi posle relevantnih završenih zadataka. UI/UX prati promenu stanja i ponašanja; ne ostavlja se kao nepovezano završno ukrašavanje.

| Zadatak | Zavisnost i predmet | Pregledljiv rezultat / uslov izlaza |
|---|---|---|
| R01 — privatnost čitanja, verzije i ugovori | Početak: F21 i aktuelni repo/Edge/SQL/klijenti | Obnovljena javna kolonska granica sa pozitivnim/negativnim dokazom; tabela stvarnih ugovora i tačnih vlasnika; očuvani kompatibilni čitači. |
| R02 — Discovery i poruka greške | R01; F15/F16/F17 | PAGE/MAP/PLACES/filteri i odvojeno stanje liste/podloge/pinova; reprodukovana oba screenshot stanja zatvorena stvarnim decoder-om i uređajem. |
| R03 — sopstveni zadaci | R01; F01 | Pet scope-ova, svi counts i pravi item format; prazna i neprazna prva strana, nastavak i dozvole. |
| R04 — identitet i kompletan rezultat AI-ja | R01; F04/F05/F06/F08 | Pun katalog, reuse/nova grana, stabilna semantika i kompletan očekivani BOTH; prava revizija/signed review/Save/binder, uključujući ranije pripremljen review i replay. |
| R05 — područje, vreme i izbor | R04 signed ugovor očuvan; F18 | Zajednički area/topology/TODAY ugovor i početni izbor bez izgubljenog kandidata; Za mene/dispatch parity i nepromenjena ručna prijava. |
| R06 — tehnički nastavak i obračun | R04; F06/F07 | Postojeći posao ima durable identitet, bounded pokušaje, receipt/readback i zaseban provider usage; prekid ne traži ponovno objašnjavanje iste usluge. |
| R07 — cena i neizvesni dodatni upisi | R01; R07a postojeći domen, R07b širi cenovni ugovor; F02/F03/F11/F13 | Korekcija ne čeka novu valutu; stvarna jedinica ostaje, isti abandon ima pravi readback, dodatni upis čuva paralelnu izmenu. |
| R08 — završetak razgovora i prikaz | R04 i relevantni deo R07; F09/F10/F12 | Jedno potrebno pitanje, autoritativan završetak, jedan pregled, veran sačuvan rezultat po usluzi; bez obaveznih suvišnih formi. |
| R09 — obaveštenja i poruke | R01/R05; F20, SB08/SB10 | Dovoljan ograničen rad reda, isti-key bez duplog slanja, suppression već prijavljene osobe, validan tačan cilj pri oba nezavisna preference izbora. |
| R10 — život podataka i privatnost | R04; F19, SB03, current export/closure vlasnici | workAreas u svim projekcijama, važeći consent replay, proverene sve kopije i autorizacija; gates ostaju zatvoreni dok ceo dokaz nije validan. |
| R11 — ostatak ekrana i usko povlačenje | Po odgovarajućim owner zavisnostima; SB/X | Svi pojedinačni backlog problemi imaju proveru; aktivne module sa istorijskim delovima ne brisati u celini. |
| R12 — stvarna celina i release presek | Prethodni relevantni zadaci | Dve uloge/nalozi, realan model i telefon, prekidi i pristupačnost, poznat deploy/OTA, merene latencije/trošak i izričiti DEV/production izlaz. |

R02 i R03 mogu se raditi paralelno nakon usklađenog R01 ugovora; nezavisni klijentski nacrti/ocene mogu napredovati paralelno sa AI radom. Promene istog review/matching/export vlasnika usklađivati sekvencijalno da jedna grana ne izgubi tuđu zaštitu. Veći cleanup ide posle popravljene aktivne veze, uz caller/kompatibilnost dokaz. SB14, provera samog proverivača, prati svaki zadatak od početka.

### 4.3. Jedinica rada i kriterijum izlaza

Svaki korak ima korisnički ishod, postojeći vlasnički put, najmanju povezanu promenu, relevantnu pozitivnu i negativnu kontrolu, potreban UI prikaz i stvarni readback. Zasebno označiti definiciju, nacrt, implementaciju i dokaz. Rad na istom review/matching/export vlasniku uskladiti sekvencijalno; nezavisne površine mogu se raditi paralelno.

Ne tražiti ponovo puni audit ili nove spekulativne arhitekture kada postoji konkretan potvrđeni uzrok. Kada određeni dokaz ili poslovna odluka nedostaje, označiti pogođeni korak i nastaviti nezavisni posao. Širi cleanup sledi popravljenu aktivnu vezu i dokaz potrošača. SB14, proveravanje samog proverivača, prati sve zadatke.

## 5. Vlasništvo nad stanjem i očuvani ugovori

Ovaj odeljak prenosi konkretne ugovore iz dostupne tehničke reference. Linijski brojevi služe nalaženju polazišta na analiziranom izvoru; posle izmene nisu trajna adresa. Serverski metapodaci pripadaju rev7 pregledu i zahtevaju relevantno osveženje pre promene. Detaljni zadaci koji slede koriste ove vlasnike umesto pravljenja paralelnih writera.

### Naručilac

| Stanje/radnja | Merodavni vlasnik | Tačno značenje |
|---|---|---|
| Razgovor i identitet pokušaja | `src/app/(app)/nova.tsx:50–325`; `src/data/aiTurnIntentJournal.ts:4–37` | Prvi send otvara razgovor stabilnim ključem. Journal čuva identifikatore, ne privatni body. PROCESSING, retry i unknown imaju različite dozvoljene nastavke. |
| Generacija i nalog | `src/hooks/useOwnedEditor.ts:27–119`; `src/app/(app)/nova.tsx:34–42,112–118,217–224` | Kasni callback ne stiče ovlašćenje ponovnim povratkom na isti account ID; bitni su i revision/fokus/generacija. |
| Spremnost završne kartice | `src/ui/v2/draftSummary.ts:52–66`; `src/ui/v2/IntakePresentation.tsx:381–399,476–477,511–517`; `src/contracts/needFactsV2.ts:16–19,67–69` | Potpun predlog, mesto/tačke i blokade odlučuju prikaz. Tekstualni `need.category` je obavezan, a skriva se iz korisničke liste nedostajućih činjenica. Nedostatak tog teksta može sakriti karticu bez jasnog sledećeg koraka. Kartica ne čeka neposredno canonical `category_id` niti opšti classification READY. Sistem treba da dovrši svoj podatak. |
| Ulaz u pregled | `src/app/(app)/nova.tsx:539,558–567`; `src/data/aiTaskReviewClientService.ts:354–369` | `canReview` je blaži od uslova završne kartice. Prepare upisuje zamrznuti review; još ne prihvata i ne objavljuje Need. Neposlat tekst ne postaje deo pregleda. |
| Prihvat/privatni nacrt/objava | `src/app/(app)/pregled-zadatka.tsx:119–340`; `src/data/aiTaskReviewClientService.ts:127–268,297–405` | `canAccept`, classificationState i geografska spremnost su odvojeni. SaveDraft prihvata bez automatskog evaluate/publish. PUBLISHED receipt traži readback istog Need-a/revizije pre završnog uspeha. |
| Razgovorna mapa | `src/ui/location/ConversationPointAsk.tsx:165–224` | Potvrda svakog pina odmah ide na server uz očekivanu reviziju; START može biti sačuvan dok END još nedostaje. |
| Mapa u pregledu | `src/ui/location/NeedLocationForm.tsx:63–104,139–145`; `src/app/(app)/pregled-zadatka.tsx:302–316` | Pojedinačna potvrda je lokalna; „Primeni potvrđene tačke” priprema novi review. Povratak bez primene ne znači sačuvan skup. Ta dva map toka ne mogu se zameniti bez očuvanja ovog značenja. |

Nema parcijalnih kartica u aktivnom razgovoru: to je postojeće route pravilo. Direktni test ili designLab scene sa karticom ne menjaju taj ugovor. Sačuvan neposlat tekst pri Back/refocus odnosi se na zadržanu montiranu rutu; nije obećanje da svaki znak preživljava gašenje procesa. [P01, P06]

Deadline prepare proširenje ostaje uslovna kompatibilnost: `src/data/aiTaskReviewClientService.ts:352,359–362` bira posebne `rpc_prepare_ai_task_review_deadline` / `rpc_prepare_ai_task_review_deadline_taxonomy` samo kada je javni build flag doslovno `true`. Read-only provera iz rev7 nije našla ta dva RPC-a, a pregledani tracked build/config i audit runtime nisu pokazali uključenu opciju. To je gate pre budućeg uključivanja, ne dokaz da običan sadašnji prepare endpoint nedostaje; efektivni flag starog APK/OTA nije time očitan. [P04, P06]

### Izvršilac

| Stanje/radnja | Merodavni vlasnik | Tačno značenje |
|---|---|---|
| Tema i ispravka | `src/app/(app)/profil/razgovor.tsx:32–52,212–225,359–363,411–424` | Promena teme sama ne šalje poruku i ne pravi novi razgovor. Ispravka vraća u isti razgovor. |
| Turn/readback | Ista ruta `:96–126,170–189,227–247`; `src/data/workerAiClientService.ts` | Stabilan identitet, readback i zaštita novijeg neposlatog unosa od kasnog odgovora. |
| Priprema i Save | Ruta `:249–292,354–379`; `src/data/workerAiClientService.ts:307–311` | Svež review iste revizije + canAccept + eksplicitni Save + saved receipt. DRAFT može odmah izabrati Save+activate; nije obavezan prethodni zaseban DRAFT Save. |
| `activate=false` | `src/data/workerAiClientService.ts:220–225` | Čuvanje bez zahteva za aktivacijom; ne deaktivira već ACTIVE profil. Zato ACTIVE rezultat u tom slučaju nije sam po sebi greška. |
| Classification READY | `src/data/workerAiClientService.ts:134–198`; `src/ui/workerProfile/WorkerAiPresentation.tsx:154–183` | Kandidati i mode parovi su pripremljeni za review. To još nije Save, admission, binding ili matching autoritet. |
| Pending nova usluga | Review + outbox/binding sloj | Nova promena ne dobija autoritet unapred. Nije automatski dokaz da sve ranije potvrđene usluge prestaju da rade. |
| Područja | `src/contracts/workerAreas.ts:1–33`; worker Edge `:202–203,503–515` | Do pet CITY/RADIUS ili jedno COUNTRY područje. RADIUS zahteva eksplicitnu kilometražu od centra mesta. `areaRequests` se razrešava na serveru; nezavisna jasna izmena ne treba da nestane zbog neuspešnog geokodiranja. |

### Semantički i trajni autoritet

Predlog modela i capture imaju `authority:NONE`. Za postojeći posao koristi se stvarni ID iz kataloga; za novu kategoriju SQL writer pravi zapis i vraća ID preko `INSERT … RETURNING`, a model ne izmišlja trajni UUID. Potpisani review, korisnički Save/Accept, admission receipt i reviziono vezivanje imaju različite uloge. Zadržati account/revision/digest ograde, idempotentnost, zaštitu od kasnog odgovora i odvojenu saglasnost za način rada. Relevantni vlasnici su `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql:717–1021,1024–1317,1318–1471`, `supabase/functions/_shared/taxonomyPostSaveWorker.mjs:25–76` i oba signed review klijenta. [P04, N04, N05]

### Tekuće serverske granice koje treba sačuvati i dovršiti

**Pristup i sesija.** Analiza rev7 ponovo potvrđuje F21. Široki table SELECT nad needs ne poništavaju uži column grantovi; row policy i column/table grant imaju različite uloge. Dve rls_private funkcije — `need_participant_can_read(uuid)` i `p6_discovery_test_world_accounts()` — potrebne su za sadašnje politike, sa authenticated USAGE/EXECUTE i bez anon/service pristupa. Private šema nema običan anon/auth table pristup. Authenticator `pgrst.db_pre_request=public.rpc_closure_api_guard` je potvrđen u rev7 pregledu; taj hook se odnosi na Data API, ne automatski na Storage/Realtime. Efektivan hook nije dokaz završene erasure mogućnosti.

**Prava za sužavanje.** Postgres/public default ACL automatski daje široke table/function/sequence grantove. Od public tabela, 17 ima bar jednu anon, a 19 bar jednu authenticated TRUNCATE/TRIGGER/REFERENCES dozvolu. Ovo nije dokaz udaljenog SQL/DDL execution puta ili demonstriranog napada. Urediti i budući default i konkretne postojeće grantove, sa namerno javnim `rpc_get_legal_bundle()` i potrebnim authenticated ulazima. Kod legacy delete-a postoje PUBLIC i role EXECUTE; samo anon revoke ne zatvara PUBLIC grant.

**Auth i PHONE.** Advisor iz rev7 pregleda navodi disabled leaked-password zaštitu; sadašnji password tok je čini relevantnom. JWT/session rotation/MFA/signup/provider/redirect/SMTP/rate-limit management vrednosti nisu ustanovljene. Pročitani `rpc_set_contact_grant`, `rpc_reveal_contact` i `grant_is_ownable` još imaju PHONE put. Zatvoriti novu PHONE saglasnost/reveal prema „Samo poruke”, uz istorijsku revokaciju i receipt kompatibilnost. EXACT_LOCATION, phone OTP prijava i slobodan tekst poruke su različiti ugovori.

**Storage.** Sva tri bucketa su private: profile-media 5 MiB, agreement-voice 4 MiB i data-export-artifacts 8 MiB, sa pregledanim MIME ograničenjima. Owner-prefix politike, restrictive v5/voice zabrane, account-open granica i Edge/SQL vlasništvo deluju zajedno. Čuvaju se immutable server putanja, hash/veličina, generation/lease, jednom priznata dispatch namera i pozitivan readback; unknown upload nije dovoljan razlog za drugi POST ili brisanje journal-a. SB04/SB05 ostaju ciljane klijentske popravke oporavka.

**Realtime.** Aplikacijska publikacija sadrži `agreement_invalidations_v1(agreement_id,revision)`; sedam ostalih stavki su servisne realtime particije. Pročitani policy i potrošači `agreementInvalidationService.ts`, `useAgreementIncomingRefresh.ts`, `useConversationInbox.ts` koriste Postgres Changes kao hint za autoritativno ponovno čitanje, sa account/focus/session ogradama. Hint nije poruka ni ovlašćenje za mark-read. Group event/refresh ostaje odvojen nedovršen posao; odsustvo private Broadcast politike nije automatski greška ovog toka.

**Zatvoreni lifecycle.** Safe config/digest upit iz rev7 daje false za retention source, export binding i closure erasure binding. Čuvaju se exact snapshot, owned download, authorization pre vraćanja bajtova, nezavisna potvrda Storage/Auth operacije i finalizacija tek po važećim rezultatima. Šest DEV tabela bez PK ostaje u sadašnjim lifecycle zavisnostima. Popraviti projektore/kopije/inventare i dokazati važeći binding; ne podizati feature gate ili menjati očekivani digest radi prolaza. Z12/Z14/Z16 su istorijski identifikatori dodatne podloge; njihovi zasebni fajlovi nisu u prilozima. Dostupni vlasnici i uslovi uneti su u ovaj plan.

## 6. Izvršni zadaci R01–R12

Svi zadaci su deo istog plana. Status opisanog koda i starih testova nije novo izvršavanje ove revizije. Pre izmene potvrditi konkretan aktuelni sadržaj i relevantni deployment; posle izmene upisati stvarni rezultat u odeljak 11. Tačno pročitane zajedničke CI komande su u odeljku 8.3. Originalne predložene per-R komande iz nedostajućeg Z09 nisu rekonstruisane po pretpostavci.

### R01 — Privatnost čitanja, stvarne dozvole i isporučeni ugovor

#### Problem, cilj i granica dokaza

**Ulazni nalazi: F21 i identitet isporuke iz F14.** Analizirani DEV presek ima `authenticated` table-level `SELECT` nad `public.needs`. Taj širi grant poništava nameru ranijeg javnog kolonskog skupa: na redovima koje RLS dopušta mogu se tražiti i `requester_account_id`, `remaining_search_closed_by_account_id` i `remaining_search_close_reason`. Uži kolonski grantovi ne oduzimaju pravo dobijeno nad celom tabelom. Bezbedna projekcija u `rpc_read_task` ne štiti zaseban direktni table API.

Dokumentovani put odnosi se na ne-vlasnikov PUBLISHED/SELECTION red u istom TEST/REAL svetu, uz otvoren nalog pozivaoca. `needs_public_discovery` i restrictive `v5_closed_account_visibility` imaju različite uloge. Primer privatnog razloga jeste SELECTION sa zatvorenom preostalom pretragom. ACTIVE i istorijski nejavni redovi proveravaju se po svojim owner/participant politikama. Prethodni audit nije čitao stvarne tuđe poslovne redove i nije dokazao anonimnu, cross-world ili stvarnu eksfiltraciju; ovu promenu treba dokazati sintetičkim nalozima.

**Cilj:** javno čitanje otkriva samo nameravani javni skup; dozvoljeni sopstveni i participant prikazi nastavljaju da rade. Paralelno nastaje tačna tabela trenutno podržanih klijent/server ugovora za naredne zadatke. Ovde navedene popravke i provere tek treba izvršiti.

#### Postojeći vlasnici i konkretni ulazi

| Vlasnik | Uloga u promeni |
|---|---|
| `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql` | Dokumentovani izvor ponovo dodatog table SELECT-a, red 6; širi `service_role` grant nad javnim rutinama na redu 12 proverava se zasebno. Primenjeni fajl se ne prepravlja kao zamena za novu migraciju. |
| `public.needs`, `needs_public_discovery`, `v5_closed_account_visibility` | Stvarna table/column prava, vidljivost po svetu i zatvorenom nalogu. Pregledati sve sadašnje politike i efektivna prava, uključujući nasleđivanje. |
| `rls_private.need_participant_can_read(uuid)`, `rls_private.p6_discovery_test_world_accounts()` | Pomoćnici sadašnjih politika. Analizirani ugovor ima authenticated USAGE/EXECUTE; ne uklanjati potrebna prava zajedno sa preširokim javnim pristupom. |
| `public.rpc_closure_api_guard`, authenticator `pgrst.db_pre_request` | Potvrđeni Data API hook; ne pretpostaviti da isti hook sam štiti Storage i Realtime. |
| `rpc_read_task`, `rpc_list_my_tasks`, `rpc_list_my_needs_page`, `rpc_discovery_v1` i njihovi invoker/helper lanci | Čitači kojima treba očuvati dozvoljeni javni ili sopstveni rezultat. |
| `src/data/needClientService.ts`, `src/data/ownTasksPage.ts`, `src/data/discoveryV1ClientTransport.ts`, `src/data/supabaseIzvor.ts` | Stvarni klijentski potrošači odgovora. Proveriti pozive i projekcije pre izmene prava. |
| `rpc_close_remaining_search` | Ostaje owner-authorized radnja sa postojećim Dogovorom i delimično izabranim kapacitetom; čuvati prihvaćene statuse PUBLISHED/SELECTION/ACTIVE i upis razloga/actor-a/vremena bez proizvoljne promene statusa. |
| Sadašnji closure schema/source/certificate vlasnici | Promena dozvola može uticati na njihove dokaze. Obnoviti dokaz sadržajno; ne menjati očekivani digest radi prolaza. |

#### Redosled rada i očuvane granice

1. Osvežiti branch/HEAD, stvarna tela i ACL relevantnih funkcija, sve `needs` politike, invoker čitače i owner helpere. Razlikovati zabeleženu primenu migracije, rekonstrukciju statements, bajtnu jednakost izvora i sadašnje efektivno pravo. Identitet u ledger-u sam ne dokazuje poslednji sadržaj funkcije ili grant-a.
2. Napraviti jednu eksplicitnu javnu kolonsku/projekcionu granicu i tačan dozvoljeni put do sopstvenih privatnih podataka. Pripremiti usku novu migraciju; ne izvršavati slepi REVOKE, stari PKG045b ili ceo P6 replayer. Promena mora očuvati RLS svet, vlasništvo, postojeće privatne šeme i closure uslove.
3. Proveriti postojeća i buduća prava. Analizirani default ACL daje široke table/function/sequence grantove; 17 public tabela ima bar jednu anon, a 19 bar jednu authenticated TRUNCATE/TRIGGER/REFERENCES dozvolu. To nije demonstriran udaljeni SQL/DDL napad, ali zahteva namerno sužavanje gde pravo nema potrošača. Sačuvati namerno javni `rpc_get_legal_bundle()` i potrebne authenticated ulaze. PUBLIC EXECUTE proveravati odvojeno: samo anon revoke ne zatvara PUBLIC pravo.
4. Proveriti `service_role` proširenja po funkciji. Dodat service grant nije sam po sebi dokaz javnog anon/auth pristupa; stari strogi ACL pinovi ipak mogu više ne odgovarati. Uskladiti verifikatore sa stvarnim dozvoljenim ugovorom, bez slabljenja poslovnog guard-a.
5. Pre isporuke utvrditi minimalnu bezbednu podržanu verziju klijenta. Privatnost se ne odlaže zato što stari klijent zahteva preširok grant. Postojeći native i OTA klijenti dobijaju jasnu kompatibilnost ili bezbedan kontrolisan izlaz; UI skrivanje nije zaštita.
6. Sa R10/R11 koordinisati zatvaranje starih PHONE metoda i grantova prema pravilu „Samo poruke”, uz očuvan EXACT_LOCATION. `rpc_set_contact_grant`, `rpc_reveal_contact` i `grant_is_ownable` imaju dokumentovani PHONE put. Phone OTP prijava i slobodan tekst poruke nisu ista funkcija i ne povlače se tom promenom.
7. Auth management konfiguraciju proveriti podržanim pristupom. Leaked-password zaštita u analiziranom preseku nije uključena i relevantna je za postojeći password tok; JWT/session rotation/MFA/signup/provider/redirect/SMTP/rate-limit vrednosti nisu potvrđene. Nedostupnu vrednost označiti kao nepoznatu, bez pretpostavke da je sigurna ili neispravna.

R01 prikuplja stvarnu kombinaciju izvora, SQL-a, Edge-a, zastavica i podržanog klijenta. About ekran pokazuje deklarisanu izvornu oznaku, ne hash celog APK-a ili ekstrahovani OTA JavaScript. Broj verzije i zeleni CI nisu dovoljan dokaz istovetne isporuke. Bezbedne metapodatke zabeležiti; tajne i privatne payload-e ne kopirati u dokaz.

#### Prihvatni dokaz

Minimalni izvršni skup koristi dva sintetička naloga istog sveta i zadatak drugog naloga u PUBLISHED/SELECTION, uključujući privatni razlog zatvorene pretrage. Kroz stvarni Auth/Data API proveriti direktni select, alias, filter, order i wildcard za sva tri privatna polja, kao i normalne javne i sopstvene readere. Proba treba da pokaže i zabranu nedozvoljenog polja i uspeh stvarno dozvoljenog sadržaja; potpuno ugašen API nije uspešna popravka.

Negativne kontrole obuhvataju drugi svet, anoniman ili zatvoren nalog, pogrešnu/isteklu sesiju i nedozvoljen participant pristup. Legitimni vlasnik dobija svoj dozvoljeni prikaz. Proveriti posledice na closure binding, RLS helpere i novu sintetičku tabelu/funkciju koju više ne smeju automatski otvoriti nepoželjni default grantovi.

| Postojeća testna putanja | Šta sačuvati ili dopuniti | Granica postojećeg dokaza |
|---|---|---|
| `supabase/proofs/discovery/p6_http_boundary.mjs` | Rebase na sadašnje vlasnike; kroz lokalni Auth/PostgREST pokriti sva tri polja i sve relevantne oblike čitanja. | Istorijski test je pokrivao direktni requester ID, ne ceo sadašnji skup. |
| `supabase/proofs/discovery/p6_world_boundary_proof.mjs` | Sačuvati SQL role/RLS i javni whitelist; dodati zatvorenog viewer-a i povezati sa HTTP granicom. | Istorijski SQL test svih tri granta nije novi Auth/HTTP prolaz. |
| `src/data/__tests__/build-identity.test.tsx` | Sačuvati dozvoljena javna identity polja i embedded/OTA prikaz. | Ne potvrđuje koji je APK/OTA stvarno instaliran niti da je kompatibilan sa živim SQL-om. |

**Izlaz:** proverena privatnosna migracija, očuvani legitimni čitači, tačni podržani ugovori i izvršen pozitivan/negativan dokaz. F21 ostaje otvoren dok se zabrana ne dokaže na stvarnoj autorizacionoj granici.

### R02 — Discovery, mapa, filteri i istinito stanje greške

#### Problem i cilj

**Ulazni nalazi: F15–F17 i SB11; kompatibilnost cene iz F02.** P6 izvor povezan sa dostavljenim telefonskim prikazom pokreće onsite PAGE pa world-seed MAP, čak i kada PAGE nema redove. Dokumentovani `rpc_discovery_v1` prihvata PAGE i EXACT_PUBLIC, odbija MAP/PLACES sa `P6_MODE_NOT_IMPLEMENTED`/22023 i nema opcione `forMe`/`minBudgetRsd` ključeve u filter whitelist-u. Agregirani logovi potvrđuju nepodržani režim, ali bez request ID-a ne pripadaju dokazano jednom konkretnom telefonu.

Istovremeno jedna MAP greška preliva se u globalni error, uklanja native map renderer i može sakriti 50 uspešno učitanih PAGE redova. Početni neuspeh i Retry stvaraju različite oblike ekrana jer prvi ne commit-uje snapshot, a Retry ga kroz execute/finally/commit objavljuje i pri neuspehu. Na ograničenom HALF panelu nastaje veliki error blok delimično prekriven donjom navigacijom. Nova legacy dijagnostika ima odvojen kvar: boolean error pretvara u tekst `true`.

**Cilj:** svaka ponuđena mogućnost liste, mape, mesta i filtera radi sa stvarnim serverom. Delimičan neuspeh ne ukida upotrebljiv rezultat. Korisnik vidi tačno šta je uspelo, šta nije i koju radnju može bezbedno da ponovi.

#### Vlasnici

| Sloj | Pune putanje i simboli |
|---|---|
| Ruta i ugovor | `src/app/(app)/zadaci.tsx`; `src/data/discoveryV1Contract.ts`; `src/data/discoveryV1MarketplaceAdapter.ts`; `src/data/discoveryV1ScreenSession.ts`; `src/data/discoveryV1Owner.ts`; `src/data/discoveryV1ClientTransport.ts`. |
| Pretraga, recent i fit | `src/data/discoveryV1SearchOwner.ts`; `src/ui/v2/discovery/recentSearches.ts`; `src/ui/v2/detail/useTaskFit.ts`. |
| Prikaz i geometrija | `src/ui/v2/discovery/DiscoveryV1Screen.tsx`; `src/ui/v2/DiscoveryPresentation.tsx`; `src/ui/v2/discovery/DiscoveryListState.tsx`; `src/ui/v2/discovery/DiscoveryListSheet.tsx`; `src/ui/system/StateView.tsx`; `src/ui/v2/discovery/mapControls.ts`; `src/app/(app)/_layout.tsx`. |
| Legacy čitanje i greška | `src/data/supabaseIzvor.ts`; `src/data/focusedResource.ts`; postojeći potrošači `DiscoveryPresentation`. |
| Server | `public.rpc_discovery_v1`; odvojeni legacy `public.rpc_list_open_tasks_v3`; `supabase/migrations/20261025000000_baseline_core_client_rpcs.sql`, posebno discovery telo na redovima 71–236 analiziranog izvora. |

#### Redosled popravke ugovora

1. Posle R01 potvrditi aktivnu putanju, deklarisane i efektivne zastavice podržanih klijenata, request/response ugovor i stvarno migrirano telo. Analizirani stari preview/production izvor uključuje P6, sadašnji EAS P6 flag je 0; efektivni OTA bundle nije ekstrahovan. Ne izjednačiti promenu zastavice sa popravljenim P6 proizvodom.
2. Uskladiti PAGE/MAP/PLACES/EXACT_PUBLIC sa mogućnostima koje izdanje stvarno nudi. Obuhvatiti filter whitelist, `forMe`, `minBudgetRsd`, cursor, page ordering, map seed/viewport, exact landing i account/world/revision granice. Ne primenjivati stari kandidat ili menjati privilegije da bi se zaobišao nepodržani režim.
3. Proveriti starog podržanog i ciljnog novog klijenta protiv iste nameravane serverske isporuke. Stari decoder prihvata TOTAL/PER_PERSON/null, ali odbija HOURLY; jedna takva stavka ruši celu PAGE poruku. Novi decoder prihvata HOURLY. Izabrati eksplicitnu strategiju kompatibilnosti, bez prećutnog izbacivanja reda, filtera ili promene satnice u ukupnu cenu. U dostavljenim dokazima nije čitan sadržaj korisnikovih živih zadataka, pa HOURLY nije potvrđen uzrok prikazanog kvara.
4. REMOTE prikaz ne šalje fizički MAP zahtev koji nema korisnički smisao. Handoff/predaja je odvojen potvrđeni podatak. Ne izmišljati fizičku geografiju da bi se zadovoljio stari endpoint.
5. Sačuvati otkazivanje, trenutni upit i njegovu generaciju. Zastareo odgovor ne sme zameniti nov filter, lokaciju, nalog ili tekst pretrage. Tačan razlog odbijanja i tačan identitet pokušaja moraju preživeti put od transporta do potrebne dijagnostike.

| Grana kompatibilnosti | Obavezna provera starog podržanog i novog klijenta |
|---|---|
| PAGE/MAP/PLACES/EXACT_PUBLIC | Prazno/neprazno, nastavak, mapiranje, tačan javni rezultat i opravdano odbijanje; stvarni izlaz prolazi odgovarajući pravi decoder. |
| `forMe` i minimalni budžet | Server prihvata definisani oblik; UI i adapter ne šalju ili tiho uklanjaju drugačije ključeve. |
| HOURLY i mešovita strana | Eksplicitno rešena podrška ceni i celoj poruci; neusaglašen format ne postaje neobjašnjeni gubitak svih redova. |
| REMOTE | Nema nepotrebnog fizičkog MAP zahteva; sačuvano značenje usluge i zasebne predaje. |
| Exact javno odredište | Autoritativan cilj van prve strane i van početnog viewport-a ostaje dostupan samo dozvoljenoj public projekciji. |

#### Legacy put ostaje zasebno proverena mogućnost

`zadaci.tsx` preko `supabaseIzvor.ts` u analiziranom legacy toku čita celu otvorenu kolekciju u stranicama od 200, najviše 25 strana, sa ukupnim route rokom 15 sekundi, `p_bbox=null` i `p_filters={}`. Jedna nevažeća stavka ili neuspešna strana može odbiti celu kolekciju. Opcioni profil/urgency enrichment ima zasebno degradiranje i nije dokazano uzrok greške. P6 „Za mene” se ovim putem ne dobija.

Zato flag 0 nije kompatibilna zamena za sve P6 funkcije ili skaliranje. Ako legacy put ostaje podržan, njegov obim, degradiranje, dijagnostika i granice opterećenja moraju biti jasni. Ako se povlači, prvo se dokazuje ciljni ugovor i proveravaju podržani stari potrošači.

#### Prikaz stanja, geometrija i oporavak

Razdvojiti najmanje PAGE/listu, native podlogu, MAP/pinove, PLACES i preview/tačan cilj. Svaka operacija ima svoj loading/success/failure i dozvoljeni Retry. Još važeće podatke zadržati uz jasan status; rezultat prethodnog filtera ne prikazivati kao odgovor novog upita. Prazan uspešan rezultat nije failure, a neuspešno čitanje nije dokaz nule zadataka.

Dokumentovani `mapShown = where !== 'remote' && !loading && !error` koristi isti globalni error da ukloni mapu i da kroz `compact=false` izabere preveliku poruku. Popraviti tu vezu kod odgovarajućeg vlasnika. Ne menjati globalni `StateView` svim potrošačima bez procene. Veliki blok ima ilustraciju 96 i veće razmake, compact 48 i manje razmake; izbor mora odgovarati stvarnom raspoloživom panelu, ne samo tome da li je renderer trenutno montiran.

HALF je početno loading/error stanje samo kada nema sačuvane `view.sheet` pozicije; sačuvani položaj ima prednost. Automatsko podešavanje visine se tokom greške preskače. End padding omogućava kraj skrola, ali ne garantuje odmah vidljivu radnju u HALF. Donja navigacija, safe area, veći tekst i tastatura moraju biti uračunati. Mala refresh radnja već postoji; problem nije nepostojanje svake radnje nego nejasan i delimično zaklonjen glavni prikaz. Lokacijsko dugme ne sme samo spustiti sheet na PEEK i skloniti objašnjenje dok mape nema.

Za F17 sačuvati bezbedan tip razloga odvojeno od booleana za prikaz. `focusedResource` odbacuje exception i čuva `error:boolean`; `String(resource.error)` zato za auth, permission, contract, mrežu i deadline daje `true`. UI treba kratak odgovarajući tekst i smislen retry; privatni SQL/provider sadržaj ostaje van korisničke poruke. Ovaj nalaz je odvojen od stare P6 slike koja taj prop nije koristila.

SB11 zatvoriti kod njegovih vlasnika: PLACES decode exception mora završiti busy stanje; recent-search nalog označiti učitanim tek posle prihvaćenog read-a ili omogućiti ponovljiv oporavak; fit cache ključ/invalidacija obuhvata relevantne promene revizije, kraja termina, pina i mode-a. Običan detail refresh već šalje null, pa problem nije svaki refresh. Ne uvoditi slučajan globalni cache reset kao zamenu za ispravan ključ.

Sačuvati MapLibre/OpenFreeMap i native/web odgovornosti, scene/focus owner i pin revision. GPS dozvola za „Moja lokacija” nije obavezan uslov svakog prikaza mape. Prazan rezultat sam ne gasi geografiju; native style/render failure proverava se odvojeno od poslovnog RPC-a. Ne pripisivati kvar nedokazanom Google API ključu ili Gemini klasifikaciji.

#### Prihvatni dokaz i postojeće provere

| Scenario | Potreban rezultat |
|---|---|
| Hladan ulaz, pravi PAGE uspeh, kontrolisani MAP failure | Pravi PAGE prolazi decoder; lista i filteri ostaju dostupni; greška pripada MAP operaciji; poslednji izbor korisnika ostaje. |
| Isti neuspeh kroz Retry | Stanje je razumljivo i dosledno i bez početnog snapshot-a i posle njegovog commit-a; nema prelaska na lažni prazni uspeh. |
| PAGE i MAP oba ne uspeju | Jasno nepoznat rezultat i dozvoljene ponovne provere; nema izmišljenog broja 0. |
| MAP se oporavi posle delimičnog uspeha | Podloga/pinovi se usklade sa važećim upitom bez resetovanja filtera i korisničkog sheet izbora. |
| PLACES decode failure, recent read failure, promenjen fit input | Busy se završi, oporavak je ponovljiv, stara fit odluka ne preživi relevantnu izmenu. |
| Mali telefon, veliki font, HALF/FULL/PEEK, povratak na tab | Objašnjenje i radnja su vidljivi i dostupni; navigacija i tastatura ih ne zaklanjaju; zasebna native map greška ne ruši dozvoljenu listu. |
| Promena naloga ili upita, odgovori obrnutim redom | Stari rezultat ne dobija novi autoritet; cancel i focus/generation granice ostaju. |

| Postojeća testna putanja | Odluka | Granica koju treba proširiti |
|---|---|---|
| `src/data/__tests__/discovery-v1-client-transport.test.ts` | Sačuvati tačan RPC, abort, 15-sekundni rok i kodove greške. | Mock ne dokazuje MAP/PLACES/filter podršku objavljenog servera. |
| `src/data/__tests__/discovery-v1-route-lifecycle.test.tsx` | Sačuvati stvarnu rutu/coordinator i reprodukcioni ulaz; posle popravke promeniti global-error očekivanje u očuvanu listu sa posebnom MAP greškom. | Bridge/presentation zamene ne dokazuju native geometriju. |
| `src/data/__tests__/discovery-presentation.test.tsx` | Sačuvati prazni P6, list/pill/nav raspored i relevantne layout slučajeve. | Fiksne mere i padding assertions nisu MapLibre ili telefon. |

Ranije izolovane tri route karakterizacije, pet boolean slučajeva i osam stari/novi decoder slučajeva opisuju reprodukovani kvar; nisu nova provera ove popravke. Završni dokaz vezati za tačan source/SQL/Edge/flags/APK/OTA i uređaj. Za performanse koristiti aktuelni reader, javne kolone i područja, hladne/tople i ponavljane/različite upite, otkaze i ceo odgovor/cursor. Klijentski rok 15 sekundi nije cilj normalnog čekanja; stari 90-sekundni prozor benchmark posmatranja nije prihvatna UX granica.

**Izlaz:** usklađen Discovery ugovor za podržane klijente, razdvojeni delimični ishodi, razumljiva dijagnostika, završiv search recovery i stvarni native dokaz prikaza.

### R03 — Moje potrebe, pet scope-ova i stabilno straničenje

#### Problem i cilj

**Ulazni nalaz: F01.** Klijent očekuje ALL/ACTIVE/DRAFTS/HISTORY/WAITING, svih pet brojača na prvoj strani i snake_case task dokument. Analizirani `rpc_list_my_needs_page` prihvata samo ALL/ACTIVE/HISTORY, uključuje DRAFT u ACTIVE, nema `counts` i vraća camelCase. Zato pada i prazna prva strana zbog brojača; dodavanje samo counts ne rešava nepraznu stranu i nastavak. Tracked preview/production uključuju paged put, ali to nije čitanje zastavice svakog instaliranog APK-a.

**Cilj:** sopstvena lista, njeni filteri, brojači i detalji predstavljaju isti poslovni skup kroz prvu i naredne strane. Ovo je zaseban reader i kvar od javnog Discovery taba.

#### Vlasnici i redosled rada

Primarni vlasnici su `src/data/ownTasksPage.ts`, `src/data/needClientService.ts`, ruta `src/app/(app)/potrebe.tsx`, `public.rpc_list_my_needs_page`, postojeći `own_task_counts` helper i `supabase/migrations/20261025000000_baseline_core_client_rpcs.sql`. Stvarni izlaz treba provesti kroz `ownTasksPage`, `mapNeed` i `readPublicNeedDetail`; ručno sklopljen fixture koji već liči na željeni JSON ne dokazuje SQL ugovor.

1. Ponovo pročitati aktuelni javni reader, count helper, task projekciju, sva upotrebljena pravila scope-a, ordering/cursor i dozvole posle R01.
2. Zadržati jednu poslovnu podelu pet scope-ova i nameravanu count particiju. DRAFT se ne sme slučajno brojati/pojavljivati kao ACTIVE zbog starijeg reader-a. Brojači pripadaju prvoj strani; nastavak ih ne prepisuje drugim skupom.
3. Pripremiti usku novu migraciju za preostali neusaglašeni javni ugovor, uz očuvan helper i task detalj. U analiziranom stanju `own_task_counts` već sadrži EX04A telo, javni paged reader je stariji. Stari EX04A apply očekuje oba prethodna tela i zato nije pravilna gotova popravka.
4. Očuvati keyset, cursor validaciju, stabilan red, dedupe, focus/account/generation granice i ponašanje nakon objave/izmene. Refresh ili nova strana ne smeju izbrisati dobar skup zbog odgovora starog naloga/upita. Pravila važenja brojača tokom promene podataka dokumentovati kod postojećeg vlasnika.
5. Proveriti i praznu i nepraznu prvu stranu svakog scope-a, sledeću stranu i kraj. Nepoznat scope ili pogrešan cursor se odbijaju; uspešna prazna lista se prihvata. Tuđ nalog ne dobija tuđe sopstvene zadatke.

#### Svih 12 baseline RPC-jeva: šta menjati i šta očuvati

Ovo je obavezna granica R02/R03, jer se oba nesklada nalaze u istoj istorijskoj migraciji. Dva utvrđena nesklada nisu dokaz da svih 12 funkcija treba vratiti ili prepisati. U analiziranom preseku devet drugih ugovora je statički kompatibilno, a jednom nedostaje opcioni `displayName`. Telo funkcije samo ne obuhvata sve ACL-ove, pomoćne tabele, triggere ili poslovne podatke. Nijedan ovde navedeni stari writer nije zbog ove tabele ponovo izvršen.

| RPC i redovi analizirane baseline migracije | Aktivni potrošači | Očuvani ugovor i odluka |
|---|---|---|
| `rpc_discovery_v1`, 71–236 | `src/data/discoveryV1ClientTransport.ts`, `src/data/discoveryV1Owner.ts`, `src/data/discoveryV1MarketplaceAdapter.ts` | R02: uskladiti ponuđene PAGE/MAP/PLACES/EXACT_PUBLIC/filter mogućnosti; ne povlačiti kompatibilne funkcije u nastavku. |
| `rpc_get_worker_execution_modes`, 241–258 | `src/data/workerExecutionModeClientService.ts` | Očuvati profileId/confirmed/modes/timestamp. Zbirni mode receipt nije entitlement niti per-service potpuna ponuda. |
| `rpc_get_my_task_relations`, 262–315 | `src/data/supabaseIzvor.ts`; `src/data/taskRelation.ts` | Očuvati 1–100 ID, OWNER/APPLIED i overlay. Odsutni odnos postaje NONE tek posle uspešnog čitanja. |
| `rpc_read_safety_target`, 322–347 | `src/data/safetyClientService.ts` | Osnovni ugovor je kompatibilan. Opcioni displayName može biti null; analizirani tracked release flag ga ne zahteva. Nije dokazan aktivni blokirajući kvar. |
| `rpc_read_task`, 354–408 | `src/data/needClientService.ts`; `src/data/supabaseIzvor.ts` | Očuvati snake_case detalj sa schedule/topology/requirements/capacity/price_basis i dozvoljenim poljima. Koristiti isti poslovni oblik za R03. |
| `rpc_list_my_tasks`, 415–428 | `src/data/needClientService.ts` | Očuvati kompatibilnu listu `rpc_read_task` dokumenata sopstvenog naloga; ona je odvojena od paged reader-a. |
| `rpc_list_my_needs_page`, 435–488 | `src/data/ownTasksPage.ts`; `src/data/needClientService.ts` | R03: popraviti pet scope-ova, counts i task wire format uz već postojeći noviji helper. |
| `rpc_get_my_agreement_review_v2`, 496–516 | `src/data/reviewCommentsClientService.ts`; `src/data/reviewsClientService.ts` | Očuvati context, tag catalog, comment policy/max 500 i sopstveni komentar. |
| `rpc_submit_agreement_review_v2`, 523–587 | `src/data/reviewCommentsClientService.ts` | Očuvati argumente/receipt, request ID i hash-replay zaštitu. Pročitani writer nije izvršni PASS. |
| `rpc_list_review_comments_v1`, 594–651 | `src/data/reviewCommentsClientService.ts` | Očuvati items/author/cursor/hasMore; null je dozvoljeno nedostupno stanje. |
| `rpc_mark_agreement_messages_read`, 658–683 | `src/data/supabaseIzvor.ts` | Očuvati integer receipt i novije izuzimanje `group_message_id`: direct chat ne zatvara grupna obaveštenja. |
| `rpc_list_my_agreements_page`, 690–777 | `src/data/agreementClientService.ts` | Očuvati keyset/currentVersion/terms/ratingDue i noviji phone-consent guard. Null workspace-only akcije/ID u listi nisu nova regresija. |

Ne prepravljati primenjenu baseline istoriju niti vraćati ceo stari candidate paket kao rollback. Istorijski EX04 dokaz ima mešavinu nepromenjenih i promenjenih tela i dodatni ACL drift; test mora krenuti od aktuelnog helper-a i čitača.

#### Minimalni pozitivan, negativan i delimičan dokaz

Za svaki od pet scope-ova izvršiti stvarni važeći SQL/API read i propustiti rezultat kroz pravi decoder: prazna prva, neprazna prva, nastavak i završna strana. Uporediti counts i članstvo sa nameravanim pravilom; proveriti promenu filtera, refresh nakon objave, dedupe i stabilnost poslednjeg prihvaćenog sadržaja. Kasnija strana ne menja counts prve. Tuđ nalog, nevažeći scope i pogrešan cursor ostaju odbijeni.

Delimični/mrežni neuspeh naredne strane ne sme se preimenovati u uspešan kraj liste, a kasni odgovor prethodnog upita ne dodaje redove novom. Odsutnost odnosa, nedostupan komentar i dopuštena null polja čuvaju svoje već navedene posebne ugovore.

| Postojeća testna putanja | Rad | Ograničenje |
|---|---|---|
| `src/data/__tests__/own-tasks-page-client.test.ts` | Sačuvati pravi decoder/mapNeed, pet counts i praznu stranu; dodati stvarni izlaz reader-a. | Ručni payload ne otkriva stari camelCase/no-counts server. |
| `src/data/__tests__/own-tasks-pager.test.ts` | Sačuvati focus, cursor, dedupe, kasni/account odgovor i counts samo prve strane. | Ne izvršava SQL reader. |
| `supabase/proofs/ex04/ex04a_proof.mjs` | Rebase namere lokalnog RPC poređenja svih pet scope-ova i outsider/anon kontrola. | Stari apply očekuje staro stanje oba vlasnika; ne izvršavati ga napamet. |

**Izlaz:** jedan ispravan own-tasks ugovor potvrđen stvarnim reader/decoder lancem, uz očuvanih ostalih deset baseline funkcija i zasebno zatvoren Discovery posao.

### R04 — Potpuna klasifikacija, stabilan identitet i potvrđena namera

#### Problem i granica prema R06

**Ulazni nalazi: F04, F05 i F08, uz semantički deo F06.** Ovaj zadatak zatvara značenje rezultata: potpun katalog, verna hijerarhija, isti smisao/isti ID, nova smislena grana, kompletan service–mode–handoff skup i bezbedno povezivanje tog rezultata sa pregledom i čuvanjem. R06 zatvara trajni posao, pokušaje, transport, cache operacije i obračun. Nezavisne izmene istog BG/review vlasnika moraju se integrisati sekvencijalno.

Cilj nije da korisnik upravlja kategorijama. Glavni requester prompt već normalizuje opis u konkretnu uslugu; ne treba tvrditi da postojeći sistem nema semantičku obradu. Potrebno je dovršiti aktivni ugovor i njegova mesta na kojima se ispravan zaključak izgubi.

#### Pune putanje vlasnika i SQL autoriteti

| Oblast | Vlasnici |
|---|---|
| Aktivni BG i postojeće AI strategije | `supabase/functions/_shared/backgroundTaxonomyArchitect.mjs`; `supabase/functions/_shared/classificationGeminiShadow.mjs`; `supabase/functions/_shared/classificationExplorer.mjs`; `supabase/functions/_shared/taxonomyScopedShadow.mjs`. Poslednja dva nisu automatski novi ciljni runtime; proveriti stvarne gate-ove i potrošače. |
| Mode i način izvršenja | `supabase/functions/_shared/serviceExecutionInstruction.mjs`; `supabase/functions/_shared/workerServiceModeContext.mjs`. |
| Foreground/capture | `supabase/functions/uskoci-ai-interview/index.ts`; `supabase/functions/uskoci-worker-interview/index.ts`; `supabase/functions/_shared/taxonomyPostSaveWorker.mjs`. |
| Katalog i hijerarhija | `supabase/migrations/20261019104047_taxonomy_parent_navigation_and_mode_admission.sql`; `supabase/migrations/20261023200000_taxonomy_snapshot_and_turn_hints.sql`; `rpc_taxonomy_query_catalog_service`; `rpc_taxonomy_fetch_snapshot_v1`. |
| Potpisani pregled/capture/binder | `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql`; `supabase/migrations/20261021103732_worker_equipment_retired_signed_policy.sql`; `supabase/migrations/20260913044510_clean_v5_unknown_ai_turn_exit.sql`; postojeći exact/candidate projection, batch writer i `rpc_complete_worker_ai_turn_service`/`rpc_prepare_worker_ai_review_taxonomy`. |
| Upis posle klasifikatora | `supabase/migrations/20261013193000_uskoci_needs_category_sync_trigger.sql`; `supabase/migrations/20261014093000_uskoci_worker_profile_authoritative_capability_sync.sql`; `needs_sync_taxonomy_category_trigger_fn`; worker authoritative capability sync i signed Need binder. |
| Klijentska potvrda i readback | `src/data/workerAiClientService.ts`; `src/data/aiTaskReviewClientService.ts`; `src/app/(app)/profil/razgovor.tsx`; `src/app/(app)/nova.tsx`; `src/app/(app)/pregled-zadatka.tsx`; `src/contracts/needFactsV2.ts`. |

Primarni princip ostaje: model i capture imaju `authority:NONE`. Postojeća kategorija koristi stvarni ID; novi ID nastaje iz validiranog SQL writer-a kroz `INSERT … RETURNING`. Potpisani pregled, korisnički Save/Accept, admission receipt i vezivanje na reviziju obavljaju različite poslove. Account/revision/digest, idempotentnost, kasni odgovor i zasebna saglasnost za mode/handoff ostaju.

#### 1. Potpunost kataloga i verna hijerarhija

Analizirani ROOTS/CHILDREN fallback ima limit 100, ne prati `nextCursor` i završava posle šest serija po 32 roditelja bez dokaza da je red prazan. Nevažeća strana može biti preskočena, a rezultat ipak označen kao full. Kasniji potpun snapshot iste version/fingerprint može vratiti isti raniji parcijalni objekat. Izolovana reprodukcija imala je 202→200 čvorova, isti nepotpun objekat posle punog snapshot-a i mali 1/2 slučaj bez exception-a. NEED helper vraća failure envelope, WORKER helper za HTTP failure baca; test ne sme pretpostaviti iste sve greške oba handler-a.

Loader mora pratiti sve strane do potvrđenog završetka, proveriti ponovljen/nevažeći cursor, preostali red roditelja, svaku neuspelu stranu i konzistentnu version/fingerprint oznaku. Nepotpuno učitavanje ostaje tehnički nedovršeno, ne tvrdnja „usluga ne postoji”. Potpun snapshot sme i mora zameniti parcijalni iste oznake. Uskladiti stvarne limite: postojeća statička granica snapshot-a 4 MiB i handler-a 512 KiB nije rešena time što je sadašnji katalog mali. Strukturni preci bez sopstvenog mode-a moraju ostati u smislenoj hijerarhiji tamo gde ih ugovor dopušta.

Analizirani snapshot sortira po canonical_key/id, dok BG prompt koristi uvlačenje po dužini putanje, label, ID i modes, bez parentId/path/aliasa. Zabeleženo je 73 children-before-parent, 31 nepovezano podstablo i 25 nelisnih čvorova koji nisu prvi u sopstvenom podstablu. To je dokaz nedovoljno označene strukture ulaza, ne dokaz konkretnog pogrešnog modelskog odgovora.

Uvesti kompaktan, jednoznačan input koji čuva `id`, `parentId` ili potpunu putanju, label, relevantne aliase, modes/scope i status lista/pretka, ili dokazano ispravan preorder sa očuvanim odnosima. Svaki postojeći čvor mora biti dostupan sa istim značenjem. Ne koristiti samo abecedni red sa uvlačenjem kao prikaz stabla. Sadašnji agregat 153 established/root-reachable čvora, 120 listova, jedan koren, devet BOTH čvorova, 17 aliasa, dubina pet i najviše 12 sibling čvorova opisuje audit presek, ne budući dozvoljeni maksimum.

#### 2. Postojeća usluga, sinonim i stvarno nova grana

Exact canonical naziv i registrovan alias već imaju deterministički put. Zatvoriti semantički REUSE za smislen neupisan sinonim: requester odluka trenutno nema pun REUSE/categoryId izlaz, a neprihvaćen REUSE daje `SEMANTIC_REUSE_ADMISSION_UNAVAILABLE`. Istom značenju sa istim scope-om ne praviti duplikat, ali blisku drugačiju uslugu ne spajati samo na osnovu slične reči.

SQL podržava CREATE_NEW_BRANCH i višestepeni path; aktivni BG builder proizvodi jedan CREATE_CHILD pod postojećim roditeljem. Bogatiji full-snapshot ugovor već postoji u shared modulu, ali ga dual foreground put zaobilazi. Izabrati i uskladiti postojeću aktivnu putanju na istom semantičkom korpusu, sa tačnošću, ukupnim čekanjem i troškom. Korisnik ne bira interne klase/flag-ove. Prisustvo instrukcije u nepozvanom modulu nije implementirana mogućnost; ne uvoditi treći klasifikator niti slepo vraćati stari režim.

Ukloniti izjednačavanje naziva bez razmaka sa nejasnom uslugom: dokumentovani `taxonomy_risk_triage_v1` daje NEEDS_CLARIFICATION za `Sisanje`, a LOW_RISK_CANDIDATE za `Sisanje kose` bez aktivnih risk pravila. Taj uslov pogađa i EXTEND_MODE postojećeg naziva. Provera stvarnog smisla, scope-a, rizika, duplikata i ID integriteta ostaje; broj reči nije zamena za nju.

#### 3. Ceo BOTH i stvarna saglasnost za način rada

Pre provider odgovora iz korisničke namere izvesti očekivani skup service–mode–handoff parova. `proposals.length>0` ne dokazuje njegovu potpunost. Dokumentovana proba za izričit BOTH vratila je ON_SITE proposal i REMOTE failure, dok je exact projekcija ipak dala READY samo za ON_SITE. Pozitivna kontrola sa oba item-a dala je oba moda. Failure/unresolved ostatak mora preživeti builder, capture i prepare do odluke o završetku.

Isti servis u oba moda zadržava isti canonical ID. Delimičan rezultat ostaje jasno nedovršen; već potvrđeni nezavisni delovi se ne gase bez pravila. Uskladiti foreground pravilo koje dopušta inherentno jasan početni mode nove konkretne usluge sa BG zahtevom za eksplicitno ponuđenim/sačuvanim mode-om. Sačuvani izbor ima prednost; citat USER poruke potvrđuje poreklo, ali sam ne garantuje potpunu saglasnost.

REMOTE uključuje digitalni rad i rad kod izvršioca/radionicu sa potrebnom predajom. Nepomenut handoff nije `{required:false}`. BG handoff predlog ne postaje korisnička saglasnost: sadašnji autoritet je foreground/saved izbor. Uskladiti prompt, izlaz, validator i prepare, uz serversku proveru celovitosti koja ne zavisi od poslušnosti prompta. Ne vraćati dodatni obavezni mode formular.

#### 4. Nepromenjeni smisao kroz novu reviziju pregleda

Worker hint je vezan za ceo `candidate|revision|base_hash`; uspešan turn povećava revision i kada je `patch:{}`. BG trigger radi samo kada tekuća poruka podržava promenu skills/mode/handoff ili pending pitanje. Zato „to je to” može sačuvati identičan kandidat, povećati reviziju 1→2 i ostaviti nula tekućih hintova uz REVIEW_REQUIRED. Stari hint redovi nisu obrisani; njihova veza više ne važi. Continuity fallback za netaknutu sesiju sa revision=0 i precizno sačuvanim potpisanim izborom nije opšte rešenje.

Odvojiti identitet semantičkog ulaza od identiteta korisničkog pregleda. Nepromenjeno značenje može se bezbedno revalidirati i vezati za novu reviziju, dok stvarna promena usluge/mode/handoff zahteva novu obradu. Ne prihvatati stari potpis ili tuđ rezultat bez provere, ne produžavati timeout kao zamenu i ne odbacivati sve semantičke rezultate samo zato što se promenila nepovezana globalna verzija kataloga.

Requester proveriti odvojeno. Njegov source obuhvata činjenice/poruke/turnove, a BG prati uži service/scope/mode/handoff skup. Budžet ili vreme mogu zastareti plan nove grane/moda bez novog BG pokušaja. Existing exact/alias kategorija ipak ima neposredno razrešavanje iz činjenica; nije svaki requester nastavak pokvaren. Semantički kontinuitet treba dokazati preko pravog prepare/Save/binder/readback-a, ne samo izdvojene completion funkcije.

#### 5. Pisci posle klasifikatora i ranije pripremljeni pokušaji

`needs_sync_taxonomy_category_trigger_fn` radi kao BEFORE INSERT OR UPDATE OF category, traži canonical ključ bez alias-a i u živom analiziranom telu za `/` pokušava poslednji naziv putanje. Neprepoznat neprazan tekst može postaviti ID na NULL. Source migracija nema isti slash fallback. Signed Need binder proverava owner/revision/ID konflikt i menja samo `category_id`; ne pokreće UPDATE-OF-category trigger. Rešenje mora obuhvatiti oba pisca i source/live razliku, bez davanja autoriteta tekstu koji pripada pogrešnom roditelju.

Worker sync čuva ID jedinstvenog canonical naziva ili registrovanog alias-a. Neregistrovano preimenovanje može izostaviti postojeću uslugu iz retained skupa i opozvati capability/opt-in. Dodavanje nepoznate usluge uz očuvanu staru ne opoziva sve. Sync ne stvara niti oživljava novi autoritet. Popraviti rename/identity vezu, ali izričito povlačenje usluge mora ostati delotvorno.

Obuhvatiti canonical naziv, registrovan/neupisan sinonim, pogrešnog roditelja sa stvarnim završnim listom, ID-only binder, novo dodavanje uz očuvanu staru uslugu, eksplicitno uklanjanje i zastarelu listu. Dokazati i već READY review, ponovljen isti Save receipt, Save→batch→binder i obrnuti red završavanja, oba moda istog ID-ja i nameran identity konflikt. Novi čisti fixture ne pokriva automatski stariji već pripremljen pokušaj; istorijski cross-mode kandidat sa promenjenim pinovima nije gotova migracija.

#### 6. Očuvati postojeće korisničke i autorizacione granice

Requester završna kartica, `canReview`, classification stanje, prihvat, privatni nacrt i objava nisu isti uslov. Tekst `need.category` je obavezan za karticu i skriven u listi nedostajućih činjenica; sistem mora dovršiti svoj podatak bez neobjašnjivog čekanja, ali to nije nova blanket zabrana svakog Save-a dok category ID/READY ne postoji. Prepare upisuje zamrznut review, još ne objavljuje; SaveDraft ne radi automatski evaluate/publish; PUBLISHED receipt traži readback istog Need-a/revizije.

Za worker-a READY označava pripremljene candidate/mode parove, ne Save, admission, binding ili matching autoritet. DRAFT može izabrati Save ili Save+activate na istom pregledu; `activate=false` ne deaktivira već ACTIVE profil. Pending nova usluga ne proglašava sve ranije potvrđene usluge neaktivnim. Promena teme ne šalje poruku i ne pravi novi razgovor; ispravka se vraća u isti razgovor. Kasni callback ne dobija pravo samo zato što se nalog promenio A→B→A.

#### Prihvatni dokaz i testovi

Dokaz obuhvata potpun/nepotpun katalog i kasniji pun snapshot iste oznake; abecedni ulaz koji nije DFS; svaki roditelj, alias i expected mode; synonym reuse; stvarno novu granu/path; jasan jednočlani naziv; BOTH sa jednim i dva odgovora; radionicu i predaju; izmenu jedne od više usluga; „to je to”/budžet/vreme/pin bez promene usluge; stvarnu promenu semantike; pripremljeni review i replay. Pozitivan ishod mora proći stvarni aktivni handler, signed prepare, korisničku potvrdu, Save, binder i autoritativni readback. Mock model se koristi za kontrolisanu grešku; ograničeni pravi model je zaseban kasniji dokaz kvaliteta.

| Postojeća testna putanja | Šta izvesti/dopuniti | Granica |
|---|---|---|
| `supabase/proofs/ai/background_taxonomy_scope.test.mjs` | Sačuvati stvarni BG builder i scope/identitet; dodati neupisan sinonim, novu granu i vezu sa signed prepare/Save/binder-om. | Kontrolisani transport sam ne zatvara ceo tok. |
| `supabase/proofs/dynamic_taxonomy/classification-gemini-shadow.test.mjs` | Sačuvati parser/planner i service/mode ugovor. | Druga putanja nije dokaz da aktivni dual handler koristi isti ugovor. |
| `src/data/__tests__/worker-ai-client.test.ts` | Sačuvati signed decoder, oba moda, child/main i stari/novi RPC izbor; povezati stvarni server rezultat. | Ručno sastavljen review ne dokazuje SQL koji ga stvara. |
| `supabase/proofs/dynamic_taxonomy/gemini-real-provider-smoke.mjs` | Zahtevati obavezno prisustvo i validnost `classificationShadowJson` pre PASS-a. | Provera samo ako polje postoji može propustiti nedostajući izlaz; wire smoke nije cela poslovna validacija. |
| `supabase/proofs/ai/classification-full-catalog-edge.test.mjs` | Aktivirati pravu relevantnu handler granu u potpuno presretnutom fixture-u, dodati potpunost/hijerarhiju/verziju. | Postojeći `https://db.invalid` fixture ne uključuje exact-DEV dual selector; shadow/direct PASS nije BG loader dokaz. |
| `supabase/proofs/ai/background_taxonomy_failures.test.mjs` | Sačuvati stvarne `buildFullTreeTaxonomyProposals`/`buildWorkerFullTreeTaxonomyProposals`, synthetic provider/catalog i failure/consent slučajeve; dopuniti strukturu. | Putanja je dodatno potvrđena na analiziranom GitHub commitu; test time nije ponovo izvršen. |

Nenajavljen mrežni poziv u lokalnoj kontrolisanoj probi mora biti odbijen fixture-om. Source regex provere ostaju korisne ograde, ali ne izvršavaju potpis ili SQL semantiku. Alternative `classificationExplorer`/shadow putanje povlačiti tek posle parity dokaza i prevezivanja aktivnih potrošača; `classificationOwnerReview.mjs` i njegov synthetic CI ulaz ne smeju nestati bez prenosa korisnih tekućih scenarija.

**Izlaz:** jedan dokumentovan aktivan semantički ugovor sa potpunim input-om i rezultatom, stabilnim ID-jem, celim BOTH i bezbednim kontinuitetom do sačuvanog autoritativnog stanja. Reprodukovani audit kvar nije novi PASS rešenja.

### R05 — Sačuvana područja, vreme i izbor stvarno dozvoljenih kandidata

#### Problem, obim i vlasnici

**Ulazni nalaz: F18.** Analizirani candidate prefilter može izbaciti radnika zbog stare profilne tačke udaljene preko 300 km pre nego što se primeni merodavno COUNTRY/CITY/RADIUS područje. Saved-area evaluator prihvata RS/STATIONARY, dok klijent poznaje i POINT_TO_POINT, MULTI_STOP, AREA_BASED i REMOTE. U TODAY_FLEXIBLE toku radnik dostupan kasnije danas može ostati bez time tier-a. To su statički lanci nad tadašnjim telima, bez izmerenog broja stvarno pogođenih naloga.

**Cilj:** početni skup kandidata ne gubi nijednog koga važeća konačna provera može dozvoliti; vreme i područje imaju isti smisao u matcher-u, „Za mene” i dispatch-u. Dobrovoljna ručna prijava zadržava zasebna pravila.

| Sloj | Konkretni vlasnici |
|---|---|
| Potvrđeno područje | `src/contracts/workerAreas.ts`; `supabase/functions/uskoci-worker-interview/index.ts`; signed candidate/review/Save vlasnici. |
| Server područja i vremena | `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql`; `private.candidate_profile_ids`; `private.candidate_profile_ids_v1b`; `private.dispatch_config_v1b`; `private.worker_area_fit_v1`; `private.worker_need_fit_v1`; `worker_need_match_v1`; `worker_need_time_tier_v1`; `discovery_for_me_v1`; `dispatch_cheap_candidate_admitted` i dispatch admission. |
| Vremenski pomoćnici | `availability_is_future`; `need_search_time_admitted_v1`; važeći availability/calendar writer-i i hard gates. |
| Ručna prijava i izbor | `match_detail_without_calendar`; `rpc_submit_response`; `rpc_select_response`. |
| Dostižni klijentski oblici | `src/data/needClientService.ts`; `src/data/aiTaskReviewClientService.ts`; `src/data/aiNeedV2Ui.ts`. |
| Istorijski dokaz/predlog | `supabase/proofs/match_category_fallback/live-candidate-stream.sql`; `supabase/proofs/match_category_fallback/dispatch-prefilter-assert.sql`. To nisu automatski aktuelna runtime tela ili odobren apply. |

#### Redosled rada i sačuvana pravila

1. Osvežiti stvarna tela i normalizovanu konfiguraciju. Očuvati uključeni signed service-scope gate: Need reviziju/category i stvarno sačuvanu Worker/service/mode saglasnost. Ne „popravljati” match uklanjanjem potvrde ili world granice.
2. Characterize isti mali skup parova prefilter→fit→match→„Za mene”→dispatch. Prvi obavezni par je udaljena stara tačka i važeći COUNTRY ili udaljeni izričiti CITY/RADIUS. Proveriti i postojeći uncapped delegate, ne samo dormant numerički cap granu. Početni retrieval mora biti nadskup konačno dozvoljenih kandidata.
3. Promeniti prefilter u postojećem vlasniku uz ograničeno čitanje, stabilan red/fairness, per-revision dedupe, postojeće budžete i remote rotaciju. Bez geography/no-preference fallback nije zamena za validno sačuvano područje. Ako saved-area evaluator vrati false, stara profilna tačka ne sme proizvoljno preglasiti tu eksplicitnu odluku.
4. Sačuvati postojeći workerAreas ugovor: do pet CITY/RADIUS ili jedno COUNTRY područje; RADIUS zahteva izričite kilometre od centra mesta. `areaRequests` se razrešava na serveru. Nezavisna jasna izmena ne treba da nestane zato što geokodiranje drugog dela nije uspelo. Ne izmišljati radius ili tačnu GPS adresu umesto korisnikovog izbora.
5. STATIONARY popravka i TODAY ne čekaju poslovnu odluku o rutama. Pre proširenja POINT_TO_POINT/MULTI_STOP/AREA_BASED dokumentovati da li oblast pokriva svaku stvarnu radnu tačku, preuzimanje/dostavu ili drugi potvrđen ugovor. Za NS→BG uporediti prevoz, više dostava i rad na dve lokacije; ne zahtevati automatski svaki tranzitni kilometar. Ako tržište ostaje RS, validacija i prikaz to čuvaju. Druga zemlja nije nenamerna posledica geometrijske popravke.
6. REMOTE ne dobija lažan profilni pin, radius, rutu ili ETA da bi prošao fizički prefilter. Postojeći potvrđeni handoff i njegove potrebne lokacijske granice ostaju zasebni. Cityless REMOTE aktivacija nije deo ove popravke: sadašnji review/activation i submit/select još imaju city uslov i njegovo uklanjanje traži drugi kompletan ugovor.

**Konfiguraciona činjenica koju ne menjati pogrešnim čitanjem:** `workerDailyCap=1000` je u analiziranom `dispatch_config_v1b` sentinel koji se pretvara u NULL, odnosno isključen dnevni cap; nije stvarno ograničenje na 1.000. Sačuvati zatečeni dispatch ALL, remote talase 300/1.000, interval 30 minuta i zaustavljanje na pet odgovora dok ne postoji obrazložena namerna promena. Ove brojeve proveriti ponovo pre rada, jer plan beleži polazni ugovor, ne trajno pravilo za svako buduće izdanje.

#### TODAY_FLEXIBLE i vremenski kontinuitet

Analizirani `worker_need_time_tier_v1` pri dodavanju empty-calendar fallback-a izgubio je posebnu TODAY granu. Za važeći TODAY sa obe granice NULL, `available_now=false` i stvarnim AVAILABLE/weekly terminom kasnije danas ne izvodi dnevni prozor. `availability_is_future` zahteva obe granice, a poslednji period fallback važi samo za FIXED_WINDOW; rezultat ostaje NULL i dalji match odbija par. `available_now=true` i dalje može dati tier1. Obuhvaćen je i već započet ograničeni TODAY sa slobodnim ostatkom dana; nisu svi TODAY zadaci neispravni.

Jedan autoritet treba da izvede dan objave i preostali dozvoljeni interval u poslovnoj zoni. Sačuvati namerni empty-calendar fallback, eksplicitni UNAVAILABLE i stvarne vremenske konflikte. Očuvati instant, lokalni datum i promenu sata; uređajna zona ne sme proizvoljno redefinisati dogovoreni dan. Ne vratiti ceo stari exact-pin kandidat radi jedne vremenske grane.

#### Ručna prijava nije automatska preporuka

`match_detail_without_calendar` svrstava service/area/time preference u dispatchBlockers, dok `responseAllowed` ima nezavisne hard gates. `rpc_submit_response` i `rpc_select_response` proveravaju responseAllowed, svet, vlasnika, reviziju, cenu, termine i postojeća ograničenja. Ne dodavati novu zabranu dobrovoljne prijave samo da bi njena odluka postala ista kao „Za mene”. Pozitivna kontrola mora dokazati da legitimni ručni submit/select i dalje rade tamo gde samo preference ne preporučuju radnika.

#### Prihvatna matrica i testovi

| Skup | Obavezni slučajevi |
|---|---|
| Područja | Stara tačka preko 300 km + COUNTRY; udaljeni izričiti CITY/RADIUS; više oblasti; bez stare tačke; unutar/van potvrđenog radius-a; izmena jedne oblasti uz očuvanje drugih. |
| Topologija | STATIONARY; svaka zaista podržana POINT_TO_POINT/MULTI_STOP/AREA_BASED varijanta prema usvojenoj odluci; REMOTE/handoff bez lažne fizičke geometrije; druga zemlja samo prema eksplicitnom tržišnom pravilu. |
| Vreme | TODAY null/null, već započet ograničen TODAY, dostupan sada i kasnije, weekly/AVAILABLE/UNAVAILABLE, kraj dana, promena zone/sata, istek, TOMORROW/WEEK/FIXED i stvarni konflikt. |
| Ceo izbor | Isti tačno navedeni parovi kroz retrieval, fit, „Za mene” i dispatch; nema samo agregata koji prikriva pogrešan par. |
| Zasebna ručna radnja | Dozvoljen submit/select uprkos samom preference blocker-u; odbijanje stvarnog hard-gate, tuđe/stare revizije i nedozvoljene sesije. |
| Ograničen rad | Stabilan red, fairness, budget/cap semantika, remote rotacija i dedupe pod ponavljanjem, bez neograničenog čitanja cele baze kao rešenja. |

| Postojeća testna putanja | Sačuvati/dopuniti | Stvarni domet |
|---|---|---|
| `supabase/proofs/ai/worker_signed_areas_sql.test.mjs` | Writer, validator, stale-source continuity i privatne helpere vezati za stvarno izvršivu proveru gde treba. | Postojeći regex čita SQL stringove; ne izvršava Save ili matching. |
| `src/data/__tests__/worker-area-route.test.tsx` | Sačuvati potvrdu grube tačke/revizije i REMOTE granicu. | Servisne zamene nisu saved-area matcher ili prefilter. |
| `src/data/__tests__/w02-worker-availability-client.test.ts` | Sačuvati normalizaciju, expected revision i conflict zaštitu. | Ne izvršava TODAY time tier i dispatch. |
| `supabase/proofs/match_category_fallback/dispatch-prefilter-assert.sql` | Rebase na aktuelne definicije i signed oblasti, sa celom malom matricom parova. | Istorijski aggregate/fixture nije sadašnji autoritativni match. |

Ne vraćati iz starih fixture-a ukinute equipment/team/experience ili all-slots politike. Current TOTAL proporcionalnost covered/original slots ostaje kod cenovnog vlasnika. **Izlaz:** bez lažno negativnog početnog izbacivanja, ista važeća area/time odluka kroz automatski lanac i očuvana zasebna ručna prijava.

### R06 — Trajan nastavak, ograničen transport, cache i tačan AI obračun

#### Problem i cilj

**Ulazni nalazi: F06/F07, uz semantički ugovor R04.** Analizirani izvor već ima stvarnu lifecycle zaštitu: devetosekundni BG rok počinje pri BG startu, neuspešan/nevažeći foreground completion prekida neodvojeni rad, potvrđen uspeh dopušta ograničen capture posle zatvaranja stream-a, ACK se proverava, a dijagnostika ne iznosi privatnu prozu. To se čuva.

Otvoreno je trajno dovršavanje kada prvi plan nije nastao ili je store/capture ishod izgubljen. Builder `failures/unresolvedServices` često ne postaju trajan status, a `.catch(()=>null)` može ostaviti samo odsustvo rezultata. Ponovljena ista usluga ne mora pokrenuti novi pokušaj. Post-save outbox traži nonempty candidates i fingerprint; pending reconciler beleži nezavršen review, ali ne rekonstruiše propušten prvi plan. `ai_turn_sweep` posle grace perioda postavlja FAILED/CANCELLED, nije automatski provider retry.

**Cilj:** svaki opravdani klasifikacioni posao ima završiv, ograničen i vidljiv lifecycle, a svaki poslati provider pokušaj zaseban poznat ili izričito nepoznat obračunski ishod. Prekid ne traži da korisnik ponovo opisuje jasnu uslugu. Poslovna idempotentnost ne obećava tačno jedan naplaćeni provider poziv.

#### Pune putanje i postojeći vlasnici

| Uloga | Vlasnici |
|---|---|
| BG, transport, budžet | `supabase/functions/_shared/backgroundTaxonomyArchitect.mjs`; `supabase/functions/_shared/geminiTaskStream.ts`; `supabase/functions/_shared/taxonomyProviderBudget.ts`; `supabase/functions/_shared/aiTestBudget.ts`. |
| Foreground/capture | `supabase/functions/uskoci-ai-interview/index.ts`; `supabase/functions/uskoci-worker-interview/index.ts`; `supabase/functions/_shared/aiPhaseTiming.mjs`. |
| Trajni post-save posao | `supabase/functions/_shared/taxonomyPostSaveWorker.mjs`; `supabase/functions/uskoci-taxonomy-postsave-worker/index.ts`; postojeći lease/receipt/outbox/pending SQL vlasnici. |
| Prvi plan, review/capture i potpis | `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql`; `supabase/migrations/20261021103732_worker_equipment_retired_signed_policy.sql`; `supabase/migrations/20260913044510_clean_v5_unknown_ai_turn_exit.sql` i aktuelni prepare/complete/binder vlasnici. |
| Katalog/verzija | `supabase/migrations/20261023200000_taxonomy_snapshot_and_turn_hints.sql`; `rpc_taxonomy_fetch_snapshot_v1`; `rpc_taxonomy_query_catalog_service`; pisci category/mode/alias sadržaja. |
| Klijentski identitet pokušaja | `src/data/aiTurnIntentJournal.ts`; `src/data/aiNeedV2Production.ts`; `src/data/workerAiClientService.ts`; `src/hooks/useOwnedEditor.ts`. |
| Govor u tekst i njegovo rezervisanje | `supabase/functions/uskoci-speech-session/index.ts`; `supabase/functions/uskoci-speech-session/proxy.ts`; `supabase/functions/_shared/aiTestBudget.ts`. Ovo nije voice-message upload journal. |

#### 1. Razdvojiti posao, provider pokušaj i poslovni upis

Pre izmene definisati minimalan trajni zapis kod postojećeg autoriteta: account/conversation, draft revision, relevantni ulaz i fingerprint, scope, očekivani mode parovi, identitet logičkog posla, provider attempt, budget, stanje, rezultat i potrebni rok/lease. Čuvati odgovarajuću privatnost i retention; ne kopirati ceo razgovor u novi trajni red samo zato što je najlakše.

Razlikovati bar tehnički prekid, stvarno potrebno korisničko razjašnjenje, spreman validan predlog, PROCESSING, nepoznat upisni/provider ishod i terminalno stanje. Stvarni semantički rezultat može se bezbedno revalidirati prema R04; stvarna promena input-a ili naloga ne sme preuzeti stari rezultat. Pending status treba da kaže da li čovek treba nešto da odgovori ili sistem završava svoju obradu, bez internog objašnjavanja kategorijskog administriranja.

Postojeći post-save red koristiti tamo gde već obrađuje odobren plan. Prvi izostali plan zahteva svoj jasno povezan trajni nastavak, ne treći klasifikator niti drugi vlasnik iste poslovne istine. Pre-review i post-save posao imaju različite preduslove i dokaze. Journal zapis pre dispatch-a i isti command/request ID ostaju; readback potvrđuje postojeći rezultat pre odluke o novom upisu.

#### 2. Pravila ponavljanja i završetak UNKNOWN stanja

Sigurno neposlat ili izričito retryable neuspeh može imati ograničen nastavak uz lease, budžet i rok. Izgubljen odgovor posle slanja nije dokaz da server ili provider nisu izvršili posao. Lokalni transport abort nije udaljeni rollback i ne znači vraćen model trošak.

Za gubitak store/capture ACK-a prvo pročitati ishod iste operacije. Potvrđen postojeći rezultat ne izaziva novi model ili drugi poslovni upis. Stari readback ne briše noviju komandu istog naloga. Za nepoznat provider generate ishod sačuvati zaseban UNKNOWN zapis; ne praviti slepo novi plaćeni pokušaj pod novim ključem.

Plan lifecycle-a mora imati završiv odgovor i kada UNKNOWN traje: vidljivo stanje, sledeću dozvoljenu proveru, kraj automatskog rada, maksimalan budžet i odgovornu intervenciju ili drugi konkretan terminalni ishod. Ne obećavati dokaz „tačno jednom naplaćeno” kada provider ne daje potreban dokaz. Ograničiti svaki retry/poll; restart instance ili telefona ne resetuje brojač i budžet na nulu.

Objavljeni post-save v5 u analiziranom preseku nema source catch dopunu za stream/UTF-8 read greške. Uskladiti baš retryable/terminal granu i isti logical request key, lease i postojeću granicu od pet pokušaja; ne primenjivati ceo stari Edge paket. Ta popravka i dalje ne stvara prvi izostali plan. Source/Edge razliku zatvoriti kontrolisanom isporukom i dokazom stvarnog paketa.

#### 3. Potpun provider odgovor i jedan vlasnik transporta

BG direktni fetch čita `res.json()` bez byte cap-a, prihvata nedostajući `finishReason`, a prisutan završetak različit od STOP već odbija. Shared `geminiTaskStream.ts` zahteva potvrđen STOP i ograničava telo na 524.288 bajtova. Uskladiti aktivni BG put sa istim potrebnim request/response ograničenjima i verifikovanim parserom; ne oslabiti potpunost radi češćeg prolaza.

BG pozivi imaju `maxOutputTokens:1024` i thinking override samo za ime modela koje sadrži 2.5; shared normalizacija ima svoj low-thinking ugovor. Proveriti stvarni podržani model/API i primeniti njegov dozvoljeni request oblik. Analizirani izvor koristi Gemini Developer API `v1beta` generateContent/streamGenerateContent i pin `gemini-3.8-flash`; efektivne tajne/gate-ovi nisu time očitani. Promena API porodice ili modela nije prećutna optimizacija.

Sačuvati postojeći devetosekundni lifecycle rok, spajanje tekstualnih delova i bezbedne tipizovane greške. Proveriti nedostajući STOP, preveliko telo, truncation, prekinut tok, nevažeći JSON/schema i potpun pozitivan odgovor. Ne tvrditi da raniji kod nije imao timeout ili je čitao samo prvi tekstualni deo. Za svaki ishod ostaje zaseban attempt/usage rezultat, uključujući neuspeh dijagnostike.

#### 4. Odvojeni BG i STT obračun

Glavni provider pokušaj već ima rezervaciju/settlement, dok direktni BG fetch nema zatvoren zaseban operation ID/onUsage tok. Exact/cache i trigger mogu izbeći BG poziv; nije svaka poruka obavezno dva modela. Svaki stvarno poslati BG attempt mora dobiti svoj budžet i poznat/UNKNOWN obračun, bez prepisivanja ili dupliranja foreground računa. Uspeh, abort, izgubljen odgovor i retry ostaju odvojeni događaji.

Za generateContent `promptTokenCount` već uključuje `cachedContentTokenCount`; cached deo ne sabirati preko punog prompt-a. `candidatesTokenCount`, `thoughtsTokenCount` i ukupni zbir imaju svoje značenje. Zapisati stvarne usage vrednosti odgovarajuće API porodice, poznati trošak ili označenu nepoznanicu; ne preslikavati parser druge API porodice. Uključiti cache create/refresh i neuspešne/nepoznate pokušaje. Istorijski koeficijenti i `realSpendUsd:null` nisu stvarni račun providera ili hard cap.

STT rezervacija se trenutno može osloboditi kada nema transkripta, iako proxy može već poslati audio i vratiti `audioBytes>0`. Odsustvo teksta nije dokaz da provider nije obradio sadržaj. Odluka o oslobađanju zahteva dispatch/usage dokaz ili izričit UNKNOWN ishod. Ovaj nalaz je rizik internog obračuna; nije dokazan stvarno pogrešan korisnički račun i ne rešava se promenom voice-message upload journal-a.

#### 5. Dostupno celo stablo i bezbedan cache

R04 određuje sadržaj i potpunost; R06 optimizuje njegovu dostavu i ponovnu upotrebu. Baza ostaje autoritet kategorija i ID-jeva. Trenutni `loadFullCatalogTree` prvo preuzima puni snapshot, pa tek onda poredi memorijski ključ, zato cache pogodak štedi deo rekonstrukcije, ne taj RPC/payload. Edge memorija je memorija pojedinačne instance sa ograničenim vekom; pozadinski `waitUntil` nije trajni red niti način da model vidi tu memoriju.

| Sloj | Ugovor koji implementacija treba da zatvori |
|---|---|
| Snapshot u bazi | Jedan kompletan semantički sadržaj, version i fingerprint/stamp svih relevantnih category/mode/alias/label/scope/parent promena. |
| Uslovni odgovor | Isti potpun stamp daje mali NOT_MODIFIED; hladan start ili promena daje pun snapshot. Novi RPC oblik ne stvara dvosmislene overload-e i zadržava podržani stari Edge caller koji još traži puni sadržaj. |
| Cache instance | Immutable potpun objekat, single-flight, atomska zamena, ograničen život i veličina. Otkazivanje jednog waitera ne ubija tuđ zajednički load; nepotpun objekat ne postaje pun. |
| Semantički rezultat | Ponovo koristi provereni nepromenjeni smisao za važeći nalog/uslugu/mode/handoff, uz novo bezbedno vezivanje za review. Ne prenosi staru saglasnost na novu nameru ili nepotpun BOTH. |
| Provider kontekst | Stabilan javni katalog/instrukcije prvi u promptu; promenljivi service/scope i privatni sadržaj ostaju odvojeni. Provider cache je zasebna, uslovna optimizacija. |

Postojeći META ponovo računa fingerprint i eligible count; ime META ne znači O(1). Postojeći fingerprint nije digest svih prompt bajtova: ne uključuje neposredno display label, alias label i scope. Pre NOT_MODIFIED/provider-cache upotrebe proširiti relevantni content stamp, uključujući rename uz isti normalized key. Ako merenje opravda unapred računat stamp/payload, obuhvatiti sve pisce atomarno ili koristiti izričito dirty stanje koje nije validan snapshot. Ne uvoditi novu materijalizovanu ili vektorsku kopiju kao konkurentski katalog.

Ukloniti dupli prefetch/builder snapshot za isti dual turn i bezuslovni puni prefetch po poruci. Novel-decision ključ sada nema fingerprint/model/prompt verziju ni TTL/size granicu; clarification mapa nema eviction. Dopuniti oba ograničenja i identitet. Worker builder ne treba ponovo plaćeno da pronalazi svaki već poznat važeći ID; obraditi promenjene/nerešene jedinice uz očuvan kompletan review. Unrelated catalog promena može dopustiti postojeću bezbednu revalidaciju istog plana, ne automatsko prihvatanje ili blanket odbacivanje.

Eksplicitni `cachedContent` uvoditi tek kada konkretan model/API, tačni tokeni stabilnog prefiksa, reuse, TTL i trošak skladištenja pokažu korist. Proveriti važeće pragove dokumentacije pri implementaciji; istorijska veličina JSON-a nije tokenizer. Auditski snapshot je imao 71.388 JSONB bajtova, a tadašnja prompt-tree serijalizacija 13.168 UTF-8 bajtova; to nije kompresovani HTTP, token broj, cena ili latencija. Implicitni cache pogodak nije garantovan. Nepostojanje eksplicitnog cache-a samo po sebi ne blokira ispravno izdanje.

Provider cache ključ obuhvata projekat, katalog version/fingerprint, tačan model, prompt/response verziju i svrhu kada se instrukcije razlikuju. Zajednički cache nikada ne sadrži korisnički nalog, razgovor ili privatni profil. Registry/kreiranje ne računaju na trajnost Edge memorije; identično kreiranje ograničiti lease/idempotency pravilom. Potvrđen miss/expiry/mismatch ima jedan ograničen fallback ili recreate uz pun snapshot i budžet. To nije dozvola za ponavljanje generate zahteva čiji je već poslati ishod UNKNOWN. Pri capture/Save/binder-u proveriti važeću DB semantiku i očuvati korisničku potvrdu.

#### Prihvatni dokaz, stvarno čekanje i postojeće provere

| Skup | Minimalan potreban dokaz |
|---|---|
| Prvi plan | Kontrolisani neuspeh pre capture-a i gubitak store ACK-a ostavljaju trajan obradiv posao; post-save/pending red se ne proglašava dokazom prve klasifikacije. |
| Nastavak | Restart procesa/instance, istekao lease, kasni odgovor i A→B→A čuvaju pravi owner/revision/command; uspešan raniji pokušaj prepoznaje se readback-om. |
| Semantička stabilnost | Nepromenjena usluga + „to je to”, vreme, budžet ili pin ne ponavljaju nepotrebno model; stvarna usluga/mode/handoff promena odbacuje stari rezultat. |
| Transport | Missing STOP, preveliko/truncated telo, prekid i nevažeći izlaz ne daju gotov rezultat; puna pozitivna kontrola prolazi. |
| Obračun | Foreground/BG/STT/cache pokušaji imaju odvojene poznate/UNKNOWN ishode; jedan settlement ne postaje dva; cached input se ne sabira dva puta; logging failure ne menja pravo stanje. |
| Snapshot/cache | Hladan/topao, isti/promenjen sadržaj, pun posle parcijalnog iste oznake, paralelni miss, otkazan waiter, rename/alias/mode/scope izmena, model/prompt promena, provider expiry/mismatch. |
| Ograničenost | Bounded pokušaji, ukupni rok, budžet i veličina/život cache-a; UNKNOWN ima konkretan dalji korak i kraj automatskog rada. |

Merenje razdvojiti na foreground provider, catalog load, BG provider i SQL capture, pa dodati tap→prvi korisni prikaz, tap→potvrđen rezultat/readback i vreme do pregleda. `PROVIDER` meri streaming provider, `NEED_COMPLETE`/`WORKER_COMPLETE` SQL completion; korisnički tekst ostaje iza uspešne potvrde upisa. Nijedna od tih postojećih faza sama ne meri render ili ukupno korisničko čekanje. Tačnost, celovitost i ukupni trošak imaju prednost nad samim smanjenjem broja poziva.

| Postojeća testna putanja | Rad i očuvani smisao | Šta nije dokazano njenim postojanjem |
|---|---|---|
| `supabase/proofs/ai/background_capture_receipt.test.mjs` | Sačuvati prave handlere, ACK/dijagnostiku i reprodukciju; postojeće očekivanje da isti input ne pokrene retry posle popravke prevesti u dokaz dozvoljenog trajnog nastavka. | Zeleni karakterizacioni test može danas potvrđivati kvar. |
| `supabase/proofs/ai/taxonomy_provider_budget.test.mjs` | Sačuvati budget modul, jednom settlement, unknown usage i otpornost na logging failure; proveriti stvarni BG caller. | Izolovan modul ne dokazuje da ga direktni BG fetch koristi. |
| `supabase/proofs/dynamic_taxonomy/taxonomy-postsave-worker.test.mjs` | Sačuvati receipt/lease/retry i dodati relevantnoj stvarnoj CI selekciji. | U analiziranom CI izboru nije bio pokrenut; mock RPC nije stvarni SQL lease ili pre-review posao. |
| `src/data/__tests__/ai-turn-intent-journal.test.ts` | Sačuvati account izolaciju i stale-clear zaštitu; dopuniti uređajski prekid gde treba. | Memorijski AsyncStorage mock nije gašenje procesa na telefonu. |
| `supabase/proofs/ai/background_taxonomy_failures.test.mjs` | Dopuniti odgovarajuće failure/consent i loader slučajeve kroz pravi builder i presretnut transport. | Synthetic provider/catalog nije živi trošak ili nova provera isporučenog Edge-a. |
| `supabase/proofs/ai/classification-full-catalog-edge.test.mjs` | Proveriti pravu dual/BG granu i uslovni snapshot ugovor. | `db.invalid` shadow/direct fixture ne zatvara BG loader sam po sebi. |

Istorijski testovi 40 capture/ACK, 16 completion/lifecycle, pet runner slučajeva i ostale izolovane probe zadržavaju svoj tadašnji obim; nisu novi runtime/device/cost rezultat. Pravi model/cache/countTokens i merenje troška rade se kao odvojena ograničena izvršna provera sa unapred određenim korpusom i budžetom.

**Izlaz:** trajan prvi plan i post-save nastavak imaju odvojene ispravne preduslove, ograničen oporavak i readback; aktivni transport proverava potpun odgovor; svaki pokušaj ima svoj obračun; kompletan katalog ne prenosi se bez potrebe; cache ne menja autoritet, privatnost ili korisničku saglasnost.

### R07 — Cena, odustajanje i dodatni profilni upis

#### Problem, zavisnosti i traženi rezultat

Ovaj zadatak zatvara F02/F03/F11/F13, uz R01 ugovore i R04 zaštitu pregleda. R07a ispravlja zastarelu potvrdu cene u već podržanom RSD/OFFERS domenu. R07b usaglašava satnicu tek posle odluke o njenoj osnovici. Odustajanje i dodatni profilni upis napreduju nezavisno od te odluke. Rezultat je isto razumljivo značenje cene u svim fazama, proverljiv ishod iste radnje i očuvana novija izmena profila.

#### Konkretni vlasnici

- `src/app/(app)/pregled-zadatka.tsx`
- `src/app/(app)/prilike/[id]/prijava.tsx`
- `src/contracts/projections.ts`
- `src/data/aiTaskReviewClientService.ts`
- `src/data/applicationClientService.ts`
- `src/data/workerProfileClientService.ts`
- `src/hooks/useOwnedEditor.ts`
- `src/ui/objava/reviewFacts.ts`
- `supabase/functions/uskoci-ai-interview/index.ts`
- `supabase/proofs/ai/currency_correction_characterization.test.mjs`
- `src/data/aiNeedV2Production.ts`
- `supabase/migrations/20260910130851_clean_w02_resolved_location_authority.sql`
- `supabase/migrations/20260904230000_clean_ru4_ai_edit_conversation.sql`
- `supabase/migrations/20261021101159_staged_task_replacement.sql`
- `supabase/migrations/20261021101527_staged_task_replacement_noop_guard.sql`

SQL autoriteti su važeći fact writer i review/prepare vlasnici, `validate_need_v2_fact`, `private.assert_application_price_v5`, `private.need_material_snapshot`, `need_full_edit_snapshot`, `task_replacement_material`, `rpc_publish_need_canonical`, `cancel_replaced_task` i `finalize_task_replacement`. Migracioni fajl je trag porekla; pre promene potvrditi stvarno tekuće telo i njegove potpise/dozvole.

#### R07a — Korekcija cene i tačan prikaz

1. Kada korisnik promeni značenje ranije potvrđene cene, u istom kanonskom toku povući staru saglasnost ili je vratiti u stanje koje traži novu potvrdu. Primer „5.000 RSD” pa „mislio sam evre” ne sme ostaviti 5.000 RSD kao važeću potvrđenu cenu. Sistem ne izmišlja kurs i ne uvodi podršku za EUR.
2. Nerešena ili nova cena mora ostati ista kroz writer, signed review, Save i eventualnu objavu. Kasnija nepovezana poruka ne sme samo ukloniti upozorenje, a sačuvati pogrešnu potvrdu. Sačuvati sve druge jasne činjenice. Prelazak na OFFERS proveriti kroz njegove stvarne posebne uslove; ne pretpostaviti da OFFERS i MY_PRICE imaju isti writer.
3. Odvojeno normalizovati protivrečan `displayValue` kao „100 EUR” uz tipizovanih 100 RSD. `src/ui/objava/reviewFacts.ts` već formatira cenu iz broja; taj ispravan put ostaje. Pratiti stvarne potrošače i sačuvane prezentacione kopije, bez tvrdnje da je glavni pregled dokazano prikazivao pogrešnu valutu.
4. **Povučena sumnja ostaje povučena:** ranije pročitano živo `private.need_material_snapshot` sadrži `priceBasis`, iako njegov source prethodnik nije isti. Ne popravljati nepostojeći dokazani live kvar. Sa R12 proveriti reproduktivnost izvora i stvarnu `price-basis-only` izmenu kroz signed review/replacement; ranije živo telo ne proglašavati sveže pročitanim bez novog upita.

#### R07b — Satnica kao kompletan poslovni ugovor

Pre izmene odrediti da li se cena odnosi na jednu osobu, celu ekipu ili eksplicitno podržane obe osnovice. Za dve osobe, tri sata i satnicu od 1.200 RSD ukupan iznos je 7.200 RSD kod satnice po osobi, odnosno 3.600 RSD kod satnice cele ekipe. Predlog za jednostavan početni ugovor je jasno označena satnica po osobi; to nije unapred odobrena odluka.

Nakon odluke usaglasiti HOURLY/PER_HOUR kroz fact validator, Edge guard, writer, pregled, objavu, prijavu, izbor, Dogovor i dekodere. Broj ljudi, jedinica, iznos, valuta i trajanje moraju imati isto značenje. Nepoznato trajanje ne proizvodi izmišljenu konačnu sumu. Ne uklanjati samo TOTAL guard. Obuhvatiti podržani stari Discovery decoder, kod kojeg jedna HOURLY stavka može odbiti celu PAGE poruku; ta kompatibilnost nije dokazan uzrok ranijih slika.

#### F11/F13 — Ista radnja i zaštićena paralelna izmena

Posle izgubljenog abandon odgovora čitati ishod iste operacije i razlikovati OPEN, ABANDONED i UNKNOWN. Ne pokretati novi prepare nad već napuštenim razgovorom niti tvrditi da postoji Need kada ga nije bilo. Ponuditi tačnu proveru i povratak. Abandon menja status; nije obećanje fizičkog brisanja svih podataka.

Opcioni izbor „dodaj veštinu” posle prijave mora biti namera za tačnu uslugu, nalog i važeću reviziju. Koristiti postojeći autoritativni merge/CAS ili odgovarajući aktivni vlasnik; ne slati staru celu uhvaćenu skills listu. Ponoviti proveru konteksta posle await granica i odbiti kasni odgovor posle A→B→A promene naloga/generacije. Sačuvati paralelno dodatu veštinu. Već potvrđena prijava ostaje uspešna kada ova sporedna radnja ne uspe.

#### A24 — Zamena javne objave

Priprema i pregled izmene ne gase staru objavu. Uspešna nova objava, zatvaranje stare i obrada starih prijava moraju ostati u istoj transakciji; kasnija greška vraća tu transakciju. Prijave se ne prenose na nove uslove. Sačuvati `NO_MATERIAL_CHANGE` zaštitu. Pokriti uspešnu zamenu, odbijenu/neizmenjenu izmenu, izgubljen ACK i grešku posle početka finalizacije. Klijent mora otvoriti stvarni potvrđeni rezultat; gubitak odgovora nije nova komanda objave.

#### Provere i uslov završetka

| Postojeća provera | Kako je koristiti i šta još mora da dokaže |
|---|---|
| `supabase/proofs/ai/currency_correction_characterization.test.mjs` | **Sačuvati reprodukciju; promeniti cilj posle popravke.** Izolovana stvarna Edge/SQL tela reprodukuju zadržanu staru potvrđenu cenu i HOURLY nesklad. To je test analiziranog CI izbora koji NAMERNO prolazi kada se postojeći kvar reprodukuje. |
| `src/data/__tests__/application-proportional-price.test.ts` | **Sačuvati.** Nezavisan celobrojni oracle i proporcionalni TOTAL/razni modovi. Nije potvrda konačne poslovne odluke o satnici/valuti niti celu writer putanju. |
| `src/data/__tests__/review-exits-and-place.test.tsx` | **Sačuvati i dopuniti.** Odbijen/unknown abandon i UX readback radnja sa mocked service. Dopuniti slučaj stvarno ABANDONED bez zasebnog Need-a i razrešenje kroz pravi read port. |
| `src/data/__tests__/application-composer-read.test.tsx` | **Sačuvati i dopuniti.** Uspešna prijava ostaje uspešna ako opcioni profile save zakaže. Ne pokriva paralelno izmenjene skills i A→B→A između success-a i dodatnog upisa. |

Najmanji novi dokazi su stvarni signed accept/Save/publish tok nakon korekcije cene, uspešan abandon sa izgubljenim ACK-om bez Need-a i kasni dodatak veštine uz paralelnu promenu i A→B→A. Pozitivne kontrole: nova važeća RSD cena može se potvrditi; OPEN se ne proglašava napuštenim; dodavanje tačne veštine u istoj dozvoljenoj reviziji radi. A24 se izvršava preko tekućih poslovnih vlasnika, ne direktnim fixture insertom koji preskače objavu.

Uslov završetka je potvrđen poslovni rezultat kroz pravi reader/writer i razumljiv prikaz na telefonu. Stare izolovane reprodukcije ne dokazuju da je pogrešna cena stvarno objavljena ili da je izazvan live incident. Pri popravci sačuvati ulaz koji je reprodukovao kvar i promeniti završno očekivanje na ispravno ponašanje, u okviru C15.


### R08 — Prirodan završetak razgovora i veran sačuvani rezultat

#### Problem i traženi rezultat

R08 zatvara F09/F10/F12 i kontinuitet naručiočevog završnog pregleda, uz R04 semantiku i relevantni deo R07. Korisnik kaže više jasnih činjenica, dobije najviše jedno stvarno potrebno pitanje, pregled iste namere i posle potvrde ponovo otvara isti sačuvani sadržaj. Opciona biografija, detaljan kalendar ili stari formular ne postaju prepreka završetku.

#### Konkretni vlasnici

- `src/app/(app)/profil/razgovor.tsx`
- `src/data/__tests__/ai-natural-server-guard.test.ts`
- `src/data/workerAiClientService.ts`
- `src/hooks/useWorkerExecutionModes.ts`
- `src/ui/workerProfile/WorkerAiPresentation.tsx`
- `src/ui/workerProfile/WorkerProfilePresentation.tsx`
- `src/ui/workerProfile/WorkerProfileSaved.tsx`
- `supabase/functions/uskoci-ai-interview/index.ts`
- `supabase/functions/uskoci-worker-interview/index.ts`
- `src/app/(app)/nova.tsx`
- `src/app/(app)/pregled-zadatka.tsx`
- `src/app/(app)/profil/radnik.tsx`
- `src/data/aiTurnIntentJournal.ts`
- `src/data/aiTaskReviewClientService.ts`
- `src/data/reviewFactProblem.ts`
- `src/hooks/useOwnedEditor.ts`
- `src/ui/v2/draftSummary.ts`
- `src/ui/v2/IntakePresentation.tsx`
- `src/contracts/needFactsV2.ts`
- `src/ui/location/ConversationPointAsk.tsx`
- `src/ui/location/NeedLocationForm.tsx`
- `src/ui/workerProfile/workerProfileDraft.ts`
- `src/contracts/workerAreas.ts`
- `supabase/functions/_shared/workerServiceModeContext.mjs`
- `supabase/functions/_shared/serviceExecutionInstruction.mjs`
- `supabase/functions/_shared/taxonomyPostSaveWorker.mjs`
- `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql`

#### Završetak, potvrda i očuvanje namere

1. U postojećem snapshot/Edge/decoder/ekran ugovoru povezati autoritativni završetak sa potrebnim poslovnim činjenicama. `hasProfileContent`, modelov tekst „gotovo”, `canAccept`, classification READY i saved receipt ostaju različiti signali. „To je to” nije automatski Save.
2. Jedan vlasnik sledećeg pitanja bira najvažniju stvarnu nejasnoću, a čuva ostale za naredni korak. Sastavljeni guard za ponavljanje i dnevnicu/satnicu ne sme tražiti više odluka odjednom. Ocenjivati značenje poruke, ne broj upitnika. Sve jasno izrečene činjenice se zadržavaju.
3. Kod naručioca rešiti skriven nedostatak tekstualnog `need.category`, koji može sprečiti završnu karticu bez vidljivog objašnjenja. To je podatak koji sistem dovršava; ne vraćati administriranje kategorije korisniku. Tekst kategorije nije konačni category ID niti univerzalni READY uslov.
4. Sačuvati blaži dozvoljeni ulaz u pregled u odnosu na završnu karticu. Prepare stvara zamrznuti review, ali ne prihvata i ne objavljuje Need. Neposlat tekst nije potvrđen deo pregleda. SaveDraft čuva privatni prihvat bez automatskog evaluate/publish; završni PUBLISHED prikaz traži readback istog Need-a i revizije.
5. DRAFT worker profil može na istom pregledu izabrati Save ili Save+activate, bez obaveznog prethodnog zasebnog Save-a. `activate=false` pri izmeni ACTIVE profila nije deaktivacija. Pending nove usluge ne ukida automatski sva ranija potvrđena prava.
6. Posle Save-a i ponovnog otvaranja profila čitati merodavan sačuvan model iste revizije i prikazati mode, relevantnu predaju, oblast i status po usluzi. Ne rekonstruisati nedostajući detalj iz stare lokalne review kartice. Kratke oznake i sklopljeni duži detalji su vizuelni predlog, ne novi obavezni formular.
7. Copy jasno razlikuje stvarno pitanje korisniku od unutrašnje obrade. „Čeka potvrdu kategorija” ne treba da izgleda kao korisnikov administrativni posao. Za REVIEW_REQUIRED dati smislen razlog i dostupnu obnovu gde je dozvoljena; ACTIVE sam nije obećanje da je svaka nova usluga već uključena u povezivanje.

Tema ili ispravka vraćaju u isti razgovor bez implicitnog slanja ili otvaranja nove sesije. Čuvati journal pre slanja, identitet pokušaja bez privatnog body-ja, account/focus/generation zaštite i noviji neposlati unos od kasnog odgovora. Zadržavanje teksta u montiranoj ruti nije automatski dokaz da svaki znak preživljava gašenje procesa; taj vek nacrta jasno definisati i proveriti.

#### Dve mape imaju različito značenje potvrde

| Tok | Kada se podatak stvarno čuva | Potrebno ponašanje pri izlasku |
|---|---|---|
| `ConversationPointAsk` | Svaki potvrđen pin odmah ide na server uz očekivanu geografsku reviziju; START može biti sačuvan dok END nedostaje. | Prikazati stvarno sačuvanu tačku i jasno nedostajući ostatak. |
| `NeedLocationForm` u pregledu | Tačke su lokalne do „Primeni potvrđene tačke”, kada se priprema novi review. | Izlazak pre Primeni ne prikazivati kao sačuvan skup. |

Vizuelno ujednačavanje ne spaja writere niti menja transakcije. Oblast rada, profilni pin i fizička predaja ne postaju isto polje. GPS dozvola za „Moja lokacija” nije opšti uslov svakog prikaza mape. Prikaz i interakciju proveriti kroz stvarni MapLibre/OpenFreeMap native/web vlasnik, fokus i pin reviziju. A24 zamena objave mora ostati ista kao u R07.

#### Ograde i kompatibilnost koje ostaju

Sačuvati aktivni name-adoption i uncertain-write recovery u `profil/radnik.tsx` i `workerProfileDraft.ts`; povučen manual editor ne čini ceo modul mrtvim. `inferWorkerExecutionModes` poziva se samo kada classificationState nedostaje; signed READY/PENDING put ga preskače. Ne opisivati sve sadašnje modove kao nagađanje niti uključivati stari formular da bi fixture prošao.

Deadline prepare bira posebne `rpc_prepare_ai_task_review_deadline` i `rpc_prepare_ai_task_review_deadline_taxonomy` samo kada je odgovarajući javni build flag doslovno `true`. Pre njegovog eventualnog uključivanja potvrditi ta dva RPC-a. Njihovo odsustvo u ranijem pregledu nije dokaz da nedostaje obični aktivni prepare, niti su time očitane efektivne zastavice starog APK-a/OTA.

#### Provere i uslov završetka

| Postojeća provera | Kako je koristiti i šta još mora da dokaže |
|---|---|
| `src/data/__tests__/worker-ai-conversation-recovery.test.tsx` | **Sačuvati i dopuniti.** Prazan/resumed chat, last-good offline stanje, jedna provera i odsustvo parcijalnih kartica. Servis i journal su testne zamene; nije dokaz autoritativnog completion signala u stvarnom toku. |
| `src/ui/workerProfile/__tests__/worker-ai-review.test.tsx` | **Sačuvati i dopuniti.** Per-service mode/handoff pregled i signed no-write policy bez stare obavezne opreme. Pregled sa zadatim props ne dokazuje da sačuvani profil prikazuje isti sadržaj. |
| `supabase/proofs/dynamic_taxonomy/worker-finish-mode-completeness.test.mjs` | **Sačuvati; dodati relevantnoj CI selekciji.** Jedna završna smernica i vidljivost nerazrešenih usluga bez implicitne potvrde. U analiziranom CI izboru nije izabran; helper nije dokaz završetka/Save/binding cele ponude. |
| `supabase/proofs/ai/interview_voice_one_question.test.mjs` | **Sačuvati i dopuniti.** Regex provera da zajednička prompt instrukcija traži jedno pitanje, pamti jasne podatke i ne tvrdi Save autoritet. Ne izvršava model ni guard; prisustvo rečenice u promptu ne dokazuje stvarni razgovor ili kombinaciju više nejasnoća. |

Dopuniti `src/data/__tests__/ai-natural-server-guard.test.ts` stvarnim kombinovanim odgovorom. Pravi tok mora obuhvatiti više usluga, BOTH istog ID-a, konkretnu predaju, normalno „to je to”, Save i ponovno otvaranje profila. Nepoznat obavezan podatak ostaje jasno označen; delimičan BOTH ne postaje kompletan pregled. Uređajski dokaz uključuje mali ekran, veći tekst, tastaturu, povratak i dostupne potvrde.

Za svaki primarni AI/pregled/profil/map ekran popuniti zajedničku specifikaciju ekrana i radnji u ovom planu: podaci i autoritet, loading/empty/error/partial/unknown, dozvoljene radnje, tekst, prekidi i mobilni prikaz. Uspešna props proba nije dokaz da isti sadržaj dolazi iz sačuvanog server modela. Nema parcijalnih kartica ili dodatnih mode/equipment/bio formulara samo zato što ih istorijski dizajn ili test sadrži.


### R09 — Obaveštenja, poruke i tačno odredište

#### Problem, zavisnosti i traženi rezultat

R09 zatvara F20/SB08/SB10 posle relevantnih R01/R05 ugovora. Poruka i prilika imaju autoritativan događaj, dovoljan ograničen kapacitet obrade, poštovane nezavisne preference i bezbedno odredište na dodir. Upis poruke, SQL tick, HTTP poziv, provider potvrda i uočena isporuka na telefonu predstavljaju različite dokaze.

#### Konkretni vlasnici

- `src/app/(app)/profil/obavestenja.tsx`
- `src/ui/AgreementChat.tsx`
- `src/ui/notifications/PushPreferences.tsx`
- `supabase/functions/_shared/pushNotificationCopy.mjs`
- `supabase/functions/uskoci-push-transport/index.ts`

Realtime potrošači su u prethodnom server pregledu imenovani kao `agreementInvalidationService.ts`, `useAgreementIncomingRefresh.ts` i `useConversationInbox.ts`; njihove pune fizičke putanje nisu navedene u dostavljenim prilozima i moraju se razrešiti pre izmene. SQL vlasnici uključuju `rpc_claim_push_transport`, `edge_worker_tick_v5`, važeći begin/suppression/dispatch, message/opportunity resolver i group sender sa immutable visibility. Pročitati njihove tekuće definicije i stvarne pozivaoce, bez slepog puštanja istorijskog candidate paketa.

#### Sveža konfiguracija, kapacitet i nepoznat ishod

1. Najpre osvežiti bezbednu konfiguraciju, gates i trag SQL wake → HTTP invocation → claim → provider → receipt → uređaj. U reviziji 7 push v37 odgovara source-u, redovni poziv radi jedan SEND i jedan RECEIPT, a minute SQL cron može završiti kao NOT_CONFIGURED ili IDLE. Poslednji TICK_OK bio je zastareo. Ti podaci nisu dokaz današnje spremnosti ili potpunog kvara.
2. Potreban kapacitet izvesti iz stvarnog dozvoljenog talasa i drugih događaja. U postojećem vlasniku odabrati bounded loop/batch ili drugo ograničeno rešenje uz ukupni rok, lease, pravičnost SEND/RECEIPT rada i izbegavanje gladovanja. Granice šest leases i 60 claims/s nisu dokaz već implementiranog batch sender-a. Meriti starost najstarijeg posla, zaostatak, drain i uspeh potvrde.
3. Čuvati token-first zaključavanje, session/world/Need/revision kontrole, isticanje, suppression i čišćenje starih provider tickets. Restart i nepoznat provider ishod ne proizvode slepi resend. Idempotentan poslovni događaj ili receipt ne znači garantovanu tačno jednu vidljivu mrežnu isporuku; to ne obećavati u UI-ju ili dokazu.

#### Admission, nezavisne preference i target

Proveriti aktivnu ručnu prijavu iste revizije pre prve opportunity delivery. Deduplikacija već napravljenog događaja ne uklanja semantički nepotrebnu prvu poruku. U zajedničkom vlasniku definisati šta se suzbija za active/withdrawn/rejected/selected, prethodnu reviziju i trku response/dispatch. Ne oslanjati se na istorijski EX06D-F5 označen NOT APPLIED ili fixture bez `worker_account_id`.

PUSH on / IN_APP off ostaju legitiman nezavisan izbor. Message i opportunity tačno odredište treba da koriste odgovarajući PUSH/internal receipt autorizacioni trag, bez potajnog IN_APP opt-in-a. Ne otvarati tuđu, nevidljivu ili isteklu poruku/priliku da bi link izgledao ispravno. Kada cilja više nema, ponuditi pošten dozvoljen opšti povratak; ne nagađati ID. Proveriti obe uloge, isteklu/opozvanu sesiju, zatvoren nalog i blokiranje.

Jedan UI prekidač koji piše REQUESTER pa WORKER treba ili da koristi postojeći atomski autoritet, ili da pouzdano čita oba ishoda i nastavlja samo nezavršen deo. Back mora uzeti u obzir writing/unknown. Prvi uspešan upis ne predstavlja se kao potpun neuspeh, a drugi neuspešan kao potpun uspeh.

#### Grupne poruke, osvežavanje i privatnost

Group sender zadržava osnovni upis poruke, receipt i immutable vidljivost, a dobija potreban događaj i autorizovan target. Ponovljeni isti message receipt ne pravi dupli poslovni događaj. Publika događaja mora odgovarati dozvoljenoj publici poruke; kasniji izlazak/blokiranje ne otvara nedozvoljen pristup. Ne emitovati svim članovima bez provere. Prethodni predlog `group-message-events-20261021` nije dokaz primenjenog emit-a.

Sačuvati Postgres Changes nad `agreement_invalidations_v1(agreement_id,revision)` kao hint za autoritativno ponovno čitanje, uz account/focus/session ograde. Hint nije puna poruka ni ovlašćenje za mark-read. Odsustvo private Broadcast politike nije samo po sebi kvar postojećeg CDC toka. Dovršiti group event/refresh kroz njegovog stvarnog vlasnika.

Refresh u `AgreementChat.tsx` učiniti stvarno vidljivom i dostupnom radnjom ili povući skrivenu fokusabilnu kontrolu uz dostupnu alternativu. `height:0`/`opacity:0` nije politika pristupačnosti. Poseban postojeći error retry ostaje upotrebljiv.

#### Provere i uslov završetka

| Postojeća provera | Kako je koristiti i šta još mora da dokaže |
|---|---|
| `src/data/__tests__/notification-preferences-client.test.ts` | **Sačuvati.** Odvojene postavke, owner/CAS, neizvestan ishod i bez tihog opt-in-a. Ne dokazuje server resolver kada je PUSH on / IN_APP off. |
| `src/data/__tests__/message-push-ingress.test.tsx` | **Sačuvati i dopuniti.** Owned događaj, poslednji tap, unavailable bez nagađanja i hladan foreground povratak. Resolver i native notification su zamene; ne zatvara stvarni provider/device tap. |
| `src/data/__tests__/v5-group-conversation-controller.test.ts` | **Sačuvati.** Čitanje/upis kontrolera, istorija i kasni odgovor/permission granice. Sam message upis ne stvara događaj za obaveštenje. |
| `supabase/proofs/chat/exact_message_event_resolver_proof.mjs` | **Sačuvati nameru; uskladiti očekivanje.** Istorijska stvarna SQL granica eksplicitno odbija suppressed/off IN_APP i PUSH kanal. Ako željena nezavisna PUSH postavka ostaje podržana, potreban je novi bezbedan dokaz cilja; ne uključivati IN_APP potajno. |

Izvršiti mali ograničen burst: jedan primalac je već odgovorio istoj reviziji, drugi nije; PUSH on/IN_APP off; grupna poruka sa tačnom publikom; zatim stvarni dodir notifikacije. Uključiti foreground, background, ugašenu aplikaciju, hladan start, isti događaj, revoked/expired sesiju i odsutan cilj. Namerno isključen push se ne šalje. Istorijski transport koji presreće Expo, koristi jedan uređaj i IN_APP on ostaje lokalni dokaz, ne novi dokaz kapaciteta, nezavisnih postavki ili native tap-a.


### R10 — Život podataka, saglasnosti, izvoz i zatvaranje naloga

#### Problem i traženi rezultat

R10 zatvara F19/SB03 uz R04 potpisanu nameru i R01 dozvole. Korisnikova potvrđena područja rada moraju opstati kroz čuvanje, izvoz i arhivske/reset projekcije; nova verzija pravila zahteva novu saglasnost; opoziv pristupa i završetak brisanja imaju stvarno potvrđen ishod. Aktivacija zatvorenih mogućnosti sledi stvarnu ispravku i proveru.

#### Konkretni vlasnici

- `src/app/(app)/profil/pravna.tsx`
- `src/ui/legal/legalReview.ts`
- `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql`

Aktuelni SQL autoriteti su `private.data_export_worker_candidate_v5(jsonb)`, `data_export_snapshot`, `closure_taxonomy_project_v1`, `closure_taxonomy_inventory_v1`, `closure_redaction_relations_v5`, `closure_redaction_patch_v5`, `closure_taxonomy_snapshot_guard_v1`, `closure_taxonomy_scope_v1`, export/grant/retention/closure komande i `public.rpc_closure_api_guard`. Proveriti i stvarne Storage/Auth executore. Owner je važeće telo i njegov program/policy ugovor, ne naziv starog kandidata.

#### Ispravka projekcija i potpunost kopija

1. U postojeći whitelist `data_export_worker_candidate_v5` dodati validiranu `workAreas` projekciju i pratiti je kroz workerAiDrafts/profile, workerAiReviews/profile i arhivski/reset candidate/review.profile. `workerAiSaves` sa samo reviewId/createdAt nije zamena za celu kopiju profila.
2. Očuvati tip, redosled i stvarno potvrđene COUNTRY/CITY/RADIUS vrednosti iz kanonskog, serverom razrešenog pregleda. U izolovanom canary-ju porediti originalnu nameru, signed review, Save, svaku živu projekciju i arhivsku/reset kopiju.
3. Stari WAR01 paket sa dvanaest funkcija nije nova migracija za slepu primenu. Preuzeti samo relevantno značenje nedostajućeg polja i uskladiti tekućeg vlasnika, njegove dozvole, source/projection/policy/certificate vezivanje i zavisnosti.
4. Šest od sedam DEV snapshot/backup tabela ima tekuće closure/redaction veze. `dev_phase1_20261014_needs_snapshot` čitaju i guard/dinamički scope. Pre njihovog povlačenja razrešiti retention i potreban istorijski dokaz, prevezati inventare/guard/scope i ponovo proveriti izvoz i brisanje. Odsutna kvalifikovana referenca za catalog snapshot nije dokaz odsutne operativne potrebe. Detaljan SV10 JSON nije dostavljen; ne izmišljati njegovu listu objekata.

#### Saglasnost, autorizacija i odbijanje nespremnog rada

Za legal-v1 unknown → legal-v2 tok autoritativno završiti ili otkazati prethodni pokušaj, pa tražiti izričitu potvrdu novog TERMS/PRIVACY hash-a. Jedan ABSENT ne dokazuje da zahtev neće naknadno stići. Stari request ne sme potvrditi novi dokument, a ekran ne sme zauvek ostati u READ_REQUIRED bez bezbednog nastavka.

Novi export zahtev bez važećeg binding-a mora ostati odbijen pre upisa zahteva, uz tačno objašnjenje. Sačuvati idempotent replay, exact snapshot, owned download i autorizaciju pre vraćanja bajtova. Testirati strani nalog, ponavljanje, revoke/download grant i zakašnjeli pokušaj; opozvan pristup se ne oživljava starim request-om.

Revizija 7 je dokumentovala false retention-source/export/erasure binding. Ne menjati očekivani digest, certifikat ili flag samo radi zelenog statusa. Zatvoriti projektore, kopije i odgovarajuće semantičko vezivanje pa izvršiti proveru tekućeg sadržaja. Dugme koje stalno odbija obavezan korisnički postupak nije završen javni proizvod.

#### Brisanje i odvojene sistemske granice

Brisanje ima zaseban dokaz svih relevantnih kopija, medija/voice, Storage i Auth koraka. Ne izjednačavati uredno dostavljene export bajtove sa potpunim izvozom niti uspešan export sa izvršenim brisanjem. Finalizovati tek nakon nezavisnih potvrda potrebnih operacija; jasno prikazati status, rok i dozvoljeno zadržavanje.

Sačuvati privatne buckete i stvarne MIME/size granice, owner-prefix i restrictive/account-open politike, immutable server putanju, hash/veličinu, generation/lease, jednu priznatu dispatch nameru i pozitivan readback. U reviziji 7 su profile-media 5 MiB, agreement-voice 4 MiB i data-export-artifacts 8 MiB; pre promene proveriti tekuća podešavanja. Unknown upload nije dovoljan razlog za novi POST ili brisanje journal-a.

Data API pre-request hook ne zatvara automatski Storage/Realtime niti dokazuje erasure spremnost. Testirati te granice odvojeno. Potpuna Auth management konfiguracija nije prethodno potvrđena; efektivne session/redirect/SMTP/provider vrednosti proveriti kroz podržan pristup. Cityless REMOTE aktivacija ostaje zasebna poslovna promena, jer review/activation i submit/select imaju sopstvene city uslove; ne uvoditi je kroz izvoz.

#### Provere i uslov završetka

| Postojeća provera | Kako je koristiti i šta još mora da dokaže |
|---|---|
| `src/data/__tests__/p1-legal-client.test.ts` | **Sačuvati i dopuniti.** Bundle decode, stabilan request i poruka o version drift-u. Dopuniti unknown prihvat starog bundle-a nakon pojave novog sadržaja u montiranom UI toku. |
| `src/data/__tests__/p2-data-export-delivery-client.test.ts` | **Sačuvati.** Auth/transport rokovi, neizvestan upis i exact streamed bytes. Uspelo byte delivery ne dokazuje potpunost polja celog izvezenog naloga. |
| `supabase/proofs/legal/p1_legal_consent_proof.mjs` | **Sačuvati nameru; uskladiti alat sa sadašnjim vlasnikom.** Istorijski lokalni server consent/replay dokaz. Nije current UI unknown readback niti celokupan pravni lifecycle. |
| `supabase/proofs/legal/p2_data_export_proof.mjs` | **Sačuvati nameru; uskladiti alat sa sadašnjim vlasnikom.** Istorijski local export/grant/race dokaz nad tadašnjim roster-om. Stari dataset spisak ne obuhvata novo workAreas polje ni sve današnje arhivske kopije. |

Najmanji izvršni skup: sintetički profil sa svim podržanim tipovima workAreas; potpun autorizovan izvoz i poređenje svih kopija; strani nalog; revoke i kasni download; ponovljeni zahtev; zaseban legal-v1 unknown → v2 montirani UI; završetak account closure uz sve relevantne kopije. Nespremni binding ostaje zatvoren tokom negativne kontrole.

Istorijski P1 v1→v2 server dokaz ne zatvara SB03 UI; P2 tadašnji roster ne obuhvata nova workAreas/sve sadašnje arhive; P3 ograničeni AI_ABANDONED_UNBOUND adapter ne dokazuje ceo account closure; stari P4 READY nije današnja dozvola aktivacije. Očuvati korisne grant/race/lock dokaze, a proširiti samo promene i nedostajuće granice.


### R11 — Ostali ekrani, oporavak i kontrolisano čišćenje

#### Zajednički rezultat i granica rada

R11a–h zatvaraju konkretne preostale SB/X nalaze i povezane regresije. Svaki podzadatak dobija ekran/radnju iz inventara ovog plana, stvarnog reader/writer vlasnika, prikaz potrebnih stanja i dokaz korisničkog ishoda. Funkcionalno dovršavanje odvaja se od uslovnog povlačenja istorije; potpuna reorganizacija svakog starog fajla nije preduslov za popravljanje aktivnog ekrana.

Sačuvati `useOwnedEditor`, journal-e, signed review, autoritativni readback, lifecycle/ACK zaštite, primenjenu SQL istoriju i aktivne formattere. Cleanup C01–C19 iz posebne sekcije ovog istog plana određuje tačne jedinice promene. Broj 912 znači uslovne odluke pri povlačenju, ne broj fajlova za brisanje; 180 putanja uključuje ciljne i kontrolne fajlove. Detaljni nedostavljeni registar nije dozvola da se nepoznati deo pretpostavi mrtvim.

#### R11a — Početna i navigacija; SB01 i SB11 regresija

**Vlasnici:** `src/ui/home/HomePresentation.tsx`, `src/app/(app)/index.tsx`, `src/app/(app)/moje-prijave.tsx`. Prečica iz moje prijave vodi na postojeću javnu `/prilike/[id]` rutu; owner put ostaje samo za sopstveni zadatak. Ne menjati serverske dozvole da bi pogrešno odredište proradilo.

Proveriti ulogu, ID, povratak i stanje sesije na početnoj, javnom detalju i listi prijava. Prikaz promenjenog sadržaja ne sme biti blokiran zastarelim search stanjem. SB11 glavno rešenje ostaje u R02: `src/data/discoveryV1SearchOwner.ts`, `src/ui/v2/discovery/recentSearches.ts`, `src/ui/v2/detail/useTaskFit.ts`. Decode izuzetak završava busy; recent nalog postaje loaded tek nakon prihvaćenog čitanja ili dobija ponovljiv fallback; fit ključ obuhvata relevantan mode/pin/kraj/reviziju. Odgovori obrnutim redom ne menjaju noviji upit. Nalaz nije dokaz da je živi PLACES već poslao neispravan odgovor.

#### R11b — Ocene i javni komentari; SB02/SB09

**Vlasnici:** `src/ui/reviews/useGivenRatings.ts`, `src/ui/reviews/useReceivedReviews.ts`, `src/app/(app)/profil/ocene.tsx`, `src/data/focusedResource.ts`, `src/ui/reviews/ReviewCommentField.tsx`, `src/ui/reviews/ReviewCommentsSection.tsx`, `src/ui/system/PublicProfileSheet.tsx`, `src/data/reviewCommentsClientService.ts`.

Invalidirati posle potvrđenog upisa ocene i obnoviti prvu stranu primljenih ocena na definisan povratak. Isti skup završenih Dogovor ID-jeva nije dokaz da su ocene nepromenjene. Čuvati account/revision granice i poslednji dobar sadržaj pri privremenoj grešci.

Povezati već obećani javni komentar sa dozvoljenim javnim čitačem/prikazom. Context/submit i rating tok ostaju aktivni. Promena publike ili ukidanje obećanja zahteva konkretnu poslovnu odluku, ne prikriven cleanup. Dokaz uključuje novu ocenu uz iste ID-jeve, refocus, javni/sopstveni profil i stvarnu vidljivost komentara; props test sopstvenog profila ne zatvara javni tok.

#### R11c — Mediji, safety i život naloga; SB04/SB05/SB15/X01/X06

**Vlasnici:** `src/features/voiceMessages/voiceMessageComposer.ts`, `src/data/agreementVoiceClientService.ts`, `src/data/voiceBinaryRead.ts`, `src/data/serverReceipt.ts`, `src/hooks/useAgreementPhotos.ts`, `supabase/functions/uskoci-media/index.ts`, `supabase/candidates/chat_voice_b1a_feature_chain.sql` kao istorijski ugovorni trag, `src/app/(app)/profil/fotografija.tsx`, `src/ui/profile/ProfilePhotoPresentation.tsx`, `src/ui/media/useTaskPhotoUploads.ts`, `supabase/functions/uskoci-ai-interview/index.ts`, `src/data/aiNeedV2Production.ts`, `src/app/(app)/nova.tsx`, `supabase/migrations/20260913044510_clean_v5_unknown_ai_turn_exit.sql`, `src/ui/safety/SafetyScreen.tsx` i `src/ui/safety/blockOutcome.ts`.

- Voice ABSENT posle pokušaja ne uklanja trajni identitet pre server cancel/reconcile. Pokazati PROCESSING/STAGED i bezbedan oporavak. Spoljašnji 15 s i unutrašnji 30 s rok usaglasiti kroz jednog timeout/abort vlasnika, umesto međusobnog prekidanja.
- Avatar sa sačuvanim UPLOAD journal-om i izgubljenim RAM bajtovima prvo proverava/otkazuje stari pokušaj prema avatar ugovoru. Tek potvrđen završetak oslobađa novu selekciju. Server-primljen upload može biti oporavljiv; conversation-only task photo API ne kopirati kao avatar rešenje.
- Photo-only claim i completion dobijaju isti kanonski tekst i attachment identitet/hash. Čuvati zaštitu od promene sadržaja pod istim ključem. Stara handler proba bila je sintetički 502 naspram tekstualne 200 kontrole, uz nepromenjena relevantna tri fragmenta; nije dokaz kvara svake fotografije niti trenutno izvršene cele Edge verzije.
- Nevažeći lokalni safety ključ dobija konkretan kontrolisan oporavak samo korumpiranog zapisa. Važeći UNKNOWN zahtev mora zadržati server reconciliation; ponavljanje saveta „otvorite ekran” nije oporavak.
- Neposredno pre prikaza potvrđenog toast-a ponoviti account/revision/lifecycle proveru. Postojeći Undo već ima account/revision ograde i ostaje. Ovo je problem veka prikaza, ne dokaz neovlašćenog upisa.

Proveriti restart sa izgubljenim bajtovima, ABSENT i kasni claim, uspešan server upload, retry/proveru, odjavu, A→B→A i dva konteksta istog naloga. Memorijski mock koji vrati STAGED nije dokaz gubitka procesa. Media i život podataka ostaju povezani sa R10, bez slabljenja Storage privatnosti.

#### R11d — Neposlati nacrti i delimični upisi; SB06/SB07/X02

**Vlasnici:** `src/ui/support/useSupportController.ts`, `src/ui/support/SupportDetailScreen.tsx`, `src/ui/support/SupportNewScreen.tsx`, `src/ui/agreements/AgreementActionsScreen.tsx`, `src/ui/agreements/agreementActionsModel.ts`, `src/ui/v2/draftSummary.ts`, `src/app/(app)/profil/podaci.tsx`, `src/ui/profile/writeWorkName.ts`.

Razdvojiti neposlat nacrt od poslate trajne komande. Nacrt podrške i odgovor preživljavaju običan background/povratak prema dogovorenom veku; nameran izlazak dobija razumljivu odluku. Posle potvrđenog slanja i pri promeni naloga privatni nacrt se čisti prema vlasniku, bez prenosa drugom nalogu.

Razlog/predlog izmene Dogovora vezati za account, agreement i version. Pri povratku očuvati sadržaj i obnoviti važeći review. Start-only termin usaglasiti kroz model, writer, read i UI; samo uklanjanje uslova `validProposal` nije potpuna podrška. Ne nametati kraj gde važeći ugovor dopušta nepoznat kraj.

Za upis requester pa worker imena koristiti jedan postojeći autoritet ili usku trajnu/revision-aware koordinaciju. Remount mora prepoznati delimičan ishod i završiti samo dozvoljeni nedostajući deo. Potvrđen displayName uz nerešen drugi upis nije ceo uspeh; oporavak ne prepisuje novije ime.

Provere uključuju blur/focus, Back, remount, pozadinu, paralelnu izmenu i prvi-upis-uspeo/drugi-unknown. Postojeći group draft dokaz ne prenosi se automatski na support/Dogovor editore.

#### R11e — Vreme, mapa, native raspored i animacije; SB12/SB13

**Vlasnici:** `src/ui/v2/ApplicationComposerPresentation.tsx`, `src/ui/v2/MyApplicationsPresentation.tsx`, `src/ui/agreements/agreementListModel.ts`, `src/ui/agreements/AgreementActionsPresentation.tsx`, `src/ui/v2/DiscoveryPresentation.tsx`, `src/ui/v2/discovery/mapControls.ts`, `src/ui/location/LocationPointEditor.tsx`, `src/ui/location/ResolvedPinMap.tsx`, `src/ui/entry/EntryWelcome.tsx`.

Usaglasiti prikaz/izmenu vremena jednom eksplicitnom poslovnom politikom i jasno označenom zonom, uz očuvan stvarni UTC instant. Proveriti uređaj u drugoj zoni, promenu sata, lokalni datum, danas/kasnije i početak bez kraja gde je dozvoljen. Jest podešen samo na UTC može prikriti razliku; promena prikaza ne sme promeniti stvarni ugovoreni trenutak.

Uskladiti Nearby tekst sa kamerom, dostupnost kontrola i panel insets; očuvati odgovarajući pin nacrt kroz blur. Razdvojiti stil/raster readiness od funkcionalnog SVG pina/drag-a gde to stvarni vlasnik dozvoljava. Nevidljivi raster trenutno može upravljati drag-om i neuspehom cele pin mape; ne uklanjati ga pre native dokaza. To nije isti potvrđeni uzrok kao F16.

Proveriti reduced-motion pri promeni postavke i životnog ciklusa, povratak, mali ekran, veći tekst, tastaturu i dostupnost svih glavnih radnji. Fiksna skeleton aritmetika i Text stubovi tabova ne dokazuju Yoga/native geometriju, MapLibre kameru ili stvarni gest. Koordinisati F16 regresiju sa R02 i različita značenja dve mape sa R08.

#### R11f — Strogi dekoderi i zajednička konfiguracija; X03/X04

**Vlasnici:** `src/data/applicationClientService.ts`, `src/data/ru4Production.ts`, `src/app/(app)/moje-prijave.tsx`, `src/data/supabaseClient.ts`, `src/data/authAvailabilityClientService.ts`, `src/data/productionLocationResolver.ts`, kao i stvarni povezani read/stream potrošači.

Na servisnoj granici odbiti NaN/Infinity i nedostajuća ili nevažeća obavezna receipt polja; klijentu dati jedinstven tačan tip. Dodatna zaštita u moje-prijave ostaje; njen dokaz ne preimenovati u već opažen lažan uspeh. Pozitivne kontrole uključuju nulu/validnu granicu gde domen to dozvoljava i kompletan receipt.

Sve potrošače vezati za isti postojeći konfiguracioni autoritet i isto pravilo dozvoljenog fallback-a/obaveznog env-a. Nedoslednost source-a nije dokaz da env nedostaje u instalaciji. Proveriti build i konfiguracije koje su stvarno podržane; ne dodavati drugi paralelni config servis.

#### R11g — Namenski proof build i provera samih proverivača; SB14

**Vlasnici:** `app.config.js`, `package.json`, `scripts/check-eas-preview.cjs`, `scripts/verify-native-patches.cjs`, `.github/workflows/ci-clean.yml` i dole imenovani proof/test fajlovi.

Usaglasiti proof flag sa plugin/native patch ugovorom i aktuelnom granom/workflow putanjom. Sačuvati consent i proveru nativnih patch bajtova. Istorijski preview PASS/proof FAIL nije kvar običnog APK-a ili `npm ci`, niti je razlog da se zaštita isključi.

Istorijski proverivač popraviti i ponovo izvršiti kada se koristi za zaključak ovog izdanja ili za promenjenog aktivnog vlasnika. Ako nije deo potrebne dokazne putanje, zadržati ga jasno vezanog za istorijski izvor ili povući prema C15; sređivanje svakog starog harness-a nije uslov objave.

| Konkretan proverivač | Potrebna korekcija ili tačna granica |
|---|---|
| `supabase/proofs/dynamic_taxonomy/gemini-real-provider-smoke.mjs` | Obavezno prisustvo i validan `classificationShadowJson` pre PASS-a; odsutno polje ne preskače proveru. Stvarni provider se ne poziva radi popravke ove statičke rupe. Smoke ne dokazuje ceo Save/binding. |
| `supabase/proofs/dynamic_taxonomy/need-review-signed-source.test.mjs`, `supabase/proofs/dynamic_taxonomy/worker-signed-review-source.test.mjs`, `supabase/proofs/dynamic_taxonomy/classification-gemini-shadow-source.test.mjs` | Sačuvati source ograde, ali staged string/regex ne nazivati izvršenim potpisom, transakcijom ili modelom. Aktuelnu integraciju vezati za stvarno migrirani owner. |
| `src/data/__tests__/worker-profile-read.test.ts` | Foreign/late Auth no-query tvrdnju postaviti na stvarni `mockRpc`, ne nepovezani `mockFrom`. Odbijanje rezultata i dokaz da poziv nije poslat proveravaju se odvojeno. |
| `supabase/proofs/d12/d12_proof.mjs` | Sačuvati stvarni P5 tok; završni PASS mora zahtevati sve obavezne grane bez neoznačenog seed/loader/ratingDue fallback-a, gaps/residuals/notVerified. Ne tvrditi da je konkretan istorijski run koristio fallback bez dokaza. |
| Istorijski EX06 S03/S04 i CUR01 proverivači | PARTIAL/SMOKE_ONLY/skip nije PASS cele situacije. Zahtevati stvarne preduslove, redove, očekivani suppression razlog, tačan stage i NULL-safe kardinalnost. `proof_stage=NULL` ne preskače obaveznu granu. |
| EX06 S04 `lib/sql.mjs` i READ_BUILDERS | SELECT koji poziva `private.emit_event` može upisati događaj; odsustvo INSERT/UPDATE/DELETE reči nije read-only dokaz. |
| `ex06b_lib.test.mjs` i stari P6 harness-i sa povučenim workflow-om | Proveriti stvarnu punu putanju u novom checkout-u pre poziva; rebase na aktuelnog CI caller-a ili istorijski pin. Obrišeni `.github/workflows/ex06b-alias-proof.yml` ne oživljavati radi starog testa. |
| EX05 S01 renderer i slični wrapperi | Vezati tačan runId, source/hash i obavezne nonempty checks; poslednji isti basename ili `result=PASS` nije dovoljno. RECORDED reprodukcija ostaje reprodukcija. |
| Frozen AI manifest; EX07/S06 byte check | Zastareo FROZEN_SOURCE_CHANGED označiti kao neupotrebljiv trenutni dokaz. Razdvojiti normalizovan CRLF check od stvarne raw-byte jednakosti; generator koji normalizuje CRLF ne daje bajtno identičan dokaz. |
| EX07/S03 native/provider i near-miss probe | E12 recovery, P14 opoziv i OS zadržavanje URL-a ostaju OBSERVATION dok se ne izvedu. Trigger koji izostavlja src promene ne pokriva novu izmenu klijenta. Prazna accepted lista iz pogrešne EXACT/FOREIGN_ECHO transformacije nije negativni dokaz; proveriti raw variants. |
| RLS-components/world-guard dijagnostika | Ukloniti ponavljanje istog PK uzorka po fazama i bare SQL echo umesto stvarnog psql poziva, tek nakon čitanja konkretne skripte. To su kvarovi alata, ne dokaz kvara današnjeg proizvoda. |

Šire porodice dokaza čuvaju sledeće granice: P6 direktni replica fixture-i nisu pravi publish; 30k/720 SQL uzoraka ili do 40k zadataka i 32 petlje nisu isto toliko korisnika, native dokaz ili produkcioni SLA. Repeatability može proći uz neuspešan performance screening. B24 stand-in trigger/istorijski deadlock nije tekući poslovni gate. B3c lokalne Auth/websocket/CDC expiry/revoke/closure provere imaju vrednost, ali ne dokazuju uređaj ili punu sadašnju erasure/export spremnost. AF22/Auth/Storage canary nije pravna sertifikacija. B1b Media Edge Auth je emuliran; stari roster ne zatvara F19. Provider mock, 12-byte JPEG ili stable ID nije prava slika, živi model ili izvršena konkurencija.

Čuvati stvarne holder/waiter, RLS, lock, receipt i negativne kontrole gde ostaju važeće. Stari ACL/pin drift proveriti prema tekućem telu i nameri, ne označiti svaku razliku regresijom. D03/promocija push-a i kasniji D12 već imaju istorijske primene; stale naslov SOURCE_ONLY/NOT APPLIED ne poništava kasniji dokaz. Inbox postoji sa aktivnim caller-om; CRLF i ACL delta vode se odvojeno. Već primenjenu zaštitu ne proglašavati nepostojećom.

Pre istorijskog harness-a proveriti prvu mutaciju, environment guard, sopstveni fixture scope i finally/rollback. p0d03/ru1 mogu DROP, pkg010/EX06 menjati cron ili prekidati backend; takve skripte idu samo na potvrđeno sopstveno izolovano okruženje, sa guard-om pre mutacije, ograničenim rokom i vraćanjem stanja. Prazan/NULL rezultat, optional assertion ili fallback ne mogu dati završni PASS. Ne izvršavati stari kontrolni patch koji menja lock redosled preko novijeg advisory → conversation → asset ugovora i ponovljenog owner čitanja.

#### R11h — Demo izolacija i ciljano povlačenje; X05

**Vlasnik:** `src/data/lazniIzvor.ts`. Izdvojiti početni fixture i pri reset-u obnoviti sve promenljive kandidate i povezane kolekcije, uključujući prijavom dodate elemente. Proveriti ponovljeni reset i nezavisnost testova. Ovo je demo/test izolacija, ne produkcioni upis.

C01–C19 primenjivati po tačnoj putanji/simbolu: odluka, trenutni caller, aktivna zamena, kompatibilnost, prevezivanje i dokaz. Ne dodavati novu funkciju da bi se opravdao nepovezan prototip. Za requester izbor čuvati memorijski `session.pending`, zamrznutu komandu, isti ključ i `readSelectedAgreement`; ne predstavljati ga kao postojeći trajni journal preko gašenja procesa. Odvojeni trajni `applicationCommandJournal` pripada radnikovoj prijavi. Sačuvati `publicTrustFacts`/`memberSincePhrase` i aktivne formattere kada se povlače stats/registry/manual alternative.

Pravilo **Samo poruke (A25)** zatvoriti kroz server/API i podržane stare klijente: `src/data/contactClientService.ts`, `src/data/ports.ts`, `src/ui/agreements/AgreementContactPlace.tsx`, `rpc_set_contact_grant`, `rpc_reveal_contact`, `grant_is_ownable`. Nova PHONE saglasnost/reveal se povlači uz istorijsku revokaciju i receipt kompatibilnost; EXACT_LOCATION i phone OTP prijava su drugi ugovori. Ne dodavati zabranu slobodnog teksta broja u poruci bez posebne poslovne odluke.

#### Zajedničke postojeće provere i završetak R11

| Postojeća provera | Kako je koristiti i šta još mora da dokaže |
|---|---|
| `src/ui/reviews/__tests__/use-given-ratings.test.tsx` | **Ispraviti očekivanje keša; sačuvati scenario.** Čitanje/greške i postojeće pravilo da isti Dogovor ID-jevi ne čitaju nove ocene. 51–55 treba dopuniti stvarnom novom ocenom uz iste ID-jeve i očekivanim invalidiranjem, ne samo remount-om iste liste. |
| `src/data/__tests__/worker-profile-read.test.ts` | **Popraviti proveru.** Mapiranje profila i odbijanje stranog/kasnog Auth rezultata. Negativni no-query assertion proverava mockFrom iako aktivni port koristi mockRpc. |
| `src/ui/support/__tests__/SupportScreens.test.tsx` | **Sačuvati i dopuniti.** Privatan support formular i retained callback/command guard. Dopuniti unsent tekst kroz blur/focus/remount prema odobrenoj nameri, ne pretpostavljati da ga drugi editor čuva. |
| `src/data/__tests__/urgent-hidden-in-v1.test.tsx` | **Sačuvati.** V1 build bez flag-a nema HITNO, čak i ako legacy podaci postoje. Jest setup globalno uključuje legacy flag; ovaj poseban test ga namerno uklanja. |

Za ostale imenovane vlasnike dopuniti njihov stvarni postojeći test ili najmanji potreban slučaj posle čitanja aktuelnog koda; ne izmišljati da već postoji test pod proizvoljnim novim nazivom. Konkretno proveriti medijski restart, neposlat support/Dogovor tekst, delimično ime, safety recovery, stvarnu zonu, map drag i nevidljivu kontrolu. Uspeh jednog editora ne dokazuje drugi.

Posle povlačenja proveriti import/require, package skripte, CI eksplicitne ulaze, Jest glob, TypeScript includes, postinstall i asset generatore. Archive ime samo ne isključuje izvršavanje. Dependency se uklanja tek kada nema potrebnog runtime/build/test potrošača. Meriti stvarne putanje, selekciju/broj testova, trajanje u istom okruženju i install/type/build; native resursi traže uređaj. Ne obećavati APK uštedu iz broja repo bajtova.


### R12 — Stvarna celina, native kandidati i objavljivanje

#### Cilj i dokazna granica

R12 povezuje rezultate relevantnih obaveznih zadataka od prve popravljene celine. Njegov završetak je jedna poznata isporučena kombinacija source-a, SQL/ACL-a, Edge sadržaja, konfiguracije, native build-a i učitanog OTA-a, na kojoj oba korisnika završavaju posao. Zeleni offline CI, isti broj verzije ili stara fotografija nisu taj dokaz. Ovo je izvršni plan; novi model/uređaj/izdanje nisu izvršeni njegovim pisanjem.

#### Konkretni vlasnici

- `app.config.js`
- `eas.json`
- `supabase/migrations/20261021101527_staged_task_replacement_noop_guard.sql`
- `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql`
- `README.md`
- `STATUS.md`
- `package.json`
- `.github/workflows/ci-clean.yml`
- `scripts/check-eas-preview.cjs`
- `scripts/verify-native-patches.cjs`
- `supabase/migrations/20261021101159_staged_task_replacement.sql`
- `supabase/migrations/20260901105922_clean_completion_and_writer_authenticated_proof.sql`
- `supabase/migrations/20260901113333_clean_ai_interview_turn_authenticated_proof.sql`
- `supabase/migrations/20260901114029_clean_ai_fact_supersession_and_human_correction.sql`

Pripadaju mu i tačni stvarno izmenjeni SQL/Edge/native vlasnici prethodnih R zadataka; konačni manifest ne može se svesti samo na četiri konfiguraciona fajla.

#### Jedan identitet isporuke i osvežavanje

R12 popunjava jedan zapis identiteta izdanja iz odeljka 10.2 ovog plana. Svi slojevi moraju pripadati stvarno proverenom kandidatu; u zapis ne ulaze tajne ni privatni payload-i.

Istorijski a969 izvor, fcef803 oznaka sa telefona, NEED151/WORKER104/post-save5 razlike i push37 parity ostaju presek revizije 7 dok se ne osveže. About oznaka nije izvučen ceo APK; 69 commit-a nije 69 popravki. Ne tražiti ponovo iste tri slike; novi dokaz tražiti samo za novu verziju ili nedostajući native/flag/request podatak. Screenshot i test moraju pripadati istoj proveravanoj kombinaciji.

Pročitati tadašnje README/STATUS/governance i deltu pre izmene/integracije. Ne vraćati staru granu/backend ili nepročitan Downloads masterplan iz memorije. Pre nego što se zameni/povlači server ugovor definisati podržani minimum klijenta i proveriti stare aktivne ulaze. Kritična privatnost se ne odlaže zbog stare verzije.

#### Prazan bootstrap, nadogradnja i oporavak

R12 sprovodi dva odvojena puta: bootstrap novog izolovanog okruženja i upgrade postojećeg. Jedinstvena tabela tri fixture migracije, tačni preduslovi i granice dokaza nalaze se u odeljku 8.4; podaci o ledger/source poreklu i tri CRLF razlike u odeljku 7.4. Proveriti stvarne funkcije, potpise, ACL/default prava, RLS, triggere, indekse i referentne podatke, uz odvojeno dokumentovanje snimljenih statements, originalnih bajtova i današnjih tela.

Široki `service_role` grant proveriti kao efektivnu dozvolu, ne zaključiti iz samog zapisa primene. Primenjenu istoriju ne prepravljati niti ponavljati tri promene radi usklađivanja broja. Stvarni upgrade čuva podatke i podržane klijente. Postupak oporavka iz odeljka 10.3 mora biti izvediv za pogođeni sloj: OTA rollback ne vraća šemu i poslovne podatke; stari rollback.preimage bez SQL terminatora ostaje evidencija, a ne automatska revert komanda.

#### Cela upotreba i merenje

R12 izvršava celovit dvostrani scenario iz odeljka 10.4, prihvatne slučajeve A01–A25 i dokaznu matricu ekrana iz odeljka 3.5. Zapis provere sadrži polja iz odeljka 8.5. Pogođena platforma dobija svoj fizički uređajski dokaz, uz kontrolisane prekide i potvrđen rezultat druge uloge. A24 čuva atomsku zamenu, a A25 server/starog klijenta i zasebnu lokacijsku dozvolu.

Zasebno potvrditi da opoziv account/session pristupa deluje i na već otvorenim odgovarajućim kanalima. Sam Data API hook ne potvrđuje Storage/Realtime granicu; stare lokalne lock/Auth/WebSocket probe zadržavaju svoj stvarni obim. Vreme, trošak, hladno/toplo stanje i kapacitet mere se po jedinstvenoj metodologiji iz odeljka 8.6, bez sabiranja neuporedivih istorijskih rezultata.

#### Postojeće provere i nivo rezultata

| Postojeća provera | Kako je koristiti i šta još mora da dokaže |
|---|---|
| `.github/workflows/ci-clean.yml` | **Sačuvati aktivni CI uz tačan nivo dokaza.** npm ci/native patch; tsc; Deno check bez izvršavanja; Jest; izabran Node; Python source integrity. Nema izvršavanja stvarnog modela, migrirane baze, build/deploy ili telefonske putanje. To je namerni offline gate, ne release-ready dokaz. |
| `supabase/proofs/ai/clean_ci_coverage.test.mjs` | **Sačuvati; dopuniti relevantan manifest.** Regex proverava Deno komandu i sedam izričitih Node puteva; odbija secrets/deploy/continue-on-error. Ne proverava sav relevantni Node test korpus ni produkcijski ishod; dopuniti samo zadatkom odabrane neophodne testove. |
| `supabase/proofs/d12/d12_proof.mjs` | **Sačuvati stvarni osnovni tok; popraviti završni kriterijum.** Stvarni poslovni P5 i jasne istorijske gap beleške imaju vrednost. Konačni result zavisi od failures/skipped, ne svih gaps/notVerified; kompletna readiness tvrdnja zahteva obavezne grane bez fallback-a. |
| `scripts/check-eas-preview.cjs` | **Uskladiti konfiguracionu proveru.** EAS preview preinstall konfiguraciona ograda. Uskladiti namenski proof build sa stvarnim plugin/native patch validatorom; nije nalog da se zaštita isključi. |

Izvršne CI komande i selekcija vode se u zajedničkoj sekciji provera ovog plana i osvežavaju iz aktuelnog workflow-a. Ne dodavati tajne/deploy ili stvarni model offline CI-ju samo da bi se nazvao E2E. Deno check nije izvršenje, source parser nije migracija, mock provider nije živi model, a PASS karakterizacije nije popravka. Potrebne Node post-save/finish-mode provere uključiti prema stvarnoj promeni i selekciji, bez automatskog pretpostavljanja da svaki `.mjs` ulazi u Jest.

Svi obavezni završni scenariji moraju imati stvarne nonempty rezultate, tačan decoder i proverene grane; PARTIAL/SKIP/NOT VERIFIED i fallback ne daju PASS cele situacije. Širi regresioni prolaz ponoviti kada zajednički promenjeni vlasnik ili obavezni gate to zahteva, ne radi povećanja zbirnog broja testova.

#### Produkcija, platforme i konačan izlaz

Sačuvati README uslov odvojenog proverenog produkcionog backenda i build zaštitu. Ne objavljivati DEV cilj kao produkciju niti kopirati privatne razvojne/testne naloge. Eksplicitan izlaz OWNER_PERSONAL/OWNER_BUSINESS iz namernog DEV TEST sveta proveriti kada se priprema stvarno izdanje. Proveriti Auth redirect/SMTP, Storage, Realtime, Edge, push, prava, konfiguraciju i stvarni paket/kanal. Nativne SDK/permission promene zahtevaju native build; sam OTA JavaScript nije dovoljan.

Za Android i iOS pratiti zasebne kandidate i uslove prodavnice iz njihove sekcije ovog plana. Android/AAB rad ne čeka Apple pristup. Pripremiti funkcionalne postupke brisanja, podrške/moderacije, deklaracije podataka, javne dokumente, store prikaze i namenski pregled obe uloge. Nedovršena obavezna funkcija ne postaje završena skrivanjem dugmeta. Statusi spremno za prijavu, podneto, odobreno, objavljeno i provereno posle objave ostaju odvojeni.

Konačni izlaz sadrži jednu važeću mapu aktivnih komponenti/pravila, popunjene ekrane/radnje, izvršni manifest stvarnih izmena/povlačenja, tačnu isporučenu kombinaciju, relevantne dokaze, poznata ograničenja i postupak oporavka. Manifest za svaki stvarno promenjen server objekat navodi identitet, zavisnosti, zamenu, kompatibilnost, redosled i rezultat; nedostavljeni istorijski SV JSON ne rekonstruisati kao original. Source review ili plan retirement-a nije dokaz da je objekat povučen.

Za svaki završen R zadatak izvestiti problem/posledicu, promenu postojećeg vlasnika, pozitivne i negativne kontrole, stvarni nivo provere i ono što ostaje nepoznato. Ne sabirati istorijske PASS brojeve u oznaku gotovog proizvoda. Ne zahtevati provider cache, sređivanje svake arhivske putanje ili svaku perf preporuku kao uslov objave ako nisu stvarna prepreka dogovorenom izdanju.

## 7. Čišćenje aktivnog izvora i servera

### 7.1. Obuhvat i granice

Čišćenje ima konkretnu svrhu: ukloniti zaista napuštenu aktivnu putanju, zadržati jedan odgovarajući vlasnički izvor i sprečiti da istorijski test vrati povučeno pravilo. Naziv legacy, odsustvo običnog caller-a ili star datum nisu sami uslov brisanja.

Istorijski registar pominje 912 uslovno razvrstanih putanja; to nije 912 fajlova za brisanje. C01–C19 ispod sadrže 180 jedinstvenih eksplicitno navedenih putanja, uključujući aktivne vlasnike i testove koji se moraju sačuvati ili prevezati. Ni taj broj nije broj fajlova za uklanjanje. Svaki paket je CONDITIONAL / NOT EXECUTED u ovoj isporuci. Stari `destructive_action_ready=false` ne postaje true iz samog ovog plana.

| Odluka | Vlasnik/podskup | Dokaz i uslov |
|---|---|---|
| Sačuvati | `useOwnedEditor`, request journal-i, signed review/digest, idempotent Save/publish i readback | Aktivne rute ih koriste. To su ograde od kasnih rezultata i nepoznatih ishoda, ne suvišna administracija. |
| Objediniti ugovor | Dual BG naspram explorer/shadow/direct/research putanja | Isti smisao, mode, cena, nova grana i obračun moraju biti provereni u aktivnoj putanji. Ne dodavati treći klasifikator radi sakrivanja razlika. |
| Sačuvati aktivne formatere | `src/data/aiNeedV2Ui.ts` | `pregled-zadatka` koristi factLabel/priceAmountRowValue; `reviewFacts` factLabel/factReviewValue/slotLabel; review client slotLabel; Intake safetyMessage; SupportReferenceView factLabel. Ceo modul nije mrtav. |
| Uslovno povući manual helper podskup | `factEditorKind`, `factChoices`, `editorCorrection`, `correctionFromText`, timestamp/list helpers, `amountDigits` | Non-test src pretraga nalazi definicije/interne pozive, ne aktivni obični editor. Proveriti podržane stare potrošače pre uklanjanja. |
| Uslovno povući dormant explicit-mode API | `prepareConfirmed`, `explicitWorkerModes`, `workerExplicitModeReviewEnabled`; `src/data/workerAiClientService.ts:36–45,280–305` | Non-test src self-reference; aktivni route test očekuje odsustvo dodatne mode forme. SQL kompatibilnost starog klijenta je poseban uslov. |
| Odvojiti demo namenu | `WorkerAiCard` | Jedini pronađen mount `src/designLab/dizajn-ai.tsx:177`; worker aktivni chat daje card()=>null. Demo nije razlog za vraćanje parcijalnih kartica; aktivni `WorkerAiReviewDetails` iz istog fajla ostaje. |
| Uslovno povući | `capturedParts`, `capturedSpeech`; `src/ui/workerProfile/workerProfileFacts.ts:64–78` | Nema spoljnog non-test src caller-a u obuhvaćenoj pretrazi. To nije autoritativni signal završetka. |
| Sačuvati aktivnu kompatibilnost | `src/app/(app)/profil/radnik.tsx`, `src/ui/workerProfile/workerProfileDraft.ts`, `src/ui/workerProfile/WorkerProfilePresentation.tsx:159–193` | Stara manual forma je povučena, ali name-adoption i uncertain-write recovery ostaju aktivni (`radnik:282–323`). Ime legacy nije dokaz za brisanje fajla. |
| Uskladiti copy i ulaze | `src/data/reviewFactProblem.ts:10`; `src/app/(app)/pregled-zadatka.tsx:343–352,517–533`; saved work-area/pin ulazi | Prošao termin se menja u razgovoru, ne u starom lokalnom editoru. Uskladiti ton i oblast/pin značenje bez novog obaveznog koraka. |
| Sačuvati istoriju, jasno indeksirati | Primenjene migracije, candidate/proof materijal, operativne beleške | Istorijska SQL funkcija ili dokaz nisu mrtav UI. CURRENT/HISTORICAL/REJECTED razdvajanje treba da spreči korišćenje starog candidate-a kao sadašnjeg ugovora. |

Legacy `inferWorkerExecutionModes` jeste keyword/city heuristika, ali aktivna worker ruta je poziva samo kada classificationState nedostaje (`src/app/(app)/profil/razgovor.tsx:282–285`). Signed READY/PENDING put je preskače. Ne opisivati sve današnje modove kao telefonsko nagađanje po ključnim rečima.

Za ekrane sa mapom treba sačuvati razliku prikaza i potvrde: MapLibre/OpenFreeMap, native/web varijanta, scene/focus owner i pin revision. GPS dozvola za „Moja lokacija” nije opšti uslov svakog prikaza mape. Prazan discovery rezultat sam po sebi ne gasi geografiju; F15/F16 su konkretniji razlozi dostavljenih stanja. S03 identifikuje About ekran, ali ne predstavlja pregled svih ostalih ekrana.

**Granica pojedinačnog registra:** istorijski `consolidated_read_register.json` nije dostavljen. Dostupne preporuke su ugrađene ovde; nisu rekonstruisane sve njegove nevidljive stavke. U izvoru se pominju i objašnjenje mikrofona, zajednički voice formatter, neprimenjeni Text.balance i uski ListSkeleton/RadarIcon/brand kandidati. Aktivni textWidth/TITLE_SIZE i sheet konfiguracija ostaju. Za takvu dodatnu promenu prvo utvrditi stvarni simbol i sadašnje potrošače; bez zapisa nema izmišljene dozvole za široko uklanjanje.

#### Pojedinačne poznate granice

`SelectionRequestRegistry` u `src/lib/selectionIdempotency.ts:31` nema non-test caller-a. Sačuvati stvarni izbor u `src/app/(app)/potrebe/[id]/kandidati.tsx`: memorijski `session.pending`, zamrznutu komandu, isti ključ i `readSelectedAgreement`. Odvojeni trajni `applicationCommandJournal` pripada prijavi radnika. Izbor nije time proglašen trajnim preko gašenja procesa; to je korekcija preciznosti, ne nov dokazan kvar. Stari `workTrustModel.statsView` nema običnog potrošača, dok `publicTrustFacts` služi javnom profilu i detalju zadatka. `manualAvailability`, `BrandScene`, `useBrandClock`, `useEntryIntro` pripadaju designLab-u; aktivna dostupnost je AI tok, a ulaz koristi tri premium PNG-a. To su pojedinačne preporuke za izolovanje ili povlačenje, bez vraćanja ručnih UI-ja iz testova.

`supabase/candidates/temporal-conflict-freezing-v1.sql` je nepovezan prototip sa starim schedule/resource/team poljima; terminalni aggregate SELECT nema INTO/RETURN u PL/pgSQL. Funkcija `private.candidate_projection(uuid)` ne postoji u current680inventaru niti ima current qualified caller. Aktivni `need_candidate_states_v5`/candidate RPC vlasnici ostaju. Ovaj prototip ne dokazuje kvar trenutnog kalendara.

Current legacy `rpc_delete_abandoned_intake_conversation` (`5829cbb6998255adae020793dd18ff33`) ima širok EXECUTE uz auth.uid/owner provere, ali prve referencirane tabele `public.need_facts_v2` i `public.ai_conversation_messages` ne postoje. Ne može se dokazati validan napad ignorisanjem te činjenice; izvršenje zapinje pre kasnijeg statusnog rizika. Nema source caller-a. Uslovno povlačenje zahteva proveru starih klijenata i zavisnosti, bez izvršavanja brisanja nad korisničkim podacima.

Stare rollback.preimage.sql kopije više funkcija ponegde spajaju `pg_get_functiondef` izlaze bez SQL terminatora. To je preimage evidencija, ne spremna revert komanda. Stare široke grantove i anon SECURITY DEFINER navode proveravati po objektu i unutrašnjem guard-u; ne menjati ACL/RLS da se samo umanji broj advisor upozorenja. Izvori i pojedinačni uslovi: Z01–Z06.

#### Precizna jedinica povlačenja

Za `workerProfileDraft.ts` uski kandidati su `foldTerm`, `hasTerm` i `toggleTerm`; `workerDraft`, `workerCommand`, `workerReadbackMatches`, `nameForSave` i povezani recovery/name-adoption ostaju. Za `workTrustModel` kandidat je `statsView`, dok `publicTrustFacts` i `memberSincePhrase` imaju stvarne javne potrošače. Za dormant worker explicit-mode podskup odsustvo non-test src caller-a ostaje uslovna preporuka: stari APK i serverski ugovor proveravaju se pre retirement-a. Primenjene SQL migracije čuvaju istoriju; kandidat, rollback preimage i demonstracioni ekran imaju zasebnu namenu. Poreklo ove odluke je opisani rev7 pregled; sadašnje potrošače proveriti u konkretnoj radnoj kopiji.

### 7.2. Konkretni paketi C01–C19

Za svaki paket očuvati sva navedena polja. Putanje su tačno prenete iz dostupne analize, relativno prema repozitorijumu; njihov status i sadržaj proveravaju se pre promene.

#### C01 — Nereferencirani template resursi

**Veza:** R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Ukloniti 21 označeni template/placeholder resurs iz aktivnog stabla zajedno sa eventualnim suvišnim asset unosima.

**Ostaje:** Aktivne app-icon/premium-entry/reference-entry resurse, fontove, njihove manifeste i install generisanje.

**Preduslov:** Osvežiti referenciranje u app/EAS/Metro/native konfiguraciji, generatorima i dinamičkim putanjama; isti basename u drugom folderu nije isti asset.

**Tačne poznate putanje:**

```text
assets/entry-splash-empty.xml
assets/images/android-icon-background.png
assets/images/android-icon-foreground.png
assets/images/android-icon-monochrome.png
assets/images/expo-badge-white.png
assets/images/expo-badge.png
assets/images/expo-logo.png
assets/images/favicon.png
assets/images/icon.png
assets/images/logo-glow.png
assets/images/react-logo.png
assets/images/react-logo@2x.png
assets/images/react-logo@3x.png
assets/images/splash-icon.png
assets/images/tabIcons/explore.png
assets/images/tabIcons/explore@2x.png
assets/images/tabIcons/explore@3x.png
assets/images/tabIcons/home.png
assets/images/tabIcons/home@2x.png
assets/images/tabIcons/home@3x.png
assets/images/tutorial-web.png
```

**Dokaz posle promene:** Nema nepostojeće require/import/config putanje. Install/build proverava aktivne ulazne resurse. Novi native izgled ikone/ulaza odgovara cilju; veličina APK-a meri se zasebno.

#### C02 — Stari ručni izbor veština

**Veza:** R08, R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Povući foldTerm, hasTerm i toggleTerm i test koji postoji samo radi tog quick-pick editora.

**Ostaje:** workerDraft, workerCommand, workerReadbackMatches, nameForSave i aktivni recovery/name-adoption; AI izmena profila.

**Preduslov:** Potvrditi tačne simbole, import-e i podržane ugovore; ne brisati ceo workerProfileDraft.ts.

**Tačne poznate putanje:**

```text
src/ui/workerProfile/workerProfileDraft.ts
src/ui/workerProfile/__tests__/worker-profile-terms.test.ts
src/app/(app)/profil/radnik.tsx
```

**Dokaz posle promene:** Nema mrtvih exporta/importa starog quick-pick-a. Ime, readback i neizvestan Save čuvaju važeće ponašanje. Testni skup više ne zahteva ukinuti ručni editor.

#### C03 — Ručni editor činjenica pored aktivnih AI formattera

**Veza:** R08, R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Povući factEditorKind, factChoices, editorCorrection, correctionFromText, amountDigits i njihove isključivo interne manual helper-e kada se testovi prevežu.

**Ostaje:** factLabel, priceAmountRowValue, factReviewValue, slotLabel i safetyMessage sa svim aktivnim pregled/support potrošačima.

**Preduslov:** U svakom testu odvojiti zaštitu aktivnog prikaza od očekivanja ukinutog ručnog unosa; sačuvati korekciju kroz isti razgovor.

**Tačne poznate putanje:**

```text
src/data/aiNeedV2Ui.ts
src/data/__tests__/aiNeedV2Ui.test.ts
src/data/__tests__/ru2-ai-v2-ui.test.ts
src/data/__tests__/w02-capability-terms.test.ts
```

**Dokaz posle promene:** Pregled, podrška i AI prikaz imaju iste važeće labele i novčano značenje. Nema novih lokalnih writer-a činjenica. Relevantne pozitivne i negativne provere ostaju.

#### C04 — Stari card i layout podskupovi

**Veza:** R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Povući nekorišćene CardHead/CardDecision/CardFoot/CardBriefFoot/CardRequirement/CardPerson/CardPlaces/CardNext/CardNote/CardWaitingLine/CardFootLine; uz njih stari headBeside/wrapTitle/titleColumn i test-only requesterPrijava podskup.

**Ostaje:** Aktivne task/status/capacity/rating/spoken helper-e, CardStatus/CardStatusLine/CardTitle/WaitingDot, textWidth/font tabelu/TITLE_SIZE i stvarno odvojene requester/worker kompozicije.

**Preduslov:** Povezati svaki uklonjeni export sa testom i aktivnom zamenom; ne spajati različite uloge samo radi manjeg broja komponenti.

**Tačne poznate putanje:**

```text
src/ui/v2/TaskFace.tsx
src/ui/v2/cardHeadFit.ts
src/ui/v2/CandidateFace.tsx
src/ui/v2/PrijavaCard.tsx
```

**Dokaz posle promene:** Sve aktivne kartice i koraci Dogovora čuvaju iznos, broj ljudi, status i pristupačnost. Testovi ne zahtevaju više napuštenu vizuelnu implementaciju. Type/build nema preostalih import-a.

#### C05 — Nepovezani selection registry i privatna stats alternativa

**Veza:** R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Povući SelectionRequestRegistry sa isključivo njegovim testom, te statsView/reliabilityNeeds podskup gde je bez običnih potrošača.

**Ostaje:** Stvarni requester izbor u kandidati ruti: memorijski session.pending, frozen command, isti ključ i readSelectedAgreement; odvojeni trajni applicationCommandJournal radnika; publicTrustFacts/memberSincePhrase.

**Preduslov:** Rekoncilovati noviju odluku u registru i proveriti sve tip/export potrošače; ne izjednačiti memorijsko pending stanje i trajni journal.

**Tačne poznate putanje:**

```text
src/lib/selectionIdempotency.ts
src/lib/__tests__/selectionIdempotency.test.ts
src/ui/profile/workTrustModel.ts
src/ui/profile/__tests__/work-trust-model.test.ts
```

**Dokaz posle promene:** Prijava i izbor ostaju zaštićeni od ponavljanja u svom stvarnom obimu. Javni profil i poverenje zadržavaju autoritativne podatke. Uklonjeni test ne umanjuje pokriće stvarnog ruta/servis toka.

#### C06 — Duplikat identičnog testa

**Veza:** R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Ukloniti jednu od dve identične provere prvog dolaska redova (588–604 i 606–622 na analiziranom izvoru).

**Ostaje:** Jednu kompletnu proveru: najviše šest prvih animiranih redova; topla lista i promena filtera bez ponovljene animacije.

**Preduslov:** Pre izmene osvežiti tačne granice testa; nema potrebe menjati proizvod radi uklanjanja duplikata.

**Tačne poznate putanje:**

```text
src/data/__tests__/agreement-collection-presentation.test.tsx
```

**Dokaz posle promene:** Ostaje jedna identična smislena provera i svi ostali različiti slučajevi. Broj slučajeva se smanji za jedan tek nakon stvarnog runner izveštaja.

#### C07 — Stari ulazni motion i design-only reference

**Veza:** R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Iz aktivnog izvora i default suite-a povući isključivo napuštenu BrandScene/V49/useEntryIntro referencu sa njenim testovima i starim token allowance-om; design scenu ukloniti ili prevezati u jednom zahvatu.

**Ostaje:** Aktivni EntryWelcome, premium PNG, BrandAssets/BrandRaster, potrebni brandParts/BRAND_PARTS i postinstall generisani font/reference-entry ulazi dok ih potrošači koriste.

**Preduslov:** Sačuvati jedan jasno označen dizajn dokaz samo ako služi aktuelnom vizuelnom cilju; proveriti install/build i putanju potrebnog fonta.

**Tačne poznate putanje:**

```text
src/ui/entry/BrandScene.tsx
src/ui/entry/BrandSceneReview.tsx
src/ui/entry/entryV49Math.ts
src/ui/entry/entryV49Notes.ts
src/hooks/useEntryIntro.ts
src/data/__tests__/entry-brand-scene-clock.test.tsx
src/data/__tests__/entry-v49-reference.test.ts
src/data/__tests__/entry-intro-hook.test.tsx
src/ui/system/__tests__/one-token-source.test.ts
src/designLab/dizajn-profil.tsx
scripts/sync-entry-reference-assets.cjs
```

**Dokaz posle promene:** Aktivni welcome/splash ostaje tačan na uređaju. Jest više ne zahteva staru animaciju. Install iz čistog checkout-a ne zavisi od obrisanog izvora.

#### C08 — V1 AI portovi i fake AI

**Veza:** R04, R08, R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Povući legacy V1 intake/confirm/publish port i njegove override-e kao zajedničku celinu; izdvojiti fixture-e koje još trebaju tekućim testovima.

**Ostaje:** Aktivni V2 razgovor, signed review/Save/publish, aktivne ne-AI komande/readere centralnog Izvor porta i smislen reset demo stanja.

**Preduslov:** Prvo ukloniti/rebindovati legacy članove porta i test potrošače. Proveriti konfiguracije koje mogu izabrati test/dev izvor.

**Tačne poznate putanje:**

```text
src/data/aiCommandOverrides.ts
src/data/aiProductionOverrides.ts
src/data/productionAuthorityOverrides.ts
src/data/lazniAi.ts
src/data/index.ts
src/data/ports.ts
src/data/lazniIzvor.ts
```

**Dokaz posle promene:** Nema V1 slanja ili objave iz aktivne kompozicije. Postojeći V2 put i ostale Izvor funkcije rade. Retired-only testovi ne vraćaju ručne V1 činjenice.

#### C09 — Nepovezani owner-review builder i eksplicitni CI ulaz

**Veza:** R04, R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Premestiti ili povući source-only Gate A builder i isključivo njegov synthetic test zajedno sa eksplicitnim CI pozivom, posle prenosa važećih scenarija.

**Ostaje:** Aktivni potpisani review/prepare/Save/binder, revalidaciju identiteta i kompletan BOTH; ne smanjiti potrebnu zaštitu samo uklanjanjem CI reda.

**Preduslov:** R04 mapira svaku korisnu proveru na aktivnog vlasnika i proverava stvarni Edge bundle; CI izmenu prikazati sa zamenom.

**Tačne poznate putanje:**

```text
supabase/functions/_shared/classificationOwnerReview.mjs
supabase/proofs/dynamic_taxonomy/classification-owner-review.test.mjs
.github/workflows/ci-clean.yml
```

**Dokaz posle promene:** Nema dangling CI putanje. Istovetne važeće invariants proverava aktivni put. Synthetic istorijska projekcija se više ne predstavlja kao dokaz stvarnog Save-a.

#### C10 — Aktivne i alternativne AI strategije

**Veza:** R04, R06, R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Posle odabira i dokaza ciljnog postojećeg toka povući nepodržane alternativne flag grane, njihove izvozove i retired-only testove.

**Ostaje:** Puni semantički ugovor, nove grane, isti ID, oba moda, stvarnu saglasnost i postojeće granice potrošnje/timeout-a; foreground razgovor i pozadinski posao mogu imati različite potrebne uloge.

**Preduslov:** Isti korpus, merena tačnost/latencija/trošak, kompatibilnost starog podržanog build-a i usklađeni source/Edge deploy.

**Tačne poznate putanje:**

```text
supabase/functions/_shared/classificationExplorer.mjs
supabase/functions/_shared/classificationGeminiShadow.mjs
supabase/functions/_shared/taxonomyScopedShadow.mjs
supabase/functions/uskoci-ai-interview/index.ts
supabase/functions/uskoci-worker-interview/index.ts
```

**Dokaz posle promene:** Jedan dokumentovan aktivan ugovor i popis dozvoljenih konfiguracija. Neaktuelna strategija nema runtime/CI ulaz. Svi R04/R06 slučajevi imaju dokaz preko aktivnog puta.

#### C11 — Messages-only povlačenje PHONE delova

**Veza:** R11, R12. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Povući PHONE metode/portove i positive-feature testove koje važeći proizvod više ne podržava; povezati sa posebnom kompatibilnom serverskom migracijom.

**Ostaje:** Poruke, važeći tačan lokacijski grant i njegove privatnosne provere; istorijski negativni test da stari klijent ne može vratiti povučenu PHONE mogućnost.

**Preduslov:** Proveriti stare native/OTA klijente i server grantove, current source ugovor i namenu svake testne tvrdnje.

**Tačne poznate putanje:**

```text
src/data/contactClientService.ts
src/data/ports.ts
src/data/__tests__/m04-privatnost-kontakt.test.ts
src/ui/agreements/AgreementContactPlace.tsx
STATUS.md
```

**Dokaz posle promene:** Aktivan i podržani stari klijent poštuju messages-only ugovor. Tačna lokacija ostaje zasebno autorizovana. Nema nove zabrane teksta poruke bez posebne poslovne odluke.

#### C12 — Nepovezane buduće GPS i permission putanje

**Veza:** R09, R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Iz aktivnog opsega povući controller/prototip i testove koji samo dokazuju nezakačenu buduću mogućnost; potrebno generičko GPS/permission ponašanje zadržati kod aktivnog vlasnika.

**Ostaje:** Aktivni exact-location grant, native location helpers i postojeći push enrollment/permission tok.

**Preduslov:** Inženjerska preporuka je izolovati neaktivnu buduću referencu; aktiviranje nove GPS SHARE funkcije bio bi poseban proizvodni opseg.

**Tačne poznate putanje:**

```text
src/data/agreementCurrentLocationService.ts
src/ui/agreements/AgreementLocationController.ts
src/data/__tests__/v5-agreement-current-location-controller.test.ts
src/data/__tests__/v5-agreement-current-location-service.test.ts
src/ui/permissions/notificationAsk.ts
src/ui/permissions/__tests__/permission-sites.test.ts
```

**Dokaz posle promene:** Default produktni testovi ne zahtevaju nezakačen prototip. Aktivni permission i lokacijski tokovi zadržavaju svoju proveru. Nema dangling import-a ni izgubljenog native helper-a.

#### C13 — Javni komentari: ugovor pre povlačenja čitača

**Veza:** R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Odluku o starom prikazu doneti zajedno sa SB09: povezati potvrđen javni komentar ili uskladiti obećanje i izdvojiti neaktivni public-list podskup.

**Ostaje:** Aktivni context/submit servis, ocene i stvarna privatnost publikovanja; ne izbrisati ceo reviewComments servis.

**Preduslov:** Utvrditi važeću publiku komentara; ako se menja obećanje proizvoda, prikazati korisniku konkretnu odluku, ne sakriti je pod cleanup.

**Tačne poznate putanje:**

```text
src/ui/reviews/ReviewCommentsSection.tsx
src/ui/reviews/__tests__/review-comments-section.test.tsx
src/data/reviewCommentsClientService.ts
```

**Dokaz posle promene:** Tekst pri slanju i stvarna dostupnost komentara saglasni. Submit/context i rating tok ostaju. Retired-only testovi ne nameću drugu publiku.

#### C14 — Testovi povučenih pravila i istorijski oracle

**Veza:** R04, R07, R08, R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Razdvojiti stare 11-stem/fee/HITNO/equipment/license i kopirane oracle pretpostavke; povući retired-only pozitivna očekivanja iz default acceptance-a.

**Ostaje:** Važeće privacy/ownership/canonical identity/budget granice i korisne sintetičke slučajeve prevezane na sadašnji ugovor.

**Preduslov:** Za svaku tvrdnju navesti aktuelni izvor pravila, ili da je istorijska kompatibilnost; otkriti optional/skip/NULL slučajeve koji mogu lažno proći.

**Tačne poznate putanje:**

```text
src/data/__tests__/ex06-corpus-contract.test.ts
supabase/proofs/pkg051/pkg051_proof.mjs
supabase/proofs/match_category_fallback/source.test.mjs
```

**Dokaz posle promene:** Test više ne vraća ukinutu funkciju. Neophodan safety invariant ostaje u tekućoj proveri. Istorijski PASS ima označen stari source/runtime i nije release gate.

#### C15 — Aktuelni kvar kao zelena karakterizacija

**Veza:** R02, R06, R07, R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Posle konkretne popravke promeniti završno očekivanje sa ponavljanja kvara na ispravan rezultat; zadržati precizan ulaz/prekid koji je kvar reprodukovao.

**Ostaje:** Reprodukciju stare RSD potvrde, neuspešnog capture-a, MAP failure posle uspešne liste i nove ocene uz iste ID-jeve.

**Preduslov:** Test i popravka u istom pregledljivom radu, uz pozitivnu kontrolu; ne menjati assertion samo da trenutni kod prođe.

**Tačne poznate putanje:**

```text
supabase/proofs/ai/currency_correction_characterization.test.mjs
supabase/proofs/ai/background_capture_receipt.test.mjs
src/data/__tests__/discovery-v1-route-lifecycle.test.tsx
src/ui/reviews/__tests__/use-given-ratings.test.tsx
```

**Dokaz posle promene:** Isti slučaj sada dokazuje željeno ponašanje. Uspešan redovni tok i relevantni neuspeh ostaju. CI rezultat ima jasnu semantiku.

#### C16 — Dokazi, kandidati i zamrznuti generatori

**Veza:** R01, R11, R12. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Za svaku historical/candidate grupu zadržati minimalan manifest sa commitom, hash-em, namenom i zamenom, a nepotrebne kopije izbaciti iz aktivne grane kada nisu input tekućeg build/test/replay-a. Ne održavati drugu arhitekturu u kandidatima.

**Ostaje:** Primenu i poreklo stvarno korišćenog SQL-a, nužne fixtures i dokazive rollback preimage reference, te aktuelne minimalne canary/replay alatke.

**Preduslov:** Za frozen generator prvo utvrditi da li se koristi kao rekonstrukcija/potpisni dokaz; ne regenerisati primenjeni bundle. Prevezati putanje u current kontrolama na minimalan potreban izvor.

**Tačne poznate putanje:**

```text
README.md
STATUS.md
supabase/candidates/ex04a_own_tasks_page.sql
supabase/candidates/temporal-conflict-freezing-v1.sql
supabase/proofs/push_single_target/promotion/expected-prelocation-surface.json
```

**Dokaz posle promene:** Default build/test/deploy nema staru install/apply/revert putanju. Jedan manifest vodi do tačnog starog izvora i aktuelne zamene. Izolovan replay/current bootstrap radi bez uklonjenih slučajnih kopija.

#### C17 — Test i build katalog posle čišćenja

**Veza:** R11, R12. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Uskladiti package scripts, eksplicitne CI putanje, Jest selekciju, TypeScript includes i generisanje sa odlukama o aktivnom/istorijskom sadržaju. Premeštanje u archive samo po sebi ne isključuje __tests__ glob ni **/*.ts include.

**Ostaje:** Obavezne tekuće safety/regression/integrity provere i pouzdan install/build iz zaključanih zavisnosti.

**Preduslov:** Svaki uklonjeni test ili CI ulaz mora imati razlog RETIRED_RULE/DUPLICATE/REPLACED_BY_CURRENT/EXPLICIT_HISTORICAL_ONLY; nikakvo opšte isključivanje na osnovu sporosti ili failure-a.

**Tačne poznate putanje:**

```text
package.json
jest.config.cjs
tsconfig.json
.github/workflows/ci-clean.yml
scripts/sync-entry-reference-assets.cjs
supabase/migrations/check_migration_integrity.py
```

**Dokaz posle promene:** Runner list/count pre-posle, zbir trajanja i relevantno pokriće uz isti environment. Nema neselektovanog obaveznog testa ni testnog fajla koji štiti samo napušteni UI. Dependency lock i install/build su koherentni; paket se uklanja samo kad nema potrebnog runtime/build/test potrošača.

#### C18 — Potpuno identične premium slike i njihove kopije

**Veza:** R11. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Konsolidovati tri potvrđena byte-identical para na aktivni premium-entry vlasnički put i prevezati ostale potrošače/provenance; zatim ukloniti višak kopija iz aktivnog stabla.

**Ostaje:** Isti pikseli/izgled i sve stvarne upotrebe; canonical premium-entry put se predlaže zato što je aktivni ulazni vlasnik.

**Preduslov:** Proveriti literalne/dinamičke import-e, asset manifest/generator i dizajn galerije; ne ukloniti putanju pre rebind-a.

**Tačne poznate putanje:**

```text
assets/brand/premium-entry/discover.png
assets/brand/premium-entry/logo.png
assets/brand/premium-entry/publish.png
assets/brand/uskoci-dimensional-20261003.png
assets/illustrations/uskoci-discover-v3.png
assets/illustrations/uskoci-task-launch-v2.png
```

**Dokaz posle promene:** Izgled aktivnog ulaza i svih drugih potrošača ostaje isti. Install/build proverava novi jedinstveni izvor. Saopštiti stvarne repo byte rezultate; APK veličina se zasebno meri.

#### C19 — Identični SQL i proof blizanci

**Veza:** R11, R12. **Status:** uslovni kandidat, nije izvršeno.

**Jedinica promene:** Kod byte-identical candidate/migration i ponovljenih proof kopija izabrati primenjenu migraciju ili jasno određen evidencioni vlasnički zapis; prevezati aktuelne testove i manifest linkove, pa ukloniti suvišnu aktivnu kopiju kada nema nezavisnu funkciju.

**Ostaje:** Primenjene migracije i njihov originalni hash; tačan istorijski run/commit identitet i sadržaj potreban za audit/replay/rollback.

**Preduslov:** Za svaku grupu zabeležiti canonical source i sve putanjske zavisnosti. Frozen istorijski runner ne prepraviti da glumi tadašnji drugačiji izvor; sačuvati istorijski manifest ili commit referencu.

**Tačne poznate putanje:**

```text
supabase/candidates/ai-location-01-20261002/before-edge/src/contracts/needFactsV2.ts
supabase/candidates/ai-location-01-20261002/before-edge/supabase/functions/_shared/aiTestBudget.ts
supabase/candidates/ai-location-01-20261002/before-edge/supabase/functions/_shared/geminiTaskStream.ts
supabase/candidates/ai-location-01-20261002/location_reply_candidate.sql
supabase/candidates/ai-location-01-20261002/src/contracts/needFactsV2.ts
supabase/candidates/ai-location-01-20261002/supabase/functions/_shared/aiTestBudget.ts
supabase/candidates/ai-location-01-20261002/supabase/functions/_shared/geminiTaskStream.ts
supabase/candidates/ai-location-01-20261002/supabase/functions/_shared/locationReply.ts
supabase/candidates/ai-location-01-20261002/supabase/functions/uskoci-ai-interview/index.ts
supabase/candidates/closure-current-20261021/helpers.sql
supabase/candidates/closure-current-20261021/migration-with-proof.sql
supabase/candidates/closure-taxonomy-20261018/helpers.sql
supabase/candidates/dynamic-taxonomy-20261011/ai-catalog-context-deep-ancestry-v2.sql
supabase/candidates/dynamic-taxonomy-20261011/create-child-v2-forward-dev.sql
supabase/candidates/dynamic-taxonomy-20261011/create-new-branch-v3-forward-dev.sql
supabase/candidates/dynamic-taxonomy-20261011/need-binder-selection-hotfix-dev-v1.sql
supabase/candidates/dynamic-taxonomy-20261011/need-review-versioned-optin-dev-20261016.sql
supabase/candidates/dynamic-taxonomy-20261011/signed-binding-requeue-dev-v1.sql
supabase/candidates/ex05-rc02-20261002/rc02_candidate.sql
supabase/candidates/pkg023j_home_attention.sql
supabase/candidates/published-edit-guard-20261021/candidate.sql
supabase/candidates/worker-personal-profile-edge-20261003/proof/dialogue_fixture.mjs
supabase/candidates/worker-personal-profile-edge-20261003/task/after/src/contracts/needFactsV2.ts
supabase/candidates/worker-personal-profile-edge-20261003/task/after/supabase/functions/_shared/aiTestBudget.ts
supabase/candidates/worker-personal-profile-edge-20261003/task/after/supabase/functions/_shared/geminiTaskStream.ts
supabase/candidates/worker-personal-profile-edge-20261003/task/after/supabase/functions/_shared/locationReply.ts
supabase/candidates/worker-personal-profile-edge-20261003/task/before/src/contracts/needFactsV2.ts
supabase/candidates/worker-personal-profile-edge-20261003/task/before/supabase/functions/_shared/aiTestBudget.ts
supabase/candidates/worker-personal-profile-edge-20261003/task/before/supabase/functions/_shared/geminiTaskStream.ts
supabase/candidates/worker-personal-profile-edge-20261003/task/before/supabase/functions/_shared/locationReply.ts
supabase/candidates/worker-personal-profile-edge-20261003/task/before/supabase/functions/uskoci-ai-interview/index.ts
supabase/candidates/worker-personal-profile-edge-20261003/worker/after/supabase/functions/_shared/aiTestBudget.ts
supabase/candidates/worker-personal-profile-edge-20261003/worker/after/supabase/functions/_shared/geminiTaskStream.ts
supabase/candidates/worker-personal-profile-edge-20261003/worker/before/supabase/functions/_shared/aiTestBudget.ts
supabase/candidates/worker-personal-profile-edge-20261003/worker/before/supabase/functions/_shared/geminiTaskStream.ts
supabase/functions/_shared/pushNotificationCopy.mjs
supabase/migrations/20260907100000_clean_n08_notification_preferences.sql
supabase/migrations/20260907110000_clean_d03_message_retry.sql
supabase/migrations/20260907120000_clean_ai_need_draft_safety_authority.sql
supabase/migrations/20260908120000_clean_p0e_completion_guards.sql
supabase/migrations/20260908130000_clean_p1_legal_consent_ledger.sql
supabase/migrations/20260908140000_clean_p4_processor_map_registry.sql
supabase/migrations/20260908150000_clean_p3_retention_schedule_registry.sql
supabase/migrations/20260908160000_clean_p2_data_export_requests.sql
supabase/migrations/20260908170000_clean_d0140a_policy_bundle_registration.sql
supabase/migrations/20260910153005_clean_p2_export_delivery_authority.sql
supabase/migrations/20260910162955_clean_p3_retention_execution_authority.sql
supabase/migrations/20261016172724_dev_need_review_taxonomy_versioned_20261016.sql
supabase/migrations/20261016185402_dev_signed_taxonomy_binding_requeue_20261016.sql
supabase/migrations/20261016185727_dev_signed_need_binder_selection_20261016.sql
supabase/migrations/20261017223855_create_child_v2_signed_review_dev_20261018.sql
supabase/migrations/20261017230303_taxonomy_root_branch_v3_20261018.sql
supabase/migrations/20261017230429_taxonomy_deep_ancestry_v2_20261018.sql
supabase/migrations/20261021095622_published_task_edit_containment.sql
supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql
supabase/operations/dev-alpha/ledger/20260919221214_dev_alpha_pkg023j_home_attention.sql
supabase/operations/dev-alpha/ledger/20261002172532_dev_alpha_ex05_rc02_media_cancel_lock_order.sql
supabase/operations/dev-alpha/ledger/20261002185306_dev_alpha_ai_location_01_contextual_map_dialogue.sql
supabase/proofs/ai/ai_draft_authority_candidate.sql
supabase/proofs/ai/dialogue_fixture.mjs
supabase/proofs/completion/p0e_completion_guards_candidate.sql
supabase/proofs/legal/p1_legal_consent_candidate.sql
supabase/proofs/legal/p2_data_export_candidate.sql
supabase/proofs/legal/p2_export_delivery_candidate.sql
supabase/proofs/legal/p3_retention_execution_candidate.sql
supabase/proofs/legal/p3_retention_schedule_candidate.sql
supabase/proofs/legal/p4_processor_map_candidate.sql
supabase/proofs/notifications/d03_message_retry_candidate.sql
supabase/proofs/notifications/n08_preferences_candidate.sql
supabase/proofs/policy/d0140a_bundle_registration_candidate.sql
supabase/proofs/push_single_target/promotion/edge-before/functions/_shared/pushNotificationCopy.mjs
supabase/proofs/push_single_target/promotion/edge-candidate/functions/_shared/pushNotificationCopy.mjs
supabase/proofs/push_single_target/promotion/edge-candidate/functions/uskoci-push-transport/index.ts
supabase/proofs/push_single_target/promotion/live-certificate-checked.json
supabase/proofs/push_single_target/promotion/live-edge-capture.json
supabase/proofs/push_single_target/promotion/live-preflight-capture.json
supabase/proofs/push_single_target/promotion/live-surface-capture.json
supabase/proofs/push_single_target/promotion/recapture-20261009/capture.json
supabase/proofs/push_single_target/promotion/recapture-20261009/cert.json
supabase/proofs/push_single_target/promotion/recapture-20261009/edge.json
supabase/proofs/push_single_target/promotion/recapture-20261009/surface.json
supabase/proofs/push_single_target/supabase/functions/_shared/pushNotificationCopy.mjs
supabase/proofs/push_single_target/supabase/functions/uskoci-push-transport/index.ts
```

**Dokaz posle promene:** Current kontrole i isolated bootstrap ne zavise od uklonjene kopije. Istorijski run/commit ostaje proverljiv. Nema slepog izvršavanja starog apply/revert kandidata.


### 7.3. Serverske promene i granica SV01–SV14

Originalna analiza opisuje 14 SV grupa u `dokazi/server_final/change_manifest.json`, sa 12 izvršnih polja po grupi. Taj fajl nije dostavljen. Nijedan kompletan pojedinačni SV zapis ne može se tvrditi rekonstruisanim iz dostupnih Markdown priloga. To ne sprečava konkretne poznate R zadatke, ali sprečava da se nepoznati zapis predstavi kao nalog za povlačenje objekta.

| SV oznaka | Stvarno dostupan sadržaj | Šta je dozvoljeno zaključiti |
|---|---|---|
| SV01 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV02 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV03 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV04 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV05 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV06 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV07 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV08 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV09 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV10 | Delimično: šest DEV tabela bez PK sa closure vezama, prema tekstualnoj referenci. | Sačuvati poznate lifecycle zavisnosti; tačan puni zapis i scope ostaju nedostupni. |
| SV11 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV12 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV13 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |
| SV14 | Pojedinačni zapis nije dostavljen. | Ne izmišljati identitet objekta, uslove, zamenu ili komandu. |

Sledeće serverske teme jesu izričito opisane u prilozima. Čuvaju se bez izmišljanja njihovih SV brojeva:

| Predmet | Konkretan redosled i očuvana granica | Uslov završetka |
|---|---|---|
| F21 i podrazumevane/efektivne dozvole | Urediti stvarni table/column grant i buduće default ACL; čuvati RLS svet/vlasnik i namerno javni legal bundle. PUBLIC EXECUTE razmotriti zasebno od anon/auth grantova. | Dozvoljene projekcije rade; direktni zabranjeni pristup i nove testne funkcije ne dobijaju neželjena prava. |
| Legacy intake delete | Proveriti podržane stare klijente; povezati active abandon/retention, pa kompatibilno zatvoriti zastareli RPC i njegove PUBLIC/role grantove. | Nema poziva na odsutne stare tabele, tuđeg pristupa ili promene značenja abandon-a. |
| PHONE | Povlačiti zajedno server/API/klijentski ugovor u skladu sa „Samo poruke”. | Stari klijent ne vraća PHONE; zaseban EXACT_LOCATION i njegove privatnosne provere rade. |
| Odbijajući taxonomy wrapper | Zadržati zatvoreno odbijanje dok kompatibilnost i dinamički/istorijski potrošači ne dozvole uklanjanje. | Nijedan caller ne može tiho vratiti stari automatski upis kategorije. |
| Sedam DEV snapshot/backup tabela | Šest ima sadašnje closure/redaction veze; needs snapshot i aktivan guard/dinamički scope. Odrediti retention i minimalan dokaz, prevezati te vlasnike pa uklanjati potvrđeni višak. | Export, redakcija, zatvaranje i vlasništvo pokrivaju sadašnji sadržaj bez odsutne relacije; potreban dokaz ostaje dostupan. |
| Dupli scope lookup indeks | Sačuvati primarni indeks; novom uskom migracijom povući samo potvrđeno redundantni `work_taxonomy_service_scopes_lookup`, nakon provere eksplicitnih zavisnosti. | Ista unikatnost i lookup; nema tvrdnje da je time dobijena velika merena ušteda. |
| Ostalih 136 performance preporuka | Raditi prema konkretnom query/trigger/lifecycle trošku, ne masovno dodavanje 93 indeksa ili brisanje 13 nula-scan indeksa. | Jednaka semantika i mereno opravdanje svake promene; policy OR publike ostaju ispravne. |

Za stvarno sprovedenu serversku promenu zapisati: tačan identitet; trenutno telo/prava; svrhu; poznate zavisnosti; odluku; zamenu; kompatibilnost; redosled; podatke/prava; povratni ili kompenzacioni postupak; prihvatanje; izvršeni status. Objekat ne povlačiti pre važećeg dokaza ovih uslova. Primena originalnog manifesta, kada bude dostupan, ostaje provera prema sadašnjem stanju, ne automatski DROP spisak.

### 7.4. Poreklo migracija, indeksi i granice statistike

Sledeći brojevi i definicije preneti su iz rev7 serverskog pregleda; u ovoj reviziji nisu ponovo upitani iz baze.

Z15 beleži svih 193 source migracija i 314 tadašnjih ledger zapisa. Isti ID postoji za 93 source fajla; 100 source ID-jeva nema isti DB ID, a 221 DB ID nema isti source ID. Po imenu se poklapa 94 source migracije; 97 nema ni isto ime ni verziju. Od 314 DB zapisa, 219 ima NULL statements. Samo 39 source fajlova je bajtno identično sačuvanim statements spojenim novim redom. Ovi brojevi označavaju poreklo, ne 100 unapplied migracija i ne zahtev za ledger repair.

| Source ID | DB ID | Naziv | Potpuno pročitana razlika |
|---|---|---|---|
| 20261026145430 | 20261026145706 | worker_ai_signed_work_areas | Samo dodatni završni CRLF; sva tri funkcijska tela ista. |
| 20261026150020 | 20261026150106 | worker_ai_area_source_continuity | Samo dodatni završni CRLF; telo funkcije isto. |
| 20261026150523 | 20261026150745 | classification_hint_revision_fence | Samo dodatni završni CRLF; sva četiri funkcijska tela ista. |

F14 zahteva odvojena dva puta: determinističku izgradnju novog izolovanog okruženja i kontrolisanu nadogradnju postojećeg DEV-a. Porediti definicije, grantove, policy/default izraze, triggere, indekse i potrebne referentne podatke. Ne izvoditi restore/repair na živom sistemu radi usklađivanja broja. Tri istorijske proof migracije sa fixture preduslovima ostaju poseban bootstrap problem iz odeljka 8.4 ovog plana; njihova pročitana prisutnost nije dokaz neuspeha svake obnove.

**Savetnici:** 325 security stavki u šest grupa i 136 performance stavki u pet grupa su presek rev7 pregleda, dok ranijih 322 ostaje istorijski. Svih 136 performansnih preporuka dobilo je zapis i vezu sa konkretnom tabelom, trenutnim indeksima i pronađenim funkcijskim referencama. 93 FK bez pokrivajućeg indeksa traže stvaran relevantan query/delete plan; 18 ponovljenih auth/current_setting poziva u RLS može se optimizovati samo uz očuvanu semantiku; pet permissive preklapanja može namerno predstavljati OR dozvoljenih publika. Trinaest indeksa sa nula evidentiranih scan-ova nije automatski za brisanje. Sedam snapshot tabela bez PK prvo zahteva odluku o životu i zavisnostima podataka.

Statistika je sa DEV-a: 167 public/private tabela, oko 25 MB sa njihovim indeksima/TOAST-om, ne veličina celog projekta. `n_live_tup`/`n_dead_tup` su procene. PostgreSQL je 17.6; zabeleženi globalni reset statistike je 20.08.2026. u 19:53:32 UTC, ali pojedinačni reset nije isključen. `track_functions=none`, pa nema osnove da se funkcija proglasi mrtvom na osnovu odsutnog broja poziva. Ovaj teret rada nije reprezentativan produkcioni benchmark.

**Dokazivo preklapanje indeksa:** `private.work_taxonomy_service_scopes_lookup` i `work_taxonomy_service_scopes_pkey` imaju btree nad `(category_id, normalized_scope)`, iste kolacije, klase, smer, broj ključnih/ukupnih atributa, tablespace i reloptions, bez izraza/predikata. Lookup je nonunique/nonprimary, bez constraint-a; PK je unique i vezan za primarni ključ. Lookup je validan/ready, 8.192 bajta, nula scan-ova. Povlačenje obuhvata novu migraciju, source kontrolu, proveru eksplicitnih index/hint zavisnosti i očuvanu unikatnost/lookup; PK ostaje. To nije nalog da se uklone ostali indeksni kandidati.

**Stare tabele sa sadašnjim potrošačima:** šest od sedam DEV snapshot/backup tabela je u `closure_taxonomy_inventory_v1`, `closure_redaction_relations_v5` i `closure_redaction_patch_v5`. `dev_phase1_20261014_needs_snapshot` dodatno čitaju `closure_taxonomy_snapshot_guard_v1` i dinamički `closure_taxonomy_scope_v1`. Za `dev_phase1_20261014_catalog_snapshot` nije pronađena qualified referenca u trenutnim telima; to nije dokaz odsustva istorijske/operativne potrebe. Povlačenje mora prvo promeniti kodirane inventare, guard i scope, sačuvati nužan audit/rollback dokaz i ponovo proveriti export/closure, pa tek potom ukloniti tabelu.

`pg_depend` ima 6.168 relevantnih veza; dodatni indeks iz svih 680 prethodno pročitanih, sveže identičnih tela sadrži kvalifikovane reference. U src/ i Edge source-u nađeno je 95 literalnih `.rpc` mesta u 87 imena. To nije potpun pozivni graf: generički transport, string tela, nekvalifikovani i dinamički nazivi, stari klijenti i operativni pozivi imaju posebnu proveru. [PostgreSQL dokumentacija](https://www.postgresql.org/docs/current/ddl-depend.html) izričito opisuje granicu praćenja zavisnosti u tekstualnim telima. Z16 zato čuva i nerešeni uslov umesto lažne dozvole za brisanje.

## 8. Prihvatanje, testovi i merenja

### 8.1. Kako se bira dovoljna provera

Za svaku promenu birati najkraći dokaz koji prelazi stvarnu rizičnu granicu. Promena wire ugovora traži stvarni odgovor kroz pravi decoder; promena prava pozitivni i negativni autorizovani zahtev; promena native geometrije stvarni prikaz i gest na uređaju. Izmena nekoliko reči sama ne zahteva novi veliki testni sistem.

Sačuvati korisne postojeće provere i dopuniti konkretno odsutni slučaj. Ne uvoditi hiljade testova koji samo preslikavaju implementaciju. Broj testova, source snapshot ili PASS pogrešne karakterizacije nisu dovoljan kriterijum. Istorijskih 14.143 testa i raniji CI uspeh nisu novo izvršenje ove revizije.

Pre starog harness-a pročitati njegov početni mutirajući rad, environment guard, obuhvat podataka i cleanup/rollback. `SELECT` koji poziva mutirajuću funkciju nije read-only. Destruktivni helper za DROP, repliku, cron ili prekid backend-a pripada potvrđenoj izolovanoj bazi sa odgovarajućim zadatkom, nikada nepoznatom DB_URL-u. Ovo pravilo ne sprečava rutinske lokalne i bezbedne read-only provere.

**Proverivač mora moći da padne:** tražiti stvarne obavezne grane, NULL-safe uslove i kardinalnost, neprazan fixture/oracle, pravi stage, aktuelno telo i pravi decoder. Neoznačeni fallback, izostali slučaj ili `notVerified` ne postaju PASS. D12 ima validan stvarni P5 dokaz, ali završni status ne zatvara sve dodatne gap grane. EX06 PARTIAL/SMOKE_ONLY ostaje ograničen dokaz. Istorijski equipment/fee/PHONE/11-stem test nije izvor sadašnje poslovne politike. Jake lock/RLS/receipt provere ostaju.

### 8.2. Zajednički prihvatni slučajevi A01–A25

Sledeći slučajevi su merila završnog ponašanja, a ne tvrdnja da svi danas padaju. Za SB/X se dodatni konkretan uslov nalazi u odgovarajućem R11 podzadatku ili R09/R10. Svaki scenario koristi postojeće smisleno pokriće i samo potreban dodatni dokaz. Rezultat se vezuje za tačan klijent/server i ne prenosi automatski na drugo izdanje.

| Scenario | Očekivano ponašanje i potrebna granica |
|---|---|
| **A01 Korekcija valute** |5.000 RSD→„mislio sam evre”: stara cena gubi status važeće saglasnosti; nema izmišljenog kursa/OFFERS. F03 guard→writer→signed review→accept/objava. |
| **A02 MY_PRICE satnica / OFFERS** |Jedinica ostaje ista kroz podržan domen; OFFERS zaseban izbor. F02 validator/Edge/application writer i stari podržani decoder. |
| **A03 Sinonim i tekstualni writer** |„Oprati prozorska stakla” za postojeće „Pranje prozora” bez upisanog alias-a: isti ID i isti scope, bez fasade/novog duplikata. F05 model→provera→review→binding; proveriti i Need text-trigger, canonical/registrovan/neupisan alias, pogrešnu parent putanju i ID-only binder. |
| **A04 Stvarno nova usluga** |Opravdan parent ili potrebna nova grana/path, konkretan smisao i stvarni DB ID; jasnoća ne zavisi od razmaka u nazivu. Predlog nije aktivna sposobnost pre potvrde. F05. |
| **A05 BOTH** |Časovi online i kod polaznika: oba moda, isti ID; kontrolisano izostavljanje REMOTE ne daje lažno potpun rezultat. F08 builder→review→Save. |
| **A06 Radionica/predaja** |Popravka računara kod izvršioca, donošenje/preuzimanje u Novom Sadu: REMOTE sa tim handoff-om, bez ON_SITE/kurira/svetske isporuke po pretpostavci. F08/F10. |
| **A07 Bogat profil** |Osam usluga: ukloniti jednu, dodati jednu, promeniti jedan mode; sve nepogođene usluge i handoff ostaju. Biografija se menja samo gde postaje netačna. Rename/sync ne gubi postojeći ID zbog neupisanog sinonima; nepoznato dodavanje uz staru uslugu ne ukida sve; izričito povlačenje ostaje delotvorno. F05/F06/F08. |
| **A08 Više područja** |Novi Sad 30 km ostaje, Subotica CITY→Beograd CITY; bez izmišljenog radijusa/GPS adrese. Stvarni resolver→workAreas→signed Save/readback/matching; ne tiho legacy svođenje. |
| **A09 ACTIVE + pending** |Pokazati konkretno čekanje nove promene, ne pripisati joj autoritet iz ACTIVE i ne ugasiti nezavisne stare potvrđene izbore bez server pravila. F06/F10. |
| **A10 Izgubljen Save/publish ACK** |Isti command/owner/digest, canonical readback, bez novog modela/evaluacije/objave pri samom povratku. DRAFT Save i aktivacija/objava ostaju odvojeni izbori. |
| **A11 Izgubljen abandon ACK** |ABANDONED+Proveri potvrđuje napuštanje bez novog prepare/write; OPEN kontrola ne daje lažan uspeh. F11. |
| **A12 Moji zadaci** |Svih 5 scope-ova, counts, prazna/neprazna prva i naredna strana/cursor, pravi task oblik kroz pravi decoder. F01. |
| **A13 Parcijalan katalog** |Neuspeli CHILDREN na malom stablu i nextCursor slučaj; potpun kasniji snapshot zamenjuje parcijalno. Nema lažnog „usluga ne postoji”. F04. |
| **A14 Dovršavanje klasifikacije** |Tehnički BG/capture prekid dobija bounded trajni nastavak. Uspešan BG zatim vreme→područje→„to je to” čuva tačan plan; stvarna usluga/mod promena odbacuje stari. F06/F07; per-attempt obračun. |
| **A15 Jedno pitanje** |Satnica + ponavljane subote: zadržati jasan posao, tražiti jednu sledeću odluku, sačuvati drugu nejasnoću. F12. |
| **A16 A→B→A/fokus** |Kasni turn/review/Save i F13 sporedni upis ne ožive samo zbog istog account ID-ja; ne brišu novi unos niti tuđu/noviju listu. |
| **A17 Tačna isporuka** |Source/Edge/SQL/flags/APK/OTA/device zabeleženi; obe uloge završe dogovorene tokove uz pravi readback. Kvalitet modela, latencija i trošak zahtevaju stvarno ograničeno merenje. F14. |
| **A18 Prirodan završetak** |Routing poznat +„to je to” vodi jednom pregledu bez obaveznog bio/kalendar/mode formulara; zaista obavezno nepoznato daje jedno pitanje. F09 i requester readiness. |
| **A19 Instalirani discovery ugovor** |Matrica podržani stari native/OTA × ciljni novi klijent × stvarni backend: cold onsite PAGE+MAP, prazno/popunjeno, pan/next page, PLACES, forMe/minimum budget, EXACT_PUBLIC, HOURLY politika i REMOTE bez MAP zahteva. F15/F02, uz očuvane ACL/anchor/cancel granice. |
| **A20 Greške u raspoloživom prostoru** |Isti failure na prvom ulazu i retry; PAGE uspeh/MAP failure; HALF/FULL/PEEK, mali ekran/veliki font, native map failure odvojeno. Objašnjenje i akcija vidljivi, lokacijsko dugme smisleno. F16. |
| **A21 Bezbedna dijagnostika** |Auth/permission/contract/network/deadline imaju razlikovljiv interni razlog, prikladan kratak korisnički tekst i retry; nema literalnog true ni privatnog provider/SQL sadržaja. F17. |
| **A22 Buduća dostupnost i izuzetak** |Izričita dostupnost od budućeg datuma ili jedan kalendarski izuzetak menja pravi kalendar/matching samo u traženom opsegu; druga pravila ostaju. Zona, lokalni datum i instant ostaju tačni, uključujući promenu sata. Nije novo obavezno pitanje u intervjuu niti nov dokaz kvara. |
| **A23 Privatnost, izvoz i zatvaranje** |Autorizovani izvoz, opoziv granta, javna privatnost i završetak zatvaranja imaju potvrđen status/readback. Kasni pokušaj ne obnavlja povučeni pristup; važeće zadržavanje podataka nije isto što i javna dostupnost. Sačuvan raniji kriterijum, bez tvrdnje da je ceo tok sada izvršen. |

Za SB/X slučajeve uslov zatvaranja je u njihovom redu, kod konkretnog vlasnika. Cilj je proverljiv poslovni i korisnički rezultat kroz tačno utvrđenu granicu. Dodatni nepovezani PASS, promenjen tekst bez popravljenog stanja ili sama jednakost hash-a ne zatvaraju nalaz.

#### Dodatne zajedničke granice

F21 prvo traži obnovljenu granicu privatnih kolona uz funkcionalne javne/sopstvene čitače. F18 traži istu listu dozvoljenih parova područje/topologija/vreme u retrieval→matcher→Za mene→dispatch, uz ručni submit/select koji zadržava svoje granice. F19 traži workAreas u svakoj živoj/arhivskoj projekciji i potpunu novu proveru izvoza/zatvaranja pre aktivacije. F20 traži kapacitet reda, same-revision response suppression i stvarni cilj pri PUSH on/IN_APP off. Pozitivne kontrole su običan prvi kandidat, validna stara sačuvana usluga, oba moda istogID-a, namerno isključen push i opravdano odbijena tuđa/istekla radnja.

Globalna provera čuva trenutne signed service-scope consent, saved review/request identitet, reviziju, account/world i kalendar. Current TOTAL je srazmeran covered/original slots; stare testove koji traže all-slots politiku prevoditi na važeći ugovor. Availability testovi sa New York uređajem često namerno očekuju Europe/Belgrade poslovnu politiku; nisu sami dokaz buga vremenske zone ili globalne podrške. OWNER_PERSONAL/OWNER_BUSINESS trenutno pripadaju TEST svetu kao namerna DEV izolacija; release izlaz je izričit preduslov, ne tiha data promena.

#### A24/A25 — dve izričite regresione granice celog toka

**A24, zamena javne objave:** `pregled-zadatka.tsx:201–210` i replacement decoder opisuju odvojenu novu objavu. Aktuelni `rpc_publish_need_canonical` odgovara telu u `20261021101159_staged_task_replacement.sql:812`, a `cancel_replaced_task` telu na `:639`; trenutni `finalize_task_replacement` dodatno odbija `NO_MATERIAL_CHANGE`. U istom publish pozivu finalizacija zatvara staru objavu i prijave pre potvrde nove, uz transakcioni rollback pri kasnijoj grešci. Nema prenosa tuđe prijave na nove uslove. To je SOURCE ugovor potvrđen aktuelnim body tragom i novim poređenjem otisaka, ne nov runtime PASS. R07/R08/R12 treba da sačuvaju uspešnu, odbijenu, neizmenjenu i prekinutu zamenu, bez gašenja prethodne objave pre uspeha. Četiri opisana body odnosa pripadaju rev7 dokazu; nisu novo izvršavanje ove revizije.

**A25, samo poruke:** STATUS već određuje povlačenje PHONE mogućnosti iz Dogovora. Aktivni `AgreementContactPlace` vodi u Poruke i odvojeno čuva lokacijsku dozvolu. Završni dokaz R11/R12 mora obuhvatiti server i podržane stare klijente; slobodno kucanje broja u poruci nije automatski nova moderaciona zabrana. To je zatvaranje važeće namere, bez vraćanja stare opcije iz istorijskih testova.

### 8.3. Tačno pročitani CI ulazi na a969

`package.json` i `.github/workflows/ci-clean.yml` ponovo su pročitani u ovoj reviziji na punom SHA iz odeljka 1. Sledeće su **stvarne komande tog workflow-a**, ne rekonstruisane komande iz nedostajućeg Z09 i ne tvrdnja da su sada pokrenute. Workflow koristi Node 24, Python 3.11 i Deno 2.5.6, uz 30-minutni job timeout i read pristup repozitorijumu.

```bash
npm ci
npx tsc --noEmit

deno check --no-config --no-lock --no-npm --no-remote \
  supabase/functions/uskoci-ai-interview/index.ts \
  supabase/functions/uskoci-worker-interview/index.ts \
  supabase/functions/uskoci-taxonomy-postsave-worker/index.ts

npm test -- --maxWorkers=2 --silent

node --test --test-concurrency=2 --test-reporter=dot supabase/proofs/ai/*.test.mjs

node --test --test-reporter=dot \
  supabase/proofs/dynamic_taxonomy/worker-interview-question-policy.test.mjs \
  supabase/proofs/taxonomy/published_need_category_gate.test.mjs \
  supabase/proofs/taxonomy/live_writer_characterization.test.mjs \
  supabase/proofs/dynamic_taxonomy/classification-owner-review.test.mjs \
  supabase/proofs/dynamic_taxonomy/worker-signed-review-source.test.mjs \
  supabase/proofs/dynamic_taxonomy/need-review-signed-source.test.mjs

node --test --test-reporter=dot \
  supabase/proofs/dynamic_taxonomy/classification-gemini-shadow.test.mjs \
  supabase/proofs/dynamic_taxonomy/service-handoff.test.mjs \
  supabase/proofs/dynamic_taxonomy/worker-existing-identity-recovery.test.mjs \
  supabase/proofs/dynamic_taxonomy/classification-direct-reply.test.mjs \
  supabase/proofs/dynamic_taxonomy/classification-verified-alias.test.mjs \
  supabase/proofs/dynamic_taxonomy/classification-turn-feedback.test.mjs \
  supabase/proofs/dynamic_taxonomy/classification-gemini-shadow-source.test.mjs

python supabase/migrations/check_migration_integrity.py
python -m unittest discover -s supabase/migrations -p test_migration_integrity.py
```

Izvršavati iz korena stvarne radne kopije uz postojeći lock i pročitana repo uputstva. `npm ci` pokreće postojeći postinstall: `patch-package --error-on-fail --error-on-warn`, `scripts/verify-native-patches.cjs` i `scripts/sync-entry-reference-assets.cjs`. Ne rešavati neuspeh preskakanjem tih zaštita. Instalacija može zahtevati dostupnu mrežu i odgovarajući runtime; odsutan preduslov beleži se kao blokada, ne kao prolaz. Plan ne nalaže nasumično ažuriranje zavisnosti.

Jest selekcija iz analize je `**/__tests__/**/*.test.ts?(x)`. `.mjs` nije Jest test samo zato što u imenu ima `test`; gornji Node izbor obuhvata AI glob i 13 imenovanih taxonomy testova. `taxonomy-postsave-worker.test.mjs` i `worker-finish-mode-completeness.test.mjs` nisu u toj Node selekciji. `v5_media_deno_runtime.test.ts` nije deo prikazanog izvršavanja. Njihov konkretan R zadatak određuje potreban zaseban poziv posle provere setup-a, bez uključivanja svih istorijskih mutirajućih alatki.

Globalni Jest setup koristi UTC i legacy HITNO flag; `urgent-hidden-in-v1` uklanja taj flag da sačuva odsustvo opcije u V1. To ne menja kanon proizvoda. Zasebna provera vremenskih zona mora koristiti drugi TZ i jasno poslovno pravilo.

`currency_correction_characterization.test.mjs` reprodukuje staru potvrđenu cenu/satnički nesklad, a `background_capture_receipt.test.mjs` odsustvo automatskog nastavka. Oba mogu biti zelena uz postojeći kvar. Posle popravke sačuvati reprodukcioni ulaz, a završni uslov uskladiti sa željenim ishodom. Prompt-string test `interview_voice_one_question.test.mjs` i SQL-string test `worker_signed_areas_sql.test.mjs` ostaju source zaštite; ne predstavljaju dokaz stvarnog odgovora ili Save-a.

Deno `check` ne pokreće model/server, Python integritet ne dokazuje primenu migracija, a ceo navedeni CI ne zamenjuje native build, živi SQL/API decoder, pravi model, push isporuku ili dve uloge na telefonima. Tačne preuzete testne putanje i nedostajući scenariji raspoređeni su uz R01–R12 u ovom dokumentu.

### 8.4. Bootstrap, nadogradnja i poreklo šeme

R12/F14 mora odvojeno dokazati podizanje novog izolovanog okruženja i kontrolisanu nadogradnju postojećeg. Broj source migracija i ledger zapisa sam ne određuje šta je primenjeno. Porediti stvarne funkcije, ACL, RLS, default/grant izraze, triggere, indekse i neophodne referentne podatke.

Tri istorijske proof migracije imaju posebne fixture preduslove:

| Migracija u `supabase/migrations/` | Potreban prethodni sadržaj |
|---|---|
| `20260901105922_clean_completion_and_writer_authenticated_proof.sql` | Potpuno pokriven aktivni Dogovor; inače `AUTH_PROOF_FIXTURE_REQUIRED`. |
| `20260901113333_clean_ai_interview_turn_authenticated_proof.sql` | Otvoren NEED_INTAKE; inače `AI_TURN_PROOF_FIXTURE_REQUIRED`. |
| `20260901114029_clean_ai_fact_supersession_and_human_correction.sql` | Otvoren razgovor sa aktivnom činjenicom; inače `AI_SUPERSESSION_PROOF_FIXTURE_REQUIRED`. |

Nije izvršen ceo izolovani replay koji bi dokazao da prethodni koraci zadovoljavaju ove uslove. Zato nisu dokazani ni neuspeh svake prazne instalacije ni potpuna reproduktivnost. Potreban je konkretan bootstrap/fixture plan i izvršen rezultat. Primenjena istorija ostaje neizmenjena; stare proof upise ne pokretati na živom sistemu samo zato što su smešteni u migrations folder.

Ranija sumnja da živo telo ne čuva samostalni `priceBasis` ostaje povučena: preuzeto živo telo ga ima, dok ga stariji source prethodnik nema. Otvoren je dokaz porekla i reproduktivne isporuke, a ne ponovo proglašen isti poslovni kvar. Detaljne brojeve i ograničenja porekla koristi odeljak 7.4.

### 8.5. Cele situacije i uređajski dokaz

Jedinstveni izvršni scenario je u odeljku 10.4, sa dva fizička telefona, odvojenim nalozima i zasebnim dokazom svake ciljane platforme. Prihvatni A slučajevi dodaju tačne rizične granice, a R matrice postojeće testne ulaze. Uključiti i offline povratak gde je relevantan; ni zastareo pregled ni neizvestan odgovor ne opravdavaju novu poslovnu radnju ili lažan uspeh.

Ovaj odeljak određuje sadržaj zapisa tog izvršenja. Svaka značajna promena koja poništava određeni dokaz ponavlja samo pogođeni scenario i potreban gate. Uspeh druge verzije, drugog naloga ili druge platforme ne popunjava nedostajući rezultat.

U zapis uređajskog dokaza uneti: scenario J/A/F, uloge, uređaj/OS/font, mrežu, source SHA, native build, OTA/runtime/kanal, backend/Edge/SQL presek, vreme radnje, očekivano, opaženo i granicu. Screenshot/video prati taj zapis; ne predstavlja samostalni dokaz nevidljivog serverskog upisa.

### 8.6. Pravi model, latencija, trošak i kapacitet

Determinističke ugovorne testove odvojiti od ograničenog živog korpusa. Semantička provera traži sačuvanu nameru, činjenice, sigurnu granicu i dozvoljen završetak; ne traži identičnu rečenicu pri svakom odgovoru. Pre živog rada odrediti korpus, broj pokušaja i ukupan budžet u odobrenom opsegu. Beležiti sve foreground/BG/STT pokušaje, retry, timeout, UNKNOWN, provider usage i ograničenja obračuna. Jedan logički posao može imati više stvarnih naplativih pokušaja.

Meriti korisnikov doživljaj i potvrđeni rezultat:

| Mera | Obavezan kontekst |
|---|---|
| Dodir → vidljiv lokalni odziv | Stvaran uređaj, tip radnje i stanje UI-ja. |
| Dodir → prvi koristan sadržaj | Hladno/toplo stanje, mreža, stream politika i verzija. |
| Dodir → potvrđen ishod/readback | Sve relevantne serverske faze i redovi, ne samo provider trajanje. |
| AI ukupni pokušaji i trošak | Korpus, model, tokeni, cache/BG/STT, UNKNOWN i retry. |
| Push čekanje i isporuka | Veličina reda, starost najstarijeg posla, claim/send/receipt/device faza. |
| Recovery posle restarta | Isti identitet radnje, podaci i konačan autoritativni rezultat. |

`PROVIDER` meri modelski stream, a `NEED_COMPLETE`/`WORKER_COMPLETE` SQL completion. Analizirani put zadržava tekst do prihvaćenog completion-a; nijedan taj timer sam nije vreme do korisnog rendera ili pregleda. Ubrzavanje mora sačuvati ovu granicu ili imati jednako jasan novi ugovor.

Uz p50/p95 navesti broj uzoraka i uslove. Četiri ranija realGemini poziva od oko 2,9–7,2 s nisu dokaz p95, odziva ispod sekunde ili uštede od 75%. `realSpendUsd:null` i istorijski koeficijenti nisu stvarna faktura ni dokaz čvrstog ukupnog limita. Cache tokeni uključeni u provider prompt ukupno ne sabiraju se još jednom kao dodatni tokeni.

**Početni predlozi za planiranje, bez tvrdnje da su odobreni ili izmereni:** približno 250 ms za lokalni odziv, do 3 s za tipično mrežno čitanje u dogovorenim uslovima i do 8 s za prvi koristan AI odgovor u p95 reprezentativnog uzorka. Pre release-a granice potvrditi ili obrazloženo promeniti na osnovu merenja; ne pomerati ih tiho radi prolaza. Postojeći discovery deadline od 15 s i stari prozor od 90 s nisu ciljevi normalnog korisničkog čekanja.

Kapacitet reda dokazati ograničenim očekivanim talasom i konkurentnim događajima. Deklarisan batch, uspešan SQL cron ili provider acceptance nisu dokaz uređajske isporuke. Broj sintetičkih profila nije broj istovremenih korisnika. Izmerena tehnička optimizacija prihvata se samo uz sačuvano značenje, prava, potpunost i korisnički rezultat.

## 9. Otvorene odluke i šta može napredovati odmah

Poznata ispravnost, interni tehnički izbor i promena poslovnog obećanja imaju različit postupak. Vlasniku se pokazuje konkretan, pregledljiv predlog samo gde odluka menja proizvod. Izbor klase, retry vlasnika, cache invalidacije ili rasporeda programerskog rada rešava izvršni tim u okviru važeće namere.

### 9.1. Satnica kroz broj ljudi i trajanje — R07b

Potrebno je zaključiti da li HOURLY označava cenu po osobi, sat cele ekipe ili izričitu podršku oba značenja. **Dve osobe × tri sata × 1.200 RSD = 7.200 RSD** kada je satnica po osobi; **tri sata × 1.200 RSD = 3.600 RSD** kada je to cena sata cele ekipe. Primer objašnjava ugovor, ne tvrdi da aplikacija već obračunava konačan račun.

Predlog najmanjeg jasnog ugovora jeste satnica po osobi, vidljivo označena kroz razgovor, review, objavu, prijavu, izbor i Dogovor. Kada trajanje nije poznato, prikazati ugovorenu satnicu bez izmišljene ukupne sume. Podrška oba značenja može biti odluka proizvoda, ali se ne izvodi iz enum-a. Pred odluku pripremiti povezane prikaze i tabelu posledica, uključujući kompatibilnost decoder-a.

**R07a korekcija zastarele RSD potvrde, F11 abandon i F13 zaštita paralelnog profila ne čekaju ovu odluku.** Korekcija „mislio sam evre” povlači staru nevažeću saglasnost, ali sama ne uvodi EUR, kurs ili automatski OFFERS.

### 9.2. Područje posla sa više lokacija — deo R05

Za Novi Sad–Beograd razlikovati rad na lokaciji, mesto preuzimanja, odredište i tranzit. Uporediti najmanje prevoz između gradova, dostavu sa više stanica i stvaran rad na dve lokacije.

| Predlog | Posledica koju treba prikazati |
|---|---|
| Sve stvarne radne tačke u sačuvanom području | Jasniji uslov višelokacijskog rada; može suziti preporuke prevozniku koji dobrovoljno vozi izvan svog polazišnog područja. |
| Polazište/preuzimanje u području uz vidljivu celu rutu | Širi izbor za prevoz; potrebno jasno odrediti za koje topologije važi i šta se obećava primaocu preporuke. |

Nijedan predlog nije ovim planom proglašen prihvaćenim. Ne zahtevati pokriće svakog tranzitnog kilometra i ne menjati ručni `responseAllowed` kao nuspojavu preporuka. Za POINT_TO_POINT/MULTI_STOP/AREA_BASED odluka mora imati tipizovan predicate, primere i pozitivne/negativne parove.

**Popravka stare profilne tačke, već određenog STATIONARY područja, izgubljenog COUNTRY/CITY/RADIUS kandidata i TODAY raspoloživosti napreduje nezavisno.**

### 9.3. Vizuelni pravac, dve mape i platforme

Pripremiti povezane reprezentativne ekrane na postojećim komponentama, sa uspešnim, praznim i neuspešnim stanjima. Potvrda pravca odnosi se na stvaran prikaz; ne tražiti od korisnika da unapred osmisli svaki razmak, naziv klase ili unutrašnje stanje.

Jasno označavanje trajnosti obe mape je obavezno odmah. Promena redosleda pregleda/mape ili mehanike potvrde je zaseban konkretan predlog: `ConversationPointAsk` sada čuva svaku potvrđenu tačku, a `NeedLocationForm` lokalni skup primenjuje kroz novi review. Vizuelno ujednačavanje ne sme neprimetno promeniti njihove writere.

Brojač „0 od 2 → 1 od 2 → 2 od 2” koristiti tek kada je potvrđeno da li model broji osobe, mesta ili timski kapacitet; klik nije autoritativni broj. Redosled Android/iOS objave određuje se prema stvarnom stanju i odluci vlasnika, uz zaseban dokaz za svaku platformu. Postojeće Android APK iskustvo daje početnu osnovu, ne automatsko odricanje od iOS cilja.

### 9.4. Šta nije skriveni deo ovog rada

Nove valute, monetizacija, HITNO, pretplate, ukidanje administrativnog grada, nova GPS SHARE funkcija, promena publike već obećanog javnog komentara ili zabrana brojeva u porukama imaju poseban razlog i odluku ako se uopšte predlažu. Povezivanje već obećane funkcije i ispravka potvrđenog tehničkog kvara ne čekaju izmišljenu novu poslovnu dilemu.

Odluke D01–D07 pominju se u istorijskom Z09, koji nije dostavljen. Ovaj plan čuva konkretne dostupne odluke opisane iznad; ne izmišlja sadržaj ni novo preslikavanje njihovih sedam originalnih identifikatora. Kada zapis postane dostupan, relevantan dokaz se povezuje sa ovim odeljkom bez drugog plana.

## 10. Produkcija, dokaz izdanja, prodavnice i podrška

### 10.1. Cilj, važenje i status

Cilj je potpuno dovršena aplikacija sa svim postojećim aktivnim funkcijama i potvrđenim obećanjima, proverena u stvarnoj upotrebi i pripremljena za Google Play i Apple App Store. Redosled platformskih izdanja može biti različit. Nezavršena aktivna funkcija ne uklanja se iz obima samo da bi izdanje dobilo zelenu oznaku; namerna promena proizvoda ima konkretnu odluku i usklađene posledice.

**Ovaj odeljak je izvršni plan, a ne potvrda da su produkcija, build, testeri, dokumenti, nalozi ili prijave već završeni.** Zvanični uslovi prodavnica navedeni su prema proveri od **27. oktobra 2026.** Pred predaju proveriti njihove tada važeće verzije i konkretne poruke konzole. Izvor aplikacije, stanje prodavnice i stvarno instalirani paket imaju zasebne dokaze.

Pročitani [README analiziranog izvora](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/README.md) zahteva odvojen, proveren produkcioni backend. U istom preseku [eas.json](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/eas.json) još sadrži DEV cilj u produkcionom profilu, a build contract namerno sprečava takvu objavu. **Zaštita ostaje uključena dok se ne ispuni njen stvarni uslov.** Stanje ponovo proveriti pre izmene; ne prenositi istorijski podatak kao novu runtime potvrdu.

R12 prikuplja dokaz od prve završene vertikale R01–R11. Konačni pregled povezuje tačne rezultate u jedno izdanje; nije prvo mesto na kome se proverava da li se delovi međusobno uklapaju.

### 10.2. Jedan proverljiv identitet izdanja

Za svakog kandidata voditi jedan zapis u ovom planu ili postojećem projektnom registru. Nema novog paralelnog sistema sertifikata. Ako je podatak nepoznat, označiti ga kao nepoznat i navesti kako se zatvara.

| Sloj | Obavezan sadržaj zapisa |
|---|---|
| Izvor | Repozitorijum, grana, commit, radno stablo, relevantni dependency lock i datum preseka. |
| Baza | Projekat/okruženje, stvarna šema, funkcije, ACL/RLS, primenjene migracije i poznate razlike. |
| Edge | Stvarno objavljene verzije i sadržaj pogođenih funkcija, ugovori i bezbedno proverene efektivne zastavice. |
| Native | Android/iOS, package/bundle ID, javna verzija, build broj, artefakt i bezbedni potpisni metapodaci. |
| OTA | Runtime, kanal, tačan update identitet i dokaz učitanog sadržaja gde je dostupan. |
| Konfiguracija | Auth, redirect-i, mejl, Storage, Realtime, push i ostali potrebni ugovori pravog okruženja; bez tajni u izveštaju. |
| Uređaji | Model, OS, način instalacije/nadogradnje, nalog/uloga, mreža i početno stanje scenarija. |
| Provere | Komanda ili scenario, vreme, rezultat, obuhvat, log bez privatnog sadržaja i relevantan screenshot/video. |
| Otvorene stavke | Vlasnik, razlog, posledica i da li blokira konkretno izdanje ili samo određenu platformu. |

Commit, SQL presek, Edge, native i OTA moraju odgovarati kombinaciji koja je zaista proverena. Zeleni CI drugog commita, stari About ekran ili istorijski telefon ne potvrđuju ovaj zapis. Native SDK, dozvole, potpis i druge native promene zahtevaju odgovarajući novi build; JavaScript OTA nije zamena za njega.

### 10.3. Produkcioni prelaz i obnova

1. **Potvrditi stvarni cilj.** Proveriti trenutno važeći produkcioni projekat, naloge izdavača i dozvoljene deploy radnje. Ne koristiti DEV kao produkciju i ne kopirati razvojne privatne podatke/testne naloge u javno okruženje. OWNER_PERSONAL/OWNER_BUSINESS izlaz iz namernog TEST sveta mora biti izričito projektovan i proveren.
2. **Dokazati bootstrap.** U sopstvenom izolovanom okruženju napraviti bazu iz dokumentovanih ulaza. Razdvojiti potrebni seed od dokaznih fixture-a; stara proof migracija može zahtevati ranije postojeći Dogovor ili AI razgovor. Proveriti stvarne funkcije, šemu, ACL/RLS, trigere i indekse. Uspešan zapis migracije nije dokaz njihove potpune semantičke jednakosti.
3. **Dokazati upgrade.** Nadograditi reprezentativan postojeći presek uz očuvanje podataka, prava i podržanih klijenata. Razlika broja ledger zapisa i source migracija nije sama kvar. Ne ponavljati primenjenu migraciju ili prepravljati istoriju radi lepšeg broja.
4. **Pripremiti kompatibilan redosled.** Najpre dodati i proveriti potrebne ugovore, zatim kompatibilnog klijenta, pa povući stari put kada prestane da bude potreban. Kritična privatnost se ne odlaže radi stare verzije; rešava se odgovarajućom kompatibilnom granicom ili eksplicitnim ograničenjem nepodržanog klijenta.
5. **Proveriti kompletnu konfiguraciju.** Auth/session, validni linkovi, aktivacioni mejl, dozvole, Storage, Realtime, Edge, push, ograničenja i potrebne zastavice moraju pripadati istom okruženju. Puna Auth management podešavanja i efektivne tajne koje nisu viđene ostaju neproverene; ne pretpostavljati njihove vrednosti.
6. **Uskladiti identitet aplikacije.** Paket, potpis, runtime/OTA i native dozvole pripadaju istom nameravanom izdanju. Analizirani [app.config.js](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/app.config.js) navodi Android store paket `rs.uskoci`; stvarni identitet i vlasništvo u Play Console tek treba potvrditi.
7. **Proveriti oporavak.** Za aplikaciju, Edge i bazu odrediti stvaran povratni ili kompenzacioni postupak. OTA rollback ne vraća šemu niti poništava već nastale poslovne podatke. Dokaz obnove izvodi se u odgovarajućem izolovanom okruženju, uz očuvanje potrebnih preimage/backup podataka.
8. **Pripremiti pristup recenzentu.** Namenski nalozi i reprezentativan sadržaj moraju omogućiti pregled obe uloge i važnih funkcija bez privilegija nad stvarnim tuđim podacima. Potreban backend ostaje dostupan tokom pregleda.

Pre starih harness-a proveriti prve mutacije, environment guard, obuhvat podataka i oporavak. SELECT nad mutirajućom funkcijom nije read-only. Bootstrap, destructive helper-i, masovni retry i proof upisi ne pokreću se na živom sistemu samo zato što postoje u istoriji. Primenjene migracije i stvarno potrebni dokazi porekla ostaju sačuvani.

### 10.4. Dokaz sa dva telefona i stvarnim korisničkim tokom

Završni dvostrani dokaz koristi **dva fizička telefona, dva odvojena testna naloga i stvaran kandidat aplikacije**. Korisnici moraju videti stvarne posledice radnje druge strane. Emulatori, izolovani SQL, mock i jednostrani screenshot ostaju korisni prethodni dokazi, ali ne zamenjuju završni prolaz. Za iOS objavu potreban je stvarni iOS dokaz; dve Android instalacije ga ne daju.

Proći celu priču: opis potrebe → ispravka → pregled → privatni nacrt i ponovno otvaranje → objava → pronalaženje → prijava → izbor → Dogovor → poruke/izmena/završetak → ocena. Odvojeno proveriti profil izvršioca, njegove oblasti i načine rada, Save/Save+activate, izmenu aktivnog profila i nepotvrđeni novi deo bez gašenja nepogođenih potvrđenih usluga.

Obavezne granice završnog prolaza:

- Stvaran model i stvarni upis/readback; nepromenjena usluga ostaje ista kroz novu reviziju, a stvarna promena odbacuje zastareli rezultat.
- Izgubljen odgovor, dupli dodir, restart, zastareo pregled i promena naloga ne stvaraju dupli efekat ili tuđi sadržaj. Nepoznat ishod proverava istu radnju.
- Oba načina iste usluge i relevantna REMOTE predaja imaju potpun i potvrđen smisao; nema lažne fizičke mape.
- Sačuvano područje i vreme prolaze retrieval, fit, „Za mene” i dispatch, uz odvojeno očuvanu ručnu prijavu. Buduća dostupnost i pojedinačni izuzetak menjaju samo traženi opseg; datum, zona i instant ostaju dosledni.
- Lista, mapa i filteri rade sa pravim objavljenim odgovorom i decoder-om; parcijalna greška ne skriva korisne rezultate.
- Push se prati kroz događaj, SQL/HTTP buđenje, claim, provider, uređaj i dodir. Stari TICK_OK, uspešan cron ili provider acceptance nisu svež uređajski dokaz. IN_APP/PUSH preference i autorizacija odredišta proveravaju se odvojeno.
- Poruke i prilozi imaju proverenu vidljivost, nacrt, oporavak i status; PHONE povlačenje pokriva server i podržane stare klijente, uz očuvanu zasebnu preciznu lokaciju.
- Tuđi nalog ne čita privatno; važeći pravni dokument, ponovljena potvrda, izvoz, opoziv download prava i završetak zatvaranja imaju pravi rezultat.
- Instalacija i nadogradnja sa minimalne podržane verzije čuvaju dozvoljene podatke i rešavaju stare komande. Pre deinstalacije proveriti lokalne nacrte; odvojeni preview/store identiteti ne garantuju njihov prenos.
- Mali ekran, uvećan tekst, tastatura, safe areas, Back/gest, čitač ekrana i reduced motion provereni su na odgovarajućoj platformi.

Merenje ovog prolaza koristi jedinstvene definicije, uzorkovanje i budžet iz odeljka 8.6. Zapis konkretnog izvršenja popunjava odeljak 8.5; nema druge paralelne metodologije ili zbirnog PASS-a bez poznatog kandidata.

### 10.5. Artefakti, izlazne kapije i odgovornost

Za svaki red u istom planu upisati **konkretnu odgovornu osobu**, datum i vezu do stvarnog rezultata. Uloge ispod su predlog raspodele odgovornosti, ne tvrdnja da je neko već preuzeo posao. Status počinje kao **UNPROVEN** dok izvršni dokaz ne postoji; konkretna prepreka dobija **BLOCKED**, a **PASS** važi samo za imenovani opseg. „Nije primenljivo” zahteva razlog koji odgovara stvarnom izdanju.

| Kapija / veza | Pregledljiv artefakt | Uslov izlaza | Odgovorna uloga | Početni status |
|---|---|---|---|---|
| Identitet; R01/R12 | Zapis source/SQL/Edge/native/OTA/uređaja | Svaki sloj stvarno potvrđen ili jasno ograničen; kandidat nije mešavina nepoznatih verzija. | Integrator izdanja | UNPROVEN za novi kandidat |
| Privatnost; R01/R10 | ACL/RLS, javne projekcije i negativne probe | Tri privatne kolone zaštićene; dozvoljeni čitači rade; nema prelaska naloga/sveta. | Vlasnik baze i bezbednosti | UNPROVEN |
| AI i potvrde; R04/R06/R08 | Semantički korpus, receipt/readback, attempt/usage rezultati | Potpuni očekivani skup, stabilan ID, pravi Save i ograničen nastavak/trošak. | Vlasnik AI ugovora | UNPROVEN |
| Povezivanje i posao; R03/R05/R07 | Ceo dvostrani scenario | Tačni uslovi, područja/vreme, prijava, izbor, Dogovor i završetak. | Vlasnik poslovnog domena | UNPROVEN |
| Poruke/push; R09/R11 | Svež trag do dva uređaja i autorizovanog odredišta | Potrebni događaji, preference, vidljivost, oporavak i kapacitet reda potvrđeni. | Vlasnik komunikacije | UNPROVEN |
| UI/UX; R02/R08/R11 | Matrica tok–ekran–radnja–vlasnik–test–telefon | Sve aktivne površine imaju konačna potrebna stanja i native dokaz. | Vlasnik UI/UX i mobilne provere | UNPROVEN |
| Podaci i pravni tok; R10 | Verzije dokumenata, consent, export i closure rezultati | Pravi dokument, potrebne kopije, autorizacija i stvaran završetak; binding kapije nisu zaobiđene. | Vlasnik podataka i izdavač | UNPROVEN |
| Reprodukcija/obnova; R11/R12 | Bootstrap, upgrade, parity i restore/kompenzacija | Potrebna šema/prava reprodukovani; podaci i podržani klijenti sačuvani. | Vlasnik baze i isporuke | UNPROVEN |
| Čist aktivni izvor; R11/R12 | Stvarni manifest izmena/povlačenja i zavisnosti | Uklonjen samo dokazani višak; potrošači prevezani, obavezne provere očuvane. | Integrator i vlasnici domena | UNPROVEN |
| Produkcija; R12 | Potvrđena ciljna konfiguracija i build contract | Zaseban proveren backend; nema DEV/TEST curenja; zaštita ostaje delotvorna. | Vlasnik isporuke | BLOCKED prema analiziranom preseku; osvežiti |
| Android; R12 | Potpisan AAB, Play probe i popunjena prijava | Ispunjene primenljive Android/Play obaveze iz sledećeg odeljka. | Android vlasnik i izdavač | UNPROVEN |
| iOS; R12 | Potpisan iOS kandidat, uređaj/TestFlight i prijava | Ispunjene primenljive iOS/Apple obaveze iz sledećeg odeljka. | iOS vlasnik i izdavač | UNPROVEN |
| Operacije; R12 | Kontakti, obrada prijava, nadzor i postupak incidenta | Neko stvarno prima i obrađuje zahteve; postoji postupak za neispravno izdanje. | Operativni vlasnik | UNPROVEN |
| Konačna predaja; R12 | Potpun pregled kandidata i otvorenih rizika | Sve obavezne primenljive kapije imaju dokaz; važeće ovlašćenje pokriva predaju/puštanje. | Vlasnik proizvoda i izdavač | Nije odobreno ovim dokumentom |

Za svaki R zadatak završni zapis sadrži problem i posledicu za korisnika, promenjenog postojećeg vlasnika, pozitivnu i negativnu kontrolu, stvarni nivo dokaza i preostalo ograničenje. Ukupan broj PASS testova ne nadoknađuje nedostajući ključni dokaz. Proverivači moraju odbiti nedostajući/NULL/pogrešan rezultat, praznu fixture granu i neoznačen fallback.

### 10.6. Zajednički uslovi proizvoda za prodavnice

**Izdavač i podrška.** Potvrditi stvarni identitet/tip izdavača i obavezne kontakte. Podrška mora primati zahteve sa objavljenih adresa i iz aplikacije. Pravila i politika privatnosti moraju biti javno dostupni i odgovarati stvarnom izdanju; ne ostaviti nacrt, nepopunjeno polje ili link bez sadržaja.

**Mapa podataka.** Popisati nalog, profil, lokaciju, poruke, fotografije/glas, AI obradu, push identifikatore i dijagnostiku, kao i stvarne primaoce/SDK-ove, svrhu, prenos i rokove zadržavanja. Prijave privatnosti ne prepisuju se iz generičkog obrasca. Google Data safety obuhvata i prikupljanje/deljenje kroz ugrađene SDK-ove. [P3]

**AI i saglasnost.** Jasno objasniti koje podatke spoljašnji AI prima i zašto. Apple zahteva jasno otkrivanje i izričitu dozvolu pre deljenja ličnih podataka sa spoljnim AI-jem. Proveriti konkretan tok, verziju obaveštenja i potvrde; postojanje opšte politike samo po sebi nije dokaz ispravne izričite dozvole. Ne uvoditi dodatno pitanje pri svakom pozivu bez razloga iz stvarnog ugovora. [P10]

**Korisnički sadržaj i zaštita.** Potrebni su odgovarajuće prijavljivanje neprimerenog sadržaja/korisnika, blokiranje gde je primenljivo i stvaran proces obrade. Google zahteva odgovarajuću stalnu moderaciju, a Apple obuhvata zaštite za UGC u 1.2. Dugme bez obrade ne završava tok. Definisati odgovornog primaoca, način provere, dozvoljenu meru i obaveštavanje po važećim pravilima; ovaj plan ne izmišlja novu kaznenu ili moderacionu poslovnu politiku. [P4] [P10]

**Dozvole i brisanje.** Mikrofon, fotografije, lokacija i push traže se kada korisnik razume njihovu svrhu. Odbijanje ima smislen nastavak gde je moguć. Brisanje mora stvarno obuhvatiti potrebne podatke, kopije i integracije, uz objašnjena primenljiva zadržavanja. Neispravan retention/export/closure binding popravlja se sadržajno; ne menja se očekivani hash/certifikat samo radi prolaza. Blokirano brisanje nije konačan prihvatljiv korisnički ishod. [P5] [P9]

**Materijal za prijavu.** Naziv, ikona, opis, uzrast/sadržaj, screenshotovi i uputstvo moraju odgovarati funkcijama proverenog kandidata. Pokriti obe uloge i važne dozvole. Ako nema naplate platforme, ne vraćati stare naknade radi popunjavanja listinga ili dokumentacije. Eventualna buduća monetizacija ima zasebnu poslovnu odluku i proveru tada primenljivih store pravila.

### 10.7. Android i Google Play

APK služi Android instalaciji/probi. Za novu Play aplikaciju pripremiti odgovarajući **potpisan Android App Bundle (AAB)** i proveriti aplikaciju koju Play stvarno isporučuje. Uspeh lokalnog APK-a nije dokaz tog paketa. [P1]

| Stavka | Potreban konkretan rezultat |
|---|---|
| Nalog i paket | Potvrđen vlasnik/tip Play naloga, potrebna verifikacija, aplikacija u konzoli, package ID i ovlašćen pristup. |
| Potpis i artefakt | AAB, odgovarajući ključevi/potpis i bezbedno čuvani potpisni podaci; proverene Play instalacije. [P1] |
| Target nivo | Prema proveri 27.10.2026, nova telefonska aplikacija ili update cilja Android 16 / API 36 ili viši; ne oslanjati se na raniji API 35 prag. Pred predaju potvrditi aktuelni primenljivi zahtev. [P2] |
| Native biblioteke | Proverene potrebne 64-bitne biblioteke i 16 KB kompatibilnost stvarnog paketa, uz primenljivi rok/obaveštenje konzole. [P6] |
| Privatnost | Data safety, politika, dozvole i SDK ponašanje međusobno odgovaraju konačnom build-u. [P3] |
| Brisanje naloga | Put u aplikaciji i javna veb mogućnost za zahtev brisanja naloga i pripadajućih podataka; stvarni postupak iza oba ulaza. [P5] |
| Testiranje | Internal/closed proba kandidata. Za lični nalog otvoren posle 13.11.2023. primenjuje se najmanje 12 prijavljenih testera neprekidno 14 dana pre zahteva za production pristup; potvrditi da li važi za ovaj nalog. [P7] |
| Pregled | Pristup recenzentu, podaci za obe uloge, ispravan listing, sadržajni upitnici i odgovarajuća provera pre objave. |
| Puštanje | Kandidat i primenljive kapije provereni; predaja i javno puštanje pokriveni važećim ovlašćenjem. |

Nalog, testeri, završeni dani testiranja i deklaracije nisu ovim dokumentom potvrđeni. Ispunjenih 14 dana nije automatska garancija production pristupa ili prihvatanja aplikacije. Store paket i preview paket mogu imati različite identitete i lokalne podatke.

### 10.8. iOS i Apple App Store

iOS dobija sopstveni build, potpis, native provere i prijavu. Zajednički Expo/React Native izvor može deliti poslovni kod, ali Android dokaz ne potvrđuje iOS dozvole, tastaturu, navigaciju, medije, linkove ili push.

| Stavka | Potreban konkretan rezultat |
|---|---|
| Nalog i aplikacija | Potvrđen Apple Developer/App Store Connect pristup, identitet izdavača, bundle ID, potpis i potrebne capabilities. |
| Toolchain | Prema proveri 27.10.2026, minimum za predaju uključuje Xcode 26 ili noviji i iOS 26 SDK ili noviji. To nije tvrdnja da minimalno podržani telefon mora imati iOS 26. [P8] |
| Uređaj i TestFlight | Provereni stvarni iOS tokovi, instalacija, dozvole, back/gest, tastatura, mediji, linkovi i push; odgovarajuća TestFlight proba kandidata. |
| Brisanje naloga | Pokretanje brisanja iz aplikacije. Sama deaktivacija ili obavezan običan mejl podršci nisu dovoljan opšti tok za ovu vrstu aplikacije. [P9] |
| App Privacy i SDK-ovi | Tačni App Privacy odgovori, potrebni privacy manifests i razlozi za obuhvaćene API-je prema stvarnim zavisnostima/build-u. [P11] [P12] |
| Spoljni AI | Jasno objašnjenje i izričita dozvola pre deljenja ličnih podataka sa spoljnim AI-jem. [P10] |
| Način prijave | Ako postoje obuhvaćene društvene prijave, proveriti odgovarajuću alternativu prema pravilu 4.8. Email/password sam po sebi ne znači automatsku obavezu Sign in with Apple. [P10] |
| Korisnički sadržaj | Funkcionalne zaštite i obrada prema 1.2, zajedno sa pravilima proizvoda. [P10] |
| Predaja | Opis, screenshotovi konačnog kandidata, uzrast/sadržaj, support/privacy linkovi, nalozi i napomene za pregled obe uloge. |

Nedostajući iOS dokaz ostaje otvorena iOS stavka. Ne zaustavlja nepovezani Android rad, ali se ne prikriva tvrdnjom da je „aplikacija spremna za obe prodavnice”.

### 10.9. Podrška, nadzor i oporavak posle puštanja

Pre javnog izdanja odrediti stvarnu odgovornu osobu i postupak za kvar glavnog toka, privatnost, zastale pozadinske poslove, porast AI troška, neuspešno brisanje i prijavu neprimerenog sadržaja. Koristiti postojeće instrumente i vlasnike; nova administrativna aplikacija nije automatski potrebna.

Pratiti verziju uz crash/grešku, uspeh ključnih radnji, vreme do potvrđenog ishoda, starost najstarijeg posla, zaostatak reda, nepoznate provider ishode, stvarne neuspehe dostave i zaostatak podrške. Log ne sadrži tajne, sirove privatne razgovore ili nepotrebne lične podatke. Za svaku metriku unapred odrediti vlasnika, značaj i konkretan uslov koji pokreće reakciju; cilj se ne pomera prećutno radi prolaza.

Postupak incidenta obuhvata: potvrdu pogođene verzije i opsega, bezbedno zaustavljanje daljeg štetnog efekta kroz postojeće kontrole, očuvanje potrebnog dokaza, popravku ili kompatibilan povratak, proveru integriteta podataka i proveru obnovljenog korisničkog toka. Klijentski rollback ne označava bazu automatski vraćenom. Radnje nad živim podacima i javnom isporukom moraju ostati u važećem odobrenom obimu.

Pre svake naredne verzije sačuvati konkretne izmene, pogođene granice, provere i postupak za zaustavljanje ili popravku lošeg izdanja. Prva objava i update nemaju svuda iste opcije postepenog puštanja; odabrati dostupnu kontrolu publike prema konkretnoj konzoli. Ne obećavati da se već instalirana loša verzija svuda trenutno uklanja.

### 10.10. Konačna potvrda R12 i nastavak rada

Završni paket u jedinstvenom planu sadrži stvarni manifest promena i povlačenja, postojeće vlasnike i njihove zavisnosti, izvršene provere, poznatu isporučenu kombinaciju, konačna stanja ekrana, dokaze obnove i preostala ograničenja. Analitički manifest nije potvrda izvršenog povlačenja. Istorijski dokazi čuvaju svoje vreme; novi status se zasniva na novom rezultatu.

Pre konačne odluke imenovati tačan Android/iOS kandidat, potvrditi sve primenljive obavezne kapije i navesti svaku preostalu stavku sa posledicom. Nerešena privatnost, gubitak podataka, lažan uspeh, neprohodan osnovni tok, nedostupno obavezno brisanje, nepoznata produkcija ili neispunjen primenljivi store uslov blokiraju odgovarajuće izdanje. Manja prihvaćena nepravilnost ima vlasnika i plan popravke; nečitljivo ili zaklonjeno glavno dugme nije takva sitnica.

Pripremiti sve što je potrebno da predaja bude konkretna i pregledljiva pre završne odluke o puštanju. Postojanje ovog plana ne predstavlja novu dozvolu za javnu objavu, plaćanje ili destruktivnu produkcionu radnju. Već važeća korisnikova ovlašćenja ostaju važeća; rutinske nezavisne pripreme i provere ne zahtevaju ponovljeno odobrenje.

Rok za objavu određuje se nakon svežeg preseka, procene konkretnih zadataka, platformskih uslova i stvarnih dokaza. Broj testova ili dužina izveštaja ne određuju datum. Posle svakog završenog dozvoljenog koraka nastaviti sledeći relevantni korak, ažurirati iste R/J/F/SB/X veze i kratko prijaviti rezultat i preostalu prepreku. Ne proglašavati background rad nakon završetka aktivne sesije.

### Zvanični izvori prodavnica za ovaj odeljak

- **P1:** [Google Play, Android App Bundle](https://support.google.com/googleplay/android-developer/answer/9844279)
- **P2:** [Google Play, target API nivo](https://support.google.com/googleplay/android-developer/answer/11926878?hl=en)
- **P3:** [Google Play, Data safety](https://support.google.com/googleplay/android-developer/answer/10787469?hl=en)
- **P4:** [Google Play, korisnički sadržaj](https://support.google.com/googleplay/android-developer/answer/9876937?hl=en-GB)
- **P5:** [Google Play, brisanje naloga](https://support.google.com/googleplay/android-developer/answer/13327111?hl=en)
- **P6:** [Android Developers, 16 KB kompatibilnost](https://developer.android.com/guide/practices/page-sizes)
- **P7:** [Google Play, testiranje novih ličnih naloga](https://support.google.com/googleplay/android-developer/answer/14151465?hl=en)
- **P8:** [Apple, aktuelni zahtevi predaje](https://developer.apple.com/news/upcoming-requirements/)
- **P9:** [Apple, brisanje naloga u aplikaciji](https://developer.apple.com/support/offering-account-deletion-in-your-app/)
- **P10:** [Apple App Review Guidelines, posebno 1.2, 4.8 i 5.1.2(i)](https://developer.apple.com/app-store/review/guidelines/)
- **P11:** [Apple, privacy manifests i SDK obaveze](https://developer.apple.com/news/?id=3d8a9yyh)
- **P12:** [Apple, App Privacy Details](https://developer.apple.com/app-store/app-privacy-details/)

[P1]: https://support.google.com/googleplay/android-developer/answer/9844279
[P2]: https://support.google.com/googleplay/android-developer/answer/11926878?hl=en
[P3]: https://support.google.com/googleplay/android-developer/answer/10787469?hl=en
[P4]: https://support.google.com/googleplay/android-developer/answer/9876937?hl=en-GB
[P5]: https://support.google.com/googleplay/android-developer/answer/13327111?hl=en
[P6]: https://developer.android.com/guide/practices/page-sizes
[P7]: https://support.google.com/googleplay/android-developer/answer/14151465?hl=en
[P8]: https://developer.apple.com/news/upcoming-requirements/
[P9]: https://developer.apple.com/support/offering-account-deletion-in-your-app/
[P10]: https://developer.apple.com/app-store/review/guidelines/
[P11]: https://developer.apple.com/news/?id=3d8a9yyh
[P12]: https://developer.apple.com/app-store/app-privacy-details/

## 11. Kontinuitet: ažurira se ovaj isti plan

### 11.1. Jedan operativni ulaz

`CODEX_PLAN_RADA.md` ostaje dokument iz kojeg se nastavlja rad. Novi nalaz, odluka ili izvršeni rezultat unosi se uz odgovarajući postojeći R/J/F/SB/X/C zapis. Ne praviti još jedan „master”, paralelni backlog ili dopunu koju korisnik mora ručno da spaja. Kada veća izmena promeni prioritet, ažurirati ovaj redosled i obrazložiti promenu.

Kod, testovi, slike, build i sirovi rezultati prirodno ostaju stvarni projektni artefakti. U planu se čuva kratak indeks njihovog identiteta i značenja. Oni dokazuju zapis; nisu alternativni planovi sa drugačijim instrukcijama. Nedostupni dokaz ne dobija izmišljenu putanju, sadržaj ili PASS.

Svaka sesija počinje čitanjem poslednjeg statusa ovog plana i uskim osveženjem relevantnog izvora, deployment-a i korisničkih odluka. Nije potreban novi potpuni audit pre svakog malog zadatka. Uloga osveženja je da se sačuvaju novije izmene, postojeći dobri vlasnici i stvarna kompatibilnost.

### 11.2. Početni operativni status ove revizije

| Celina | Trenutno dostignuto | Sledeći stvarni izlaz |
|---|---|---|
| Jedinstveni plan | Objedinjeni dostupni zahtevi, nalazi, putanje, scenariji, UI/UX i release obaveze. | Ažurirati isti dokument posle stvarnog rada. |
| R01–R12 | Izvršno razrađeni zadaci sa postojećim vlasnicima i kriterijumima. | Konkretna implementacija i odgovarajuća provera u odobrenom opsegu. |
| J01–J14 i pomoćni ulazi | Definisane povezane korisničke priče i inventar grupa. | Route/stanje mapa stvarne verzije, razrađeni prikazi i uređajski dokaz. |
| F/SB/X | Sačuvano svih 42 nalaza i primarno R mapiranje. | Zatvarati pojedinačno stvarnim ishodom; preneti dokaz nije nov incident ni popravka. |
| C01–C19 | Sačuvana konkretna jedinica promene, putanje, očuvano i preduslovi. | Proveriti sadašnje potrošače i sprovesti samo opravdano povlačenje. |
| Satnica i više lokacija | Konkretni izbori i njihove posledice pripremljeni u odeljku 9. | Odluka za zahvaćeni ugovor; nepovezane popravke napreduju. |
| Konačni izgled | Uslovi i proces razrade uključeni u plan. | Stvarni nacrti potrebnih stanja, implementacija i snimci kandidata. |
| Produkcija i prodavnice | Poznate kapije i materijal koji treba završiti. | Ispunjen stvarni produkcioni cilj i provereni Android/iOS kandidati. |

Izraz „definisano” nije „nacrtano”, „nacrtano” nije „implementirano”, a „implementirano” nije „dokazano na telefonu”. U završnom statusu nijedna od tih kolona ne popunjava drugu automatski.

### 11.3. Zapis jednog završenog ili blokiranog koraka

| Polje | Sadržaj koji se ažurira u ovom planu |
|---|---|
| Identitet | Datum; R/J/F/SB/X/C; tačna namera i obuhvat. |
| Polazište | Repo/branch/SHA; relevantni backend/Edge/native/OTA; korisnička odluka ako je promenjen ugovor. |
| Promena | Postojeći vlasnici, konkretne putanje i efekat koji korisnik dobija. |
| Očuvano | Granice naloga/revizije, prava, saglasnosti, idempotentnost i podržani čitači. |
| Provera | Stvarna komanda ili uređajski scenario, ulazi, vreme, rezultat i nivo dokaza. |
| Negativna kontrola | Koji pogrešan, tuđ, zastareo ili nepoznat ishod je zaista odbijen/rešen. |
| Status | DEFINED / IN_PROGRESS / IMPLEMENTED / VERIFIED na navedenom nivou; BLOCKED sa konkretnim razlogom; REJECTED uz razlog. |
| Isporuka | Commit/diff/build/OTA identitet gde postoji; bez tvrdnje o neizvršenom deploy-u. |
| Ograničenje i nastavak | Preostali posao, njegov vlasnik/zavisnost i prvi sledeći dozvoljeni korak. |

Statusi mogu biti jednostavniji u postojećem repo registru, ali značenje mora ostati isto. Ne održavati dve neusaglašene verzije činjenice. Ako je rezultat istorijski, navesti tadašnji presek i relevantnu razliku.

### 11.4. Izvršni nalog za narednu odobrenu implementacionu sesiju

Sledeći tekst je sastavni deo ovog plana i može se koristiti kao početni nalog uz korisnikovo zaduženje za implementaciju:

> Nastavi USKOČI iz aktuelnog fizičkog repozitorijuma prema ovom jedinstvenom `CODEX_PLAN_RADA.md`. Pročitaj stvarno dostupna važeća repo uputstva, README i STATUS; proveri relevantnu deltu od `a9692e11942609bab9406215c3e407d79589dafa`, stvarne pogođene server/klijentske ugovore i poslednje korisničke odluke. Sačuvaj novije izmene i postojeće dobre vlasnike. Ne rekonstruiši stari projekat iz memorije.
>
> Prvo zatvori R01 privatnu kolonsku granicu i tačan kompatibilni ugovor. R02 i R03 mogu zatim napredovati nezavisno gde ne menjaju istog vlasnika. R04/R06 povezuju potpun semantički rezultat i trajni nastavak; R05/R07/R08 dovršavaju stvarni poslovni i korisnički rezultat. Nezavisne R09/R10/R11 popravke izvodi po njihovim stvarnim zavisnostima. R12 prikuplja integracioni i uređajski dokaz od prve završene celine, a konačni release prolaz dolazi posle relevantnih kapija.
>
> Za svaku vertikalu poveži korisničku radnju, postojeći reader/writer, UI stanje, tačnu proveru i gde je potrebno telefon. Sačuvaj account/focus/revision granice, journal pre slanja, signed review, stvarnu saglasnost, stabilan identitet i readback. Predlog, Save, aktivacija, objava i matching autoritet ostaju različiti. Ne uvodi treći AI sistem, parcijalne kartice, dodatne obavezne formulare ili stare PHONE/HITNO/naknade iz istorijskih testova.
>
> Izaberi najmanju povezanu promenu koja rešava potvrđeni uzrok. Sačuvaj relevantne postojeće provere i dodaj samo nedostajući dokaz stvarnog rizika. CI i izolovana proba ne predstavljaju sami native/server/model PASS. Zastareo karakterizacioni PASS promeni tek zajedno sa stvarnom popravkom i odgovarajućom kontrolom. Stare SQL kandidate ne primenjuj kao celinu preko novijih funkcija.
>
> UI/UX razradi u istom radu: stvarni prikazi, nazivi, glavni i sporedni koraci, loading/empty/error/partial/offline/unknown, povratak, tastatura, veliki font i pristupačnost. Novi prikaz mora biti povezan sa pravim stanjem; screenshot ne zamenjuje readback. Ne traži ponovo ista tri stara snimka. Za nedostajuće aktuelne prikaze pripremi konkretnu malu grupu scenarija i nastavi sve što ne zavisi od njih.
>
> Satnicu i višelokacijsko područje razreši konkretnim prikazom opcija iz odeljka 9 kada zahvaćeni ugovor dođe na red. Nepovezane poznate popravke ne zaustavljaj. Tehničke izbore rešavaj samostalno unutar važeće namere; korisniku ostavi stvarne poslovne i veće vizuelne odluke.
>
> Čišćenje sprovedi po C paketima tek uz potvrđene potrošače, zamenu i potreban dokaz. Primenjene migracije, neophodni rollback/audit izvori i aktivni delovi mešovitih modula ostaju. Nedostajući SV manifest nije dozvola za izmišljeni DROP. Production guard, izvoz/closure binding i privatnosna ograničenja se sadržajno zadovoljavaju, ne zaobilaze.
>
> Posle svakog završenog dozvoljenog koraka ažuriraj ovaj isti plan: šta je promenjeno, zašto, kako je provereno, na kojoj verziji, šta ostaje i koji korak sledi. Nastavi sledeći relevantan dozvoljeni korak bez rutinskog traženja nove potvrde. Ako postoji stvarna prepreka, precizno je navedi i završi nezavisan rad. Produkcionu predaju pripremi kao konkretan pregledljiv kandidat; izvrši je kada važeće korisničko ovlašćenje pokriva tu radnju.

### 11.5. Prvi pregledljiv izlaz nastavka

Prvi izlaz nije novi opšti izveštaj. To je osvežen zapis relevantnog izvora i ugovora, konkretna popravljena R01 granica sa pozitivnim/negativnim dokazom kada je implementacija odobrena, pa prva završena R02/R03 vertikala prema zavisnostima. Uz to nastaje početna matrica stvarnih ekrana i nedostajućih prikaza, sa poznatim identitetom telefonske verzije. Potreban dokaz i blokade beleže se ovde.

Rok se određuje prema stvarnom izvršnom preseku, obimu zahvata, uređajima i uslovima prodavnica. Dužina dokumenta, broj fajlova ili veliki broj starih testova nisu osnov za datum. Konačan pregled R12 mora pokazati stvaran proizvod koji korisnik može proći, a ne samo zbir zatvorenih tehničkih kartica.

## 12. Izvori, nedostajući dokaz i obuhvat objedinjavanja

### 12.1. Dostavljeni materijal

Operativne instrukcije iz dostupnih priloga unesene su u odgovarajuće odeljke ovog plana. Sledeći izvori služe poreklu i proveri ranijih zaključaka, a ne ručnom sklapanju dodatnih planova. Izvorna imena fajlova imaju dodatke `(1)`, `(2)` ili `(3)` iz preuzimanja; ne označavaju sami različit poslovni kanon.

| Oznaka | Izvor | Veličina i SHA-256 dostavljenog sadržaja |
|---|---|---|
| D1 | [PROCITAJ_PRVO (1).md](https://chatgpt.com/library?file_id=libfile_af1d195761c08191810beabec28d7b54&account_id=personal) | 6,768 bajta; `785fa8a9aa5f770afabce4ee340f5bc3dcfc2acc915e117af5fcdaba2e10716c` |
| D2 | [USKOCI_IZVESTAJ (1).md](https://chatgpt.com/library?file_id=libfile_16847a3164048191a1928eac6741b2b7&account_id=personal) | 122,293 bajta; `4c9bfcd588ee907ba1fc5fd6cede913177a944df3088246b9b428b4208bb6c60` |
| D3 | [CODEX_PLAN_RADA (3).md](https://chatgpt.com/library?file_id=libfile_0698d8f07f0481918eb6673cba090560&account_id=personal) | 76,146 bajta; `6415f2b7ddf2f95e4f087d69898e8594ff5d9745988c6caf183468f46058ce4b` |
| D4 | [TEHNICKI_DOKAZI (1).md](https://chatgpt.com/library?file_id=libfile_fcb6db7fab888191b17c186afdd3716b&account_id=personal) | 201,566 bajta; `a6175e283ddce98dc95ff4f5ba713dceb720fb12ac3a89b5569d046b1998068f` |
| D5 | [MANIFEST (1).json](https://chatgpt.com/library?file_id=libfile_20ebab9074048191903ef0c2f90d8507&account_id=personal) | 24,572 bajta; `1caf6bf264a35aa78c80bec312c9d165a3def5f16756db18cbc3fa6de645074a` |
| D6 | [USKOCI_IZVESTAJ (2).pdf](https://chatgpt.com/library?file_id=libfile_c607057cfa38819197ddb1afa3268fa9&account_id=personal) | 573,205 bajta; `31342dbc3d9252ba49611efea5bbc227d10e3db1a04a56841290066a154eed50` |

Pet payload priloga sadržajno odgovara njihovim zapisima u manifestu. Manifest ukupno navodi 125 payload fajlova, pa 120 zasebnih dokaznih fajlova nije deo dostavljenog sadržaja. PDF ima 40 strana i sadrži ranije screenshotove; slike nisu istovremeno dostupne kao njihove originalne pojedinačne datoteke.

**Šta nije rekonstruisano:** sadržaj nedostajućih JSON/log/SQL dokaznih fajlova, originalne per-R komandne linije/preduslovi iz Z09, potpun individualni SV01–SV14 manifest, svaki zapis originalnog registra svih putanja i nedostupan Downloads masterplan. Poznati tekstualni zahtevi, imena testova i uslovi jesu ugrađeni. Odgovarajući dokaz se pribavlja ili ponovno stvara pre konkretnog zahvata koji od njega zavisi.

Oznake Z01–Z16, E, P, N, EX, PKG i slične unutar prenetih tehničkih matrica označavaju istorijske izvore/probe, a ne dodatne fajlove navodno priložene uz ovaj plan. Zvanični store izvori P1–P12 imaju zasebne pune URL-ove u odeljku 10. Nema tvrdnje da su nedostajući istorijski dokazi danas ponovo izvršeni.

### 12.2. Usko pročitani trenutni repozitorijum

Repo: `uskocibusiness-boop/USKOCI-EAN`; grana: `feature/uskoci-cisto`; SHA: `a9692e11942609bab9406215c3e407d79589dafa`. Poređenje grane sa SHA u ovoj reviziji vratilo je identično, ahead 0 / behind 0. Konkretni pročitani ulazi:

- **G1:** [README.md](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/README.md).
- **G2:** [STATUS.md](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/STATUS.md).
- **G3:** [app.config.js](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/app.config.js).
- **G4:** [eas.json](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/eas.json).
- **G5:** [package.json](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/package.json).
- **G6:** [.github/workflows/ci-clean.yml](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/.github/workflows/ci-clean.yml).
- **G7:** [supabase/proofs/ai/background_taxonomy_failures.test.mjs](https://github.com/uskocibusiness-boop/USKOCI-EAN/blob/a9692e11942609bab9406215c3e407d79589dafa/supabase/proofs/ai/background_taxonomy_failures.test.mjs) — samo početni setup i potvrda putanje, bez izvršavanja.

Nisu preuzeti svi repo fajlovi niti ponovljen live Supabase pregled u ovoj reviziji. Istorijsko pokriće 3.335 tekstualnih fajlova / 626.320 redova, 99 binarnih resursa i ukupno 3.434 praćene putanje pripada ranijem kumulativnom direktnom/hash/diff/semantičkom pregledu iz priloga. Ne predstavlja novi full read, instalaciju ili runtime potvrdu.

### 12.3. Provera sadržajne pokrivenosti ovog plana

Objedinjavanje zadržava svih 42 nalaza sa primarnim R mapiranjem, svih 12 R paketa i R11a–h, J01–J14, A01–A25 i C01–C19. Uz R pakete stoje dostupni vlasnici i per-R testne matrice; uz cleanup su konkretne putanje i preduslovi. UI/UX, telefonski dokaz, produkcija, obe prodavnice i podrška deo su istog operativnog toka.

Prethodna zasebna rev8 dopuna je sadržajno ugrađena. Aktuelan dokument za sledeći rad je ovaj `CODEX_PLAN_RADA.md`. Izmena koja kasnije promeni neku činjenicu ažurira isti zapis i njegovo vreme; istorijski dokaz se ne preimenuje u sadašnji rezultat.
