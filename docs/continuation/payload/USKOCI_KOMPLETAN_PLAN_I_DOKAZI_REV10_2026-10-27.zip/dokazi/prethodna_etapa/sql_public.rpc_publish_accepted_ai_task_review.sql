CREATE OR REPLACE FUNCTION public.rpc_publish_accepted_ai_task_review(p_review_id uuid, p_client_request_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
declare u uuid:=auth.uid(); r private.ai_task_reviews; c private.ai_task_review_commands; v_published jsonb;
begin
 if u is null then raise exception 'AUTH_REQUIRED' using errcode='28000'; end if;
 perform private.closure_assert_open(u);
 lock table private.publication_policy_bundles,private.publication_policy_rule_refs,private.location_market_configs in share mode;
 select * into r from private.ai_task_reviews where id=p_review_id and account_id=u;
 if not found then raise exception 'TASK_REVIEW_NOT_FOUND' using errcode='42501'; end if;
 select * into c from private.ai_task_review_commands where review_id=r.id and account_id=u for update;
 if not found or c.client_request_id is distinct from p_client_request_id then raise exception 'TASK_REVIEW_COMMAND_MISMATCH' using errcode='42501'; end if;
 if c.state='PUBLISHED' then return private.ai_task_review_command_document(r.id); end if;
 if c.state<>'EVALUATED' or c.evaluation#>>'{decision,outcome}' is distinct from 'ALLOW' then raise exception 'PUBLICATION_DECISION_NOT_ALLOW' using errcode='55000'; end if;
 if r.policy_binding is distinct from private.ai_task_review_policy(r.envelope#>>'{location,taskCountryCode}')
 then raise exception 'TASK_REVIEW_POLICY_STALE' using errcode='PT409'; end if;
 v_published:=public.rpc_publish_need_canonical(c.need_id,c.need_revision,(c.evaluation#>>'{decision,decisionSequence}')::bigint,
  (r.envelope->>'responseDeadline')::timestamptz,'v5-publish:'||r.id::text);
 update private.ai_task_review_commands set state='PUBLISHED',published=v_published where review_id=r.id;
 return private.ai_task_review_command_document(r.id);
end $function$
