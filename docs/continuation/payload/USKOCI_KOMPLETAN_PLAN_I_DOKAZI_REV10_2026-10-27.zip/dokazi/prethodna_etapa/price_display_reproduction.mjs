// Current full Edge handler; synthetic Auth, SQL and Gemini only. No network.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {loadOwnedIntakeHandler} from '../current/supabase/proofs/ai/owned_intake_edge_runtime.mjs';
const root=new URL('../current/',import.meta.url);
const id=n=>`${String(n).padStart(8,'0')}-1111-4111-8111-111111111111`;
const account=id(1),conversation=id(2),requestId=id(3),turnId=id(4),attemptId=id(5);
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json'}});
const env={SUPABASE_URL:'https://synthetic.invalid',SUPABASE_ANON_KEY:'SYNTHETIC_ANON',SUPABASE_SERVICE_ROLE_KEY:'SYNTHETIC_SERVICE',
 AI_PROVIDER:'gemini',GEMINI_API_KEY:'SYNTHETIC_PROVIDER',GEMINI_MODEL:'gemini-3.8-flash',USKOCI_GEMINI_PAID_TEST_ENABLED:'true',
 USKOCI_TAXONOMY_DUAL_GEMINI:'false',USKOCI_TAXONOMY_UNIFIED_SHADOW:'false'};
let completion,providerCalls=0;const calls=[];
const turn=(state='PROCESSING',body={})=>({conversationId:conversation,clientRequestId:requestId,state,turnId,retryAllowed:false,
 receipt:state==='SUCCEEDED'?{userMessageId:id(6),assistantMessageId:id(7),proposedCount:body.p_proposals.length,safety:body.p_safety,schemaVersion:'NEED_FACT_V2',authoritative:true}:null});
const runtime=loadOwnedIntakeHandler({env:n=>env[n],log:()=>{},fetch:async(url,init={})=>{
 url=String(url);const body=init.body?JSON.parse(init.body):null;calls.push(new URL(url).pathname);
 if(url.endsWith('/auth/v1/user'))return json({id:account});
 if(url.includes('/ai_conversations?'))return json([{id:conversation,account_id:account,status:'OPEN',fact_schema_version:'NEED_FACT_V2'}]);
 if(url.endsWith('/rpc_ai_claim_need_turn_v2_service'))return json({turn:turn(),claim:{attemptId,leaseExpiresAt:new Date(Date.now()+90000).toISOString(),context:{schemaVersion:'NEED_FACT_V2',history:[],activeFacts:[]}}});
 if(url.endsWith('/rpc_ai_test_budget_reserve_service'))return json({admitted:true,reservationId:id(8),replay:false,code:'AI_TEST_RESERVED'});
 if(url.endsWith('/rpc_ai_dispatch_need_turn_v2_service'))return json(true);
 if(url.startsWith('https://generativelanguage.googleapis.com/')){
  providerCalls++;return json({candidates:[{content:{parts:[{text:JSON.stringify({safety:'ALLOW',assistantMessage:'Razumem cenu.',
   facts:[{key:'need.price_rsd',valueJson:'100',displayValue:'100 EUR',confidence:0.95,evidence:'100 RSD'}],
   dialogue:{next:'ACK',questionKey:'NONE',taskRelation:'CONTINUE',priceUnit:'UNSPECIFIED',schedulePattern:'UNSPECIFIED'}})}]},finishReason:'STOP'}]});
 }
 if(url.endsWith('/rpc_ai_complete_need_turn_v2_service')){completion=body;return json(turn('SUCCEEDED',body));}
 if(url.endsWith('/rpc_ai_fail_need_turn_v2_service'))return json(turn('FAILED'));
 assert.fail('UNEXPECTED_SYNTHETIC_ROUTE '+new URL(url).pathname);
}});
const response=await runtime.handler(new Request('https://edge.invalid',{method:'POST',headers:{Authorization:'Bearer SYNTHETIC','Content-Type':'application/json'},
 body:JSON.stringify({conversationId:conversation,clientRequestId:requestId,text:'Cena je 100 RSD.'})}));
const output=await response.json();assert.equal(response.status,200);assert.equal(providerCalls,1);
assert.equal(completion.p_proposals.length,1);assert.equal(completion.p_proposals[0].key,'need.price_rsd');
assert.equal(completion.p_proposals[0].value,100);assert.equal(completion.p_proposals[0].displayValue,'100 EUR');
const sqlEvidence=[
 ['supabase/migrations/20260910130851_clean_w02_resolved_location_authority.sql','1419-1528','writer independently validates numeric value and nonempty displayValue, then stores both'],
 ['supabase/migrations/20260907120000_clean_ai_need_draft_safety_authority.sql','53-143','review returns stored display_value unchanged'],
 ['supabase/migrations/20261021103954_task_review_writer_readiness.sql','177-197','signed taxonomy review copies displayValue; only handoff is rederived'],
 ['supabase/migrations/20261021101159_staged_task_replacement.sql','572-635','signed acceptance binds the envelope digest, then confirms facts by server identity'],
].map(([path,lines,rule])=>({path,lines,rule,sha256:createHash('sha256').update(readFileSync(new URL(path,root))).digest('hex')}));
const result={head:'5e7790e8445e09f38275ec19bdb86e8948c66558',boundary:'CURRENT_FULL_EDGE_HANDLER_WITH_SYNTHETIC_IO; SQL chain is a separate static source trace, no PostgreSQL/live/provider/device execution',
 input:'Cena je 100 RSD.',providerCalls,httpStatus:response.status,completion,output,calls,sourceHashes:runtime.sourceHashes,sqlEvidence,assertionsPassed:true,contradictoryDisplayReachesWriter:true};
const path=fileURLToPath(new URL('price_display_reproduction.json',import.meta.url));writeFileSync(path,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({assertionsPassed:true,httpStatus:response.status,proposal:completion.p_proposals[0],output:path},null,2));
