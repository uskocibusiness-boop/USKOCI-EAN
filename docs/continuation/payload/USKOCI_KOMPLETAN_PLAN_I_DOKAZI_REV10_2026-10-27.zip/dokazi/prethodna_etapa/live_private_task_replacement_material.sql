CREATE OR REPLACE FUNCTION private.task_replacement_material(p_need uuid)
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
 with source as (
  select private.need_full_edit_snapshot(n.id) as s,d.handoff,d.critical_conditions
  from public.needs n left join public.need_requirement_details d on d.need_id=n.id where n.id=p_need
 ), normalized as (
  select s || jsonb_build_object(
   'approximateCity',nullif(s->>'approximateCity',''),
   'approximateArea',nullif(s->>'approximateArea',''),
   'publicTopology',jsonb_strip_nulls(case when s#>'{publicTopology,waypoints}'='[]'::jsonb
      then (s->'publicTopology')-'waypoints' else s->'publicTopology' end),
   'privateLocation',case when s->'privateLocation'='null'::jsonb then null
     else jsonb_strip_nulls((s->'privateLocation')||jsonb_build_object(
       'exactAddress',nullif(s#>>'{privateLocation,exactAddress}',''),
       'accessNotes',nullif(s#>>'{privateLocation,accessNotes}',''))) end,
   'criticalConditions',to_jsonb(array_remove(coalesce(critical_conditions,'{}'::text[]),
      'Predaja: '||private.taxonomy_handoff_display_v1(handoff))),
   'handoff',handoff) as s from source
 ) select jsonb_strip_nulls(case when s->'privateLocation'='{}'::jsonb then s-'privateLocation' else s end) from normalized;
$function$
