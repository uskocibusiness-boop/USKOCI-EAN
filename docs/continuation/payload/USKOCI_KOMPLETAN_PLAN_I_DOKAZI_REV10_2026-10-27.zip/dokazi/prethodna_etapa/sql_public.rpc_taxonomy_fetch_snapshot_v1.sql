CREATE OR REPLACE FUNCTION public.rpc_taxonomy_fetch_snapshot_v1(p_generation integer DEFAULT 1)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'pg_catalog'
 SET statement_timeout TO '5s'
AS $function$
DECLARE
 v_version bigint; v_fingerprint text; v_items jsonb; v_result jsonb;
BEGIN
 IF coalesce(auth.jwt()->>'role','')<>'service_role' THEN
  RAISE EXCEPTION 'TAXONOMY_SNAPSHOT_DENIED' USING errcode='42501'; END IF;
 IF p_generation IS DISTINCT FROM 1 THEN
  RAISE EXCEPTION 'TAXONOMY_SNAPSHOT_INVALID' USING errcode='22023'; END IF;
 SELECT catalog_version INTO v_version FROM private.work_taxonomy_control WHERE singleton;
 v_fingerprint:=private.taxonomy_admission_fingerprint_v1();
 IF v_version IS NULL OR v_version<1 OR v_fingerprint IS NULL OR v_fingerprint!~'^[0-9a-f]{32}$' THEN
  RAISE EXCEPTION 'TAXONOMY_SNAPSHOT_CATALOG_UNAVAILABLE' USING errcode='55000'; END IF;

 -- Top-down walk from the roots over ESTABLISHED categories. Ancestry is organisation, not permission to perform a
 -- leaf's mode (the same rule the paged catalogue query states): an item is listed when it has its OWN direct
 -- ON_SITE/REMOTE mode row and an ESTABLISHED chain to a root; ancestors need no mode of their own.
 WITH RECURSIVE modes AS (
   SELECT m.category_id, array_agg(DISTINCT m.execution_scope::text ORDER BY m.execution_scope::text) AS scopes
   FROM private.work_taxonomy_category_modes m
   WHERE m.execution_scope IN('ON_SITE','REMOTE')
   GROUP BY m.category_id
 ), tree(id,label,canonical_key,parent_id,path_labels,path_ids) AS (
   SELECT c.id,c.label,c.canonical_key,c.parent_id,ARRAY[c.label]::text[],ARRAY[c.id]::uuid[]
   FROM private.work_taxonomy_categories c
   WHERE c.state='ESTABLISHED' AND c.parent_id IS NULL
  UNION ALL
   SELECT c.id,c.label,c.canonical_key,c.parent_id,t.path_labels||c.label,t.path_ids||c.id
   FROM tree t
   JOIN private.work_taxonomy_categories c ON c.parent_id=t.id AND c.state='ESTABLISHED'
   WHERE NOT c.id=ANY(t.path_ids)
 )
 SELECT coalesce(jsonb_agg(jsonb_build_object(
   'categoryId',t.id,'label',t.label,'parentId',t.parent_id,
   'aliases',coalesce((SELECT jsonb_agg(a.label ORDER BY a.label COLLATE "C")
      FROM (SELECT DISTINCT al.label FROM private.work_taxonomy_aliases al WHERE al.category_id=t.id) a),'[]'::jsonb),
   'modes',to_jsonb(mo.scopes),
   'path',to_jsonb(t.path_labels),'pathIds',to_jsonb(t.path_ids),
   'isLeaf',NOT EXISTS(SELECT 1 FROM tree ch JOIN modes cm ON cm.category_id=ch.id WHERE ch.parent_id=t.id)
  ) ORDER BY t.canonical_key COLLATE "C",t.id),'[]'::jsonb)
 INTO v_items FROM tree t JOIN modes mo ON mo.category_id=t.id;

 v_result:=jsonb_build_object('schemaVersion','TAXONOMY_CATALOG_SNAPSHOT_V1','generation',1,
  'catalogVersion',v_version,'catalogFingerprint',v_fingerprint,
  'count',jsonb_array_length(v_items),'categories',v_items,
  'classificationAuthority','NONE','capabilityAuthority','NONE','notificationAuthority','NONE');
 IF octet_length(v_result::text)>4194304 THEN
  RAISE EXCEPTION 'TAXONOMY_SNAPSHOT_TOO_LARGE' USING errcode='54000'; END IF;
 RETURN v_result;
END $function$
