// Read-only analytical reproduction. No source changes, database or network.
// Native-imports the exact checked-in loader; all RPC responses are synthetic.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const sourceUrl = new URL('../source/supabase/functions/_shared/backgroundTaxonomyArchitect.mjs', import.meta.url);
const sourceSha256 = createHash('sha256').update(readFileSync(sourceUrl)).digest('hex');
assert.equal(sourceSha256, '712738b1f724c6478d9b57ffca8a6b1ba2dbb6755dc5853f6e54f7654a495bf5');
const previousFetch = globalThis.fetch;
let networkCalls = 0;
globalThis.fetch = async () => { networkCalls++; throw new Error('NETWORK_FORBIDDEN_BY_ANALYTICAL_PROBE'); };

const version = 19;
const fingerprint = '11111111111111111111111111111111';
const id = number => '00000000-0000-4000-8000-' + String(number).padStart(12, '0');
const node = (number, parentId = null, isLeaf = true) => ({
  categoryId: id(number), label: 'Synthetic service ' + number, aliases: [],
  parentId, modes: ['ON_SITE'], path: ['Synthetic service ' + number],
  pathIds: [id(number)], isLeaf,
});
const page = (operation, items, nextCursor = null) => ({
  schemaVersion: 'TAXONOMY_CATALOG_QUERY_V1', action: 'CATALOG_QUERY',
  operation, scope: 'ALL', catalogVersion: version, catalogFingerprint: fingerprint,
  items, count: items.length, nextCursor,
  classificationAuthority: 'NONE', capabilityAuthority: 'NONE', notificationAuthority: 'NONE',
});
const opaqueCursor = kind => Buffer.from(JSON.stringify({
  schema: 1, query: 'synthetic-' + kind, version, fingerprint, rank: 100,
  key: 'synthetic-service-100', id: id(100),
})).toString('base64');

try {
  // Isolated module instance prevents one fixture's cache from contaminating another.
  const smallLoader = await import(sourceUrl.href + '?probe=small');
  const smallNodes = [node(1, null, false), node(2, id(1), true)];
  const smallCalls = [];
  const smallRpc = async (name, args) => {
    smallCalls.push({ name, query: args?.p_query ?? null });
    if (name === 'rpc_taxonomy_fetch_snapshot_v1') throw new Error('SYNTHETIC_SNAPSHOT_UNAVAILABLE');
    assert.equal(name, 'rpc_taxonomy_query_catalog_service');
    const query = args.p_query;
    if (query.operation === 'META') return { ok: true, data: page('META', []) };
    if (query.operation === 'ROOTS') return { ok: true, data: page('ROOTS', [smallNodes[0]]) };
    assert.equal(query.operation, 'CHILDREN');
    assert.equal(query.categoryId, id(1));
    return { ok: true, data: page('CHILDREN', [smallNodes[1]]) };
  };
  const small = await smallLoader.loadFullCatalogTree(smallRpc, new AbortController().signal);
  assert.deepEqual(small.categories.map(item => item.categoryId), smallNodes.map(item => item.categoryId));
  const positiveControlCalls = smallCalls.slice();

  const pagedLoader = await import(sourceUrl.href + '?probe=paged-and-recovery');
  const roots = Array.from({ length: 101 }, (_, index) => node(index + 1, null, index !== 0));
  const children = Array.from({ length: 101 }, (_, index) => node(index + 1001, id(1), true));
  const allNodes = [...roots, ...children];
  const pagedCalls = [];
  let snapshotAvailable = false;
  const pagedRpc = async (name, args) => {
    pagedCalls.push({ name, query: args?.p_query ?? null });
    if (name === 'rpc_taxonomy_fetch_snapshot_v1') {
      if (!snapshotAvailable) throw new Error('SYNTHETIC_SNAPSHOT_UNAVAILABLE');
      return { ok: true, data: { catalogVersion: version, catalogFingerprint: fingerprint, categories: allNodes } };
    }
    assert.equal(name, 'rpc_taxonomy_query_catalog_service');
    const query = args.p_query;
    if (query.operation === 'META') return { ok: true, data: page('META', []) };
    if (query.operation === 'ROOTS') return { ok: true, data: page('ROOTS',
      query.cursor ? roots.slice(100) : roots.slice(0, 100), query.cursor ? null : opaqueCursor('roots')) };
    assert.equal(query.operation, 'CHILDREN');
    assert.equal(query.categoryId, id(1));
    return { ok: true, data: page('CHILDREN',
      query.cursor ? children.slice(100) : children.slice(0, 100), query.cursor ? null : opaqueCursor('children')) };
  };
  const partial = await pagedLoader.loadFullCatalogTree(pagedRpc, new AbortController().signal);
  const loadedIds = new Set(partial.categories.map(item => item.categoryId));
  const missingIds = allNodes.filter(item => !loadedIds.has(item.categoryId)).map(item => item.categoryId);
  const cursorCalls = pagedCalls.filter(call => call.query?.cursor);
  assert.equal(allNodes.length, 202);
  assert.equal(partial.categories.length, 200);
  assert.deepEqual(missingIds, [id(101), id(1101)]);
  assert.equal(cursorCalls.length, 0);
  const fallbackCallCount = pagedCalls.length;

  snapshotAvailable = true;
  const recovered = await pagedLoader.loadFullCatalogTree(pagedRpc, new AbortController().signal);
  assert.equal(pagedCalls.length, fallbackCallCount + 1);
  assert.equal(recovered, partial);
  assert.equal(recovered.categories.length, 200);

  // NEED's RPC adapter returns HTTP failure envelopes instead of throwing.
  // Reuse the positive control's complete two-node tree; only CHILDREN differs.
  const failureLoader = await import(sourceUrl.href + '?probe=need-child-http-failure');
  const childFailureCalls = [];
  const childFailureRpc = async (name, args) => {
    childFailureCalls.push({ name, query: args?.p_query ?? null });
    if (name === 'rpc_taxonomy_query_catalog_service' && args.p_query.operation === 'CHILDREN') {
      return { ok: false, status: 503, data: { code: 'SYNTHETIC_RPC_UNAVAILABLE' } };
    }
    return smallRpc(name, args);
  };
  const afterChildFailure = await failureLoader.loadFullCatalogTree(childFailureRpc, new AbortController().signal);
  assert.equal(afterChildFailure.categories.length, 1);
  assert.deepEqual(afterChildFailure.categories.map(item => item.categoryId), [id(1)]);
  assert.equal(networkCalls, 0);

  const result = {
    schema: 'SERVER_CATALOG_ANALYTICAL_PROBE_V1',
    sourceCommit: 'a9692e11942609bab9406215c3e407d79589dafa',
    sourcePath: fileURLToPath(sourceUrl), sourceSha256,
    sourceChanged: false, sourceLoad: 'native ESM import with fixture-specific module cache key',
    environment: { node: process.version, realRpcCalls: 0, modelCalls: 0, networkCalls },
    positiveControl: { expectedNodes: 2, actualNodes: small.categories.length, passed: true, calls: positiveControlCalls },
    pagedFallback: {
      expectedNodes: allNodes.length, actualNodes: partial.categories.length, missingIds,
      advertisedNextCursor: ['ROOTS', 'CHILDREN'], cursorRequests: cursorCalls.length,
      calls: pagedCalls.slice(0, fallbackCallCount), reproduced: true,
    },
    recoveredSnapshotSameVersionAndFingerprint: {
      snapshotContains: allNodes.length, actualNodes: recovered.categories.length,
      reusedPartialObject: recovered === partial, calls: pagedCalls.slice(fallbackCallCount), reproduced: true,
    },
    needShapedChildHttpFailure: {
      expectedNodes: 2, actualNodes: afterChildFailure.categories.length,
      failedResponse: { ok: false, status: 503, data: { code: 'SYNTHETIC_RPC_UNAVAILABLE' } },
      resultWasReturnedWithoutThrowing: true, calls: childFailureCalls, reproduced: true,
    },
    limits: [
      'All catalog content and cursors are synthetic; no deployed database or provider was called.',
      'This proves the loader control flow on these fixtures, not current DEV catalog incompleteness.',
      'The six-batch guard and ancestry without modes were inspected statically, not exercised here.',
    ],
  };
  const outputUrl = new URL('./server_catalog_probe_result.json', import.meta.url);
  writeFileSync(outputUrl, JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ output: fileURLToPath(outputUrl), expectedNodes: allNodes.length,
    pagedActual: partial.categories.length, recoveredActual: recovered.categories.length,
    childFailureExpected: 2, childFailureActual: afterChildFailure.categories.length, networkCalls }));
} finally {
  globalThis.fetch = previousFetch;
}
