# USKOČI — pregled i izvršenje, 27.10.2026.

Pregledana su oba dostavljena paketa, potvrđeno polazište na GitHub-u i lokalno, osveženi relevantni DEV metapodaci i završena izolovana klijentska popravka F17 sa 347 prolaznih testova i TypeScript proverom. REV10 ostaje operativni plan R01–R12; REV14 određuje ciljnu UX arhitekturu. Ovaj zapis je evidencija izvršenja i odluka uz taj plan, a ne novi konkurentni plan.

## Šta je potvrđeno

| Provera | Rezultat | Granica dokaza |
|---|---|---|
| REV10 prenos | 138/138 sadržajnih fajlova odgovara veličinama i SHA-256 u manifestu; nema izgubljenih priloga. | Potvrđuje prenos, ne istorijsku tačnost svakog nalaza. |
| REV14 struktura | 77 jedinstvenih ugovora u JSON-u, od toga 50 označenih `Full screen` i 27 drugih površina. | Nije dokaz 77 implementiranih ekrana. |
| Source | Lokalni `USKOCI-CISTO` i udaljeni `feature/uskoci-cisto` na `a9692e11942609bab9406215c3e407d79589dafa`. | Original ima dodatnu nepraćenu fasciklu priloga; praćeni kod nije izmenjen. |
| DEV | Potvrđen `leqcwgzvjsxugfgzdmth`, 15 Edge funkcija i 314 stavki migracionog ledgera. | Metadata nije identitet deployed bundle-a niti dokaz source parity-ja. |
| R01/F21 | `authenticated` ima table SELECT i efektivni SELECT nad sva tri privatna Need polja; `anon` ih nema. | Nisu čitani tuđi poslovni redovi; nema tvrdnje o stvarnom incidentu ili anonimnom curenju. |
| R01 preflight | Izvršen u read-only transakciji; pronađena 21/21 očekivana funkcija; snimljene politike, prava, potpisi, hash-evi i API konfiguracija. | Ne zamenjuje sintetičke Auth/PostgREST pozitivne i negativne kontrole. |
| Closure | Sveža read-only provera: retention source readiness i erasure binding su `false`; postojeći sertifikati ne odgovaraju sadašnjem digest-u. | To je postojeće stanje, pre nove ACL promene. Export binding nije pozivan. |

Aktuelni DEV AI metadata: task intervju v151, worker intervju v104, post-save v5. To ne potvrđuje da novije lokalne AI popravke postoje u deployed kodu. Native APK/OTA nisu provereni ovom sesijom.

## Izvršene odluke i promene

**UX usklađenje:** [USKOCI_REV14_USKLADJENJE.md](USKOCI_REV14_USKLADJENJE.md) razrešava kontradiktorne opise navigacije, Dogovora, ikona, obraćanja i stanja. Drugi tab je Moje potrebe ili Prilike prema nameri. Dogovor čuva participant ulogu i backend actionstate; Tok/Dokazi zahtevaju stvarne čitače i dozvole. Male ikone su 2D, obraćanje formalno Vi. Neodređeni `rev12_specific` marker ne postaje završeno stanje.

**F17, deo R02:** u izolovanoj kopiji `uskoci-implementation`, grana `work/rev14-review-f17`, popravljena je putanja `focusedResource → zadaci → DiscoveryPresentation → DiscoveryListState`. Boolean `error` ostaje kompatibilan, a odvojena ograničena kategorija prenosi razlog. UI ne prikazuje `true`, SQL/provider poruke ili payload. Nepoznat kvar ne proglašava se lošom internet vezom. Čuvaju se account/focus/generation zaštite i ponašanje sačuvanog prikaza pri osvežavanju.

**R01 dokaz:** [r01_read_preflight.sql](uskoci-implementation/supabase/proofs/privacy/r01_read_preflight.sql) je nova, ponovljiva kataloška provera. Nema aplikacionih upisa niti poziva poslovnih writer-a. [README](uskoci-implementation/supabase/proofs/privacy/README.md) opisuje granice i preostale kontrole. Nova migracija nije pripremljena kao spremna za primenu: još nedostaje kompletan dokaz kompatibilnosti i autorizacione granice.

## Verifikacija klijentske promene

Status F17: **IMPLEMENTED + VERIFIED_LOCAL**. Prošlo je **8/8 Jest skupova, 347/347 testova**, TypeScript `--noEmit` i `git diff --check`. Nema novih neuspešnih testova. Prvi pokušaj nije pokrenuo testove zbog Windows `spawn EPERM`; izvršeni prolaz koristi `--runInBand --detectOpenHandles` bez izmene projektne konfiguracije. Tačne komande, skupovi i trajanja su u [potvrdi testova](evidence/f17-tests.json).

Regresije pokrivaju stvarnu route/resource/list-state putanju sa zamenjenim transportom i native rasporedom: auth, pristup, mrežu, timeout, malformed odgovor, RPC odbijanje pre vraćanja redova, unknown kvar, retry, promenu naloga A→B→A, zakašnjele greške, retained refresh i postojeće P6/presentation/own-profile potrošače. Nezavisan pregled je ispravio tvrdnju da su podaci primljeni i kada je zahtev odbijen pre odgovora. Native prikaz i server integracija nisu potvrđeni ovim testovima.

Zavisnosti su postojeće instalirane zavisnosti iz `USKOCI-CISTO`, dostupne lokalnoj kopiji kroz `node_modules` junction. Oba `package-lock.json` imaju SHA-256 `af0dd7c3ebcee931de0304d74efbbbb5385177d1dfea20cca6c60046379b41e0`. Node je v24.18.0. Nije izvršena nova instalacija zavisnosti.

Lokalna isporuka ima dva commit-a: `264d12dcc73d58cb33b33dfed873bf2be730c784` (F17 kod i testovi) i `936e1e26202cc4bbd48d1450bdec7a6c951fd6fa` (R01 preflight i zapis izvršenja). Radno stablo te kopije je čisto. [Prenosivi patch](USKOCI_F17_I_R01.patch) sadrži obe promene prema osnovi `a9692e11942609bab9406215c3e407d79589dafa`; nije samostalna aplikacija.

## Šta ostaje otvoreno

1. **R01/F21 ostaje prvi integracioni prioritet.** Pripremiti eksplicitan javni whitelist prema aktuelnim potrošačima, proveriti novu ACL promenu na disposable target-u i kroz pravi Auth/PostgREST. Proveriti direktni select, alias, filter, order i wildcard za sva tri privatna polja; javni, sopstveni i dozvoljeni participant read moraju nastaviti da rade. Promena prava ulazi u closure digest: ne menjati expected hash samo radi zelenog statusa.
2. **R02 nije završen F17 popravkom.** PAGE/MAP/PLACES, partial error, očuvanje liste uz grešku mape, HALF/FULL panel i native ponašanje ostaju zasebni zahvati i dokazi. R03 zahteva pet scope-ova, counts i wire format.
3. **REV13 nije dostavljen niti pronađen ciljanim lokalnim traženjem.** REV14 prenosi njegove ugovore i tvrdnje o čitanju. Deset `rev12_specific` stanja, Tok/Dokazi i trajnost workspace izbora još nemaju kompletan nezavisan dokaz. Jasne nezavisne popravke mogu napredovati.
4. **Z10/D06 i Z10/D08 ostaju poslovne odluke:** osnovica satnice i pokrivanje više lokacija. Do tada nema izmišljenih ukupnih cena ni novih pravila pokrivanja. One ne blokiraju F17 ili sadašnji pregled prava.
5. **R04–R12, golden requester/worker tokovi i izdanje nisu završeni.** Potrebni su stvarni AI/readback scenariji, pune vertikale, telefon, zaseban Android/iOS dokaz i potvrđen produkcioni cilj. Lokalni testovi nisu deploy ili uređajski dokaz.

## Trag dokaza

- [REV10 analiza](review-plan-rev10.md) — operativni redosled, R/C/SV zavisnosti i izvorni dokazi.
- [REV14 analiza](review-ux-rev14.md) — pregled 77 ugovora i tačne reference protivrečnosti.
- [R01 source i live analiza](source-audit-r01.md) — invoker čitači, privatne kolone, skrivene zavisnosti i closure.
- [Integritet ulaza](evidence/input-verification.json), [source/Edge/ledger metadata](evidence/delivery-metadata.json).
- [Aktuelni potpuni kataloški preflight](evidence/live-r01-preflight.json), [izabrane definicije](evidence/live-r01-definitions.json), [legacy reader](evidence/live-r01-legacy-reader.json), [closure zavisnosti](evidence/live-closure-dependencies.json).
- [Sveži closure status](evidence/live-closure-status.json) — bez promene ili prisilnog prihvatanja sertifikata.
- [Sažetak advisory-ja](evidence/live-security-advisory-summary.json). Advisory INFO/WARN nije automatski potvrđena ranjivost; posebno je ponovo prijavljena isključena provera kompromitovanih lozinki.

Napomena o otiscima: u početnom `live-r01-snapshot.json` ključ `body_md5` nastao je iz cele `pg_get_functiondef` definicije. Za precizno poređenje koristiti noviji `live-r01-preflight.json`, koji razdvaja `body_md5` i `definition_md5`.

Originalni ZIP-ovi i raspakovani sadržaj ostaju neizmenjeni izvori. Radni kod i novi dokazi nalaze se u ovom radnom prostoru; ništa nije objavljeno na GitHub, DEV ili produkciju.
