# Pregled UX/Product Master REV14

Datum pregleda: 27.10.2026. Ovaj dokument je analiza dostavljenih specifikacija; ne predstavlja dokaz izmene ili rada aplikacije.

## Obuhvat i izvori

- Pročitan je sadržaj svih 77 ugovora i svih opštih odeljaka `review-inputs/USKOCI_UX_PRODUCT_MASTER_REV14_2026-10-27/USKOCI_UX_PRODUCT_MASTER_REV14.md` (3.709 redova). Posle početnog čitanja, identične ponovljene redove čitao sam jednom: svih 2.001 različitih nepraznih redova obrađeno je uz originalne brojeve redova. To uklanja ponavljanje, ne različite zahteve.
- `USKOCI_SURFACE_MAP_REV14.json` je parsiran u celini: 77 zapisa, 77 jedinstvenih ID-jeva; pregledani su svi surface/merge i primary-action guard/effect zapisi, a ključni layout/role/source ugovori upoređeni sa masterom. Ima 50 površina označenih tačno kao `Full screen` i 27 ostalih; to nije 77 zasebnih ruta.
- Pročitani su `README.md`, `KOMANDA_ZA_CODEX_REV14.txt` i sva tri `.dot` dijagrama. HTML je pregledan kao izvorni dokument; nije izvršavan njegov JavaScript niti je urađena vizuelna/native verifikacija.
- Za prioritete su ciljano provereni REV10 `CODEX_PLAN_RADA.md`, naročito redovi 278–348 i R01–R03, i relevantni delovi `PROCITAJ_PRVO.md`/`USKOCI_IZVESTAJ.md`. Ovo nije novi potpuni audit REV10 dokaza ili aktuelnog repozitorijuma.

U nastavku `REV14:broj` znači red u master Markdown fajlu, a `REV10 plan:broj` red u `CODEX_PLAN_RADA.md` dostavljenog REV10 paketa.

## Šta je jasno i spremno da vodi implementaciju

REV14 daje dobar cilj arhitekture: jedan nalog, dve privremene namere, zajednički Dogovori i Poruke. Workspace bira prioritet i navigacioni kontekst, dok konkretni backend odnos i dozvole ostaju autoritet za podatke i komande (REV14:5–24, 520).

Centralni objekat je Dogovor sa sopstvenim prihvaćenim uslovima. Predlog izmene nikada ne prepisuje važeće uslove do prihvatanja; izvršilac označava završetak, naručilac potvrđuje; ocenjivanje dolazi tek nakon dozvoljenog završenog stanja (REV14:35–64, 1623, 1684, 2082). Kasnija izmena oglasa ne menja Dogovor; dostupnost radnika ne menja prihvaćeni termin (REV14:1332, 2601).

Treba sačuvati sledeće ugovore kroz svaku vizuelnu promenu:

1. **Isti pokušaj i isti sadržaj.** Unknown rezultat čita/reconciliuje postojeći identitet; nije dozvola za novi writer. Receipt i autoritativno čitanje prethode uspehu. Bitno za AI, publish, prijavu, izbor, poruke, izmene, ocenu, support i closure.
2. **Account/focus/revision granice.** Izgubljena prava uklanjaju privatni prikaz; promena workspace-a ne menja participant role i ne otkriva privatni cache (REV14:194, 1644, 1665).
3. **Cena je iznos + valuta + osnova, ljudi su zaseban podatak.** HOURLY ne dobija izmišljeni total dok Z10/D06 nije rešena (REV14:65–66; REV10 `PROCITAJ_PRVO.md`:49).
4. **Javni i privatni kanali ostaju odvojeni.** Pre Dogovora postoji Q&A/ponuda; privatni razgovor pripada Dogovoru. Telefon nije podrazumevani kanal. Tačna lokacija traži zasebnu dozvolu i konkretnog primaoca (REV14:1912, 3613–3623).
5. **Dve mape nisu isti writer.** ConversationPointAsk odmah čuva potvrđenu tačku; NeedLocationForm drži izbor lokalno do Apply i novog review-a (REV14:695, 778–798).
6. **Sačuvani profil je per-service/per-mode.** BOTH je kompletan očekivani skup istog serviceId; activate=false ne deaktivira ACTIVE profil; lokalni review nije autoritet trajnog profila (REV14:905–938, 2518–2526).
7. **Greška jednog reader-a ostaje lokalna.** Home shell, lista/mapa, profile/Q&A dodatne sekcije, dostupnost i arhivski izvori ne nestaju svi zbog jednog neuspelog read-a (REV14:548, 964, 1065, 2268, 2319).

## Nesaglasnosti i praznine koje treba izričito zatvoriti

| Prioritet | Nalaz i tačno mesto | Preporučena odluka |
|---|---|---|
| Visok | Nedostaje izvorni REV13 paket koji master navodi na redovima 3–4. Dostavljeni REV10 nije dokaz da su prisutne REV12/REV13 dopune. | Ne proglašavati REV13 ugovore ili FULL čitanje 711/42 fajla našim novim dokazom. Aktuelni source/owner i dostavljeni REV10 služe za nezavisnu potvrdu; nepoznate dopune voditi otvoreno. |
| Visok | IA na redovima 19/22 zahteva `Moje potrebe`/`Prilike`, ali `home.layout_order` u JSON-u i REV14:536 još kažu `Početna / Zadaci / Dogovori / Poruke`; REV14:560 kaže da su sva četiri taba zajednička. | Dati prednost jasnoj novoj odluci iz odeljka 2: ista četiri mesta u shell-u, drugo mesto menja cilj/oznaku po nameri; Dogovori/Poruke ostaju zajednički. Uskladiti MD, JSON i routiranje pre koda. |
| Visok | Odeljak 4 i red 3688 zahtevaju `Pregled / Poruke / Tok / Dokazi`; detalj na 1633 i JSON `agreementDetail.layout_order` navode samo `Pregled / Poruke`. JSON ikone ipak navode četiri taba. Nema posebnog ugovora za sadržaj/reader/paging `Tok` i `Dokazi`. | Definisati njihove stvarne izvore, dozvole i fallback. Tok može prikazivati samo potvrđene događaje; Dokazi se prikazuju samo za podržane priloge. Ne praviti prazne ili izmišljene galerije/aktivnosti. |
| Visok | Worker golden path ide direktno Prilike → prijava, a prijava zahteva aktivan profil (REV14:1110). Aktivacija profila nije prikazana u worker dijagramu. | Dodati uslovnu granu za missing/DRAFT/SUSPENDED profil i povratak na isti task/prijavu nakon dozvoljenog završetka profila; ne nametati onboarding za puko pregledanje. |
| Srednji | Novi workspace selector nema svoj ugovor među 77 zapisa: nema definisanog početnog izbora, trajnosti po nalogu, ponašanja pri auth/deep link-u ili očuvanja drugog taba. | Prvi shell zadatak treba da definiše ove granice i utvrdi postojeći owner. Deep link u tuđem kontekstu ne sme automatski promeniti dozvole ili odbaciti draft. |
| Srednji | Globalno formalno `Vi/Vam/Vas` (194) nasuprot velikom broju tekstova `Tvoja prijava`, `Nemaš`, `Tebe`, kao i neispravnim mešavinama `Zaboravili si` (299), `Još nisi sastavili` (2513), `Nisi tražili` (3053). JSON čuva mnoge iste tekstove. | Uvesti jedinstven rečnik konačnog UI copy-ja i uskladiti aktivne labele. Korisnički istorijski tekst ostaje doslovan. |
| Srednji | Pravilo male 2D/hero 2.5D na 95–101 i 3701 protivreči settings Done uslovu `2.5D ... po stavci` na 2652. | Primena opšteg REV14 pravila: semantičke 2D ikone u redovima; 2.5D za velike namere i odabrane empty/success momente. |
| Srednji | Pin za hitan zadatak na 75 nasuprot zabrani vraćanja istorijskog HITNO režima bez odluke na 1382 i REV10 izveštaj:217. | Ne uvoditi novi HITNO/payment tok. Vizuelni naglasak koristiti samo ako aktuelni reader i važeće poslovno pravilo imaju odgovarajući podatak. |
| Srednji | Deset JSON zapisa ima nedefinisan marker `rev12_specific`: personal, avatar, password, notifications, notificationPreferences, privacy, export, safety, supportRequest, supportDetail. | Zameniti marker konkretnim state kontraktom tek uz izvorni ugovor/aktuelni owner; marker ne sme postati implementirani enum ni dokaz pokrivenosti. |
| Srednji | REV14 upućuje na M04, M07, M08, M20, M21 i M22, ali ne donosi njihov kompletan registar; npr. M04 na 1932/1947/1953 i M07/M21 na 1370. | Voditi kao reference čiji izvor nedostaje. Ne zaključivati da je read-only proveravanje poruke već implementirano. Mapirati svaki ID na aktuelnu kodnu/proizvodnu razliku. |
| Srednji | Master eksplicitno navodi da cold durability selection nije implementirana (1553) i da export request ref nije durable (3058). | To su implementacione razlike sa korisničkim posledicama, a ne gotove sposobnosti. Proveriti trenutni source i zasebno rešiti restart recovery. |
| Niži | Worker `.dot` vodi `Označi završetak → Ocena`, preskačući potvrdu naručioca koju master i agreement dijagram pravilno zahtevaju. | Ispraviti dijagram dodatnim wait/completed/eligibility korakom; dijagram ne koristiti kao runnable state machine. |

JSON je koristan indeks konsolidacije, ali nije potpun izvršni ugovor: ima jedan `primary_action` po površini, dok MD često opisuje više različitih komandi; nema polja za runtime owner, konkretne state opise i prihvatne dokaze. `merge_into` je ljudski tekst (`newTaskAI / workerAI`, `taskReview → ownTask`), ne stabilna lista ID-jeva za automatsko generisanje navigatora.

## Redosled i prva implementaciona celina

REV14:3685–3692 određuje red dizajna. REV10 plan:335–348 određuje tehničke zavisnosti. Mogu se slediti zajedno: shell i UX specifikacija mogu napredovati dok se potvrđuju aktivni ugovori, ali novi izgled ne zatvara F21/R01 niti popravlja nekompatibilne Discovery i own-needs wire ugovore.

**Prvi konkretan rez:** potvrditi aktuelni checkout/head, mapirati shell/Home/entry vlasnike i uskladiti konflikt drugog taba; implementirati mali shell/Home rez nad postojećim reader-ima. Obuhvat: dve privremene namere, tačno drugo odredište, zajednički Dogovori/Poruke, avatar kao ulaz u Profil, pouzdan povratak i lokalne Home greške. Ne uvoditi novu business ulogu ili paralelni state owner. Ako nema spremnog inbox build gate-a, prikaz mora odgovarati stvarnoj sposobnosti (REV14:1904).

Istovremeno, za tehnički prvi paket ostaje **R01/F21 + identitet isporuke F14**. Prijavljeni table-level SELECT rizik treba ponovo potvrditi na aktuelnom autoritetu; dokument nije dokaz da problem i dalje postoji niti da je došlo do eksfiltracije. Posle R01, **R02 (F15–F17/SB11)** i **R03 (F01)** mogu napredovati paralelno. To otključava Prilike i Moje potrebe, dva najvažnija ulaza novog shell-a.

Zatim pratiti requester i worker vertikale, uz AI R04/R06/R08 i cenu/integritet R07 po zavisnostima. Izbor → Dogovor → izmena → završetak → ocena mora sačuvati stvarni dvostrani ugovor. Ne odlagati native dokaz do poslednjeg dana: REV10 plan:331 izričito počinje prikupljanje od prve vertikale. Raspored, profil, privacy i support slede sa sopstvenim dokazima. Cleanup ide tek posle reference/caller provere.

Otvorene **Z10/D06** (satnica po osobi ili ekipi) i **Z10/D08** (više radnih lokacija) ne blokiraju nezavisne tehničke popravke. Ne mešati Z10/D06 sa starijom Z09/D06 „Samo poruke“ (REV10 `PROCITAJ_PRVO.md`:49).

## Prihvatni dokaz za prvi rez

- Četiri korenska mesta su dostupna kada je shell spreman; spor/neuspešan opcioni Home reader ih ne blokira.
- Promena namere menja Home prioritet/drugi cilj, a postojeći Dogovor zadržava participant role i dozvoljene akcije.
- Task kartica iz moje prijave otvara javni `/prilike/[id]`; own task otvara vlasnički pregled (REV14:539, 552; REV10 plan:305).
- Back ne pravi lanac root tabova, vraća poznati scroll/kontekst, a account promena ne pokazuje privatne podatke prethodnog naloga.
- Prazno stanje postoji tek nakon uspešnog read-a; unknown nije nula niti nova komanda. Nijedna dekorativna kartica nije izmišljeni aktivan Dogovor ili sačuvan draft.
- Provere tastature, velikog fonta, screen reader-a i reduced motion-a prate promenjene površine. Konačan cilj traži Android i iOS, širine 360/390/430 dp i text scale 1/1.3/2 (REV14:3692); statički pregled ili web screenshot to ne dokazuju.

Za svaku celinu voditi odvojeno: **projektovano**, **implementirano na konkretnom SHA**, **runtime dokazano na konkretnom build-u/uređaju** (REV14:3703). To je ključ da se novi UX plan ne zameni tvrdnjom da je proizvod već završen.
