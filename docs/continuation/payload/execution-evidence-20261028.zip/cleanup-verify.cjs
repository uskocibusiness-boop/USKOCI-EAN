'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const cp = require('node:child_process');
const root = path.resolve(__dirname, 'uskoci-implementation');
const ts = require(require.resolve('typescript', { paths: [root] }));
process.chdir(root);
const inventory = JSON.parse(fs.readFileSync('../cleanup-asset-preimages.json','utf8').replace(/^\uFEFF/,''));
const hash = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const mapping = {
  'assets/brand/uskoci-dimensional-20261003.png': 'assets/brand/premium-entry/logo.png',
  'assets/illustrations/uskoci-discover-v3.png': 'assets/brand/premium-entry/discover.png',
  'assets/illustrations/uskoci-task-launch-v2.png': 'assets/brand/premium-entry/publish.png',
};
for (const [old,current] of Object.entries(mapping)) {
  if(fs.existsSync(old) || hash(current) !== inventory.find(i=>i.path===old).sha256) throw new Error('BAD_CANONICAL_ASSET:'+old);
}
const illustrations = JSON.parse(fs.readFileSync('assets/illustrations/MANIFEST.json','utf8'));
for(const entry of illustrations) {
  const p = path.resolve('assets/illustrations',entry.file);
  if(hash(p)!==entry.sha256 || fs.statSync(p).size!==entry.bytes) throw new Error('BAD_MANIFEST:'+entry.file);
}
const provenance = JSON.parse(fs.readFileSync('assets/illustrations/PROVENANCE.json','utf8'));
for(const entry of provenance.files) if(!fs.existsSync(path.resolve('assets/illustrations',entry))) throw new Error('BAD_PROVENANCE:'+entry);
for(const svg of ['assets/entry-splash-mark.svg','assets/discovery/uskoci-task-material.svg']) {
  const source=fs.readFileSync(svg,'utf8');
  for(const match of source.matchAll(/href="([^"]+\.png)"/g)) {
    const target=path.resolve(path.dirname(svg),match[1]);
    if(target!==path.resolve('assets/brand/premium-entry/logo.png')) throw new Error('BAD_SVG_TARGET');
    if(!fs.existsSync(target)) throw new Error('BAD_SVG_REFERENCE');
  }
  const before=cp.execFileSync('git',['show','HEAD:'+svg],{encoding:'utf8'});
  if(source.replace(/\r\n/g,'\n')!==before.replace('brand/uskoci-dimensional-20261003.png','brand/premium-entry/logo.png').replace(/\r\n/g,'\n')) throw new Error('SVG_CHANGED_BEYOND_REFERENCE');
}
const {getConfig} = require(require.resolve('@expo/config',{paths:[root]}));
const config = getConfig(root,{skipSDKVersionRequirement:true}).exp;
const sources = [config.icon,config.ios.icon,config.android.adaptiveIcon.foregroundImage,config.android.adaptiveIcon.monochromeImage,config.web.favicon];
for(const plugin of config.plugins) {
  if(!Array.isArray(plugin)) continue;
  if(plugin[0]==='expo-font') sources.push(...plugin[1].fonts);
  if(plugin[0]==='expo-splash-screen') sources.push(plugin[1].image,plugin[1].dark.image);
}
for(const source of sources) if(!fs.existsSync(source) || source.startsWith('./assets/images/')) throw new Error('BAD_CONFIG_ASSET:'+source);
const files=cp.execFileSync('git',['ls-files','-z'],{encoding:'utf8'}).split('\0').filter(p=>/^(src|scripts|plugins)\//.test(p)&&/\.(js|jsx|ts|tsx|cjs|mjs)$/.test(p)&&fs.existsSync(p));
let checked=0;
const dynamicRequires=[];
function checkAsset(file,value) {
  if(!value.startsWith('.') || !/\.(png|jpg|jpeg|webp|svg|ttf|otf)$/.test(value)) return;
  checked++;
  if(!fs.existsSync(path.resolve(path.dirname(file),value))) throw new Error('MISSING_IMPORT:'+file+':'+value);
}
for(const file of files) {
  const source=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true);
  function visit(node) {
    if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='require') {
      if(node.arguments.length===1&&ts.isStringLiteralLike(node.arguments[0])) checkAsset(file,node.arguments[0].text);
      else dynamicRequires.push({file,expression:node.getText(source)});
    }
    if(ts.isImportDeclaration(node)&&ts.isStringLiteralLike(node.moduleSpecifier)) checkAsset(file,node.moduleSpecifier.text);
    ts.forEachChild(node,visit);
  }
  visit(source);
}
const output={canonicalPairs:Object.keys(mapping).length,illustrationManifestEntries:illustrations.length,provenanceEntries:provenance.files.length,configuredAssetPaths:sources,relativeAssetImportsChecked:checked,dynamicRequires,referenceGenerator:'3 outputs verified by sync-entry-reference-assets.cjs',nativeBuildOrApkSizeMeasured:false};
fs.writeFileSync('../cleanup-asset-verification.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(output,null,2));
