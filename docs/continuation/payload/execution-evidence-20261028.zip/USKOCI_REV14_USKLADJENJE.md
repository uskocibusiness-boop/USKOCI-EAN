# USKOČI — usklađenje odluka REV14

27.10.2026. Radni dodatak dostavljenom UX masteru. Originalni paketi ostaju neizmenjeni. Dodatak razrešava međusobno suprotne opise; ne potvrđuje implementaciju ili runtime.

Prednost imaju izričite odluke REV14 iz opštih odeljaka 0–10 i završnih kriterijuma. Nasleđeni detalji pojedinačnih ekrana usklađuju se sa tim odlukama. Aktuelni backend ugovori i dozvole određuju šta aplikacija zaista može da izvrši.

| Oblast | Usvojena odluka | Konkretna izmena pri implementaciji | Dokaz/granica |
|---|---|---|---|
| Donja navigacija | Namera **Treba mi neko**: Početna · Moje potrebe · Dogovori · Poruke. Namera **Želim da uskočim**: Početna · Prilike · Dogovori · Poruke. | Uskladiti `home.layout_order`, labele i drugi cilj sa odeljkom 2. `Moje potrebe` vodi postojećem owner ulazu `/potrebe`; `Prilike` postojećem discovery ulazu `/zadaci`. Sačuvati kompatibilne stare rute. | REV14:19–24, 520 nasuprot 536/560. Promena namere ne menja nalog, podatkovnu ulogu ili participant prava. |
| Promena namere | Kompaktan selector na Početnoj; bottom sheet sa dve opcije i kratkim objašnjenjem. | Vezati izbor za postojeći shell/entry owner; precizirati početni izbor, trajnost po nalogu i povratak pre dodavanja novog state-a. | REV14:24. Detaljan contract za trajnost i deep-link prioritet nije dostavljen: voditi otvoreno. |
| Dogovor | Ciljne sekcije su **Pregled · Poruke · Tok · Dokazi**. | Pregled i Poruke vezati za postojeće vlasnike. Tok dodati samo nad potvrđenim događajima i stvarnim reader-om. Dokazi samo kada stvarni flow/capability i sadržaj to podržavaju; bez praznog taba ili izmišljenog upload-a. | REV14:35, 3688 nasuprot 1633 i JSON layout-u. Nedostajući reader/contract nije završen tab. Participant role + backend actionstate odlučuju komande. |
| Male ikone | Semantičke 2D ikone u redovima i karticama; utility kontrole jednostavne i neutralne. | U settings redovima ne primenjivati nasleđeni zahtev za 2.5D ikonu po stavci. 2.5D ostaje za velike namere i odabrane empty/success prikaze. | REV14:95–101, 3701 imaju prednost nad 2652. |
| Obraćanje | Formalno **Vi/Vam/Vas**, dosledno kroz aplikaciju. | Aktivne tekstove uskladiti: „Vaša prijava“, „Pregledajte prijavu“, „Još nemate prijava“, „Zaboravili ste lozinku?“, „Još niste sastavili radnu ponudu“. Istorijski tekst koji je uneo korisnik ne prepravljati. | REV14:194 ima prednost nad nasleđenim Ti/Tvoj labelama i gramatičkim mešavinama. |
| Sheet, tastatura i pristupačnost | Površina prati dužinu i složenost sadržaja. | Kratki izbor koristi sheet; dug unos i složena revizija ceo ekran. Candidate preview može preći na ceo ekran. CTA i greška moraju ostati dostupni uz tastaturu, velike fontove i native insets; Back prvo zatvara tastaturu kada ugovor tako nalaže, zatim vraća tačan kontekst i dozvoljen draft. | REV14:106–114, 1016, 1480, 1931. Proveriti fokus, screen reader, 360/390/430 dp, text scale 1/1.3/2 i reduced motion. To nije potvrđeno samim izborom komponente. |
| Worker završetak | Označavanje završetka vodi čekanju potvrde naručioca; ocena tek kada backend dozvoli. | Dopuniti worker flow dijagram korakom čekanja/completed/eligibility; ne koristiti direktno `Označi završetak → Ocena` kao izvršni tok. | REV14:1684, 1698–1720 imaju prednost nad skraćenim `worker_flow.dot`. |
| Nedovršena stanja | `rev12_specific` je nerazrešena referenca. | Za personal, avatar, password, notifications, notificationPreferences, privacy, export, safety, supportRequest i supportDetail utvrditi konkretna stanja iz izvora i aktuelnog ownera. Ne mapirati marker na success/ready i ne označavati Done. | JSON sadrži marker na deset površina. Nedostaje njegova potpuna definicija. |

## Otvorene zavisnosti i redosled

REV14 navodi `USKOCI_KOMPLETAN_PLAN_I_DIZAJN_REV13_2026-10-27.zip`, koji nije među ova dva dostavljena paketa. Zbog toga još nisu nezavisno potvrđeni originalni REV13 ugovori, M04/M07/M08/M20/M21/M22 registri, asset odluke i preneti REV12 dokazi. Dostavljeni REV10 daje tehnički plan i ranije dokaze, ali ne zamenjuje te nedostajuće izvore.

Pre runtime izmene proveriti aktuelni head i konkretne vlasnike. Vizuelni shell može napredovati kao mali prvi rez; tehničke zavisnosti REV10 ostaju R01 (privatnost i identitet isporuke), zatim R02 Discovery i R03 Moje potrebe. R02 i R03 mogu paralelno nakon R01. Nedostatak REV13 ne sprečava nezavisnu proveru aktuelnog koda ili jasno izdvojene popravke, ali sprečava tvrdnju da je čitav preneti ugovor potvrđen.

Dve poslovne odluke ostaju otvorene: **Z10/D06** — satnica po osobi ili ekipi; **Z10/D08** — pokrivanje više lokacija. Do odluke prikazivati stvarnu osnovu cene i ne izmišljati ukupne iznose ili nova pravila područja. Nezavisne popravke ne čekaju ove odluke.

Svaku stavku pratiti kroz tri odvojena statusa: **projektovano**, **implementirano na SHA**, **runtime dokazano na build-u/uređaju**. Ovaj dodatak zatvara samo navedene projektne odluke. Detaljna analiza i reference nalaze se u `review-ux-rev14.md`.
