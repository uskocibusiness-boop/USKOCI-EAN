# R01 / F21 — pregled izvora i konkretna granica popravke

Datum: 2026-10-27. Pregledan lokalni `C:/Users/user/Desktop/USKOCI-CISTO`, HEAD `a9692e11942609bab9406215c3e407d79589dafa`, grana prema matičnom zadatku `feature/uskoci-cisto`. `git status --short` je pokazao samo nepraćeni `.codex-remote-attachments/`. Nije pronađen `AGENTS.md` u repozitorijumu ni pregledanim roditeljskim direktorijumima. Ovaj podzadatak nije menjao repozitorijum, bazu ili deploy. Nisu čitani poslovni redovi, tokeni ili `.env` vrednosti.

**Zaključak:** F21 je potvrđen u sadašnjem izvoru i priloženom DEV katalogu. Najmanja ispravka je nova, proverena promena SELECT prava nad `public.needs` koja vraća eksplicitni javni skup kolona i zadržava postojeće owner/participant čitače. Jedan goli `REVOKE` nije dovoljno bezbedan paket: PostgreSQL njime uklanja i odgovarajuće kolonske grantove, invoker čitači moraju ostati funkcionalni, a table ACL ulazi u closure digest. F21 nije zatvoren ovim pregledom.

## Dokaz i izvori

Svi putevi u ovoj tabeli relativni su prema pregledanom repozitorijumu.

| Izvor | Nalaz / posledica |
|---|---|
| `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql:6` | Ponovo daje `GRANT SELECT ON TABLE public.needs TO authenticated`. Kolonski javni whitelist više ne skriva tri privatne kolone na RLS-vidljivim redovima. Red 12 dodatno daje service_role EXECUTE nad svim public rutinama; to je poseban ugovor, nije dokaz anon/auth pristupa. |
| `supabase/migrations/20261025000000_baseline_core_client_rpcs.sql:354` | `rpc_read_task(uuid)` je SECURITY INVOKER, bira imenovane kolone, ne bira requester account, actor zatvaranja ni privatni razlog. `covered_slots` i `selectable_application_count` dobijaju kompozit napravljen samo iz ID-a (400–401), čime izbegavaju implicitno čitanje celog reda. |
| Isti fajl, `:415` i `:435` | `rpc_list_my_tasks()` i `rpc_list_my_needs_page(...)` su postojeći SECURITY DEFINER ulazi sa `auth.uid()`, proverom otvorenog naloga i owner filterom. Strani caller-supplied account nije parametar. Whole-row `covered_slots(n)` na 465 je u ovom elevated owner čitaču; ne treba ga pogrešno tretirati kao javni invoker kvar. Privilegije i stvarna tela ipak proveriti na živom DEV-u. |
| `supabase/migrations/20261018201517_home_preview_invoker_fix_20261018.sql:1` | Izvor izričito čuva invoker ugovor Home čitača i ne daje pristup `requester_account_id`. Sadrži owner/profile proveru za Home preview. Ne prepisivati ga starim PKG045 telom. |
| `supabase/candidates/pkg045a_task_read_contract.sql:179` | Istorijski `is_my_task(uuid)` koristi caller-bound owner proveru. Potreban je kao ograničen helper za politike koje bi inače čitale privatni account ID u invoker kontekstu. Sadašnje telo i ACL moraju biti potvrđeni. |
| `supabase/candidates/pkg045b_task_column_privileges.sql:48` | Dokumentuje skrivene zavisnosti politika `need_sensitive_owner`, `responses_requester_read`, `response_versions_read`, `need_geography_owner_read`, `need_requirement_details_owner_read`. Sve moraju nastaviti preko dozvoljenog helpera, bez naknadnog širokog granta kao popravke. |
| `supabase/migrations/20260831114338_clean_pre_p4_participant_rls_authenticated_proof.sql:7` | `rls_private` ima potreban authenticated USAGE; helper `need_participant_can_read` authenticated EXECUTE. Helper je definer, vezan za `auth.uid()` i SELECTED/CONFIRMED/COMPLETED učešće. Ova prava ne smeju nestati opštim revoke-om. |
| `supabase/migrations/20260912230039_clean_v5_policy_bound_closure.sql:269` | `rpc_closure_api_guard` je Data API pre-request hook; restrictive `v5_closed_account_visibility` se kreira na 308. Ne poistovećivati njegov obim sa Storage ili Realtime. |
| `supabase/migrations/20261021104455_closure_taxonomy_archive_copy_coverage.sql:2078` | Closure source digest uključuje schema/erasure-program digest. Na 2121 erasure-program digest uključuje table `relacl`, owner i RLS stanje svih public/private tabela. Promena Need ACL-a zato menja taj dokaz. |
| `supabase/migrations/20260904223000_clean_ru4_close_remaining_search.sql:123` | Owner-authorized `rpc_close_remaining_search(uuid,integer,text,text)` je definer. Prihvata PUBLISHED/SELECTION/ACTIVE na 204, upisuje actor/reason na 225–226. ACL promena ne sme menjati ovu poslovnu radnju/status ili javni closed-at signal. |
| `src/data/ru4Production.ts:62` | Dodatni direktni čitač koji nije u R01 kratkoj listi: bira samo `remaining_search_closed_at` i filtrira `id`. Oba moraju biti u dozvoljenom skupu; greška čitanja mora ostati greška, ne lažno „otvoreno”. |
| `src/data/needClientService.ts:168`, `:187`, `:201` | Potrošači own-list, own-page i task RPC ugovora. |
| `src/data/supabaseIzvor.ts:241`, `:292`, `:342`, `:417` | Legacy open tasks / Home / exact landing i task čitači; moraju proći pozitivne kontrole. |
| `src/data/discoveryV1ClientTransport.ts:38` | Novi discovery RPC poziv; javni skup, filteri i decoder moraju nastaviti da rade. |

Priloženi dokaz `review-inputs/USKOCI_KOMPLETAN_PLAN_I_DOKAZI_REV10_2026-10-27/dokazi/server_final/schema_review.json` je ugnježden paket. Pod `files[path="schema_review.json"].data.table_acl_ledger[identity="public.needs"]` beleži 2026-10-27 14:40:35 UTC: authenticated table SELECT=true, anon SELECT=false, uz kolonski javni skup.

Matični zadatak je zatim pribavio novi read-only DEV katalog: `evidence/live-r01-snapshot.json` (2026-10-27 21:30:09 UTC) i `evidence/live-r01-definitions.json` (21:30:50 UTC), za `leqcwgzvjsxugfgzdmth`. Pregled ovih fajlova potvrđuje authenticated table SELECT=true i effective SELECT=true nad sve tri privatne kolone; anon table/column SELECT=false. RLS je uključen, FORCE RLS nije. To je svež dokaz efektivnih kataloških prava, bez pokušaja čitanja tuđih redova.

Nove definicije potvrđuju i da `rpc_read_task`, `rpc_discovery_v1` i `rpc_resolve_activity_event` ostaju invoker i koriste imenovane Need kolone / ID-only pozive. Discovery `SELECT *` odnosi se na već projektovane CTE, ne na `public.needs`. Pet istorijskih zavisnih politika već koristi `is_my_task`. `is_my_task` i `selectable_application_count` proveravaju `auth.uid()` i otvoren nalog; drugi helper ponovo učitava stvarni own-red i ne veruje owner vrednostima prosleđenog kompozita. Ovim pregledom nije ustanovljena potreba za prepisivanjem tih tela radi R01. Dodatni `evidence/live-r01-legacy-reader.json` potvrđuje da i legacy `rpc_list_open_tasks_v3` ostaje invoker sa imenovanim javnim projekcijama.

Napomena o imenovanju ranijeg snapshot-a: njegov ključ `body_md5` sadrži hash cele definicije. Novi `evidence/live-r01-preflight.json` eksplicitno razdvaja `body_md5` (`prosrc`) i `definition_md5` (`pg_get_functiondef`); koristiti nove ključeve pri pinovanju.

U istom paketu `files[path="captures/policies.json"].data.data` potvrđuje da pet navedenih zavisnih politika već koristi `is_my_task(n.id)`. `needs_public_discovery` upoređuje TEST/REAL skup kroz `rls_private.p6_discovery_test_world_accounts()`, owner policy koristi owner ID, participant helper svoju granicu, a `v5_closed_account_visibility` je zasebna restrictive provera. SELECTION sa zatvorenom pretragom i dalje može biti red vidljiv kroz direktni table API iako ga Discovery lista izostavlja; zato je bitan fixture sa privatnim razlogom.

## Najmanji paket koji treba pripremiti

1. Osvežiti živi katalog i snimiti potpise, tela, ACL, owner, security mode, search_path i sve politike koje direktno ili indirektno čitaju `needs`. Uključiti role membership / PUBLIC prava, ne samo tekst `relacl`.
2. Na sadašnjem reproducibilnom disposable target-u napraviti eksplicitan javni whitelist. Polazni skup je istorijskih 38 dozvoljenih kolona iz `pkg045b_task_column_privileges.sql:114`, ali ga uporediti sa današnjim kolonama i svim stvarnim potrošačima. Tri zabranjene kolone su `requester_account_id`, `remaining_search_closed_by_account_id`, `remaining_search_close_reason`. Nove kolone ne dodavati automatski na osnovu obrasca „sve osim tri”.
3. U jednoj transakciji ukloniti šire SELECT izvore za public/anon/authenticated, pa ponovo dati samo odobreni kolonski skup authenticated ulozi. Proveriti efektivna prava po svakoj koloni. Namerna service_role prava i writer ovlašćenja ne menjati usput. Ovo je opis kandidata, nije spreman SQL za izvršenje.
4. Ako sadašnji katalog potvrdi da su kompatibilni čitači/politike već postavljeni, ne menjati njihova tela. Ako otkrije novo invoker čitanje privatne kolone ili celog reda, popraviti tu projekciju/helper pre sužavanja ACL-a; ne pretvarati javni čitač u definer samo radi prolaska.
5. Closure proceniti sadržajno. Ako je pre-change readiness već false, novi expected hash ne predstavlja popravku. Sačuvati fail-closed ponašanje, zabeležiti razloge neusklađenosti i dokazati tačno šta ACL promena pomera. Puni closure/export oporavak mora rešiti dokumentovane kopije/projektore, ne prisilno vratiti READY.
6. Generisati novu migraciju tek kada je kandidat odobren kao tačan i dokaziv; ne menjati primenjeni migration fajl niti izvršavati stari PKG045b/P6 replay. Istorijski PKG045b očekuje anon table SELECT, tačne stare MD5 vrednosti i ready certifikat, što nije sadašnji ugovor.

Uputstvo baze potvrđuje da se prava sabiraju kroz direktne grantove, membership i PUBLIC, i da table REVOKE uklanja i odgovarajuće kolonske grantove. [PostgreSQL REVOKE](https://www.postgresql.org/docs/current/sql-revoke.html). RLS ograničava redove; column privileges ograničavaju kolone i wildcard na ograničenoj tabeli više ne prolazi. [Supabase column privileges](https://supabase.com/docs/guides/database/postgres/column-level-security).

## Izvršni dokaz koji nedostaje

| Proba | Potreban rezultat |
|---|---|
| Dva sintetička otvorena naloga istog sveta, tuđi PUBLISHED i SELECTION | Javni whitelist i normalni reader rade; sva tri privatna polja ne mogu se čitati. |
| SELECTION sa closed-at, actor-om i jedinstvenim privatnim razlogom | Direktni select, alias, filter, order, wildcard i computed whole-row put ne otkrivaju privatni marker; dozvoljeni closed-at ostaje čitljiv. |
| Owner / allowed participant / nonparticipant | Vlasnik i legitiman učesnik dobijaju tačno dozvoljene dokumente; strani učesnik ne dobija privatni ili istorijski sadržaj. |
| Drugi svet, anon, zatvoren nalog, malformed/expired sesija | Potvrđeno odbijanje ili očekivano odsustvo reda na stvarnoj Auth/PostgREST granici, uz odvojenu pozitivnu kontrolu. |
| Own list/page, Home preview, exact landing, discovery PAGE/MAP/PLACES | Uspešan odgovor i stvarni klijentski decoder; ne prihvatati „sve je 403” kao privatnosni prolaz. |
| Close remaining search | Owner može dozvoljenu radnju sa ispravnom revizijom/kapacitetom; strani caller odbijen; privatni actor/reason ostaju zaštićeni. |
| Closure i future-object ACL | ACL promena ima objašnjenu promenu digest-a; nema lažnog READY. Sintetička nova tabela/funkcija ne dobija nenamerna anon/auth prava posle zasebnog, eksplicitnog default-ACL paketa. |

`supabase/proofs/discovery/p6_http_boundary.mjs:134` proverava samo requester account kolonu kroz HTTP, na istorijskom PKG045b predecessor-u, sa pinovanim kandidatom i obaveznim lokalnim guardom. Treba ga rebazirati, ne pokrenuti nad DEV-om. `p6_world_boundary_proof.mjs:109` već proverava sve tri kolone kataloški i ima jake world/RLS kontrole, ali je to istorijski SQL dokaz, ne današnji Auth/HTTP dokaz. Stare workflow putanje na koje se pozivaju proveriti jer je sadašnji CI drugačiji.

U izolovanom checkout-u dodat je `uskoci-implementation/supabase/proofs/privacy/r01_read_preflight.sql` i README. SQL koristi read-only transakciju, isključivo sistemske kataloge, bez izvršavanja application/digest funkcija ili čitanja poslovnih redova. Daje obnovljiv inventar svih kolona/effective SELECT prava, zavisnih politika, ciljnih funkcija/ACL/MD5, schema/default prava i isključivo dozvoljenih PostgREST postavki. Closure definicije vraća kao izvor za proveru, ne poziva ih. Statička provera i `git diff --check` su prošli. Matični zadatak je uspešno izvršio isti preflight na potvrđenom DEV-u: `evidence/live-r01-preflight.json`, `transaction_read_only=on`, svih 21 ciljanih funkcija postoji, tri privatne kolone su i dalje efektivno readable za authenticated.

Naknadni `evidence/live-closure-dependencies.json` sadrži pet traženih živih definicija. Pregled njihovog sadržaja zatvara neposredni read-only lanac za retention/source digest i closure erasure binding: `agreement_invalidation_surface_v1` čita kataloge; `agreement_voice_surface_v1` čita kataloge i konfiguraciju jednog bucket-a; `closure_redaction_relations_v5` vraća literalni spisak tabela. Brojna druga imena u digest funkcijama jesu stringovi za hash izvora, ne izvršni pozivi. `closure_erasure_binding_v5` čita sertifikat i računa/proverava ove read-only funkcije. Nema pisanja, poslovnih export payload-a ili spoljnog poziva. Matičnom zadatku predat je ograničeni SELECT statusa ispod; sam rezultat mora se zabeležiti pre tvrdnje o aktuelnom true/false stanju.

Export binding ostaje **UNKNOWN u ovoj etapi**: novi `data_export_dataset_catalog` neposredno poziva `private.closure_taxonomy_export_catalog_v1()`, čije živo telo nije u ovom ograničenom pregledu. `data_export_projection_sha_v5` samo hash-uje izvore i ne poziva navedene snapshot/projection funkcije. Dodatno širenje audita ovde je zaustavljeno; istorijski export false nije prenet kao svež rezultat.

Bezbedan SELECT za već pregledani status (izvršavati unutar read-only transakcije, uz ograničen statement timeout):

```sql
WITH s AS MATERIALIZED (
  SELECT private.closure_source_digest_v5() AS digest,
         private.retention_ai_source_ready() AS source_ready,
         private.closure_erasure_binding_v5() IS NOT NULL AS erasure_binding_ready
)
SELECT statement_timestamp() AS captured_at,
       s.source_ready,
       s.erasure_binding_ready,
       s.digest IS NOT NULL AS source_digest_available,
       (SELECT sha256 IS NOT NULL FROM private.closure_source_v5 WHERE singleton)
         AS source_certificate_present,
       (SELECT sha256 IS NOT NULL FROM private.closure_erasure_source_v5 WHERE singleton)
         AS erasure_certificate_present,
       s.digest = (SELECT sha256 FROM private.closure_source_v5 WHERE singleton)
         AS source_certificate_matches,
       s.digest = (SELECT sha256 FROM private.closure_erasure_source_v5 WHERE singleton)
         AS erasure_certificate_matches
FROM s;
```

## Rezultat dodatne žive provere i preostali dokazi

Matični zadatak izvršio je gornju proveru 27.10.2026. u 21:37:33 UTC, u read-only transakciji. [Sačuvani rezultat](evidence/live-closure-status.json): `source_ready=false`, `erasure_binding_ready=false`; oba sertifikata postoje, ali se oba razlikuju od tekućeg source digesta. Ovo je stanje pre bilo kakve nove ACL promene. Export binding nije pozivan i ostaje neproveren.

Prikupljeni su trenutni table/column effective ACL, inherited role članstva, default ACL, povezane politike, navedeni čitači/helperi i dozvoljeni PostgREST metapodaci: [preflight](evidence/live-r01-preflight.json), [definicije](evidence/live-r01-definitions.json), [legacy reader](evidence/live-r01-legacy-reader.json). To su kataloški i izvorni dokazi; još nedostaju sledeći izvršni dokazi:

- Pozitivna i negativna Auth/PostgREST provera efektivne javne kolonske granice posle kandidata, sa sadašnjim reader-ima i sintetičkim nalozima.
- Sadržajno objašnjenje postojećeg closure mismatch-a, bez osvežavanja expected hash-a radi prolaza; zasebna provera export lanca.
- Podržani instalirani native/OTA ugovori. Deklarisani Git SHA iz About-a nije identitet svih isporučenih bajtova. Stari whole-row klijent zahteva bezbedan kontrolisani izlaz ili kompatibilnu isporuku; nije opravdanje da privatna kolona ostane otvorena.
- Disposable target koji verno predstavlja sadašnje funkcije/politike/ACL i može izvršiti sintetički Auth/PostgREST test. U ovom podzadatku taj runtime dokaz nije pokrenut.

`docs/ai-stabilization/00_BASELINE_STATE.md` beleži otvoren F0 i prethodnu granicu bez DEV deploy-a/migracija; taj dokument je dokaz prethodne faze, a ne zamena za sadašnju korisničku autorizaciju. Ovaj nalaz zato isporučuje konkretan opseg i preduuslove, bez tvrdnje da je promena primenjena ili da je F21 zatvoren.
