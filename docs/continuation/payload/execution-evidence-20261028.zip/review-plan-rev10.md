# Pregled REV10: izvršni ulaz i prvi zahvat

Datum pregleda: 27.10.2026. Ovaj dokument je rezultat pregleda dostavljenog paketa i indeks njegovih konkretnih zahteva; ne zamenjuje `CODEX_PLAN_RADA.md` i ne proglašava aplikaciju popravljenom. Pročitan je operativni plan, uključujući R01–R12, C01–C19, SV01–SV14, kriterijume, izdanje i nastavak. Ciljano su provereni F21 u tehničkoj referenci, Z09/Z10 zapisi R01/F21 i ugrađeni schema/ACL dokaz. Nijedna priložena skripta nije izvršena, živa baza nije menjana i spoljašnji repozitorijum nije menjan ovim pregledom.

## Potpunost paketa

Proverene su sve putanje, veličine i SHA-256 otisci iz `MANIFEST.json`: **138/138 sadržajnih fajlova odgovara manifestu**, uz 139 fizičkih fajlova uključujući sam manifest. Nema nedostajućih, dodatnih niti izmenjenih fajlova. Manifest sam sebe namerno ne hešira.

Provera prenosa ne potvrđuje tačnost svih istorijskih nalaza niti sadašnje stanje aplikacije. Stari unutrašnji otisci pripadaju svojim ranijim dokumentima; konačne bajtove ove isporuke određuje spoljašnji manifest.

## Autoritativno polazište

- Repo dokumentovan u REV10: `uskocibusiness-boop/USKOCI-EAN`, grana `feature/uskoci-cisto`, SHA `a9692e11942609bab9406215c3e407d79589dafa`.
- Referentni DEV projekat: `leqcwgzvjsxugfgzdmth`.
- REV10 je objedinjavanje dokumentacije. Nema novog GitHub/live Supabase/model/device/build/deploy prolaza. Poslednji puni živi serverski pregled je rev7; ciljane release/source provere su rev9.
- Tri telefonske slike pokazuju stariji `fcef803e719ba5663f6cfd8fbd5a601e08a3479b`, runtime `uskoci-v1-preview-r1`, kanal `preview`, OTA prefiks `01a163c4`. Ne potvrđuju instalaciju a969.
- Pre izmene: proveriti fizički repo/remote/HEAD, README/STATUS i stvarno dostupna repo uputstva, lokalne izmene, deltu od a969, aktuelna pogođena SQL/Edge tela i podržane klijente. Stari `USKOCI-CLEAN` nije polazište samo zato što postoji u memoriji.

Izvori: [plan §1](review-inputs/USKOCI_KOMPLETAN_PLAN_I_DOKAZI_REV10_2026-10-27/CODEX_PLAN_RADA.md#1-polazište-važenje-i-stvarni-nivo-dokaza), redovi 40–74; [početni indeks](review-inputs/USKOCI_KOMPLETAN_PLAN_I_DOKAZI_REV10_2026-10-27/PROCITAJ_PRVO.md), §5.

## Preporučeni prvi izvršni zahvat: R01/F21

Najpre pripremiti jednu usku novu migraciju i dokaz javne kolonske granice `public.needs`, sa očuvanim legitimnim javnim, sopstvenim i participant čitanjem. **Ne koristiti stari PKG045b ili ceo P6 replayer kao gotovu popravku.** Primenjena migraciona istorija ostaje netaknuta. Aktuelni nalaz treba potvrditi nad sadašnjim ciljem pre bilo kakve žive primene.

Dokumentovani uzrok je `GRANT SELECT ON TABLE public.needs TO authenticated` u `supabase/migrations/20261023210000_matching_work_areas_and_public_grants.sql:6`. Širi table SELECT preklapa nameravani javni skup od 38 kolona. Pogođena privatna polja su:

- `requester_account_id`
- `remaining_search_closed_by_account_id`
- `remaining_search_close_reason`

Istorijski dokaz obuhvata efektivan ACL i politike. Nije čitao tuđe poslovne redove i ne dokazuje stvarnu eksfiltraciju, anoniman pristup niti cross-world incident. Konkretnu vidljivost opisuje ne-vlasnikov PUBLISHED/SELECTION red u istom TEST/REAL svetu uz otvoren nalog pozivaoca. ACTIVE i istorijski nejavni redovi imaju zasebne owner/participant politike.

Prvi zahvat obuhvata sledeće zavisnosti:

1. Inventar svih sadašnjih `needs` politika, table/column grantova, role nasleđivanja, invoker reader-a i owner helper-a.
2. `rls_private.need_participant_can_read(uuid)` i `rls_private.p6_discovery_test_world_accounts()` zadržavaju potrebne authenticated USAGE/EXECUTE. Njihova istorijska namera i potpune definicije nalaze se u priloženom schema dokazu.
3. Proveriti lance `rpc_read_task`, `rpc_list_my_tasks`, `rpc_list_my_needs_page`, `rpc_discovery_v1` i klijente `needClientService.ts`, `ownTasksPage.ts`, `discoveryV1ClientTransport.ts`, `supabaseIzvor.ts`.
4. `rpc_close_remaining_search` zadržava owner autorizaciju, dozvoljena stanja i stvarni zapis razloga/actor-a/vremena. Ne promeniti ponašanje poslovne komande radi popravke čitanja.
5. Proveriti closure schema/source/certificate posledice; sadržajno obnoviti dokaz, bez promene očekivanog digesta radi zelenog statusa.
6. Proveriti postojeća i buduća default ACL prava. Šire sužavanje nepotrebnih TRUNCATE/TRIGGER/REFERENCES ili PUBLIC EXECUTE raditi tek sa tačnim potrošačima, kao posebnu pregledljivu podcelinu R01/SV01. Sačuvati namerno javni `rpc_get_legal_bundle()`.

**Obavezan dokaz pre statusa VERIFIED:** dva sintetička naloga istog sveta i tuđ PUBLISHED/SELECTION zadatak sa privatnim razlogom zatvaranja pretrage. Kroz stvarni Auth/PostgREST probati direct select, alias, filter, order i wildcard za sva tri privatna polja. Istovremeno javni i dozvoljeni sopstveni reader-i moraju prolaziti kroz pravi decoder. Negativne kontrole uključuju drugi svet, anoniman/zatvoren nalog, pogrešnu/isteklu sesiju i nedozvoljen participant pristup. Potpuno ugašen API nije uspešna popravka. Sintetički novi objekt proverava predviđene default grantove.

Postojeći testni ulazi:

- `supabase/proofs/discovery/p6_http_boundary.mjs`: zadržati nameru Auth/HTTP dokaza, proširiti sa jednog privatnog polja na sva tri i sve oblike čitanja.
- `supabase/proofs/discovery/p6_world_boundary_proof.mjs`: zadržati role/RLS/public whitelist, dodati zatvorenog viewer-a i povezati HTTP granicu.
- `src/data/__tests__/build-identity.test.tsx`: potvrđuje javna identity polja; ne potvrđuje instalirani APK niti SQL kompatibilnost.

Tačni izvori: [R01](review-inputs/USKOCI_KOMPLETAN_PLAN_I_DOKAZI_REV10_2026-10-27/CODEX_PLAN_RADA.md#r01--privatnost-čitanja-stvarne-dozvole-i-isporučeni-ugovor), redovi 410–458; [F21 tehnički dokaz](review-inputs/USKOCI_KOMPLETAN_PLAN_I_DOKAZI_REV10_2026-10-27/TEHNICKI_DOKAZI.md#f21--authenticated-table-select-poništava-granicu-tri-privatne-need-kolone), redovi 442–450; plan SV01, redovi 1856–1921. JSON lokatori:

- `dokazi/izvrsivost/readiness_review.json`: `execution_matrix.tasks[id=R01]`, `execution_matrix.findings[id=F21]`.
- `dokazi/namena_i_testovi/intent_review.json`: `test_matrix.work_items[id=R01]`.
- `dokazi/server_final/change_manifest.json`: `proposed_changes[id=SV01]`, potom tačni `object_inventory` zapisi.
- `dokazi/server_final/schema_review.json`: `files[path="schema_review.json"].data.table_acl_ledger[identity="public.needs"]`, `additional_rls_private_helpers`, `function_acl_ledger`, `schema_roles_default_acl_settings_ledger`, `objects` i `limitations`. Ugrađeni `files[]` zapisi nisu nedostajući spoljašnji fajlovi.

## Redosled posle prvog zahvata

| Korak | Ishod i zavisnost |
|---|---|
| R02 i R03 | Mogu paralelno posle potvrđenog R01 ugovora. R02 usklađuje PAGE/MAP/PLACES/filtere i odvaja greške liste/mape; R03 pet own-task scope-ova, counts i pravi wire oblik. Oba dodaju uske nove migracije, ne vraćaju celu baseline istoriju. |
| R04 i R06 | Najpre potpun katalog, stabilan ID, reuse/nova grana i ceo BOTH; zatim trajni prvi plan, bounded retry, provider STOP/body limit i zaseban BG/STT obračun. Iste BG/review vlasnike menjati sekvencijalno. |
| R05/R07/R08 | Sačuvana područja/TODAY, RSD korekcija, abandon readback, paralelni profile CAS i prirodan završetak sa stvarnim sačuvanim profilom. Satnica i više lokacija blokiraju samo svoje uske delove. |
| R09/R10/R11 | Po zavisnostima: push kapacitet/target/preference; workAreas u izvozu i kopijama; consent/closure; konkretni SB/X kvarovi. Nezavisni nacrti/ocene mogu napredovati uz AI rad. |
| R12 | Prikuplja dokaz od prve vertikale. Konačno: poznat source/SQL/ACL/Edge/flags/native/OTA skup, bootstrap i upgrade, dva naloga/telefona, zaseban Android/iOS dokaz i merena celina. |

Izvori: plan §4.2 redovi 329–354, §11.4–11.5 redovi 3271–3295. Detaljni R vlasnici i testovi su u §6; to je autoritativan radni raspored.

## Provere, odluke i granice izvršenja

R01/F21 se ne zatvara offline CI-jem niti source regex proverom. Za wire promenu potreban je stvarni odgovor kroz decoder; za prava pozitivni/negativni autorizovani zahtev; za native raspored telefon. Postojeći zeleni karakterizacioni testovi mogu namerno reprodukovati kvar. Njihov završni uslov menja se uz popravku, uz očuvan reprodukcioni ulaz.

Aktuelne CI ulaze ponovo pročitati iz checkout-a. REV10 §8.3, redovi 2855–2901, beleži Node 24, Python 3.11, Deno 2.5.6, `npm ci`, `npx tsc --noEmit`, offline Deno check, Jest, izabrane Node testove i Python migration-integrity provere. `npm ci` ima obavezne native patch/asset postinstall korake. Istorijski P6 HTTP/world testovi nisu uključeni u taj redovni CI, kao ni taxonomy post-save/finish-mode testovi. Ne pokretati istorijski harness pre čitanja prve mutacije, guard-a i cleanup-a; SQL SELECT može pozivati writer.

Otvorene poslovne odluke su **Z10/D06** (satnica po osobi ili ekipi) i **Z10/D08** (pokrivanje više radnih lokacija). Oznake nisu iste kao Z09/D06, koji već znači „Samo poruke“. Uklanjanje stare PHONE funkcije ne uklanja phone OTP, slobodan tekst broja u poruci niti EXACT_LOCATION. Predlog brojača kapaciteta ne sme brojati klikove pre potvrđenog domena osobe/mesta/ekipa.

Priprema i lokalne reverzibilne promene napreduju u korisnikovom zaduženju. Dostavljeni paket sam po sebi nije nalog za destruktivan DROP, produkcionu objavu ili plaćene model pozive; konkretan odobreni obim i pristup okruženju proveravaju se pre tih radnji. Stare dokumentacione rečenice o tadašnjem zadatku ne traže ponovnu dozvolu za svako sada autorizovano čitanje, rutinsku odluku ili lokalnu proveru.

**Nerešeno ovim pregledom:** aktuelni udaljeni HEAD, živi ACL/SQL/Edge, stvarni native/OTA/flags, minimalni podržani klijent, Auth management konfiguracija, production backend i store nalozi. Priloženi izvor nije ceo checkout. Store pravila iz §10 su istorijski preneta i moraju se ponovo proveriti pre predaje; ovaj pregled ih nije proveravao na internetu.

Rezultat narednog koraka upisati u isti `CODEX_PLAN_RADA.md` po §11.3 sa verzijom, tačnom promenom, pozitivnom/negativnom proverom, nivoom dokaza, ograničenjem i sledećom radnjom. Izvorni paket i njegov manifest zadržati kao neizmenjen dokaz.
