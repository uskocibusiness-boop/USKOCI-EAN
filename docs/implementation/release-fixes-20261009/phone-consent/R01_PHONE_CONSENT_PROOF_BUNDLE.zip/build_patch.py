from pathlib import Path
import hashlib, json, re

root = Path(__file__).parent
live = root / 'proof-fixtures'
out = root / 'supabase/candidates'
out.mkdir(parents=True, exist_ok=True)
specs = [
    ('0413-public.rpc_get_agreement_workspace.sql', 'public.rpc_get_agreement_workspace(uuid)'),
    ('0445-public.rpc_list_my_agreements.sql', 'public.rpc_list_my_agreements()'),
    ('0446-public.rpc_list_my_agreements_page.sql', 'public.rpc_list_my_agreements_page(text,integer,timestamptz,uuid)'),
]
original = []
patched = []
digests = []
for name, sig in specs:
    raw = (live / name).read_bytes()
    text = raw.decode()
    # Exactly the two existing PHONE projections, and no other logic.
    needle = "and g.status = 'GRANTED'"
    assert text.count(needle) == 2, name
    text = text.replace(needle, needle + '\n' + (' ' * 13) + 'and private.safety_grant_valid(g.granted_by_account_id, g.granted_to_account_id, g.granted_at)')
    current_md5 = hashlib.md5(raw.split(b'$function$')[1]).hexdigest()
    patched_md5 = hashlib.md5(text.encode().split(b'$function$')[1]).hexdigest()
    original.append(raw.decode().rstrip() + ';')
    patched.append(text.rstrip() + ';')
    digests.append({'signature': sig, 'before_body_md5': current_md5, 'after_body_md5': patched_md5,
                    'before_definition_sha256': hashlib.sha256(raw).hexdigest()})

signatures = ','.join("to_regprocedure('%s')" % s for _, s in specs)
metadata = f"""select coalesce(jsonb_agg(jsonb_build_object(
 'oid',p.oid,'signature',p.oid::regprocedure::text,'owner',p.proowner,'acl',p.proacl::text,
 'definer',p.prosecdef,'strict',p.proisstrict,'volatility',p.provolatile,'language',p.prolang,
 'config',p.proconfig,'args',p.proargtypes::text,'result',p.prorettype)
 order by p.oid::regprocedure::text),'[]'::jsonb)::text
 from pg_proc p where p.oid in ({signatures})"""

def guard_before(forward):
    expected = [{ 'signature': x['signature'], 'body_md5': x['before_body_md5' if forward else 'after_body_md5']} for x in digests]
    expected.append({'signature': 'private.safety_grant_valid(uuid,uuid,timestamptz)', 'body_md5': '5d658dd5d719427b0ee0b03a5d872866'})
    payload = json.dumps(expected)
    return f"""do $preflight$
declare e record; actual text; meta text;
begin
 if private.closure_erasure_program_digest_v5() is distinct from 'dab1d731ee99625c6685bbd4df391228e0857e8fbb08fde35539815b7484af65' then
  raise exception 'R01_UNEXPECTED_CLOSURE_PROGRAM_DIGEST';
 end if;
 if not coalesce(private.retention_ai_source_ready(),false) then
  raise exception 'R01_CLOSURE_SOURCE_NOT_READY';
 end if;
 for e in select * from jsonb_to_recordset('{payload}'::jsonb) as x(signature text, body_md5 text) loop
  select md5(p.prosrc) into actual from pg_proc p where p.oid=to_regprocedure(e.signature);
  if actual is distinct from e.body_md5 then
   raise exception 'R01_STALE_DEFINITION: % expected % actual %',e.signature,e.body_md5,actual;
  end if;
 end loop;
 select ({metadata}) into meta;
 perform set_config('uskoci.r01_metadata',meta,true);
 perform set_config('uskoci.r01_closure_program_digest',private.closure_erasure_program_digest_v5(),true);
end;
$preflight$;
"""

def guard_after(forward):
    expected = [{ 'signature': x['signature'], 'body_md5': x['after_body_md5' if forward else 'before_body_md5']} for x in digests]
    payload = json.dumps(expected)
    return f"""do $postflight$
declare e record; actual text; meta text;
begin
 for e in select * from jsonb_to_recordset('{payload}'::jsonb) as x(signature text, body_md5 text) loop
  select md5(p.prosrc) into actual from pg_proc p where p.oid=to_regprocedure(e.signature);
  if actual is distinct from e.body_md5 then
   raise exception 'R01_READBACK_MISMATCH: %',e.signature;
  end if;
 end loop;
 select ({metadata}) into meta;
 if meta is distinct from current_setting('uskoci.r01_metadata') then
  raise exception 'R01_METADATA_CHANGED';
 end if;
 if private.closure_erasure_program_digest_v5() is distinct from current_setting('uskoci.r01_closure_program_digest') then
  raise exception 'R01_CLOSURE_PROGRAM_DIGEST_CHANGED';
 end if;
 if not coalesce(private.retention_ai_source_ready(),false) then
  raise exception 'R01_CLOSURE_SOURCE_NOT_READY_AFTER';
 end if;
end;
$postflight$;
"""

header = """-- R01 / BE-01: enforce existing PHONE consent validity in all Agreement reads.
-- Prepared from current canonical DEV definitions (2026-10-09); NOT APPLIED.
-- Changes ONLY the two PHONE grant predicates in each of three read RPCs.
-- Preserves result shapes, ownership, ACLs, SECURITY DEFINER/search_path,
-- auth/party restrictions, pagination, ratingDue and actionState semantics.
-- No rows, tables, policies, triggers, Edge deploys or certificate update.
-- Pre/postflight enforce exact bodies, metadata and closure program digest.
begin;
set local lock_timeout = '2s';
set local statement_timeout = '15s';
"""
forward = header + guard_before(True) + '\n\n'.join(patched) + '\n' + guard_after(True) + 'commit;\n'
revert = header.replace('enforce existing PHONE consent validity in all Agreement reads.', 'EXACT REVERT: restore captured Agreement read definitions.') + guard_before(False) + '\n\n'.join(original) + '\n' + guard_after(False) + 'commit;\n'
(out / 'r01_phone_read_consent_20261009.sql').write_text(forward)
(out / 'r01_phone_read_consent_20261009.revert.sql').write_text(revert)
(root / 'patch-manifest.json').write_text(json.dumps({'source_head':'35a55f8a4e4900220c14b10f0c0ffb850810b64e', 'runtime_parent':'ce23eb06befd0260b71e0c334e5557da5df7639d', 'definitions':digests, 'candidate_sha256':hashlib.sha256(forward.encode()).hexdigest(), 'revert_sha256':hashlib.sha256(revert.encode()).hexdigest()}, indent=2) + '\n')
(root / 'baseline.sql').write_text('\n\n'.join(original) + '\n')
print(json.dumps({'files': [str(out / 'r01_phone_read_consent_20261009.sql'),str(out / 'r01_phone_read_consent_20261009.revert.sql')], 'definitions': digests},indent=2))
