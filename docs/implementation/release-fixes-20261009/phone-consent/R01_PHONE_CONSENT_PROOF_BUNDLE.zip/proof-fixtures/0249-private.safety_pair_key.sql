CREATE OR REPLACE FUNCTION private.safety_pair_key(a uuid, b uuid)
 RETURNS bigint
 LANGUAGE sql
 IMMUTABLE STRICT
 SET search_path TO 'pg_catalog'
AS $function$ select hashtextextended('uskoci:safety-pair:'||least(a,b)::text||':'||greatest(a,b)::text,8318); $function$
