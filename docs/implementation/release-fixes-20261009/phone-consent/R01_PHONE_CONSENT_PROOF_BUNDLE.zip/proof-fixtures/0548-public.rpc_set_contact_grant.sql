CREATE OR REPLACE FUNCTION public.rpc_set_contact_grant(p_agreement_id uuid, p_channel text, p_granted boolean)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
declare
  v_uid uuid := auth.uid();
  v_agreement public.agreements%rowtype;
  v_to uuid;
  v_grant_id uuid;
  v_phone text;
  v_address text;
begin
  if v_uid is null then
    raise exception 'AUTH_REQUIRED' using errcode = '28000';
  end if;
  if p_channel not in ('PHONE', 'EXACT_LOCATION') then
    raise exception 'UNSUPPORTED_CHANNEL' using errcode = '22023';
  end if;
  if p_granted is null then
    raise exception 'GRANT_DECISION_REQUIRED' using errcode = '22004';
  end if;

  select *
    into v_agreement
    from public.agreements
   where id = p_agreement_id
   for update;

  if not found then
    raise exception 'AGREEMENT_NOT_FOUND' using errcode = 'P0002';
  end if;
  if v_uid not in (v_agreement.requester_account_id, v_agreement.worker_account_id) then
    raise exception 'NOT_PARTY' using errcode = '42501';
  end if;

  v_to := case
            when v_uid = v_agreement.requester_account_id then v_agreement.worker_account_id
            else v_agreement.requester_account_id
          end;

  -- Revocation is deliberately allowed after cancellation/completion so a
  -- user can always close their own grant. New grants require a live agreement.
  if p_granted and v_agreement.status <> 'CONFIRMED' then
    raise exception 'AGREEMENT_NOT_ACTIVE' using errcode = 'P0001', detail = v_agreement.status;
  end if;

  if p_channel = 'PHONE' and p_granted then
    select nullif(btrim(a.phone), '')
      into v_phone
      from public.app_accounts a
     where a.id = v_uid;
    if v_phone is null then
      raise exception 'PHONE_NOT_SET' using errcode = 'P0001';
    end if;
  end if;

  -- Exact Need location belongs to the requester. A worker cannot grant a
  -- requester's address back to them or to anyone else.
  if p_channel = 'EXACT_LOCATION' then
    if v_uid <> v_agreement.requester_account_id then
      raise exception 'NOT_LOCATION_OWNER' using errcode = '42501';
    end if;
    if p_granted then
      select nullif(btrim(s.exact_address), '')
        into v_address
        from public.need_sensitive s
       where s.need_id = v_agreement.need_id;
      if v_address is null and not exists (
        select 1 from public.need_sensitive s join public.needs n on n.id=s.need_id join public.need_geography g on g.need_id=n.id
        where s.need_id=v_agreement.need_id and s.resolved_location is not null
          and private.resolved_location_record_valid(s.resolved_location,n.task_country_code,g.public_topology,s.exact_address,n.requester_account_id)
      ) then
        raise exception 'LOCATION_NOT_SET' using errcode = 'P0001';
      end if;
    end if;
  end if;

  if p_granted then
    insert into public.access_grants (
      agreement_id,
      channel,
      granted_by_account_id,
      granted_to_account_id,
      status,
      granted_at,
      revoked_at,
      expires_at
    ) values (
      p_agreement_id,
      p_channel,
      v_uid,
      v_to,
      'GRANTED',
      statement_timestamp(),
      null,
      null
    )
    on conflict (agreement_id, channel, granted_by_account_id, granted_to_account_id)
    do update set
      status = 'GRANTED',
      granted_at = statement_timestamp(),
      revoked_at = null,
      expires_at = null
    returning id into v_grant_id;
  else
    update public.access_grants
       set status = 'REVOKED',
           revoked_at = coalesce(revoked_at, statement_timestamp())
     where agreement_id = p_agreement_id
       and channel = p_channel
       and granted_by_account_id = v_uid
       and granted_to_account_id = v_to
    returning id into v_grant_id;
  end if;

  return jsonb_build_object(
    'agreementId', p_agreement_id,
    'channel', p_channel,
    'grantedByAccountId', v_uid,
    'grantedToAccountId', v_to,
    'granted', p_granted,
    'grantId', v_grant_id,
    'authoritative', true
  );
end;
$function$
