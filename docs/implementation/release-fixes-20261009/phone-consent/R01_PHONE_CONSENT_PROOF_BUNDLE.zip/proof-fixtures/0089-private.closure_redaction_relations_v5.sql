CREATE OR REPLACE FUNCTION private.closure_redaction_relations_v5()
 RETURNS text[]
 LANGUAGE sql
 IMMUTABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
 select array[
 'private.requester_identity_commands','private.worker_ai_saves','private.ai_task_review_commands',
 'private.ai_task_reviews','private.worker_ai_reviews','private.worker_ai_sessions',
 'public.ai_action_proposals','public.ai_structured_facts','public.ai_messages',
 'private.ai_need_turn_commands','private.worker_ai_turns','public.ai_conversations',
 'private.need_draft_save_commands','private.need_edit_commands','private.need_publish_commands',
 'private.response_submit_commands','private.response_withdraw_commands','private.response_revision_resolution_commands',
 'private.remaining_search_close_commands','private.preselection_qa_commands','private.qa_ai_commands',
 'private.need_publication_decisions','private.need_revision_events',
 'private.preselection_qa_answer_versions','private.preselection_qa_questions',
 'private.preselection_qa_policy_decisions','private.preselection_qa_materiality_decisions',
 'private.response_application_snapshots','public.marketplace_response_versions','public.marketplace_responses',
 'public.agreement_invalidations_v1','public.agreement_messages','private.group_messages_v5','public.agreement_versions','public.agreement_change_proposals',
 'public.agreement_execution','private.agreement_location_points','private.agreement_location_commands',
 'public.need_sensitive','public.need_geography','public.need_requirement_details','public.needs',
 'public.data_export_requests','private.data_export_artifacts',
 'public.notification_push_attempts','public.notification_deliveries','public.user_activity_events',
 'public.notification_push_devices','public.notification_preferences','public.opportunity_deliveries',
 'private.dispatch_schedule','public.dispatch_rounds','public.access_grants',
 'public.profile_availability_rules','public.profile_availability_windows','public.worker_match_preferences',
 'private.worker_calendar_events','private.worker_calendar_serialization','private.support_read_markers_v5',
 'private.owned_media_assets','private.agreement_photo_uploads_v5','private.agreement_voice_uploads_v1',
 'private.account_block_commands','private.marketplace_audit_log','private.retention_jobs',
 'private.retention_holds','private.support_commands_v5','private.support_grant_commands_v5',
 'private.account_lineage_events_v5','private.account_lineage_v5','private.group_message_visibility_v5','private.ai_test_accounts_v5','private.support_operator_grants_v5','public.app_profiles','public.app_accounts','private.agreement_review_comments_v1'
 ]::text[];
$function$
