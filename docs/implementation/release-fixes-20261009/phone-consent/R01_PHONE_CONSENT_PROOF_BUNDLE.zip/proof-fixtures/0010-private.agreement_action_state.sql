CREATE OR REPLACE FUNCTION private.agreement_action_state(p_id uuid, p_actor uuid)
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
 select jsonb_build_object('agreementId',a.id,'agreementVersion',a.current_version,'accountId',p_actor,'authoritative',true,
   'canProposeChange',a.status='CONFIRMED' and x.state='CONFIRMED' and x.worker_marked_done_at is null and not coalesce(p.has_pending,false),
   'canRespondChange',a.status='CONFIRMED' and x.state='CONFIRMED' and x.worker_marked_done_at is null and coalesce(p.can_respond,false),
   'canWithdrawChange',a.status='CONFIRMED' and x.state='CONFIRMED' and x.worker_marked_done_at is null and coalesce(p.can_withdraw,false),
   'canMarkWorkDone',p_actor=a.worker_account_id and a.status='CONFIRMED' and x.state='CONFIRMED' and x.worker_marked_done_at is null and not coalesce(p.has_pending,false),
   'canConfirmCompletion',p_actor=a.requester_account_id and a.status='CONFIRMED' and x.state in ('CONFIRMED','AWAITING_REQUESTER') and not coalesce(p.has_pending,false),
   'canCancel',a.status='CONFIRMED' and (x.state='CONFIRMED' or (x.state='AWAITING_REQUESTER' and p_actor=a.worker_account_id)),
   'pendingChanges',coalesce(p.items,'[]'::jsonb))
 from public.agreements a join public.agreement_execution x on x.agreement_id=a.id and x.agreement_version=a.current_version
 left join lateral(select bool_or(true) has_pending, bool_or(c.proposed_by_account_id<>p_actor) can_respond,
   bool_or(c.proposed_by_account_id=p_actor) can_withdraw,
   jsonb_agg(jsonb_build_object('id',c.id,'baseVersion',c.base_version,'proposedByAccountId',c.proposed_by_account_id,
     'createdAt',c.created_at,'proposedTerms',c.proposed_terms,'reason',c.reason) order by c.created_at,c.id) items
   from public.agreement_change_proposals c where c.agreement_id=a.id and c.status='PENDING') p on true
 where a.id=p_id and p_actor in (a.requester_account_id,a.worker_account_id);
$function$
