CREATE OR REPLACE FUNCTION private.audit_marketplace(p_actor uuid, p_event_type text, p_entity_type text, p_entity_id uuid, p_entity_version integer DEFAULT NULL::integer, p_detail jsonb DEFAULT '{}'::jsonb)
 RETURNS void
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
  insert into private.marketplace_audit_log (
    actor_user_id, event_type, entity_type, entity_id, entity_version, detail
  ) values (
    p_actor, p_event_type, p_entity_type, p_entity_id, p_entity_version,
    coalesce(p_detail, '{}'::jsonb)
  );
$function$
