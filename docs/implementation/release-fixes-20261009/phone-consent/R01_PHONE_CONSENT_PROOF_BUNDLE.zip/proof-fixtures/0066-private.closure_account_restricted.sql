CREATE OR REPLACE FUNCTION private.closure_account_restricted(a uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$ select exists(select 1 from private.account_closure_requests r where r.account_id=a
 and r.state in('READY','EXECUTING','FAILED','CLOSED')); $function$
