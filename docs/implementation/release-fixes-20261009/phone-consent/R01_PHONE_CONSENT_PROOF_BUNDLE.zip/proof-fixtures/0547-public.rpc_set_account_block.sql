CREATE OR REPLACE FUNCTION public.rpc_set_account_block(p_target_account_id uuid, p_blocked boolean, p_expected_revision integer, p_client_request_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
declare u uuid:=auth.uid(); r private.account_blocks; c private.account_block_commands; h text; receipt jsonb;
begin
 if u is null then raise exception 'AUTH_REQUIRED' using errcode='42501'; end if;
 if p_target_account_id is null or p_target_account_id=u or p_blocked is null or p_client_request_id is null
 or p_expected_revision is null or p_expected_revision<0 or p_expected_revision>=2147483647 then raise exception 'BLOCK_INPUT_INVALID' using errcode='22023'; end if;
 h:=encode(extensions.digest(jsonb_build_object('target',p_target_account_id,'blocked',p_blocked,'revision',p_expected_revision)::text,'sha256'),'hex');
 perform pg_advisory_xact_lock(hashtextextended('uskoci:block-command:'||u::text||':'||p_client_request_id::text,8318));
 select * into c from private.account_block_commands where actor_account_id=u and client_request_id=p_client_request_id;
 if found then
  if c.input_hash<>h then raise exception 'REQUEST_ID_REUSED' using errcode='22023'; end if;
  return c.receipt||jsonb_build_object('idempotentReplay',true);
 end if;
 if not exists(select 1 from public.app_accounts where id=p_target_account_id) then raise exception 'TARGET_NOT_AVAILABLE' using errcode='42501'; end if;
 perform pg_advisory_xact_lock(private.safety_pair_key(u,p_target_account_id));
 select * into r from private.account_blocks where blocker_account_id=u and blocked_account_id=p_target_account_id;
 if coalesce(r.revision,0)<>p_expected_revision then raise exception 'BLOCK_REVISION_CONFLICT' using errcode='PT409'; end if;
 insert into private.account_blocks(blocker_account_id,blocked_account_id,active,revision,last_blocked_at)
 values(u,p_target_account_id,p_blocked,p_expected_revision+1,case when p_blocked then clock_timestamp() end)
 on conflict(blocker_account_id,blocked_account_id) do update set active=excluded.active,revision=excluded.revision,
 last_blocked_at=case when excluded.active then clock_timestamp() else private.account_blocks.last_blocked_at end,updated_at=clock_timestamp();
 receipt:=jsonb_build_object('accountId',u,'targetAccountId',p_target_account_id,'blocked',p_blocked,'revision',p_expected_revision+1,
  'clientRequestId',p_client_request_id,'idempotentReplay',false,'authoritative',true);
 insert into private.account_block_commands(actor_account_id,client_request_id,target_account_id,input_hash,receipt) values(u,p_client_request_id,p_target_account_id,h,receipt);
 perform private.audit_marketplace(u,case when p_blocked then 'ACCOUNT_BLOCKED' else 'ACCOUNT_UNBLOCKED' end,'ACCOUNT',p_target_account_id,p_expected_revision+1,'{}');
 return receipt;
end;
$function$
