CREATE OR REPLACE FUNCTION private.safety_grant_valid(a uuid, b uuid, granted timestamp with time zone)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$ select granted is not null and not private.closure_account_restricted(a) and not private.closure_account_restricted(b)
 and not exists(select 1 from private.account_blocks x
 where ((x.blocker_account_id=a and x.blocked_account_id=b) or (x.blocker_account_id=b and x.blocked_account_id=a))
 and (x.active or x.last_blocked_at>=granted)); $function$
