CREATE OR REPLACE FUNCTION public.rpc_list_my_agreements()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
declare
  v_uid uuid := auth.uid();
  v_result jsonb;
begin
  if v_uid is null then
    raise exception 'AUTH_REQUIRED' using errcode = '28000';
  end if;

  select coalesce(jsonb_agg(x.payload order by x.created_at desc), '[]'::jsonb)
    into v_result
    from (
      select
        a.created_at,
        jsonb_build_object(
          'id', a.id,
          'currentVersion', a.current_version,
          'status', coalesce(ae.state, a.status),
          'agreementStatus', a.status,
          'title', n.title,
          'approximateArea', n.approximate_area,
          'approximateCity', n.approximate_city,
          'requiredSlots', n.required_slots,
          'startsAt', n.starts_at,
          'terms', av.terms,
          'requesterAccountId', a.requester_account_id,
          'workerAccountId', a.worker_account_id,
          'requesterName', rp.display_name,
          'workerName', wp.display_name,
          'executionMode', ae.mode,
          'requesterDeadlineAt', ae.requester_deadline_at,
          'problemOpened', (ae.problem_opened_at is not null),
          'myPhoneShared', exists (
            select 1 from public.access_grants g
             where g.agreement_id = a.id
               and g.channel = 'PHONE'
               and g.granted_by_account_id = v_uid
               and g.status = 'GRANTED'
               and (g.expires_at is null or g.expires_at > statement_timestamp())
          ),
          'theirPhone', case
            when a.status = 'CONFIRMED' and exists (
              select 1 from public.access_grants g
               where g.agreement_id = a.id
                 and g.channel = 'PHONE'
                 and g.granted_to_account_id = v_uid
                 and g.status = 'GRANTED'
                 and (g.expires_at is null or g.expires_at > statement_timestamp())
            ) then (
              select nullif(btrim(acc.phone), '')
                from public.app_accounts acc
               where acc.id = case when v_uid = a.requester_account_id then a.worker_account_id else a.requester_account_id end
            )
            else null
          end,
          'createdAt', a.created_at
        ) as payload
      from public.agreements a
      join public.agreement_versions av
        on av.agreement_id = a.id and av.version = a.current_version
      join public.needs n on n.id = a.need_id
      join public.app_profiles rp on rp.id = a.requester_profile_id
      join public.app_profiles wp on wp.id = a.worker_profile_id
      left join public.agreement_execution ae on ae.agreement_id = a.id
      where v_uid in (a.requester_account_id, a.worker_account_id)
    ) x;

  return v_result;
end;
$function$
