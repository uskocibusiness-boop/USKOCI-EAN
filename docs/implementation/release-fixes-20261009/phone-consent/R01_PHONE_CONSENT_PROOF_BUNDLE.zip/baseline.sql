CREATE OR REPLACE FUNCTION public.rpc_get_agreement_workspace(p_agreement_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
declare
  v_uid uuid := auth.uid();
  v_result jsonb;
begin
  if v_uid is null then
    raise exception 'AUTH_REQUIRED' using errcode = '28000';
  end if;

  select jsonb_build_object(
      'id', a.id,
      'currentVersion', a.current_version,
      'status', coalesce(ae.state, a.status),
      'agreementStatus', a.status,
      'title', n.title,
      'approximateArea', n.approximate_area,
      'approximateCity', n.approximate_city,
      'requiredSlots', n.required_slots,
      'startsAt', n.starts_at,
      'terms', av.terms,
      'requesterAccountId', a.requester_account_id,
      'workerAccountId', a.worker_account_id, 'requesterProfileId', a.requester_profile_id, 'workerProfileId', a.worker_profile_id,
      'requesterName', rp.display_name,
      'workerName', wp.display_name,
      'executionMode', ae.mode,
      'requesterDeadlineAt', ae.requester_deadline_at,
      'problemOpened', (ae.problem_opened_at is not null),
      'myPhoneShared', exists (
        select 1 from public.access_grants g
         where g.agreement_id = a.id
           and g.channel = 'PHONE'
           and g.granted_by_account_id = v_uid
           and g.status = 'GRANTED'
           and (g.expires_at is null or g.expires_at > statement_timestamp())
      ),
      'theirPhone', case
        when a.status = 'CONFIRMED' and exists (
          select 1 from public.access_grants g
           where g.agreement_id = a.id
             and g.channel = 'PHONE'
             and g.granted_to_account_id = v_uid
             and g.status = 'GRANTED'
             and (g.expires_at is null or g.expires_at > statement_timestamp())
        ) then (
          select nullif(btrim(acc.phone), '')
            from public.app_accounts acc
           where acc.id = case when v_uid = a.requester_account_id then a.worker_account_id else a.requester_account_id end
        )
        else null
      end,
      'needId', a.need_id,
      'applicationId', a.selected_response_id,
      'createdAt', a.created_at
    )
    into v_result
    from public.agreements a
    join public.agreement_versions av
      on av.agreement_id = a.id and av.version = a.current_version
    join public.needs n on n.id = a.need_id
    join public.app_profiles rp on rp.id = a.requester_profile_id
    join public.app_profiles wp on wp.id = a.worker_profile_id
    left join public.agreement_execution ae on ae.agreement_id = a.id
   where a.id = p_agreement_id
     and v_uid in (a.requester_account_id, a.worker_account_id);

  if v_result is null then
    raise exception 'AGREEMENT_NOT_FOUND_OR_FORBIDDEN' using errcode = 'P0002';
  end if;
  return v_result || jsonb_build_object('actionState', private.agreement_action_state(p_agreement_id,v_uid));
end;
$function$;

CREATE OR REPLACE FUNCTION public.rpc_list_my_agreements()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
declare
  v_uid uuid := auth.uid();
  v_result jsonb;
begin
  if v_uid is null then
    raise exception 'AUTH_REQUIRED' using errcode = '28000';
  end if;

  select coalesce(jsonb_agg(x.payload order by x.created_at desc), '[]'::jsonb)
    into v_result
    from (
      select
        a.created_at,
        jsonb_build_object(
          'id', a.id,
          'currentVersion', a.current_version,
          'status', coalesce(ae.state, a.status),
          'agreementStatus', a.status,
          'title', n.title,
          'approximateArea', n.approximate_area,
          'approximateCity', n.approximate_city,
          'requiredSlots', n.required_slots,
          'startsAt', n.starts_at,
          'terms', av.terms,
          'requesterAccountId', a.requester_account_id,
          'workerAccountId', a.worker_account_id,
          'requesterName', rp.display_name,
          'workerName', wp.display_name,
          'executionMode', ae.mode,
          'requesterDeadlineAt', ae.requester_deadline_at,
          'problemOpened', (ae.problem_opened_at is not null),
          'myPhoneShared', exists (
            select 1 from public.access_grants g
             where g.agreement_id = a.id
               and g.channel = 'PHONE'
               and g.granted_by_account_id = v_uid
               and g.status = 'GRANTED'
               and (g.expires_at is null or g.expires_at > statement_timestamp())
          ),
          'theirPhone', case
            when a.status = 'CONFIRMED' and exists (
              select 1 from public.access_grants g
               where g.agreement_id = a.id
                 and g.channel = 'PHONE'
                 and g.granted_to_account_id = v_uid
                 and g.status = 'GRANTED'
                 and (g.expires_at is null or g.expires_at > statement_timestamp())
            ) then (
              select nullif(btrim(acc.phone), '')
                from public.app_accounts acc
               where acc.id = case when v_uid = a.requester_account_id then a.worker_account_id else a.requester_account_id end
            )
            else null
          end,
          'createdAt', a.created_at
        ) as payload
      from public.agreements a
      join public.agreement_versions av
        on av.agreement_id = a.id and av.version = a.current_version
      join public.needs n on n.id = a.need_id
      join public.app_profiles rp on rp.id = a.requester_profile_id
      join public.app_profiles wp on wp.id = a.worker_profile_id
      left join public.agreement_execution ae on ae.agreement_id = a.id
      where v_uid in (a.requester_account_id, a.worker_account_id)
    ) x;

  return v_result;
end;
$function$;

CREATE OR REPLACE FUNCTION public.rpc_list_my_agreements_page(p_scope text DEFAULT 'ALL'::text, p_limit integer DEFAULT 30, p_before_at timestamp with time zone DEFAULT NULL::timestamp with time zone, p_before_id uuid DEFAULT NULL::uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
declare
  v_uid uuid := auth.uid();
  v_items jsonb;
  v_restricted boolean;
begin
  if v_uid is null then raise exception 'AUTH_REQUIRED' using errcode = '28000'; end if;
  if p_limit is null or p_limit < 1 or p_limit > 100 or (p_before_at is null) <> (p_before_id is null) then
    raise exception 'INVALID_PAGE' using errcode = '22023';
  end if;
  if p_scope is null or p_scope not in ('ALL','ACTIVE','HISTORY') then
    raise exception 'INVALID_SCOPE' using errcode = '22023';
  end if;

  -- EX-04 S3 (RC-03): whether MY rating of a finished Dogovor is still due is part of the page, so the client never has to ask once per Dogovor. It is exactly the answer of
  -- rpc_get_my_agreement_review(...).eligible: no review of mine yet, my account is not under a closure restriction, and the Dogovor and its execution are COMPLETED.
  v_restricted := private.closure_account_restricted(v_uid);
  select coalesce(jsonb_agg(x.payload order by x.created_at desc, x.id desc), '[]'::jsonb) into v_items
  from (
    select a.created_at, a.id,
      jsonb_build_object(
        'id', a.id, 'sortAt', a.created_at,
        'currentVersion', a.current_version,
        'status', coalesce(ae.state, a.status),
        'agreementStatus', a.status,
        'title', n.title,
        'approximateArea', n.approximate_area,
        'approximateCity', n.approximate_city,
        'requiredSlots', n.required_slots,
        'startsAt', n.starts_at,
        'terms', av.terms,
        'requesterAccountId', a.requester_account_id,
        'workerAccountId', a.worker_account_id, 'requesterProfileId', a.requester_profile_id, 'workerProfileId', a.worker_profile_id,
        'requesterName', rp.display_name,
        'workerName', wp.display_name,
        'executionMode', ae.mode,
        'requesterDeadlineAt', ae.requester_deadline_at,
        'problemOpened', (ae.problem_opened_at is not null),
        'myPhoneShared', exists (
          select 1 from public.access_grants g
           where g.agreement_id = a.id and g.channel = 'PHONE' and g.granted_by_account_id = v_uid
             and g.status = 'GRANTED' and (g.expires_at is null or g.expires_at > statement_timestamp())),
        'theirPhone', case
          when a.status = 'CONFIRMED' and exists (
            select 1 from public.access_grants g
             where g.agreement_id = a.id and g.channel = 'PHONE' and g.granted_to_account_id = v_uid
               and g.status = 'GRANTED' and (g.expires_at is null or g.expires_at > statement_timestamp())
          ) then (
            select nullif(btrim(acc.phone), '') from public.app_accounts acc
             where acc.id = case when v_uid = a.requester_account_id then a.worker_account_id else a.requester_account_id end)
          else null
        end,
        'pendingChange', (
          select jsonb_build_object('id', c.id, 'proposedByMe', c.proposed_by_account_id = v_uid, 'createdAt', c.created_at)
            from public.agreement_change_proposals c
           where c.agreement_id = a.id and c.status = 'PENDING'
           order by c.created_at desc, c.id desc
           limit 1),
        'createdAt', a.created_at,
        'ratingDue', coalesce(a.status = 'COMPLETED' and ae.state = 'COMPLETED' and not v_restricted
          and not exists (select 1 from private.agreement_reviews rv where rv.agreement_id = a.id and rv.reviewer_account_id = v_uid), false)
      ) as payload
    from public.agreements a
    join public.agreement_versions av on av.agreement_id = a.id and av.version = a.current_version
    join public.needs n on n.id = a.need_id
    join public.app_profiles rp on rp.id = a.requester_profile_id
    join public.app_profiles wp on wp.id = a.worker_profile_id
    left join public.agreement_execution ae on ae.agreement_id = a.id
    where v_uid in (a.requester_account_id, a.worker_account_id)
      and (p_scope = 'ALL' or (p_scope = 'ACTIVE') = (coalesce(ae.state, a.status) in ('CONFIRMED','AWAITING_REQUESTER')))
      and (p_before_at is null or (a.created_at, a.id) < (p_before_at, p_before_id))
    order by a.created_at desc, a.id desc
    limit p_limit + 1
  ) x;

  return jsonb_build_object(
    'items', case when jsonb_array_length(v_items) > p_limit then v_items - p_limit else v_items end,
    'hasMore', jsonb_array_length(v_items) > p_limit,
    'asOf', statement_timestamp());
end
$function$;
