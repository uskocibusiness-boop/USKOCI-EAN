# R01 / BE-01 — PHONE consent read repair

Status: **LOCALLY PROVEN; APPLIED BY ROOT TO CANONICAL DEV.** Root is the only integrator/live writer. This subagent made no live or GitHub writes.

Root's application/readback receipt (2026-10-09): migration version `20261009172613`, ledger `238`, stored statement MD5 `eb1cc4786635c042818b843e3bb2efed` equals the sent candidate bytes. Root reports all three after-body MD5s match, existing safety helper/owner/ACL/security/search_path metadata unchanged, closure program digest unchanged, certified/source/erasure digest remains `0201a7ccf74a3a5d0ed397d714392881af6ea1056b42f549097f9d3ecd9a4acb`, and readiness remains true. Root independently reran both 67-check local proofs. The candidate header's “NOT APPLIED” records preparation-time provenance; its bytes are preserved exactly as applied.

Canonical source: `uskocibusiness-boop/USKOCI-EAN`, `work/uskoci-ui-unification-20260924`, refreshed HEAD `35a55f8a4e4900220c14b10f0c0ffb850810b64e`. This is a docs-only successor of the audited source. The three captured current server body MD5s independently match root's fresh live read.

## Concrete delta

Exactly six existing PHONE grant predicates gain the existing canonical `private.safety_grant_valid(g.granted_by_account_id, g.granted_to_account_id, g.granted_at)` condition: `myPhoneShared` and `theirPhone` in `rpc_get_agreement_workspace`, `rpc_list_my_agreements`, and `rpc_list_my_agreements_page`.

The read therefore follows the same existing block/closure/grant-time rule as `rpc_reveal_contact`. Blocking either direction hides the phone and makes the UI's own sharing flag false. Unblocking does not restore pre-block consent. A fresh valid grant after unblocking does restore consent. No new consent architecture, rows, tables, policies, triggers, grants, Edge changes, or certificate update.

Existing auth/party restrictions, JSON keys, non-phone fields, paging, pending change, ratingDue and actionState remain unchanged. Existing inactive Agreement behavior remains unchanged. The patch does not invent a new lifecycle rule.

## Exact guards

Candidate and revert run in one transaction, with a 2-second lock timeout and 15-second statement timeout. They reject stale reader or safety-function body MD5s, reject unexpected live closure program digest, require `private.retention_ai_source_ready()` before and after, preserve OID/owner/ACL/security/search_path/strictness/volatility/language/arguments/result metadata, verify all new stored body MD5s and unchanged program digest. The live expected program digest is `dab1d731ee99625c6685bbd4df391228e0857e8fbb08fde35539815b7484af65`.

The three reader signatures are absent from the actual `closure_erasure_program_digest_v5` and `closure_source_digest_v5` protected function lists. They are not trigger-returning functions. The schema, invalidation and voice digest surfaces do not include their bodies. A live preflight/postflight is still required: a fixture digest is not the canonical certificate.

## Actual PostgreSQL proof

`proof.mjs` executes real PostgreSQL, not a JavaScript SQL emulator. Both engines passed **67 checks, 0 failures**, with **12 deliberately observed FAIL-before assertions** per engine, across both callers and all three read RPCs:

- PostgreSQL 17.5 / PGlite 0.3.14 — same major as canonical PostgreSQL 17.6.1.165. Its `extensions.digest` fixture wrappers use native PostgreSQL SHA-256 because this test package does not ship pgcrypto.
- PostgreSQL 18.3 / PGlite 0.5.8 — real pgcrypto loaded, same 67 checks PASS.

The actual three read definitions, grant/revoke command, block/unblock command, safety predicate, closure restriction predicate, pair key, audit write and action-state definition execute against synthetic fixture tables. Tests cover active block, both directions, unblock without old-consent resurrection, fresh regrant, revoke, expiration, closure restriction, inactive Agreement, foreign ID, empty foreign lists, direct phone-table denial, missing auth, anonymous EXECUTE denial, paging validation, exact valid-consent JSON parity, revert/reapply and metadata/digest invariants.

Two certificate admission checks are also exercised: the exact production digest rejects the synthetic catalog, and an unready fixture gate rejects before writes.

**Limits:** This is a minimal synthetic relational fixture, not the complete canonical schema/trigger/RLS deployment. `auth.uid()` reads a synthetic JWT claim setting; no JWT signature/Auth server is involved. The candidate's fixed expected live digest is substituted with the actual synthetic catalog digest for successful local execution. `retention_ai_source_ready` is a fixture SQL function reading a synthetic ready setting; its live certificate correctness is not proved by that fixture. The actual canonical closure program digest algorithm itself runs unchanged. No PostgREST, production concurrency/load, real provider, real user data, emulator or physical device was used. No live mutation occurred.

## Files

- `supabase/candidates/r01_phone_read_consent_20261009.sql` — narrowly scoped guarded candidate.
- `supabase/candidates/r01_phone_read_consent_20261009.revert.sql` — exact guarded revert of all three original bodies.
- `patch-manifest.json` — old/new body MD5s and candidate/revert SHA-256.
- `proof.mjs`, `proof-result.json`, `proof-result-pg17.json`, `proof.log`, `proof-pg17.log` — reproducible local proof and exact engine identities.
- `build_patch.py` — deterministic generator from immutable current captured definitions.

The isolated `test-runtime*` directories are audit tooling only. No application manifest, lockfile, dependency, current-source file, GitHub source or DEV state was modified.

## Integration sequence

1. Refresh live body hashes, expected closure digest and retention-ready; verify canonical HEAD still carries the same backend code scope.
2. Apply exact candidate bytes only after root review. Any pre/postcondition mismatch rolls the transaction back.
3. Read back each body MD5, owner/ACL/config, unchanged digest and live readiness. Record receipt using the existing ledger/control tracker.
4. Run bounded current-client reads with legitimate test parties, then check consent indicator/phone display in the final native build. Do not manufacture business data or claim device acceptance from local proof.

Rollback is exact SQL revert and is locally verified. Runtime client shape is compatible with the current APK; no client deployment is required to stop server disclosure.
