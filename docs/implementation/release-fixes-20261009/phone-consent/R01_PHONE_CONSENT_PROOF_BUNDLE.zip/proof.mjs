import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { strict as assert } from 'node:assert';
const engine17=process.env.PHONE_PROOF_ENGINE==='pg17';
const {PGlite}=await import(engine17?'./test-runtime-pg17/node_modules/@electric-sql/pglite/dist/index.js':'./test-runtime/node_modules/@electric-sql/pglite/dist/index.js');
const extensions=engine17?{}:{pgcrypto:(await import('./test-runtime/node_modules/@electric-sql/pglite/dist/contrib/pgcrypto.js')).pgcrypto};

const base = new URL('./', import.meta.url);
const live = new URL('./proof-fixtures/', import.meta.url);
const file = (path) => readFileSync(new URL(path,base),'utf8');
let fixtureDigest;
const fixtureCandidate = (path) => file(path)
  .replaceAll('dab1d731ee99625c6685bbd4df391228e0857e8fbb08fde35539815b7484af65',fixtureDigest);
const sql = (path) => readFileSync(new URL(path,live),'utf8').trimEnd() + ';';
const report = { sourceHead:'35a55f8a4e4900220c14b10f0c0ffb850810b64e',
  scope:'Real PostgreSQL/WASM, synthetic minimal relational fixture. Actual three read definitions, safety predicate, closure restriction predicate, grant/revoke command, block/unblock command, pair key, audit write and agreement action-state definitions execute unchanged. Supabase JWT verification, full schema/RLS/trigger integration and real device are not claimed.',
  checks:[], baselineExpectedFailures:[], limitations:[] };
const db = new PGlite({extensions});
const q = async (query,params=[]) => (await db.query(query,params)).rows;
const check = async (name,fn) => { try { await fn(); report.checks.push({name,status:'PASS'}); } catch(e) { report.checks.push({name,status:'FAIL',error:e.message,code:e.code}); throw e; } };
const A='10000000-0000-0000-0000-000000000001', B='10000000-0000-0000-0000-000000000002', C='10000000-0000-0000-0000-000000000003';
const AG='20000000-0000-0000-0000-000000000001';
const uid = async (id) => { await db.exec('reset role'); await q("select set_config('request.jwt.claim.sub',$1,false)",[id||'']); await db.exec('set role authenticated'); };
const admin = async (query) => { await db.exec('reset role'); return db.exec(query); };
const readers = {
  workspace: async () => (await q('select public.rpc_get_agreement_workspace($1) value',[AG]))[0].value,
  legacy: async () => (await q('select public.rpc_list_my_agreements() value'))[0].value.find(v=>v.id===AG),
  paged: async () => (await q("select public.rpc_list_my_agreements_page('ALL',30,null,null) value"))[0].value.items.find(v=>v.id===AG),
};
const grant = async (who,on=true) => { await uid(who); return q("select public.rpc_set_contact_grant($1,'PHONE',$2)",[AG,on]); };
const block = async (who,to,on,revision) => { await uid(who); return q('select public.rpc_set_account_block($1,$2,$3,gen_random_uuid()) value',[to,on,revision]); };
const phones = async (name,expectedPhone,expectedShared,who=A) => {
  await uid(who);
  for (const [reader,read] of Object.entries(readers)) await check(`${name}/${reader}`,async()=>{
    const result=await read(); assert.equal(result.theirPhone,expectedPhone); assert.equal(result.myPhoneShared,expectedShared);
  });
};

try {
  report.engine=(await q('select version() value'))[0].value;
  await db.exec(`
create schema auth; create schema private; create schema extensions; create schema storage;
${engine17?`create function extensions.digest(data bytea,algorithm text) returns bytea language sql immutable strict as $$select sha256(data) where algorithm='sha256'$$;
create function extensions.digest(data text,algorithm text) returns bytea language sql immutable strict as $$select sha256(convert_to(data,'UTF8')) where algorithm='sha256'$$;`:'create extension pgcrypto with schema extensions;'}
create role authenticated; create role anon; create role service_role;
create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
create function private.retention_ai_source_ready() returns boolean language sql stable as $$select coalesce(current_setting('r01.fixture_ready',true),'false')::boolean$$;
select set_config('r01.fixture_ready','true',false);
grant usage on schema auth,public to authenticated,anon,service_role;
create table public.app_accounts(id uuid primary key,phone text);
create table public.app_profiles(id uuid primary key,display_name text);
create table public.needs(id uuid primary key,title text,approximate_area text,approximate_city text,required_slots int,starts_at timestamptz);
create table public.agreements(id uuid primary key,current_version int,status text,need_id uuid,requester_account_id uuid,worker_account_id uuid,requester_profile_id uuid,worker_profile_id uuid,selected_response_id uuid,created_at timestamptz);
create table public.agreement_versions(agreement_id uuid,version int,terms jsonb);
create table public.agreement_execution(agreement_id uuid,agreement_version int,state text,mode text,requester_deadline_at timestamptz,problem_opened_at timestamptz,worker_marked_done_at timestamptz);
create table public.agreement_change_proposals(id uuid,agreement_id uuid,status text,created_at timestamptz,proposed_by_account_id uuid,base_version int,proposed_terms jsonb,reason text);
create table public.need_sensitive(need_id uuid,exact_address text);
create table public.access_grants(id uuid primary key default gen_random_uuid(),agreement_id uuid,channel text,granted_by_account_id uuid,granted_to_account_id uuid,status text,granted_at timestamptz,revoked_at timestamptz,expires_at timestamptz,unique(agreement_id,channel,granted_by_account_id,granted_to_account_id));
create table private.account_closure_requests(account_id uuid,state text);
create table private.account_blocks(blocker_account_id uuid,blocked_account_id uuid,active boolean,revision int,last_blocked_at timestamptz,updated_at timestamptz,primary key(blocker_account_id,blocked_account_id));
create table private.account_block_commands(actor_account_id uuid,client_request_id uuid,target_account_id uuid,input_hash text,receipt jsonb,primary key(actor_account_id,client_request_id));
create table private.marketplace_audit_log(actor_user_id uuid,event_type text,entity_type text,entity_id uuid,entity_version int,detail jsonb);
create table private.agreement_reviews(agreement_id uuid,reviewer_account_id uuid);
create table storage.objects(id uuid);
insert into public.app_accounts values('${A}','+3816000001'),('${B}','+3816000002'),('${C}','+3816000003');
insert into public.app_profiles values('${A}','Synthetic A'),('${B}','Synthetic B'),('${C}','Synthetic C');
insert into public.needs values('${AG}','Synthetic task','Synthetic area','Synthetic city',2,'2026-10-10T08:00Z');
insert into public.agreements values('${AG}',1,'CONFIRMED','${AG}','${A}','${B}','${A}','${B}',null,'2026-10-09T08:00Z');
insert into public.agreement_versions values('${AG}',1,'{"synthetic":true}');
insert into public.agreement_execution values('${AG}',1,'CONFIRMED','ACTIVE',null,null,null);
`);
  for(const name of ['0066-private.closure_account_restricted.sql','0245-private.safety_grant_valid.sql','0010-private.agreement_action_state.sql','0249-private.safety_pair_key.sql','0051-private.audit_marketplace.sql','0548-public.rpc_set_contact_grant.sql','0547-public.rpc_set_account_block.sql','0089-private.closure_redaction_relations_v5.sql']) await db.exec(sql(name));
  // Create inert catalog relations required by the real closure digest algorithm.
  // These fixtures are not represented as the complete canonical schema/certificate.
  const relationList=(await q('select private.closure_redaction_relations_v5() value'))[0].value;
  for (const relation of relationList) await db.exec(`create table if not exists ${relation}(id uuid)`);
  for (const relation of ['private.safety_reports','private.support_events_v5','private.support_decisions_v5','private.support_cases_v5','private.closure_executions_v5']) await db.exec(`create table if not exists ${relation}(id uuid)`);
  await db.exec(sql('0080-private.closure_erasure_program_digest_v5.sql'));
  await db.exec(file('baseline.sql'));
  for(const sig of ["public.rpc_get_agreement_workspace(uuid)","public.rpc_list_my_agreements()","public.rpc_list_my_agreements_page(text,integer,timestamptz,uuid)","public.rpc_set_contact_grant(uuid,text,boolean)","public.rpc_set_account_block(uuid,boolean,integer,uuid)"]){
    await db.exec(`revoke all on function ${sig} from public; grant execute on function ${sig} to authenticated`);
  }
  await db.exec('grant execute on function public.rpc_get_agreement_workspace(uuid),public.rpc_list_my_agreements() to service_role');
  for (const relation of relationList) await db.exec(`alter table ${relation} enable row level security`);
  await grant(A); await grant(B);
  const initial={}; await uid(A); for(const[name,read]of Object.entries(readers)) initial[name]=await read();
  await block(A,B,true,0);
  for(const who of [A,B]) {
    await uid(who);
    for(const[name,read]of Object.entries(readers)) {
      const result=await read();
      // These assertions are deliberately expected to fail against baseline.
      for(const[field,expected]of [['theirPhone',null],['myPhoneShared',false]]){
        let failed=false; try {assert.equal(result[field],expected);} catch {failed=true;}
        assert.ok(failed,`Baseline unexpectedly fixed ${name}/${field}`);
        report.baselineExpectedFailures.push({caller:who===A?'A':'B',reader:name,field,status:'FAIL_BEFORE_CONFIRMED'});
      }
    }
  }
  await admin('delete from private.account_blocks; delete from private.account_block_commands');
  const beforeDigest=(await q('select private.closure_erasure_program_digest_v5() value'))[0].value;
  report.fixtureDigestBefore=beforeDigest;
  fixtureDigest=beforeDigest;
  report.certificateGuardSubstitutions={expectedDigest:'synthetic fixture digest replaces live expected digest',retentionSourceReady:'fixture SQL function reads a synthetic ready setting because canonical certificate objects are not present; guard runs, but not counted as certificate readiness proof'};
  if(engine17) report.limitations.push('PG17 fixture maps extensions.digest SHA-256 to native PostgreSQL sha256 bytea/text wrappers because PGlite0.3.14 does not ship pgcrypto. Phone authorization logic is not stubbed. PG18 companion proof uses real pgcrypto.');
  await check('exact production expected-digest guard rejects synthetic catalog',async()=>{
    let error;try{await db.exec(file('supabase/candidates/r01_phone_read_consent_20261009.sql'))}catch(e){error=e};await db.exec('rollback');assert.match(error?.message||'',/R01_UNEXPECTED_CLOSURE_PROGRAM_DIGEST/);
  });
  await q("select set_config('r01.fixture_ready','false',false)");
  await check('unready certificate guard rejects before changing readers',async()=>{
    let error;try{await db.exec(fixtureCandidate('supabase/candidates/r01_phone_read_consent_20261009.sql'))}catch(e){error=e};await db.exec('rollback');assert.match(error?.message||'',/R01_CLOSURE_SOURCE_NOT_READY/);
  });
  await q("select set_config('r01.fixture_ready','true',false)");
  await db.exec(fixtureCandidate('supabase/candidates/r01_phone_read_consent_20261009.sql'));
  await check('actual transactional candidate runs and digest is unchanged',async()=>assert.equal((await q('select private.closure_erasure_program_digest_v5() value'))[0].value,beforeDigest));
  await uid(A); for(const[name,read]of Object.entries(readers)) await check(`unblocked valid consent exact JSON shape/${name}`,async()=>assert.deepEqual(await read(),initial[name]));
  await phones('valid grants A sees B','+3816000002',true,A); await phones('valid grants B sees A','+3816000001',true,B);
  await block(A,B,true,0);
  await phones('active A block hides both grants',null,false,A); await phones('active A block symmetric B read',null,false,B);
  await block(A,B,false,1);
  await phones('unblock does not restore old consent A',null,false,A); await phones('unblock does not restore old consent B',null,false,B);
  await grant(A); await grant(B);
  await phones('new post-unblock consent A','+3816000002',true,A); await phones('new post-unblock consent B','+3816000001',true,B);
  await grant(B,false);
  await phones('B revocation hides phone for A',null,true,A); await phones('B revocation myPhoneShared false','+3816000001',false,B);
  await grant(B);
  await admin(`update public.access_grants set expires_at='2000-01-01' where granted_by_account_id='${B}'`);
  await phones('expired B consent hides phone for A',null,true,A); await phones('expired B consent myPhoneShared false','+3816000001',false,B);
  await grant(B);
  await admin(`insert into private.account_closure_requests values('${B}','READY')`);
  await phones('closure restricted peer invalidates consent A',null,false,A); await phones('closure restricted peer invalidates consent B',null,false,B);
  await admin('delete from private.account_closure_requests');
  await block(B,A,true,0);
  await phones('reverse B block hides A read',null,false,A); await phones('reverse B block hides B read',null,false,B);
  await block(B,A,false,1); await grant(A); await grant(B);
  await admin(`update public.agreements set status='CANCELLED' where id='${AG}'`);
  await uid(A); for(const[name,read]of Object.entries(readers)) await check(`inactive Agreement does not reveal phone/${name}`,async()=>assert.equal((await read()).theirPhone,null));
  await admin(`update public.agreements set status='CONFIRMED' where id='${AG}'`);
  await uid(C);
  await check('foreign agreement ID workspace denied',async()=>{let error;try{await readers.workspace()}catch(e){error=e};assert.equal(error?.code,'P0002')});
  await check('foreign account legacy list empty',async()=>assert.deepEqual((await q('select public.rpc_list_my_agreements() value'))[0].value,[]));
  await check('foreign account paged list empty',async()=>assert.deepEqual((await q("select public.rpc_list_my_agreements_page('ALL',30,null,null) value"))[0].value.items,[]));
  await check('direct phone table read denied',async()=>{let error;try{await q('select phone from public.app_accounts')}catch(e){error=e};assert.equal(error?.code,'42501')});
  await uid(null); await check('missing auth denied',async()=>{let error;try{await readers.workspace()}catch(e){error=e};assert.equal(error?.code,'28000')});
  await uid(A); await check('invalid paging retains 22023',async()=>{let error;try{await q("select public.rpc_list_my_agreements_page('ALL',0,null,null)")}catch(e){error=e};assert.equal(error?.code,'22023')});
  await admin('set role anon'); await check('anon EXECUTE denied',async()=>{let error;try{await readers.workspace()}catch(e){error=e};assert.equal(error?.code,'42501')});
  await admin('reset role');
  await db.exec(fixtureCandidate('supabase/candidates/r01_phone_read_consent_20261009.revert.sql'));
  await check('exact revert executes and restores all stored body hashes',async()=>{
    for(const def of JSON.parse(file('patch-manifest.json')).definitions) assert.equal((await q('select md5(prosrc) value from pg_proc where oid=to_regprocedure($1)',[def.signature]))[0].value,def.before_body_md5);
  });
  await check('revert keeps fixture closure digest unchanged',async()=>assert.equal((await q('select private.closure_erasure_program_digest_v5() value'))[0].value,beforeDigest));
  await db.exec(fixtureCandidate('supabase/candidates/r01_phone_read_consent_20261009.sql'));
  await check('candidate is reapplicable after exact revert',async()=>assert.equal((await q('select private.closure_erasure_program_digest_v5() value'))[0].value,beforeDigest));
  report.result='PASS';
} catch(e) { report.result='FAIL'; report.error={message:e.message,code:e.code,stack:e.stack}; console.error(e.message,e.code); }
finally {
  report.passed=report.checks.filter(x=>x.status==='PASS').length;
  report.failed=report.checks.filter(x=>x.status==='FAIL').length;
  report.candidateSha256=createHash('sha256').update(file('supabase/candidates/r01_phone_read_consent_20261009.sql')).digest('hex');
  report.limitations.push('The fixture closure digest uses the exact canonical program-digest function on an isolated synthetic catalog. Equality proves this candidate does not change that algorithm\'s protected fixture surface; the live certificate value is independently checked at integration. It is not the complete canonical schema or live certificate reproduction.');
  report.limitations.push('PGlite is PostgreSQL compiled to WASM; no PostgREST, JWT signature verification, production concurrency/load, provider call or physical-device execution occurred.');
  writeFileSync(new URL(engine17?'proof-result-pg17.json':'proof-result.json',base),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({result:report.result,engine:report.engine,passed:report.passed,failed:report.failed,baselineExpectedFailures:report.baselineExpectedFailures.length,error:report.error?.message}));
  await db.close();
  if(report.result!=='PASS')process.exitCode=1;
}
