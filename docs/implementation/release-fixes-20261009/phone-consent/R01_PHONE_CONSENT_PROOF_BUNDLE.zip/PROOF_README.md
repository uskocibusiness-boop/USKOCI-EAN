# Isolated PostgreSQL consent regression proof

This folder is self-contained evidence tooling. It adds no application dependency.

The SQL fixtures are exact captured current server definitions, identified by hashes in `patch-manifest.json`. All names and phone values inserted by `proof.mjs` are synthetic. `baseline.sql` is the original three read RPC bodies. The candidate and revert are byte-identical to the reviewed integration artifacts.

Run from this directory:

```sh
npm install --prefix test-runtime --ignore-scripts --no-audit --no-fund @electric-sql/pglite@0.5.8
node proof.mjs
npm install --prefix test-runtime-pg17 --ignore-scripts --no-audit --no-fund @electric-sql/pglite@0.3.14
PHONE_PROOF_ENGINE=pg17 node proof.mjs
```

Expected: each engine reports `PASS`, `passed: 67`, `failed: 0`, `baselineExpectedFailures: 12`. This is 67 distinct checks on two PostgreSQL builds, not 134 independent product tests.

The fixture substitutes the exact expected live closure digest with its synthetic actual digest and uses a synthetic retention-ready function. Neither fixture substitution counts as live certificate correctness. The exact real closure program digest algorithm, function bodies, metadata-preservation checks and revert run inside PostgreSQL.

The PG17 build does not package pgcrypto; its SHA-256 wrappers use native PostgreSQL `sha256`. The PG18 companion runs real pgcrypto. Engine identities are recorded in JSON. The WASM engine, minimal fixture tables and synthetic Auth claim cannot prove PostgREST/JWT verification, full canonical schema/trigger/RLS integration, concurrency, device or production acceptance.

`test-runtime/` and `test-runtime-pg17/` are throwaway tooling and must not be committed or added to the mobile application's package manifests/lockfile.
